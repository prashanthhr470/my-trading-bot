"""
Killing the top of a process chain on Windows leaves its children running.
That is how two multi_symbol_market_data.py processes survived their cTrader
worker, each still holding a broker connection. These tests spawn real
processes to pin the snapshot-then-terminate fix.
"""

import subprocess
import sys
import time

import pytest

from app.core import process_tree

pytestmark = pytest.mark.skipif(sys.platform != "win32", reason="Windows process API")

SLEEPER = "import time; time.sleep(60)"

PARENT_WITH_CHILD = (
    "import subprocess, sys, time\n"
    "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])\n"
    "print(child.pid, flush=True)\n"
    "time.sleep(60)\n"
)


def _wait_until_gone(pid, seconds=5.0):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if pid not in process_tree.running_pids():
            return True
        time.sleep(0.1)
    return False


def test_killing_a_parent_orphans_its_child_until_the_snapshot_is_terminated():
    parent = subprocess.Popen([sys.executable, "-c", PARENT_WITH_CHILD], stdout=subprocess.PIPE, text=True)
    tree = []
    try:
        child_pid = int(parent.stdout.readline())
        time.sleep(1.5)  # let every launcher in the chain start its interpreter
        tree = process_tree.descendants(parent.pid)
        assert child_pid in {record.pid for record in tree}

        parent.kill()
        parent.wait(timeout=10)
        # The defect: the child outlives the process that was stopped.
        assert child_pid in process_tree.running_pids()

        stopped = process_tree.terminate_survivors(tree)

        assert child_pid in {record.pid for record in stopped}
        # Every process in the snapshot is gone, not just the one we printed.
        assert all(_wait_until_gone(record.pid) for record in tree)
    finally:
        parent.kill()
        process_tree.terminate_survivors(tree)


def test_a_record_whose_creation_time_does_not_match_is_never_terminated():
    sleeper = subprocess.Popen([sys.executable, "-c", SLEEPER])
    leftovers = []
    try:
        time.sleep(0.5)
        leftovers = process_tree.descendants(sleeper.pid)
        # Same PID, different creation time: what a reused PID looks like.
        impostor = process_tree.ProcessRecord(pid=sleeper.pid, parent_pid=0, exe="python.exe", created=1)

        assert process_tree.terminate_survivors([impostor]) == []
        assert sleeper.poll() is None
    finally:
        sleeper.kill()
        sleeper.wait()
        process_tree.terminate_survivors(leftovers)


def test_a_process_without_children_has_no_descendants():
    sleeper_code = "import time; time.sleep(5)"
    # The base interpreter itself, not a venv launcher, so it has no child of its own.
    base_python = getattr(sys, "_base_executable", sys.executable)
    sleeper = subprocess.Popen([base_python, "-c", sleeper_code])
    try:
        time.sleep(0.5)
        assert process_tree.descendants(sleeper.pid) == []
    finally:
        sleeper.kill()
        sleeper.wait()


def test_nothing_to_terminate_is_a_no_op():
    assert process_tree.terminate_survivors([]) == []
