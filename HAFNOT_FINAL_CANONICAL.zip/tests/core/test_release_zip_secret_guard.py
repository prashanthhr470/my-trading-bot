"""
The release ZIP must never carry a credential, whatever the file is called:
.env.example once held the real cTrader client secret while only .env was excluded.
"""

import json
from pathlib import Path

import hafnot_build_release_zip as builder


def _project(tmp_path):
    (tmp_path / ".env").write_text("CTRADER_CLIENT_ID=abc123def456ghi\nCTRADER_CLIENT_SECRET=s3cr3t-value-0987\nDRY_RUN=true\n",
                                   encoding="utf-8")
    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "ctrader_oauth_tokens.json").write_text(json.dumps({"accessToken": "tok-access-123456789"}),
                                                                 encoding="utf-8")
    return tmp_path


def test_credential_values_come_from_env_and_the_token_file(tmp_path):
    values = builder.known_secret_values(_project(tmp_path))

    assert set(values) == {"abc123def456ghi", "s3cr3t-value-0987", "tok-access-123456789"}  # not DRY_RUN


def test_a_file_containing_a_real_secret_is_caught_whatever_its_name(tmp_path):
    root = _project(tmp_path)
    (root / ".env.example").write_text("CTRADER_CLIENT_SECRET=s3cr3t-value-0987\n", encoding="utf-8")
    (root / "notes.md").write_text("token tok-access-123456789 pasted by mistake", encoding="utf-8")
    (root / "clean.py").write_text("CLIENT_SECRET = os.getenv('CTRADER_CLIENT_SECRET')", encoding="utf-8")
    relatives = [Path(".env.example"), Path("notes.md"), Path("clean.py")]

    leaks = builder.files_containing_secrets(root, relatives, builder.known_secret_values(root))

    assert sorted(p.as_posix() for p in leaks) == [".env.example", "notes.md"]


def test_placeholders_pass(tmp_path):
    root = _project(tmp_path)
    (root / ".env.example").write_text("CTRADER_CLIENT_SECRET=your_ctrader_client_secret\n", encoding="utf-8")

    assert builder.files_containing_secrets(root, [Path(".env.example")], builder.known_secret_values(root)) == []
