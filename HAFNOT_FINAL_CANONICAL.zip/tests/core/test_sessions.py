from datetime import datetime, timezone

from app.core.sessions import get_session_state


def test_london_new_york_overlap_detected():
    # 14:00 UTC in summer (BST/EDT both in effect) is squarely inside both
    # London (08:00-17:00 local) and New York (08:00-17:00 local) windows.
    reference = datetime(2026, 7, 15, 14, 0, tzinfo=timezone.utc)
    state = get_session_state(reference)

    assert state.london_open is True
    assert state.new_york_open is True
    assert state.london_new_york_overlap is True
    assert state.session_label == "LONDON_NEW_YORK_OVERLAP"


def test_off_hours_detected():
    # 21:30 UTC is after London/New York close and before Tokyo's next
    # 09:00 JST (00:00 UTC) open.
    reference = datetime(2026, 7, 15, 21, 30, tzinfo=timezone.utc)
    state = get_session_state(reference)

    assert state.london_open is False
    assert state.new_york_open is False
    assert state.tokyo_open is False
    assert state.session_label == "OFF_HOURS"


def test_tokyo_session_detected():
    # 02:00 UTC = 11:00 JST, inside Tokyo's 09:00-18:00 local window, and
    # well before London's 08:00 UTC (summer) open.
    reference = datetime(2026, 7, 15, 2, 0, tzinfo=timezone.utc)
    state = get_session_state(reference)

    assert state.tokyo_open is True
    assert state.london_open is False
    assert "TOKYO" in state.active_sessions


def test_dst_transition_does_not_crash_and_shifts_correctly():
    # Winter (GMT/EST, UTC+0 / UTC-5) vs summer (BST/EDT, UTC+1 / UTC-4):
    # the same UTC wall-clock hour can fall on different sides of a local
    # session boundary across the DST transition. This only proves the
    # zoneinfo-based lookup runs correctly across both regimes, not a
    # specific expected direction of shift.
    winter = get_session_state(datetime(2026, 1, 15, 8, 0, tzinfo=timezone.utc))
    summer = get_session_state(datetime(2026, 7, 15, 8, 0, tzinfo=timezone.utc))

    assert isinstance(winter.london_open, bool)
    assert isinstance(summer.london_open, bool)


def test_defaults_to_now_without_error():
    state = get_session_state()
    assert state.utc_timestamp is not None
