import json

import app.core.research_archive as archive


def _last_record(directory, symbol):
    path = next((directory / symbol.lower()).glob("*.jsonl"))
    return json.loads(path.read_text(encoding="utf-8").splitlines()[-1])


def test_closed_market_snapshot_is_marked_closed(tmp_path, monkeypatch):
    # Found in the live archive: weekend snapshots were labelled "TOKYO" with no open/closed flag.
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)

    assert archive.record_snapshot(symbol="XAUUSD", bid=4348.33, ask=4348.5, market_open=False, force=True)

    assert _last_record(tmp_path, "XAUUSD")["market_open"] is False


def test_open_market_snapshot_is_marked_open(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)

    archive.record_snapshot(symbol="EURUSD", bid=1.1, ask=1.10002, market_open=True, force=True)

    assert _last_record(tmp_path, "EURUSD")["market_open"] is True


def test_unknown_market_state_is_recorded_as_unknown_not_open(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)

    archive.record_snapshot(symbol="GBPJPY", bid=200.0, ask=200.02, force=True)

    assert _last_record(tmp_path, "GBPJPY")["market_open"] is None
