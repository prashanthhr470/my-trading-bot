"""
Tests for app.core.market_hours.

Fixtures use the REAL Pepperstone intervals fetched from the DEMO account
(data/broker/symbol_specs.json) copied in here, so the tests are
deterministic and do not depend on that file. Every instant below was
checked against observed live behaviour: feeds fresh on Friday afternoon,
flat on Saturday, and gold quiet during its daily break while FX traded.
"""

import json
from datetime import datetime, timezone

import pytest

from app.core import market_hours as mh

EURUSD_SPEC = {
    "schedule_time_zone": "America/New_York",
    "schedule": [
        {"start_second": 61260, "end_second": 147540},
        {"start_second": 147660, "end_second": 233940},
        {"start_second": 234060, "end_second": 320340},
        {"start_second": 320460, "end_second": 406740},
        {"start_second": 406860, "end_second": 492900},
    ],
    "holidays": [],
}

XAUUSD_SPEC = {
    "schedule_time_zone": "America/New_York",
    "schedule": [
        {"start_second": 64860, "end_second": 147540},
        {"start_second": 151260, "end_second": 233940},
        {"start_second": 237660, "end_second": 320340},
        {"start_second": 324060, "end_second": 406740},
        {"start_second": 410460, "end_second": 492900},
    ],
    # The real holiday returned by the broker: 2026-09-07, 21:30-23:59:59 Moscow.
    "holidays": [
        {
            "holidayId": "4164",
            "name": "07.09.2026 EC 21:30",
            "scheduleTimeZone": "Europe/Moscow",
            "holidayDate": "20703",
            "isRecurring": False,
            "startSecond": 77400,
            "endSecond": 86399,
        }
    ],
}


def _utc(*args):
    return datetime(*args, tzinfo=timezone.utc)


@pytest.fixture
def schedules():
    return {
        "EURUSD": mh.parse_schedule("EURUSD", EURUSD_SPEC),
        "XAUUSD": mh.parse_schedule("XAUUSD", XAUUSD_SPEC),
    }


# --- open / closed against observed reality ---

def test_friday_afternoon_both_open(schedules):
    instant = _utc(2026, 9, 11, 19, 12)  # feeds were fresh
    assert mh.is_market_open("EURUSD", instant, schedules) is True
    assert mh.is_market_open("XAUUSD", instant, schedules) is True


def test_saturday_both_closed(schedules):
    instant = _utc(2026, 9, 12, 3, 8)  # feeds were flat, restart loop observed
    assert mh.is_market_open("EURUSD", instant, schedules) is False
    assert mh.is_market_open("XAUUSD", instant, schedules) is False


def test_gold_daily_break_closed_while_fx_open(schedules):
    instant = _utc(2026, 9, 8, 21, 30)  # Tuesday 17:30 EDT
    assert mh.is_market_open("XAUUSD", instant, schedules) is False
    assert mh.is_market_open("EURUSD", instant, schedules) is True


def test_sunday_open_is_staggered(schedules):
    at_1730_edt = _utc(2026, 9, 13, 21, 30)
    assert mh.is_market_open("EURUSD", at_1730_edt, schedules) is True   # opens 17:01
    assert mh.is_market_open("XAUUSD", at_1730_edt, schedules) is False  # opens 18:01

    at_1830_edt = _utc(2026, 9, 13, 22, 30)
    assert mh.is_market_open("XAUUSD", at_1830_edt, schedules) is True


def test_daylight_saving_is_handled_by_zoneinfo(schedules):
    # January is EST (UTC-5), not EDT - the same local 17:30 is 22:30Z.
    gold_break_winter = _utc(2026, 1, 6, 22, 30)
    assert mh.is_market_open("XAUUSD", gold_break_winter, schedules) is False
    assert mh.is_market_open("EURUSD", gold_break_winter, schedules) is True

    before_break_winter = _utc(2026, 1, 6, 21, 30)  # 16:30 EST
    assert mh.is_market_open("XAUUSD", before_break_winter, schedules) is True


def test_friday_close(schedules):
    assert mh.is_market_open("EURUSD", _utc(2026, 9, 11, 20, 50), schedules) is True   # 16:50 EDT
    assert mh.is_market_open("EURUSD", _utc(2026, 9, 11, 21, 0), schedules) is False   # 17:00 EDT


# --- holidays ---

def test_real_broker_holiday_closes_an_otherwise_open_session(schedules):
    # 2026-09-07 19:00Z = 22:00 Moscow (inside 21:30-23:59) = 15:00 EDT Monday,
    # which the weekly schedule alone says is open.
    assert mh.is_market_open("XAUUSD", _utc(2026, 9, 7, 19, 0), schedules) is False
    # 17:00Z = 20:00 Moscow, before the holiday window.
    assert mh.is_market_open("XAUUSD", _utc(2026, 9, 7, 17, 0), schedules) is True


def test_holiday_on_a_different_date_does_not_apply(schedules):
    # Same local time one week later is not a holiday.
    assert mh.is_market_open("XAUUSD", _utc(2026, 9, 14, 19, 0), schedules) is True


def test_recurring_holiday_matches_month_and_day_in_later_years():
    spec = dict(EURUSD_SPEC)
    spec["holidays"] = [{
        "name": "Christmas",
        "scheduleTimeZone": "America/New_York",
        "holidayDate": str((datetime(2020, 12, 25).date() - mh.UNIX_EPOCH_DATE).days),
        "isRecurring": True,
        "endSecond": 86399,
        # startSecond omitted, as MessageToDict does for a proto3 default of 0
    }]
    schedules = {"EURUSD": mh.parse_schedule("EURUSD", spec)}

    # Friday 2026-12-25 10:00 EST - open by weekly schedule, closed by holiday.
    assert mh.is_market_open("EURUSD", _utc(2026, 12, 25, 15, 0), schedules) is False
    assert mh.is_market_open("EURUSD", _utc(2026, 12, 24, 15, 0), schedules) is True


def test_omitted_proto_defaults_are_parsed_as_defaults():
    spec = dict(EURUSD_SPEC)
    spec["holidays"] = [{"name": "full day", "holidayDate": "20703"}]
    schedule = mh.parse_schedule("EURUSD", spec)

    holiday = schedule.holidays[0]
    assert holiday.start_second == 0
    assert holiday.end_second == mh.SECONDS_PER_DAY - 1
    assert holiday.is_recurring is False
    assert holiday.time_zone == "America/New_York"  # falls back to the symbol's zone


# --- unknowns fail toward detecting real outages ---

def test_unknown_symbol_returns_none_not_closed(schedules):
    assert mh.is_market_open("GBPJPY", _utc(2026, 9, 12, 3, 8), schedules) is None


def test_bad_time_zone_yields_no_schedule():
    spec = dict(EURUSD_SPEC)
    spec["schedule_time_zone"] = "Not/AZone"
    assert mh.parse_schedule("EURUSD", spec) is None


def test_missing_schedule_yields_no_schedule():
    assert mh.parse_schedule("EURUSD", {"schedule_time_zone": "America/New_York", "schedule": []}) is None


def test_naive_datetime_is_treated_as_utc(schedules):
    naive_saturday = datetime(2026, 9, 12, 3, 8)
    assert mh.is_market_open("EURUSD", naive_saturday, schedules) is False


def test_interval_running_past_end_of_week_wraps():
    schedules = {"TEST": mh.SymbolSchedule(
        symbol="TEST", time_zone="UTC", intervals=((600_000, 610_000),),
    )}
    assert mh.is_market_open("TEST", _utc(2026, 9, 12, 23, 30), schedules) is True   # Sat 23:30
    assert mh.is_market_open("TEST", _utc(2026, 9, 13, 0, 30), schedules) is True    # Sun 00:30, wrapped
    assert mh.is_market_open("TEST", _utc(2026, 9, 13, 3, 0), schedules) is False    # past end


# --- stale-feed assessment (what the supervisor uses) ---

def test_weekend_stale_feeds_do_not_require_recovery(schedules):
    result = mh.assess_stale_feeds(["XAUUSD", "EURUSD"], _utc(2026, 9, 12, 3, 8), schedules)
    assert result.expected_closed == ("XAUUSD", "EURUSD")
    assert result.unexpected == ()
    assert result.requires_recovery is False


def test_stale_feed_while_market_open_requires_recovery(schedules):
    result = mh.assess_stale_feeds(["EURUSD"], _utc(2026, 9, 11, 19, 12), schedules)
    assert result.unexpected == ("EURUSD",)
    assert result.requires_recovery is True


def test_gold_break_alone_does_not_require_recovery_but_fx_outage_does(schedules):
    during_break = _utc(2026, 9, 8, 21, 30)

    only_gold = mh.assess_stale_feeds(["XAUUSD"], during_break, schedules)
    assert only_gold.requires_recovery is False

    gold_and_fx = mh.assess_stale_feeds(["XAUUSD", "EURUSD"], during_break, schedules)
    assert gold_and_fx.expected_closed == ("XAUUSD",)
    assert gold_and_fx.unexpected == ("EURUSD",)
    assert gold_and_fx.requires_recovery is True


def test_stale_symbol_without_a_schedule_still_requires_recovery(schedules):
    # Missing schedule must never silently suppress outage recovery.
    result = mh.assess_stale_feeds(["GBPJPY"], _utc(2026, 9, 12, 3, 8), schedules)
    assert result.unexpected == ("GBPJPY",)
    assert result.requires_recovery is True


def test_open_symbols_excludes_only_positively_closed(schedules):
    during_break = _utc(2026, 9, 8, 21, 30)
    assert mh.open_symbols(["XAUUSD", "EURUSD", "GBPJPY"], during_break, schedules) == ["EURUSD", "GBPJPY"]


# --- loading from disk ---

def test_load_schedules_missing_file_returns_empty(tmp_path):
    assert mh.load_schedules(tmp_path / "does_not_exist.json") == {}


def test_load_schedules_round_trip_from_fetcher_format(tmp_path):
    path = tmp_path / "symbol_specs.json"
    path.write_text(json.dumps({
        "fetched_at": "2026-09-12T03:00:00+00:00",
        "symbols": {"EURUSD": EURUSD_SPEC, "XAUUSD": XAUUSD_SPEC, "BROKEN": {"schedule": []}},
    }), encoding="utf-8")

    loaded = mh.load_schedules(path)

    assert set(loaded) == {"EURUSD", "XAUUSD"}
    assert len(loaded["XAUUSD"].holidays) == 1
    assert mh.is_market_open("EURUSD", _utc(2026, 9, 12, 3, 8), loaded) is False


def test_corrupt_specs_file_returns_empty(tmp_path):
    path = tmp_path / "symbol_specs.json"
    path.write_text("{not json", encoding="utf-8")
    assert mh.load_schedules(path) == {}
