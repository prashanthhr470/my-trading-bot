import json

import app.core.research_archive as archive


def test_record_snapshot_writes_one_line(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)
    archive._last_write_at.clear()

    written = archive.record_snapshot(
        symbol="EURUSD", bid=1.1000, ask=1.1002,
        orderflow_evidence={"depth_imbalance": 0.2},
        core_strategy_result=None,
        session_label="LONDON",
        force=True,
    )
    assert written is True

    files = list(tmp_path.rglob("*.jsonl"))
    assert len(files) == 1

    lines = files[0].read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1

    record = json.loads(lines[0])
    assert record["symbol"] == "EURUSD"
    assert record["spread"] == 1.1002 - 1.1000
    assert record["orderflow"]["depth_imbalance"] == 0.2


def test_rate_limiting_skips_rapid_repeated_calls(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)
    monkeypatch.setattr(archive, "SAMPLE_INTERVAL_SECONDS", 300)
    archive._last_write_at.clear()

    first = archive.record_snapshot(symbol="GBPUSD", bid=1.35, ask=1.351)
    second = archive.record_snapshot(symbol="GBPUSD", bid=1.35, ask=1.351)

    assert first is True
    assert second is False  # rate-limited, no time has passed


def test_force_bypasses_rate_limit(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)
    archive._last_write_at.clear()

    first = archive.record_snapshot(symbol="USDJPY", bid=154.0, ask=154.02, force=True)
    second = archive.record_snapshot(symbol="USDJPY", bid=154.0, ask=154.02, force=True)

    assert first is True
    assert second is True


def test_enforce_retention_deletes_oldest_files_first(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)

    symbol_dir = tmp_path / "xauusd"
    symbol_dir.mkdir()

    old_file = symbol_dir / "2026-01-01.jsonl"
    old_file.write_text("x" * 1000, encoding="utf-8")

    new_file = symbol_dir / "2026-01-02.jsonl"
    new_file.write_text("y" * 1000, encoding="utf-8")

    import os
    import time as time_module
    old_time = time_module.time() - 100000
    os.utime(old_file, (old_time, old_time))

    freed = archive.enforce_retention(max_bytes=1000)

    assert freed > 0
    assert not old_file.exists()
    assert new_file.exists()


def test_enforce_retention_does_nothing_when_under_cap(tmp_path, monkeypatch):
    monkeypatch.setattr(archive, "ARCHIVE_DIR", tmp_path)

    symbol_dir = tmp_path / "eurusd"
    symbol_dir.mkdir()
    f = symbol_dir / "2026-01-01.jsonl"
    f.write_text("small", encoding="utf-8")

    freed = archive.enforce_retention(max_bytes=10_000_000)
    assert freed == 0
    assert f.exists()


def test_never_raises_on_write_failure(tmp_path, monkeypatch):
    # Point ARCHIVE_DIR at a path that cannot be created (a file, not a
    # directory, blocking directory creation) to force an OSError.
    blocker = tmp_path / "blocked"
    blocker.write_text("i am a file, not a directory", encoding="utf-8")
    monkeypatch.setattr(archive, "ARCHIVE_DIR", blocker)
    archive._last_write_at.clear()

    result = archive.record_snapshot(symbol="XAUUSD", bid=1.0, ask=1.1, force=True)
    assert result is False  # failed cleanly, did not raise
