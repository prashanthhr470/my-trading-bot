"""
Raw quote logs are capped per file on every storage pass, keeping the newest
complete records, instead of growing until data/ nears the 4.5 GB soft limit.
"""

import json

import hafnot_storage_guard as guard


def _write_events(path, count):
    lines = [json.dumps({"type": "spot", "n": i, "bid": 1.1, "ask": 1.1001}) for i in range(count)]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return lines


def test_an_oversized_event_file_keeps_only_its_newest_complete_records(tmp_path, monkeypatch):
    data = tmp_path / "data"
    (data / "openapi").mkdir(parents=True)
    events = data / "openapi" / "eurusd_market_events.jsonl"
    lines = _write_events(events, 2000)
    small = data / "openapi" / "gbpusd_market_events.jsonl"
    _write_events(small, 10)
    monkeypatch.setattr(guard, "DATA", data)
    monkeypatch.setattr(guard, "RAW_TRIM_TRIGGER_BYTES", 20_000)
    monkeypatch.setattr(guard, "RAW_KEEP_BYTES", 5_000)

    guard.enforce_storage()

    kept = events.read_text(encoding="utf-8").splitlines()
    assert events.stat().st_size <= 5_000
    assert kept[-1] == lines[-1]
    assert all(json.loads(line)["type"] == "spot" for line in kept)  # no cut records
    assert len(small.read_text(encoding="utf-8").splitlines()) == 10  # under the cap: untouched
