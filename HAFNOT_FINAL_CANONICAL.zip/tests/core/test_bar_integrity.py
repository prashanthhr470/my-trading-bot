import json

import pytest

from app.core.data_quality import clean_bars, load_bar_file


def _bar(timestamp, price=1.10, volume=100):
    return {
        "timestamp": timestamp,
        "open": price,
        "high": price + 0.001,
        "low": price - 0.001,
        "close": price,
        "volume": volume,
    }


T16 = "2021-10-12T16:00:00+00:00"
T17 = "2021-10-12T17:00:00+00:00"
T18 = "2021-10-12T18:00:00+00:00"


def test_identical_chunk_boundary_duplicate_is_collapsed():
    # The exact defect found in data/historical/bars: one boundary bar returned twice.
    result = clean_bars([_bar(T16), _bar(T17), _bar(T17), _bar(T18)], timeframe="H1")

    assert len(result.bars) == 3
    assert result.duplicates_removed == 1
    assert result.conflicting_timestamps == ()
    assert result.timestamp_report.duplicate_count == 0
    assert result.changed is True


def test_output_is_chronological_even_when_input_is_not():
    result = clean_bars([_bar(T18), _bar(T16), _bar(T17)], timeframe="H1")
    assert [bar["timestamp"] for bar in result.bars] == [T16, T17, T18]


def test_conflicting_duplicates_are_reported_and_keep_the_last():
    result = clean_bars([_bar(T17, price=1.10), _bar(T17, price=1.20)], timeframe="H1")

    assert len(result.bars) == 1
    assert result.bars[0]["close"] == 1.20
    assert result.conflicting_timestamps == (T17,)


def test_strict_mode_refuses_conflicting_duplicates():
    with pytest.raises(ValueError):
        clean_bars([_bar(T17, price=1.10), _bar(T17, price=1.20)], strict=True)


def test_strict_mode_accepts_identical_duplicates():
    result = clean_bars([_bar(T17), _bar(T17)], strict=True)
    assert len(result.bars) == 1


def test_same_instant_in_different_string_forms_is_one_bar():
    result = clean_bars([_bar("2021-10-12T17:00:00+00:00"), _bar("2021-10-12T17:00:00Z")])

    assert len(result.bars) == 1
    assert result.duplicates_removed == 1
    assert result.conflicting_timestamps == ()


def test_invalid_bars_are_dropped_and_counted():
    high_below_low = {"timestamp": T17, "open": 1.1, "high": 1.0, "low": 1.05, "close": 1.1}
    missing_timestamp = {"open": 1.1, "high": 1.2, "low": 1.0, "close": 1.1}

    result = clean_bars([_bar(T16), high_below_low, missing_timestamp])

    assert result.invalid_removed == 2
    assert len(result.bars) == 1


def test_clean_series_is_reported_unchanged():
    result = clean_bars([_bar(T16), _bar(T17)], timeframe="H1")
    assert result.changed is False
    assert result.duplicates_removed == 0


def test_historical_data_is_not_flagged_stale_for_being_old():
    result = clean_bars([_bar(T16), _bar(T17)], timeframe="H1")
    assert not any("stale" in issue.lower() for issue in result.timestamp_report.issues)


def test_load_bar_file_uses_period_and_cleans(tmp_path):
    path = tmp_path / "eurusd_h1.json"
    path.write_text(
        json.dumps({"symbol": "EURUSD", "period": "H1", "bars": [_bar(T16), _bar(T17), _bar(T17)]}),
        encoding="utf-8",
    )

    result = load_bar_file(path)

    assert result.duplicates_removed == 1
    assert len(result.bars) == 2
    assert result.timestamp_report.timeframe == "H1"


def test_empty_series_is_safe():
    result = clean_bars([])
    assert result.bars == []
    assert result.raw_count == 0
    assert result.changed is False
