"""
The paper engine reads each symbol's latest quote every 30 seconds. It must read
only the end of the (very large) event file and still return the newest valid spot.
"""

import json

import app.paper.market_snapshot as ms


def _spot(i, bid=1.1, ask=1.1001):
    return json.dumps({"type": "spot", "timestamp": f"2026-09-14T06:{i // 60 % 60:02d}:{i % 60:02d}+00:00",
                       "symbol": "EURUSD", "bid": bid, "ask": ask})


def test_the_newest_valid_spot_is_returned_from_the_tail(tmp_path, monkeypatch):
    path = tmp_path / "eurusd_market_events.jsonl"
    lines = [_spot(i, bid=1.1 + i / 1e6, ask=1.1001 + i / 1e6) for i in range(20_000)]
    path.write_text("\n".join(lines) + "\n" + '{"type": "spot", "bid": 1.2', encoding="utf-8")  # cut final line
    monkeypatch.setattr(ms, "EVENT_FILE", path)

    event = ms.latest_market_event()

    assert event == json.loads(lines[-1])


def test_the_tail_widens_past_non_spot_records(tmp_path, monkeypatch):
    path = tmp_path / "eurusd_market_events.jsonl"
    noise = [json.dumps({"type": "depth", "padding": "x" * 100}) for _ in range(50)]
    path.write_text("\n".join([_spot(1)] + noise) + "\n", encoding="utf-8")
    monkeypatch.setattr(ms, "EVENT_FILE", path)
    monkeypatch.setattr(ms, "TAIL_BYTES", 256)

    assert ms.latest_market_event() == json.loads(_spot(1))


def test_invalid_quotes_are_skipped_and_an_empty_file_returns_none(tmp_path, monkeypatch):
    path = tmp_path / "eurusd_market_events.jsonl"
    path.write_text("\n".join([_spot(1), _spot(2, bid=1.2, ask=1.1)]) + "\n", encoding="utf-8")
    monkeypatch.setattr(ms, "EVENT_FILE", path)
    assert ms.latest_market_event() == json.loads(_spot(1))

    path.write_text("", encoding="utf-8")
    assert ms.latest_market_event() is None
