"""
app.paper.multi_symbol_paper used to give each symbol its own $10,000
account and to open positions without costs or reasons. These tests pin the
shared portfolio account and process_trade's costed, journaled admission.
"""

import json
import threading

import pytest

import app.paper.multi_symbol_paper as engine
from app.forex_v2.risk import AccountState, FxQuote, RiskConfig, TradeRequest, evaluate_paper_trade
from dataclasses import asdict


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    journal = tmp_path / "journal.jsonl"
    monkeypatch.setattr(engine, "JOURNAL_FILE", journal)
    monkeypatch.setattr(engine, "PORTFOLIO_ACCOUNT_FILE", tmp_path / "portfolio_account.json")
    monkeypatch.setattr(engine, "_PORTFOLIO_ACCOUNT", None)
    return journal


def _journal(path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def _candidate(symbol="EURUSD", bid=1.1000, ask=1.1002, stop=1.0992, target=1.1022, with_costed=True):
    decision = evaluate_paper_trade(
        request=TradeRequest(symbol=symbol, side="BUY", stop_loss=stop, take_profit=target),
        quote=FxQuote(symbol=symbol, bid=bid, ask=ask),
        account=AccountState(equity_usd=10_000.0, day_start_equity_usd=10_000.0),
        config=RiskConfig(max_spread_pips=3.0),
    )
    plan = {"entry": decision.position.entry_fill_price, "stop_loss": stop, "take_profit": target}
    if with_costed:
        plan["costed_position"] = asdict(decision.position)
    return {
        "final_decision": "BUY_CANDIDATE", "execution_allowed": False,
        "trade_authorized": False, "broker_order": False, "paper_trade_plan": plan,
    }


def test_an_open_position_on_one_symbol_blocks_a_candidate_on_another(isolated, monkeypatch):
    # End to end through the engine's account state, the risk model and the safety gate.
    import asyncio

    adapter = engine.canonical_signal_adapter
    monkeypatch.setattr(adapter, "REQUIRE_VALIDATED_BASELINE", False)
    candidate = {"direction": "BUY", "entry": 2000.02, "stop_loss": 1995.0, "take_profit": 2015.0}

    class _Spec:
        def build_signal_provider(self):
            return lambda bars, i: candidate

    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _Spec())
    bars = [{"timestamp": "2026-01-01T00:00:00+00:00", "open": 2000.0, "high": 2000.5, "low": 1999.5, "close": 2000.0}] * 10
    account = engine.portfolio_account()

    def _gold():
        return asyncio.run(adapter.run(
            "XAUUSD", account_state=engine.build_account_state("XAUUSD", account),
            bid=2000.0, ask=2000.02, load_bars=lambda symbol, period: (bars, None),
        ))

    assert _gold()["final_decision"] == "BUY_CANDIDATE"  # control: nothing open yet

    engine.process_trade("EURUSD", _candidate(), account)
    blocked = _gold()

    assert blocked["final_decision"] == "WAIT"
    assert "safety gate" in blocked["gate"]["reason"]


def test_every_symbol_and_thread_shares_one_portfolio_account(isolated):
    seen = []
    start = threading.Barrier(8)

    def _worker():
        start.wait()
        seen.append(engine.portfolio_account())

    threads = [threading.Thread(target=_worker) for _ in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert len({id(account) for account in seen}) == 1
    account = seen[0]
    assert account.max_positions == engine.canonical_signal_adapter.MAX_OPEN_POSITIONS == 1
    assert account.risk_percent == RiskConfig().risk_per_trade_pct == 0.5
    assert account.portfolio_limits == RiskConfig()


def test_a_costed_candidate_opens_a_paper_position(isolated):
    account = engine.portfolio_account()

    trade = engine.process_trade("EURUSD", _candidate(), account)

    assert trade is not None and trade["event"] == "OPENED"
    assert trade["trade"]["costed"] is not None
    assert len(account.positions) == 1


def test_an_uncosted_candidate_is_refused_and_journaled(isolated):
    account = engine.portfolio_account()

    trade = engine.process_trade("EURUSD", _candidate(with_costed=False), account)

    assert trade is None
    assert account.positions == {}
    [record] = _journal(isolated)
    assert (record["event"], record["reason"]) == ("PAPER_OPEN_REJECTED", "MISSING_COSTED_POSITION")


def test_a_second_symbol_is_refused_while_a_position_is_open_with_the_reason_journaled(isolated):
    account = engine.portfolio_account()
    engine.process_trade("EURUSD", _candidate(), account)

    trade = engine.process_trade(
        "GBPUSD", _candidate(symbol="GBPUSD", bid=1.2500, ask=1.2502, stop=1.2490, target=1.2524), account,
    )

    assert trade is None
    rejected = [r for r in _journal(isolated) if r["event"] == "PAPER_OPEN_REJECTED"]
    assert rejected[-1]["symbol"] == "GBPUSD"
    assert rejected[-1]["reason"] == "MAX_POSITIONS_REACHED"
