"""
The paper engine now keeps ONE portfolio account for every symbol, opens
only costed positions, and re-checks portfolio caps under the account lock.
These tests pin that, and that a costed close is priced by the same model
as the backtests rather than by an uncosted R multiple.
"""

import threading
from dataclasses import asdict

import pytest

from app.forex_v2.risk import AccountState, FxQuote, RiskConfig, TradeRequest, close_paper_position, evaluate_paper_trade
from app.paper.paper_account import PaperAccount

EURUSD = dict(symbol="EURUSD", bid=1.1000, ask=1.1002, stop=1.0992, target=1.1022)
GBPUSD = dict(symbol="GBPUSD", bid=1.2500, ask=1.2502, stop=1.2490, target=1.2524)
AUDUSD = dict(symbol="AUDUSD", bid=0.6600, ask=0.6602, stop=0.6592, target=0.6622)


def _costed(market, side="BUY"):
    decision = evaluate_paper_trade(
        request=TradeRequest(symbol=market["symbol"], side=side, stop_loss=market["stop"], take_profit=market["target"]),
        quote=FxQuote(symbol=market["symbol"], bid=market["bid"], ask=market["ask"]),
        account=AccountState(equity_usd=10_000.0, day_start_equity_usd=10_000.0),
        config=RiskConfig(max_spread_pips=3.0),
    )
    assert decision.accepted, decision.reason
    return decision.position


def _account(tmp_path, max_positions=3):
    return PaperAccount(
        starting_equity=10_000.0, risk_percent=0.5, max_positions=max_positions,
        state_path=tmp_path / "portfolio_account.json", portfolio_limits=RiskConfig(),
    )


def _open(account, market, trade_id):
    costed = _costed(market)
    position, reason = account.try_open_position(
        trade_id=trade_id, symbol=market["symbol"], direction="BUY", entry=costed.entry_fill_price,
        stop_loss=market["stop"], take_profit=market["target"], costed_position=costed,
    )
    return costed, position, reason


def test_take_profit_is_priced_by_the_backtest_cost_model(tmp_path):
    account = _account(tmp_path)
    costed, position, reason = _open(account, EURUSD, "T1")
    assert reason is None
    assert position.risk_amount == pytest.approx(costed.risk_amount_usd)

    closed = account.update_price("EURUSD", bid=1.1022, ask=1.1024)

    expected = close_paper_position(position=costed, exit_price=1.1022, config=RiskConfig())
    uncosted = (1.1022 - costed.entry_fill_price) / (costed.entry_fill_price - 1.0992) * costed.risk_amount_usd
    assert closed[0]["exit_reason"] == "TAKE_PROFIT"
    assert closed[0]["pnl"] == pytest.approx(expected.net_pnl_usd)
    assert closed[0]["pnl"] < uncosted
    assert closed[0]["exit_fill_price"] == pytest.approx(expected.exit_fill_price)
    assert account.equity == pytest.approx(10_000.0 + expected.net_pnl_usd)


def test_stop_loss_loses_the_costed_risk_amount(tmp_path):
    account = _account(tmp_path)
    costed, _, _ = _open(account, EURUSD, "T1")

    closed = account.update_price("EURUSD", bid=1.0992, ask=1.0994)

    assert closed[0]["exit_reason"] == "STOP_LOSS"
    assert closed[0]["pnl"] == pytest.approx(-costed.risk_amount_usd, rel=1e-6)
    assert closed[0]["result_r"] == pytest.approx(-1.0, rel=1e-6)


def test_the_position_limit_is_reported_not_silent(tmp_path):
    account = _account(tmp_path, max_positions=1)
    _open(account, EURUSD, "T1")

    _, position, reason = _open(account, GBPUSD, "T2")

    assert position is None
    assert reason == "MAX_POSITIONS_REACHED"


def test_currency_exposure_cap_applies_at_open_time(tmp_path):
    account = _account(tmp_path, max_positions=3)
    assert _open(account, EURUSD, "T1")[2] is None
    assert _open(account, GBPUSD, "T2")[2] is None

    _, position, reason = _open(account, AUDUSD, "T3")

    assert position is None
    assert reason == "CURRENCY_EXPOSURE_CAP"


def test_concurrent_opens_cannot_exceed_the_limit(tmp_path):
    account = _account(tmp_path, max_positions=1)
    markets = [EURUSD, GBPUSD, AUDUSD] * 4
    costed = [_costed(market) for market in markets]
    start = threading.Barrier(len(markets))
    outcomes = []

    def _worker(i):
        start.wait()
        outcomes.append(account.try_open_position(
            trade_id=f"T{i}", symbol=markets[i]["symbol"], direction="BUY", entry=costed[i].entry_fill_price,
            stop_loss=markets[i]["stop"], take_profit=markets[i]["target"], costed_position=costed[i],
        ))

    threads = [threading.Thread(target=_worker, args=(i,)) for i in range(len(markets))]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert sum(1 for position, _ in outcomes if position is not None) == 1
    assert len(account.positions) == 1


def test_a_costed_position_for_another_symbol_is_refused(tmp_path):
    account = _account(tmp_path)
    costed = _costed(EURUSD)

    position, reason = account.try_open_position(
        trade_id="T1", symbol="GBPUSD", direction="BUY", entry=1.2502,
        stop_loss=1.2490, take_profit=1.2522, costed_position=costed,
    )

    assert position is None
    assert reason == "COSTED_POSITION_MISMATCH"


def test_the_costed_position_survives_a_restart(tmp_path):
    account = _account(tmp_path)
    costed, _, _ = _open(account, EURUSD, "T1")

    reloaded = _account(tmp_path)

    assert reloaded.positions["T1"].costed == asdict(costed)
    closed = reloaded.update_price("EURUSD", bid=1.0992, ask=1.0994)
    assert closed[0]["pnl"] == pytest.approx(-costed.risk_amount_usd, rel=1e-6)


def test_open_exposures_feed_the_risk_model(tmp_path):
    account = _account(tmp_path)
    costed, _, _ = _open(account, EURUSD, "T1")

    [exposure] = account.open_exposures()

    assert (exposure.symbol, exposure.side) == ("EURUSD", "BUY")
    assert exposure.risk_amount_usd == pytest.approx(costed.risk_amount_usd)
    assert account.open_costed_positions() == [costed]


def test_an_uncosted_open_position_cannot_be_reported_to_the_risk_model(tmp_path):
    # Its true risk is unknown; reporting a guess would loosen every portfolio cap.
    account = _account(tmp_path)
    account.open_position(trade_id="LEGACY", symbol="EURUSD", direction="BUY", entry=1.1, stop_loss=1.099, take_profit=1.102)

    with pytest.raises(ValueError, match="LEGACY"):
        account.open_costed_positions()
