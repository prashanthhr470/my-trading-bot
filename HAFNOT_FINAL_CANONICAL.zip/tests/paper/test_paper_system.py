﻿from __future__ import annotations

import tempfile
from pathlib import Path

from app.paper.paper_account import (
    PaperAccount,
)


def make_account(
    tmp_path: Path,
    *,
    equity: float = 10000.0,
    risk: float = 1.0,
    max_positions: int = 1,
) -> PaperAccount:

    return PaperAccount(
        starting_equity=equity,
        risk_percent=risk,
        max_positions=max_positions,
        state_path=(
            tmp_path
            / "account.json"
        ),
    )


def test_buy_take_profit(tmp_path):

    account = make_account(
        tmp_path
    )

    position = account.open_position(
        trade_id="TEST-BUY",
        symbol="XAUUSD",
        direction="BUY",
        entry=100.0,
        stop_loss=99.0,
        take_profit=102.0,
    )

    assert position is not None

    closed = account.update_price(
        "XAUUSD",
        bid=102.0,
        ask=102.1,
    )

    assert len(closed) == 1

    assert (
        closed[0]["exit_reason"]
        == "TAKE_PROFIT"
    )

    assert (
        closed[0]["result_r"]
        == 2.0
    )


def test_sell_stop(tmp_path):

    account = make_account(
        tmp_path
    )

    position = account.open_position(
        trade_id="TEST-SELL",
        symbol="XAUUSD",
        direction="SELL",
        entry=100.0,
        stop_loss=101.0,
        take_profit=98.0,
    )

    assert position is not None

    closed = account.update_price(
        "XAUUSD",
        bid=101.0,
        ask=101.1,
    )

    assert len(closed) == 1

    assert (
        closed[0]["exit_reason"]
        == "STOP_LOSS"
    )

    assert (
        closed[0]["result_r"]
        == -1.0
    )


def test_position_limit(tmp_path):

    account = make_account(
        tmp_path,
        max_positions=1,
    )

    first = account.open_position(
        trade_id="FIRST",
        symbol="XAUUSD",
        direction="BUY",
        entry=100.0,
        stop_loss=99.0,
        take_profit=102.0,
    )

    second = account.open_position(
        trade_id="SECOND",
        symbol="XAUUSD",
        direction="BUY",
        entry=100.0,
        stop_loss=99.0,
        take_profit=102.0,
    )

    assert first is not None
    assert second is None


def test_safety_invariants(tmp_path):

    account = make_account(
        tmp_path
    )

    snapshot = account.snapshot()

    assert snapshot["paper_trading"] is True
    assert snapshot["live_execution"] is False
    assert snapshot["broker_orders"] == 0


def test_account_math(tmp_path):

    # Completely isolated account.
    #
    # This test MUST NOT read the real persistent
    # paper account from data/paper/account.json.

    account = make_account(
        tmp_path,
        equity=10000.0,
        risk=1.0,
    )

    account.open_position(
        trade_id="MATH",
        symbol="XAUUSD",
        direction="BUY",
        entry=100.0,
        stop_loss=99.0,
        take_profit=102.0,
    )

    closed = account.update_price(
        "XAUUSD",
        bid=102.0,
        ask=102.1,
    )

    assert len(closed) == 1

    # $10,000 × 1% = $100 risk.
    # TP is 2R.
    # Therefore P&L must be exactly $200.

    assert (
        closed[0]["risk_amount"]
        == 100.0
    )

    assert (
        closed[0]["result_r"]
        == 2.0
    )

    assert (
        closed[0]["pnl"]
        == 200.0
    )

    snapshot = account.snapshot()

    assert (
        snapshot["equity"]
        == 10200.0
    )

    assert (
        snapshot["net_r"]
        == 2.0
    )

    assert (
        snapshot["win_rate"]
        == 100.0
    )
