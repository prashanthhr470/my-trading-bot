"""
Tests for app.paper.canonical_signal_adapter - Phase K's drop-in
replacement for the old FinalAgentPipeline.run() call in
app.paper.multi_symbol_paper.py.

Bars and quotes are injected (load_bars / bid / ask) rather than read
from data/live/bars and the live event files, so these tests prove the
adapter's own orchestration logic: bar availability/staleness gating,
calling the registered strategy's signal provider, risk sizing, the
execution safety gate, and the output contract. They do NOT prove the
live cTrader fetch works - that is hafnot_live_bar_feed.py's job and
needs a live connection.

No pytest-asyncio plugin is installed in this project (only anyio, as a
transitive dependency, with no anyio_backend fixture configured) - rather
than add a test dependency, adapter.run() is driven with asyncio.run()
inside plain synchronous test functions.
"""

import asyncio
import json
import time

import pytest

import app.paper.canonical_signal_adapter as adapter


@pytest.fixture(autouse=True)
def _disable_validation_gate(monkeypatch):
    """
    The validated-baseline gate is exercised by its own tests below. The
    rest of these tests target the downstream path (bars, quotes, risk,
    safety gate), so the gate is switched off for them - otherwise every
    one of them would stop at NO_TRADE and prove nothing.
    """

    monkeypatch.setattr(adapter, "REQUIRE_VALIDATED_BASELINE", False)
    yield


class _FakeSpec:
    def __init__(self, provider):
        self._provider = provider

    def build_signal_provider(self):
        return self._provider


def _bars(count=10, price=2000.0):
    return [
        {
            "timestamp": "2026-01-01T00:00:00+00:00",
            "open": price, "high": price + 0.5, "low": price - 0.5, "close": price,
        }
        for _ in range(count)
    ]


def _load_bars_ok(bars=None):
    bars = bars if bars is not None else _bars()

    def _loader(symbol, period):
        return bars, None

    return _loader


def _load_bars_problem(message):
    def _loader(symbol, period):
        return [], message

    return _loader


def _run(symbol, **kwargs):
    return asyncio.run(adapter.run(symbol, **kwargs))


# --- symbol / strategy configuration ---

def test_symbol_not_configured_returns_no_trade():
    result = _run("NOTAREALSYMBOL", account_state={}, load_bars=_load_bars_ok())
    assert result["final_decision"] == "NO_TRADE"
    assert result["execution_allowed"] is False
    assert result["broker_order"] is False


def test_unregistered_strategy_returns_no_trade(monkeypatch):
    def _raise_not_found(sid, v):
        raise FileNotFoundError()

    monkeypatch.setattr(adapter, "load_strategy", _raise_not_found)

    result = _run("XAUUSD", account_state={}, load_bars=_load_bars_ok())
    assert result["final_decision"] == "NO_TRADE"


# --- bar availability (the failure that was previously silent) ---

def test_missing_bars_file_returns_wait_with_explanation(monkeypatch):
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: None))

    result = _run(
        "XAUUSD", account_state={}, bid=2000.0, ask=2000.02,
        load_bars=_load_bars_problem("No live bars file at xauusd_m5.json - feed has not produced one yet."),
    )

    assert result["final_decision"] == "WAIT"
    assert "No live bars file" in result["gate"]["reason"]


def test_stale_bars_return_wait_not_a_trade(monkeypatch):
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: None))

    result = _run(
        "XAUUSD", account_state={}, bid=2000.0, ask=2000.02,
        load_bars=_load_bars_problem("Live bars are 40.0 minutes old (limit 15) - the bar feed has stopped refreshing."),
    )

    assert result["final_decision"] == "WAIT"
    assert "stopped refreshing" in result["gate"]["reason"]


def test_real_loader_reports_missing_file_rather_than_raising(tmp_path, monkeypatch):
    """The real _load_live_bars must degrade to an explained problem, not
    an exception - an exception here is what previously surfaced as a
    bare NO_TRADE in the journal."""

    monkeypatch.setattr(adapter, "LIVE_BARS_DIR", tmp_path / "bars")

    bars, problem = adapter._load_live_bars("XAUUSD", "M5")
    assert bars == []
    assert "No live bars file" in problem


def test_real_loader_flags_stale_file(tmp_path, monkeypatch):
    bars_dir = tmp_path / "bars"
    bars_dir.mkdir()
    path = bars_dir / "xauusd_m5.json"
    path.write_text(json.dumps({"bars": _bars()}), encoding="utf-8")

    # Backdate well beyond MAX_BARS_AGE_SECONDS.
    old = time.time() - (adapter.MAX_BARS_AGE_SECONDS + 600)
    import os
    os.utime(path, (old, old))

    monkeypatch.setattr(adapter, "LIVE_BARS_DIR", bars_dir)

    bars, problem = adapter._load_live_bars("XAUUSD", "M5")
    assert bars == []
    assert "old" in problem


def test_real_loader_accepts_a_fresh_file(tmp_path, monkeypatch):
    bars_dir = tmp_path / "bars"
    bars_dir.mkdir()
    path = bars_dir / "xauusd_m5.json"
    path.write_text(json.dumps({"bars": _bars(count=5)}), encoding="utf-8")

    monkeypatch.setattr(adapter, "LIVE_BARS_DIR", bars_dir)

    bars, problem = adapter._load_live_bars("XAUUSD", "M5")
    assert problem is None
    assert len(bars) == 5


# --- strategy / quote / safety path ---

def test_no_candidate_returns_no_trade(monkeypatch):
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: None))

    result = _run("XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok())
    assert result["final_decision"] == "NO_TRADE"
    assert "No qualifying setup" in result["gate"]["reason"]


def test_signal_provider_exception_returns_wait_not_crash(monkeypatch):
    def _raises(bars, i):
        raise RuntimeError("boom")

    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(_raises))

    result = _run("XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok())
    assert result["final_decision"] == "WAIT"
    assert "boom" in result["gate"]["reason"]


def test_missing_quote_returns_wait_never_invents_a_price(monkeypatch):
    candidate = {"direction": "BUY", "entry": 2000.0, "stop_loss": 1990.0, "take_profit": 2020.0}
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    result = _run("XAUUSD", account_state={}, load_bars=_load_bars_ok())
    assert result["final_decision"] == "WAIT"
    assert "bid/ask" in result["gate"]["reason"]


def test_valid_candidate_produces_buy_candidate_with_safe_output_contract(monkeypatch):
    candidate = {
        "direction": "BUY", "entry": 2000.02, "stop_loss": 1995.0, "take_profit": 2015.0,
        "data_sources_used": ["ohlc_bars"],
    }
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    # bid/ask 2 pips apart (pip_size=0.01 for XAUUSD) - within RiskConfig's
    # default max_spread_pips=2.0, so this reaches the safety-gate path.
    result = _run(
        "XAUUSD",
        account_state={"equity_usd": 10_000.0, "day_start_equity_usd": 10_000.0},
        bid=2000.0, ask=2000.02,
        load_bars=_load_bars_ok(),
    )

    assert result["final_decision"] == "BUY_CANDIDATE"
    # Hard-safety fields must always be exactly False, matching the old
    # pipeline's contract that app.paper.multi_symbol_paper.process_trade
    # depends on to ever accept a PAPER (never live/broker) position.
    assert result["execution_allowed"] is False
    assert result["trade_authorized"] is False
    assert result["broker_order"] is False
    assert result["paper_trade_plan"]["stop_loss"] == 1995.0
    assert result["paper_trade_plan"]["take_profit"] == 2015.0
    assert result["strategy_id"] == "liquidity-sweep-fvg"


def test_wide_spread_is_rejected_by_risk_sizing(monkeypatch):
    """A realistic gold spread (30 pips at pip_size=0.01) exceeds
    RiskConfig's default max_spread_pips=2.0 and must be refused, not
    traded through. This is a live behavior worth knowing about, not a
    hypothetical - see the adapter's notes."""

    candidate = {"direction": "BUY", "entry": 2000.3, "stop_loss": 1995.0, "take_profit": 2015.0}
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    result = _run(
        "XAUUSD", account_state={}, bid=2000.0, ask=2000.3, load_bars=_load_bars_ok(),
    )

    assert result["final_decision"] == "WAIT"
    assert "SPREAD_CAP" in result["gate"]["reason"]


def test_invalid_reward_risk_candidate_is_blocked_by_safety_gate(monkeypatch):
    """A candidate with reward:risk below the gate's 1.5 floor must be
    rejected - proves the REAL ExecutionSafetyGate is consulted."""

    candidate = {"direction": "BUY", "entry": 2000.02, "stop_loss": 1999.0, "take_profit": 2001.3}
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    result = _run(
        "XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok(),
    )

    assert result["final_decision"] == "WAIT"


# --- the validated-baseline gate (§16: validation, not mere registration) ---

def test_unvalidated_strategy_cannot_trade_even_with_a_perfect_setup(monkeypatch):
    """
    The decisive safety property: a registered strategy with no validated
    out-of-sample baseline must NOT trade, even when the signal provider
    returns a clean, safety-gate-passing candidate.
    """

    monkeypatch.setattr(adapter, "REQUIRE_VALIDATED_BASELINE", True)

    import app.monitoring.degradation_monitor as dm
    monkeypatch.setattr(dm, "find_validated_baseline", lambda sid, v: None)

    candidate = {"direction": "BUY", "entry": 2000.02, "stop_loss": 1995.0, "take_profit": 2015.0}
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    result = _run(
        "XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok(),
    )

    assert result["final_decision"] == "NO_TRADE"
    assert "no validated out-of-sample baseline" in result["gate"]["reason"]


def test_validated_strategy_is_allowed_through_the_gate(monkeypatch):
    monkeypatch.setattr(adapter, "REQUIRE_VALIDATED_BASELINE", True)

    import app.monitoring.degradation_monitor as dm
    monkeypatch.setattr(
        dm, "find_validated_baseline",
        lambda sid, v: {"test_type": "OUT_OF_SAMPLE", "expectancy_r": 0.2, "trade_count": 40,
                        "win_rate": 0.45, "profit_factor": 1.3, "max_drawdown_percent": 7.0},
    )

    candidate = {"direction": "BUY", "entry": 2000.02, "stop_loss": 1995.0, "take_profit": 2015.0}
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    result = _run(
        "XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok(),
    )

    assert result["final_decision"] == "BUY_CANDIDATE"


def test_live_registry_state_currently_blocks_every_configured_symbol(monkeypatch):
    """
    Documents the ACTUAL current state against the real registry (no
    mocking of the baseline lookup): none of the live-configured
    strategies has a validated baseline, so none may trade. If this test
    ever fails, a strategy has genuinely passed validation - update it
    deliberately, and check that was intended.
    """

    monkeypatch.setattr(adapter, "REQUIRE_VALIDATED_BASELINE", True)

    candidate = {"direction": "BUY", "entry": 2000.02, "stop_loss": 1995.0, "take_profit": 2015.0}
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: candidate))

    for symbol in adapter.STRATEGY_FOR_SYMBOL:
        result = _run(
            symbol, account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok(),
        )
        assert result["final_decision"] == "NO_TRADE", symbol
        assert "no validated out-of-sample baseline" in result["gate"]["reason"], symbol


def test_output_always_has_the_keys_the_old_pipeline_contract_requires(monkeypatch):
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: None))

    result = _run("XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok())

    for key in ("final_decision", "paper_trade_plan", "trade_authorized", "execution_allowed", "broker_order"):
        assert key in result


def test_blocked_result_still_identifies_the_strategy_that_was_evaluated(monkeypatch):
    # Found in the live archive: gate-blocked results recorded strategy_id=None.
    monkeypatch.setattr(adapter, "REQUIRE_VALIDATED_BASELINE", True)

    import app.monitoring.degradation_monitor as dm
    monkeypatch.setattr(dm, "find_validated_baseline", lambda sid, v: None)
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: None))

    result = _run("XAUUSD", account_state={}, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok())

    assert result["final_decision"] == "NO_TRADE"
    assert result["strategy_id"] == "liquidity-sweep-fvg"
    assert result["strategy_version"] == "2.0.0"


def test_no_setup_result_identifies_the_strategy(monkeypatch):
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: None))

    result = _run("EURUSD", account_state={}, bid=1.1, ask=1.10002, load_bars=_load_bars_ok())

    assert result["final_decision"] == "NO_TRADE"
    assert result["strategy_id"] == "liquidity-sweep-fvg"


def test_unconfigured_symbol_claims_no_strategy():
    result = _run("NOTAREALSYMBOL", account_state={}, load_bars=_load_bars_ok())
    assert result.get("strategy_id") is None


# --- the real account state reaches the risk model and the safety gate ---
# Until 2026-09-12 the gate was always told "0 open positions, 0% daily loss,
# kill switch off", and the risk model never saw an open position.

_GOLD_CANDIDATE = {"direction": "BUY", "entry": 2000.02, "stop_loss": 1995.0, "take_profit": 2015.0}


def _open(symbol, side, risk):
    # The risk model accepts only its own position type (anything else is INVALID_ACCOUNT_STATE).
    from app.forex_v2.risk import PaperPosition
    buy = side == "BUY"
    return PaperPosition(
        symbol=symbol, side=side, lots=0.5, units=50_000, entry_fill_price=1.1000,
        stop_exit_price=1.0980 if buy else 1.1020, take_profit_exit_price=1.1040 if buy else 1.0960,
        risk_amount_usd=risk, expected_reward_usd=2 * risk, round_turn_commission_usd=3.5,
    )


def _gold_result(monkeypatch, account_state):
    monkeypatch.setattr(adapter, "load_strategy", lambda sid, v: _FakeSpec(lambda bars, i: _GOLD_CANDIDATE))
    return _run("XAUUSD", account_state=account_state, bid=2000.0, ask=2000.02, load_bars=_load_bars_ok())


def test_an_open_position_on_another_symbol_blocks_a_candidate_at_the_safety_gate(monkeypatch):
    # Long USDJPY offsets gold's short USD, so only the gate's position limit can refuse this.
    result = _gold_result(monkeypatch, {"open_positions": [_open("USDJPY", "BUY", 50.0)]})

    assert result["final_decision"] == "WAIT"
    assert "safety gate" in result["gate"]["reason"]


def test_a_tripped_kill_switch_blocks_a_candidate(monkeypatch):
    result = _gold_result(monkeypatch, {"kill_switch": True})

    assert result["final_decision"] == "WAIT"
    assert "safety gate" in result["gate"]["reason"]


def test_daily_loss_beyond_the_gate_limit_blocks_a_candidate(monkeypatch):
    result = _gold_result(monkeypatch, {"daily_loss_percent": 3.5})

    assert result["final_decision"] == "WAIT"
    assert "safety gate" in result["gate"]["reason"]


def test_the_risk_model_refuses_a_stacked_currency_bet(monkeypatch):
    result = _gold_result(
        monkeypatch, {"open_positions": [_open("EURUSD", "BUY", 60.0), _open("GBPUSD", "BUY", 60.0)]},
    )

    assert result["final_decision"] == "WAIT"
    assert "CURRENCY_EXPOSURE_CAP" in result["gate"]["reason"]


def test_the_plan_carries_the_costed_position_for_the_paper_account(monkeypatch):
    result = _gold_result(monkeypatch, {})

    plan = result["paper_trade_plan"]
    assert result["final_decision"] == "BUY_CANDIDATE"
    assert plan["costed_position"]["symbol"] == "XAUUSD"
    assert plan["costed_position"]["risk_amount_usd"] == plan["risk_amount_usd"]
    assert plan["costed_position"]["round_turn_commission_usd"] > 0
