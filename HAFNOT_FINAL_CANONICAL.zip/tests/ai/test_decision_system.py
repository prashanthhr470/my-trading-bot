﻿from __future__ import annotations

import pytest

import app.ai.hafnot_ai_decision_system as ai_system
from app.ai.hafnot_ai_decision_system import (
    build_complete_ai_evidence,
    run_complete_ai_decision,
    system_status,
)

AI_LOG_NAMES = ("DECISION_LOG", "EVIDENCE_LOG", "REASONING_LOG", "REJECTION_LOG", "PAPER_LOG")


@pytest.fixture(autouse=True)
def _isolate_ai_logs(tmp_path, monkeypatch):
    # Without this, every test run appended fake XAUUSD decisions to the real data/ai logs.
    for name in AI_LOG_NAMES:
        monkeypatch.setattr(ai_system, name, tmp_path / getattr(ai_system, name).name)
    yield


@pytest.fixture(autouse=True)
def _no_live_llm_calls(monkeypatch):
    # These tests previously posted to a running local Ollama model: slow (up to 38s) and nondeterministic.
    import requests

    import app.ai.provider as ai_provider

    def _refuse_network(*args, **kwargs):
        raise requests.ConnectionError("Network disabled in unit tests.")

    monkeypatch.setattr(ai_provider.requests, "post", _refuse_network)
    yield


def test_unreachable_ai_provider_fails_closed():
    result = run_complete_ai_decision(symbol="XAUUSD", intelligence=sample_intelligence())

    assert result["final_decision"] in {"NO_TRADE", "WAIT"}
    assert result["execution_allowed"] is False
    assert result["trade_authorized"] is False
    assert result["broker_order"] is False


def test_decision_logs_are_written_to_the_isolated_directory_only(tmp_path):
    real_logs = [ai_system.AI_DATA_DIR / getattr(ai_system, name).name for name in AI_LOG_NAMES]
    sizes_before = {path: path.stat().st_size for path in real_logs if path.exists()}

    run_complete_ai_decision(symbol="XAUUSD", intelligence={})

    assert any(tmp_path.iterdir()), "the decision should have written its logs into tmp_path"
    sizes_after = {path: path.stat().st_size for path in real_logs if path.exists()}
    assert sizes_after == sizes_before, "the real data/ai logs must not change during tests"


def sample_intelligence():
    return {
        "regime": {
            "regime": "TRENDING",
            "direction": "bullish",
            "confidence": "high",
            "volatility": "normal",
            "bullish_timeframes": 3,
            "bearish_timeframes": 1,
            "known_timeframes": 4,
            "timeframes": {},
        },
        "context": {
            "structure": {
                "type": "bullish",
            },
            "liquidity": {},
            "fundamentals": {},
            "news": {},
        },
        "confluence": {},
        "setup": {},
        "sentiment": {},
        "data_quality": {},
        "timeframe_summaries": {},
        "orderflow": {
            "best_bid": 4486.87,
            "best_ask": 4486.96,
            "spread": 0.09,
            "bid_depth": 50.0,
            "ask_depth": 50.0,
            "raw_imbalance": 0.0,
            "weighted_imbalance": 0.0,
            "book_pressure": 0.0,
            "short_term_book_momentum": 0.0,
            "stacking_score": 0.0,
            "pulling_score": 0.0,
            "liquidity_migration": 0.0,
            "absorption_proxy": 0.0,
            "exhaustion_proxy": 0.0,
            "confidence": 1.0,
            "quote_count": 10,
            "data_source": "cTrader_native_level2",
            "executed_trade_volume_available": False,
            "true_trade_delta_available": False,
            "depth_footprint_proxy": True,
            "heatmap": {},
            "signal": {},
        },
    }


def test_status_is_locked():
    status = system_status()

    assert status["live_execution"] is False
    assert status["broker_orders"] == 0
    assert status["ai_direct_execution"] is False
    assert status["read_only"] is True


def test_orderflow_is_in_evidence():
    evidence = build_complete_ai_evidence(
        symbol="XAUUSD",
        intelligence=sample_intelligence(),
    )

    assert "order_flow" in evidence
    assert evidence["order_flow"]["best_bid"] == 4486.87
    assert evidence["order_flow"]["best_ask"] == 4486.96
    assert evidence["data_quality"]["native_ctrader_level2"] is True


def test_invalid_intelligence_fails_closed():
    result = run_complete_ai_decision(
        symbol="XAUUSD",
        intelligence={},
    )

    assert result["final_decision"] in {
        "NO_TRADE",
        "WAIT",
    }

    assert result["execution_allowed"] is False
    assert result["trade_authorized"] is False
    assert result["broker_order"] is False
    assert result["live_execution"] is False


def test_no_broker_execution():
    result = run_complete_ai_decision(
        symbol="XAUUSD",
        intelligence=sample_intelligence(),
    )

    assert result["execution_allowed"] is False
    assert result["trade_authorized"] is False
    assert result["broker_order"] is False
    assert result["live_execution"] is False
    assert result["paper_trading"] is True
