"""
Signals decided at the 17:00 New York rollover are dropped in summer and winter alike,
and the wrapped strategy still sees every bar.
"""

import pytest

from app.quant import signal_filters as sf

SPEC = {"type": "exclude_new_york_hours", "hours": [17]}


def _provider(calls):
    def provider(visible_bars, index):
        calls.append(index)
        return {"direction": "BUY"}
    return provider


@pytest.mark.parametrize("opened, dropped", [
    ("2026-07-08T17:00:00+00:00", True),    # H4 bar closes 21:00 UTC = 17:00 New York (EDT)
    ("2026-01-08T18:00:00+00:00", True),    # closes 22:00 UTC = 17:00 New York (EST)
    ("2026-07-08T13:00:00+00:00", False),   # closes 17:00 UTC = 13:00 New York
    ("2026-01-08T17:00:00+00:00", False),   # closes 21:00 UTC = 16:00 New York in winter
])
def test_rollover_decisions_are_dropped_across_daylight_saving(opened, dropped):
    calls = []
    filtered = sf.apply_filter(_provider(calls), SPEC, timeframe_minutes=240)

    signal = filtered([{"timestamp": opened}], 7)

    assert (signal is None) is dropped
    assert calls == [7]


def test_invalid_hour_specs_are_refused():
    for bad in ({"type": "exclude_new_york_hours", "hours": []}, {"type": "exclude_new_york_hours", "hours": [24]},
                {"type": "exclude_new_york_hours", "hours": [17], "extra": 1}):
        with pytest.raises(ValueError):
            sf.validate_filter(bad)
    assert "America/New_York" in sf.describe(SPEC)
