import pytest

from app.quant import strategy_registry as registry
from app.quant import strategy_scorecard as scorecard


def _spec(strategy_id):
    return registry.StrategySpec(
        strategy_id=strategy_id,
        version="1.0.0",
        family=registry.StrategyFamily.BREAKOUT.value,
        entry_rules="test",
        exit_rules="test",
        stop_loss_logic="test",
        take_profit_logic="test",
        timeframe="H1",
        symbols=["XAUUSD"],
        session_conditions="test",
        regime_conditions="test",
        parameters={},
        transaction_cost_assumptions="test",
        risk_model="test",
        signal_provider_module="app.quant.asian_range_breakout_strategy",
        signal_provider_factory="make_signal_provider",
    )


@pytest.fixture(autouse=True)
def _use_tmp_registry(tmp_path, monkeypatch):
    monkeypatch.setattr(registry, "SPECS_DIR", tmp_path / "specs")
    monkeypatch.setattr(registry, "RESULTS_DIR", tmp_path / "results")
    yield


def _record(strategy_id, test_type, symbol, **scorecard_fields):
    registry.record_result(strategy_id, "1.0.0", test_type=test_type, symbol=symbol, scorecard=scorecard_fields)


# --- design keys ---

@pytest.mark.parametrize("test_type, expected_side, expected_design", [
    ("IN_SAMPLE", "IN_SAMPLE", "BASE"),
    ("OUT_OF_SAMPLE", "OUT_OF_SAMPLE", "BASE"),
    ("IN_SAMPLE_8_SYMBOLS_70PCT", "IN_SAMPLE", "8_SYMBOLS"),
    ("OUT_OF_SAMPLE_8_SYMBOLS_30PCT", "OUT_OF_SAMPLE", "8_SYMBOLS"),
    ("IN_SAMPLE_5YR_CORRECTED_SPEC", "IN_SAMPLE", "5YR_CORRECTED_SPEC"),
    ("PARAMETER_SWEEP_9_COMBOS_IS", "SINGLE", "PARAMETER_SWEEP_9_COMBOS_IS"),
    ("ROLLING_6_WINDOW_CONSISTENCY", "SINGLE", "ROLLING_6_WINDOW_CONSISTENCY"),
])
def test_side_and_design_are_derived_from_real_registry_names(test_type, expected_side, expected_design):
    assert scorecard.side_of(test_type) == expected_side
    assert scorecard.design_key(test_type) == expected_design


# --- basics ---

def test_scorecard_with_no_results_reports_no_trades():
    registry.register_strategy(_spec("empty-strategy"))
    card = scorecard.build_scorecard("empty-strategy", "1.0.0")

    assert card.total_test_records == 0
    assert card.designs == []
    assert "NO TRADES" in card.verdict


def test_single_design_totals_by_side_and_symbol():
    registry.register_strategy(_spec("multi-symbol"))
    _record("multi-symbol", "IN_SAMPLE", "XAUUSD", trade_count=10, net_pnl_usd=100.0)
    _record("multi-symbol", "IN_SAMPLE", "EURUSD", trade_count=5, net_pnl_usd=-20.0)
    _record("multi-symbol", "OUT_OF_SAMPLE", "XAUUSD", trade_count=8, net_pnl_usd=50.0)

    card = scorecard.build_scorecard("multi-symbol", "1.0.0")
    base = card.design("BASE")

    assert base.sides["IN_SAMPLE"].trades == 15
    assert base.sides["IN_SAMPLE"].net_pnl_usd == pytest.approx(80.0)
    assert base.sides["OUT_OF_SAMPLE"].trades == 8
    assert base.sides["OUT_OF_SAMPLE"].net_pnl_usd == pytest.approx(50.0)
    assert base.sides["IN_SAMPLE"].per_symbol["XAUUSD"]["trades"] == 10
    assert base.sides["IN_SAMPLE"].per_symbol["EURUSD"]["trades"] == 5


# --- the three double-counting defects found in the real registry ---

def test_single_symbol_row_is_not_double_counted_with_the_all_row():
    # Real case: asian-range-breakout OOS showed 382 trades (348 ALL + 34 XAUUSD subset).
    registry.register_strategy(_spec("breakout"))
    _record("breakout", "IN_SAMPLE_8_SYMBOLS_70PCT", "ALL", trade_count=858, net_pnl_usd=-6070.15)
    _record("breakout", "OUT_OF_SAMPLE_8_SYMBOLS_30PCT", "ALL", trade_count=348, net_pnl_usd=-4184.26)
    _record("breakout", "OUT_OF_SAMPLE_8_SYMBOLS_30PCT", "XAUUSD", trade_count=34, net_pnl_usd=227.78)

    design = scorecard.build_scorecard("breakout", "1.0.0").design("8_SYMBOLS")

    assert design.sides["OUT_OF_SAMPLE"].trades == 348
    assert design.sides["OUT_OF_SAMPLE"].net_pnl_usd == pytest.approx(-4184.26)
    assert any("XAUUSD" in reason and "subset" in reason for reason in design.sides["OUT_OF_SAMPLE"].excluded)


def test_superseded_record_is_excluded_only_for_its_own_symbol():
    # Real case: corrected-spec XAUUSD rows replaced only the XAUUSD rows of the 5YR design.
    registry.register_strategy(_spec("sweep"))
    _record("sweep", "IN_SAMPLE_5YR", "XAUUSD", trade_count=12, net_pnl_usd=-43.46)
    _record("sweep", "IN_SAMPLE_5YR", "EURUSD", trade_count=13, net_pnl_usd=75.49)
    _record("sweep", "IN_SAMPLE_5YR_CORRECTED_SPEC", "XAUUSD", trade_count=12, net_pnl_usd=-45.34,
            supersedes="IN_SAMPLE_5YR (net -43.46, PF 0.87, pip_size=0.01)")

    card = scorecard.build_scorecard("sweep", "1.0.0")

    five_year = card.design("5YR").sides["IN_SAMPLE"]
    assert five_year.trades == 13
    assert five_year.net_pnl_usd == pytest.approx(75.49)
    assert any("superseded by IN_SAMPLE_5YR_CORRECTED_SPEC" in reason for reason in five_year.excluded)

    corrected = card.design("5YR_CORRECTED_SPEC").sides["IN_SAMPLE"]
    assert corrected.trades == 12
    assert corrected.net_pnl_usd == pytest.approx(-45.34)


def test_overlapping_designs_are_reported_separately_never_summed():
    # Real case: 2-year and 5-year tests of the same symbol overlap in time.
    registry.register_strategy(_spec("overlap"))
    _record("overlap", "IN_SAMPLE_2YR", "XAUUSD", trade_count=11, net_pnl_usd=-164.34)
    _record("overlap", "IN_SAMPLE_5YR", "XAUUSD", trade_count=12, net_pnl_usd=-43.46)

    card = scorecard.build_scorecard("overlap", "1.0.0")

    assert card.design("2YR").sides["IN_SAMPLE"].trades == 11
    assert card.design("5YR").sides["IN_SAMPLE"].trades == 12
    assert not hasattr(card, "total_trades"), "a cross-design total would be meaningless"


def test_rerun_of_the_same_test_keeps_only_the_latest():
    registry.register_strategy(_spec("rerun"))
    _record("rerun", "IN_SAMPLE", "XAUUSD", trade_count=10, net_pnl_usd=100.0)
    _record("rerun", "IN_SAMPLE", "XAUUSD", trade_count=12, net_pnl_usd=-40.0)

    side = scorecard.build_scorecard("rerun", "1.0.0").design("BASE").sides["IN_SAMPLE"]

    assert side.trades == 12
    assert side.net_pnl_usd == pytest.approx(-40.0)
    assert any("earlier run" in reason for reason in side.excluded)


def test_records_without_trade_data_do_not_create_fake_zero_totals():
    registry.register_strategy(_spec("sweep-only"))
    _record("sweep-only", "PARAMETER_SWEEP_9_COMBOS_IS", "XAUUSD", combos_tried=9, profitable_fraction=0.0)

    card = scorecard.build_scorecard("sweep-only", "1.0.0")

    assert card.design("PARAMETER_SWEEP_9_COMBOS_IS").sides["SINGLE"].has_trade_data is False
    assert "NO TRADES" in card.verdict


# --- flags and verdict ---

def test_is_oos_sign_flip_and_divergence_are_flagged_per_design():
    registry.register_strategy(_spec("overfit-strategy"))
    _record("overfit-strategy", "IN_SAMPLE", "XAUUSD", trade_count=20, net_pnl_usd=1000.0)
    _record("overfit-strategy", "OUT_OF_SAMPLE", "XAUUSD", trade_count=20, net_pnl_usd=-500.0)

    card = scorecard.build_scorecard("overfit-strategy", "1.0.0")

    assert any("divergence" in f.lower() and f.startswith("[BASE]") for f in card.overfitting_flags)
    assert any("sign flip" in f.lower() for f in card.overfitting_flags)
    assert "NOT VALIDATED" in card.verdict


def test_scorecard_flags_small_sample_results():
    registry.register_strategy(_spec("small-sample-strategy"))
    _record("small-sample-strategy", "OUT_OF_SAMPLE", "GBPUSD", trade_count=2, net_pnl_usd=214.0)

    card = scorecard.build_scorecard("small-sample-strategy", "1.0.0")

    assert any("3 or fewer trades" in f for f in card.overfitting_flags)


def test_scorecard_flags_inconsistent_rolling_windows():
    registry.register_strategy(_spec("rolling-window-strategy"))
    _record("rolling-window-strategy", "ROLLING_WINDOW", "XAUUSD",
            trade_count=132, net_pnl_usd=-629.39, windows=6, profitable_windows=3)

    card = scorecard.build_scorecard("rolling-window-strategy", "1.0.0")

    assert any("windows profitable" in f for f in card.overfitting_flags)


def test_unmeasured_metrics_are_explicitly_flagged_not_hidden_or_faked():
    registry.register_strategy(_spec("unmeasured-strategy"))
    _record("unmeasured-strategy", "IN_SAMPLE", "XAUUSD", trade_count=5, net_pnl_usd=10.0)

    card = scorecard.build_scorecard("unmeasured-strategy", "1.0.0")

    assert card.sharpe_ratio == scorecard.NOT_YET_MEASURED
    assert card.max_drawdown == scorecard.NOT_YET_MEASURED
    assert card.parameter_sensitivity == scorecard.NOT_YET_MEASURED
    assert card.monte_carlo_robustness == scorecard.NOT_YET_MEASURED
    assert card.transaction_cost_sensitivity == scorecard.NOT_YET_MEASURED
    assert card.performance_by_regime == scorecard.NOT_YET_MEASURED


def test_profitable_in_sample_is_never_promising_when_out_of_sample_fails():
    registry.register_strategy(_spec("misleading-profit-strategy"))
    _record("misleading-profit-strategy", "IN_SAMPLE", "XAUUSD", trade_count=10, net_pnl_usd=2000.0)
    _record("misleading-profit-strategy", "OUT_OF_SAMPLE", "XAUUSD", trade_count=10, net_pnl_usd=-100.0)

    card = scorecard.build_scorecard("misleading-profit-strategy", "1.0.0")
    base = card.design("BASE")

    assert base.sides["IN_SAMPLE"].net_pnl_usd > 0
    assert base.sides["OUT_OF_SAMPLE"].net_pnl_usd < 0
    assert card.overfitting_flags
    assert "NOT VALIDATED" in card.verdict
    assert "PROMISING" not in card.verdict


def test_positive_in_both_sides_of_one_design_is_promising_not_validated():
    registry.register_strategy(_spec("consistent"))
    _record("consistent", "IN_SAMPLE", "XAUUSD", trade_count=40, net_pnl_usd=400.0)
    _record("consistent", "OUT_OF_SAMPLE", "XAUUSD", trade_count=40, net_pnl_usd=390.0)

    card = scorecard.build_scorecard("consistent", "1.0.0")

    assert "PROMISING BUT UNPROVEN" in card.verdict
    assert "VALIDATED -" not in card.verdict.replace("NOT VALIDATED", "")


def test_single_symbol_row_stays_a_subset_after_its_all_row_is_superseded():
    # Real case: superseding the 8-symbol OOS row promoted the XAUUSD-only row (+$227.78) to the design total.
    registry.register_strategy(_spec("breakout-corrected"))
    _record("breakout-corrected", "OUT_OF_SAMPLE_8_SYMBOLS_30PCT", "ALL", trade_count=348, net_pnl_usd=-4184.26)
    _record("breakout-corrected", "OUT_OF_SAMPLE_8_SYMBOLS_30PCT", "XAUUSD", trade_count=34, net_pnl_usd=227.78)
    _record("breakout-corrected", "OUT_OF_SAMPLE_8_SYMBOLS_ONE_POSITION_30PCT", "ALL", trade_count=278,
            net_pnl_usd=-3683.01, supersedes="OUT_OF_SAMPLE_8_SYMBOLS_30PCT (348 trades, overlapping positions)")

    card = scorecard.build_scorecard("breakout-corrected", "1.0.0")
    old_side = card.design("8_SYMBOLS").sides["OUT_OF_SAMPLE"]

    assert old_side.has_trade_data is False
    assert any("superseded" in reason for reason in old_side.excluded)
    assert any("XAUUSD" in reason and "subset" in reason for reason in old_side.excluded)
    assert card.design("8_SYMBOLS_ONE_POSITION").sides["OUT_OF_SAMPLE"].trades == 278
