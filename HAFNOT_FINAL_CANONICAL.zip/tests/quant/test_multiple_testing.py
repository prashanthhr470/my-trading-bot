"""
The more experiments recorded, the stronger the locked-slice evidence a winner needs.
"""

import pytest

from app.quant import multiple_testing as mt


def _trades(values):
    return [{"result_r": v} for v in values]


EDGE = _trades([2.0, -1.0] * 50)       # mean +0.5R over 100 trades, t about 3.3


def test_a_real_looking_edge_passes_when_it_is_the_only_experiment():
    result = mt.check(EDGE, experiments_counted=1)

    assert result.passed
    assert result.required_p_value == pytest.approx(0.05)
    assert result.p_value < 0.001


def test_the_same_edge_fails_once_many_experiments_have_been_run():
    result = mt.check(EDGE, experiments_counted=1000)

    assert not result.passed
    assert result.required_p_value == pytest.approx(0.00005)
    assert result.required_mean_r > result.mean_r
    assert "Not significant" in result.reasons[0]


def test_no_edge_never_passes():
    assert not mt.check(_trades([1.0, -1.0] * 100), experiments_counted=1).passed


def test_too_few_trades_fail_whatever_the_result():
    result = mt.check(_trades([3.0] * 29), experiments_counted=1)

    assert not result.passed and result.p_value is None


def test_the_required_mean_is_the_pass_boundary():
    loose = mt.check(EDGE, experiments_counted=78)
    shifted = [t["result_r"] - loose.mean_r + loose.required_mean_r * 1.01 for t in EDGE]

    assert mt.check(_trades(shifted), experiments_counted=78).passed
    shifted = [t["result_r"] - loose.mean_r + loose.required_mean_r * 0.99 for t in EDGE]
    assert not mt.check(_trades(shifted), experiments_counted=78).passed


def test_critical_z_inverts_the_tail_probability():
    assert mt.critical_z(0.05) == pytest.approx(1.6449, abs=1e-3)
    assert mt.one_sided_p_value(mt.critical_z(1e-6)) == pytest.approx(1e-6, rel=1e-3)
