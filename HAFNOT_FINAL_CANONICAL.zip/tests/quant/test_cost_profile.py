"""
Measured spreads: the backtest value is the worst qualifying hourly p90, thin hours
and weekends do not count, and a profile that has not seen (nearly) a full weekday
cannot be loaded for research.
"""

import hashlib
import json
from datetime import datetime, timedelta, timezone

import pytest

from app.quant import cost_profile as cp

MONDAY = datetime(2026, 9, 14, tzinfo=timezone.utc)


def _quotes(hour_spreads, per_hour=60, day=MONDAY):
    return [(day + timedelta(hours=hour, seconds=i), spread)
            for hour, spread in hour_spreads.items() for i in range(per_hour)]


def test_the_backtest_spread_is_the_worst_hourly_p90():
    # Rollover hour: half the quotes at 2.0 pips.
    quotes = _quotes({h: 0.1 for h in range(24)}) + _quotes({21: 2.0})
    stats = cp.hourly_spread_stats(quotes)

    assert cp.backtest_spread_pips(stats) == 2.0
    assert cp.hours_observed(stats) == 24


def test_thin_hours_do_not_set_the_spread():
    quotes = _quotes({h: 0.1 for h in range(23)}) + _quotes({23: 5.0}, per_hour=10)
    stats = cp.hourly_spread_stats(quotes)

    assert cp.backtest_spread_pips(stats) == 0.1
    assert cp.hours_observed(stats) == 23


def test_weekend_quotes_are_ignored():
    saturday = MONDAY - timedelta(days=2)
    stats = cp.hourly_spread_stats(_quotes({12: 0.2}) + _quotes({12: 9.0}, day=saturday))

    assert stats[12]["samples"] == 60
    assert cp.backtest_spread_pips(stats) == 0.2


def _profile(tmp_path, entries):
    path = tmp_path / "measured_costs_20260915.json"
    path.write_text(json.dumps({"measured_from": "a", "measured_to": "b", "symbols": entries}), encoding="utf-8")
    return path


def test_a_full_day_profile_loads_with_its_hash(tmp_path):
    path = _profile(tmp_path, {"EURUSD": {"backtest_spread_pips": 0.3, "hours_observed": 24}})

    profile = cp.load_cost_profile(path, symbols=["eurusd"])

    assert profile.spreads_pips == {"EURUSD": 0.3}
    assert profile.sha256 == hashlib.sha256(path.read_bytes()).hexdigest()


def test_a_profile_missing_hours_cannot_be_used_for_research(tmp_path):
    path = _profile(tmp_path, {"XAUUSD": {"backtest_spread_pips": 1.7, "hours_observed": 10}})

    with pytest.raises(ValueError, match="only 10 of 24"):
        cp.load_cost_profile(path, symbols=["XAUUSD"])
    assert cp.load_cost_profile(path, symbols=["XAUUSD"], require_full_day=False).spreads_pips == {"XAUUSD": 1.7}


def _hours(values, samples=600):
    return {str(h): {"samples": samples, "median": v, "p90": v} for h, v in values.items()}


def test_execution_hours_charge_the_spread_of_those_hours_not_the_rollover(tmp_path):
    hours = _hours({**{h: 0.1 for h in range(24)}, 21: 12.0, 22: 0.3, 23: 0.6})
    path = _profile(tmp_path, {"EURUSD": {"backtest_spread_pips": 12.0, "hours_observed": 24, "hours": hours}})

    assert cp.load_cost_profile(path, symbols=["EURUSD"]).spreads_pips == {"EURUSD": 12.0}
    profile = cp.load_cost_profile(path, symbols=["EURUSD"], hours=(22, 23))
    assert profile.spreads_pips == {"EURUSD": 0.6}
    assert profile.execution_hours == (22, 23)


def test_windows_can_be_limited_to_the_execution_hours():
    windows = cp.hourly_windows(datetime(2026, 9, 14, 10, tzinfo=timezone.utc), 2, 10, hours=(23, 21, 22))

    assert len(windows) == 2 * 3
    assert [w[0].hour for w in windows] == [21, 22, 23, 21, 22, 23]


def test_a_profile_measuring_only_the_execution_hours_loads_for_those_hours(tmp_path):
    hours = _hours({21: 12.0, 22: 0.4, 23: 0.2})
    path = _profile(tmp_path, {"US500": {"backtest_spread_pips": 12.0, "hours_observed": 3, "hours": hours}})

    assert cp.load_cost_profile(path, symbols=["US500"], hours=(22, 23)).spreads_pips == {"US500": 0.4}
    with pytest.raises(ValueError, match="only 3 of 24"):
        cp.load_cost_profile(path, symbols=["US500"])


def test_an_unmeasured_execution_hour_is_refused(tmp_path):
    hours = _hours({h: 0.1 for h in range(22)})
    path = _profile(tmp_path, {"EURUSD": {"backtest_spread_pips": 0.1, "hours_observed": 22, "hours": hours}})

    with pytest.raises(ValueError, match="execution hours"):
        cp.load_cost_profile(path, symbols=["EURUSD"], hours=(22, 23))


def test_an_unmeasured_symbol_is_refused(tmp_path):
    path = _profile(tmp_path, {"EURUSD": {"backtest_spread_pips": 0.3, "hours_observed": 24}})

    with pytest.raises(ValueError, match="GBPUSD"):
        cp.load_cost_profile(path, symbols=["EURUSD", "GBPUSD"])


def test_hourly_windows_cover_every_hour_of_past_weekdays():
    windows = cp.hourly_windows(datetime(2026, 9, 14, 10, tzinfo=timezone.utc), 5, 10)

    assert len(windows) == 5 * 24
    assert windows[0] == (datetime(2026, 9, 7, tzinfo=timezone.utc), datetime(2026, 9, 7, 0, 10, tzinfo=timezone.utc))
    assert windows[-1][0] == datetime(2026, 9, 11, 23, tzinfo=timezone.utc)
    assert all(start.weekday() < 5 for start, _ in windows)


def test_tick_data_decodes_the_first_entry_absolute_and_the_rest_as_changes():
    entries = [(1_000_000, 110_000), (-10, 5), (-20, -3)]

    assert cp.decode_tick_data(entries) == [(1_000_000, 1.1), (999_990, 1.10005), (999_970, 1.10002)]
    assert cp.decode_tick_data(entries, delta_sign=-1) == [(1_000_000, 1.1), (1_000_010, 1.09995), (1_000_030, 1.09998)]


def test_spreads_are_sampled_from_the_latest_bid_and_ask():
    bids = [(1_000, 1.1000), (3_500, 1.1002)]
    asks = [(2_000, 1.1001), (3_000, 1.1004)]

    samples = cp.sample_spreads(bids, asks, 0, 5_000, step_ms=1_000)

    # No sample until both sides have ticked (t=2000); the quote carries forward between ticks.
    assert [t for t, _ in samples] == [2_000, 3_000, 4_000]
    assert [round(s, 5) for _, s in samples] == [0.0001, 0.0004, 0.0002]


def test_a_window_without_ticks_contributes_no_spreads():
    assert cp.sample_spreads([], [], 0, 10_000) == []


def test_the_newest_dated_profile_is_found(tmp_path):
    for name in ("measured_costs_20260915.json", "measured_costs_20260920.json", "other.json"):
        (tmp_path / name).write_text("{}", encoding="utf-8")

    assert cp.latest_profile_path(tmp_path).name == "measured_costs_20260920.json"
