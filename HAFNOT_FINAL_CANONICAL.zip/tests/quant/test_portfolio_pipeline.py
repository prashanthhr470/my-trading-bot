"""
Control-flow tests for the portfolio (pooled multi-symbol) research pipeline.
Trades and walk-forward are injected so each stage's outcome is set exactly; what
matters is the discipline: calendar-aligned splits, preregistration pinned to the
data and costs, breadth, no re-runs, and one look at the locked data.
"""

from datetime import datetime, timedelta, timezone

import pytest

from app.quant import experiment_registry, locked_oos_guard, portfolio_pipeline as pp, research_pipeline as rp, strategy_registry

SYMBOLS = ("EURUSD", "GBPUSD", "USDJPY", "XAUUSD")
START = datetime(2011, 1, 3, 21, tzinfo=timezone.utc)
CONFIG = pp.PortfolioConfig(series="test-portfolio", symbols=SYMBOLS, warmup_bars=5, min_train_trades=30,
                            min_walk_forward_trades=10, walk_forward_in_sample_days=300,
                            walk_forward_out_of_sample_days=100, data_start="2011-01-03",
                            data_end=(START + timedelta(days=2000)).date().isoformat())


@pytest.fixture(autouse=True)
def _isolated_storage(tmp_path, monkeypatch):
    monkeypatch.setattr(strategy_registry, "SPECS_DIR", tmp_path / "specs")
    monkeypatch.setattr(strategy_registry, "RESULTS_DIR", tmp_path / "results")
    monkeypatch.setattr(experiment_registry, "EXPERIMENTS_FILE", tmp_path / "experiments.jsonl")
    monkeypatch.setattr(locked_oos_guard, "LOCKED_OOS_DIR", tmp_path / "locked")
    monkeypatch.setattr(pp, "PREREGISTRATION_DIR", tmp_path / "prereg")
    yield


def _bars(days, offset=0):
    return [{"timestamp": (START + timedelta(days=offset + i)).isoformat(), "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0}
            for i in range(days)]


def _data(**hash_overrides):
    bars = {"EURUSD": _bars(2000), "GBPUSD": _bars(2000), "USDJPY": _bars(2000), "XAUUSD": _bars(1900, offset=100)}
    hashes = {s: "hash-" + s for s in SYMBOLS}
    hashes.update(hash_overrides)
    return pp.PortfolioData(bars=bars, bars_sha256=hashes, spreads_pips={s: 0.3 for s in SYMBOLS},
                            cost_profile_path="profile.json", cost_profile_sha256="profile-hash")


DEFINITION = rp.FamilyDefinition(
    strategy_id="test-trend", version="1.0.0", family="TREND_MOMENTUM", hypothesis="test hypothesis",
    entry_rules="e", exit_rules="x", stop_loss_logic="s", take_profit_logic="t",
    session_conditions="None.", regime_conditions="None.", module="app.quant.donchian_trend_strategy",
    param_grid={"channel_bars": [20, 55, 100], "target_r": [2.0, 3.0, 4.0]},
    fixed_params={"stop_atr": 2.0, "atr_period": 20},
)


def _trades(symbol, evaluation, win_r, loss_r, count=12):
    return [{"symbol": symbol, "result_r": win_r if i % 2 == 0 else loss_r,
             "pnl_usd": 50.0 * (win_r if i % 2 == 0 else loss_r),
             "entry_timestamp": evaluation[i]["timestamp"], "exit_timestamp": evaluation[i + 1]["timestamp"],
             "holding_bars": 1}
            for i in range(count)]


class FakeTrades:
    """Per-stage winning or losing trades, chosen from the date an evaluation slice starts."""

    def __init__(self, data, train="win", validation="win", locked="win", strong_symbol=None):
        self.split = pp.calendar_split(data.bars, CONFIG)
        self.modes = {"TRAIN": train, "VALIDATION": validation, "LOCKED": locked}
        self.strong_symbol = strong_symbol
        self.stages = []

    def __call__(self, warmup, evaluation, symbol, factory, params, spread_pips, config):
        begins = datetime.fromisoformat(evaluation[0]["timestamp"])
        stage = "TRAIN" if begins < self.split.train_end else ("VALIDATION" if begins < self.split.validation_end else "LOCKED")
        self.stages.append(stage)
        if self.strong_symbol:
            return _trades(symbol, evaluation, 3.0, -0.8) if symbol == self.strong_symbol else _trades(symbol, evaluation, 0.8, -1.2)
        return _trades(symbol, evaluation, 1.2, -0.8) if self.modes[stage] == "win" else _trades(symbol, evaluation, 0.8, -1.2)


def _walk_forward(positive=True, calls=None):
    def runner(*args):
        if calls is not None:
            calls.append(1)
        value = 0.2 if positive else -0.2
        return {"windows": [{"window": i, "out_of_sample_expectancy_r": value} for i in range(4)],
                "positive_window_fraction": 1.0 if positive else 0.0, "mean_out_of_sample_expectancy_r": value}
    return runner


def _run(data, trades, walk_forward=None):
    pp.preregister(DEFINITION, CONFIG, data)
    return pp.run_portfolio_experiment(DEFINITION, CONFIG, data, trade_runner=trades,
                                       walk_forward_runner=walk_forward or _walk_forward())


# --- data and splits ---

def test_the_calendar_split_is_fixed_and_shared_by_every_symbol():
    data = _data()
    split = pp.calendar_split(data.bars, CONFIG)

    # Declared boundaries, not the data: a symbol starting later (XAUUSD) contributes where it has bars.
    assert split.start == datetime(2011, 1, 3, tzinfo=timezone.utc)
    assert split.end == datetime.fromisoformat(CONFIG.data_end).replace(tzinfo=timezone.utc)
    assert split.start < split.train_end < split.validation_end < split.end
    for symbol in SYMBOLS:
        warmup, validation = pp.slice_with_warmup(data.bars[symbol], split.train_end, split.validation_end, 5)
        assert datetime.fromisoformat(validation[0]["timestamp"]) >= split.train_end
        assert len(warmup) == 5 and datetime.fromisoformat(warmup[-1]["timestamp"]) < split.train_end


def test_pooled_trades_are_ordered_by_exit_time():
    data = _data()
    split = pp.calendar_split(data.bars, CONFIG)
    trades = pp.pooled_trades({s: pp.slice_with_warmup(data.bars[s], None, split.train_end, 0) for s in SYMBOLS},
                              DEFINITION.factory(), {}, data, CONFIG, FakeTrades(data))

    assert [t["exit_timestamp"] for t in trades] == sorted(t["exit_timestamp"] for t in trades)
    assert {t["symbol"] for t in trades} == set(SYMBOLS)


def test_walk_forward_windows_stay_inside_train_and_validation():
    split = pp.calendar_split(_data().bars, CONFIG)
    windows = pp.walk_forward_windows(split, CONFIG)

    assert len(windows) >= 3
    assert all(end <= split.validation_end for _, _, end in windows)
    assert all(later[0] - earlier[0] == timedelta(days=100) for earlier, later in zip(windows, windows[1:]))


def test_symbol_trades_use_bid_bars_and_the_measured_spread(monkeypatch):
    captured = {}

    def fake_backtest(**kwargs):
        captured.update(kwargs)
        from types import SimpleNamespace
        return SimpleNamespace(trades=[])

    monkeypatch.setattr(pp, "run_costed_backtest", fake_backtest)
    pp.run_symbol_trades([], _bars(10), "GBPUSD", DEFINITION.factory(), {"channel_bars": 20, "target_r": 2.0}, 0.3, CONFIG)

    assert captured["bid_bars"] is True
    assert captured["assumed_spread_pips"] == 0.3
    assert captured["max_open_positions"] == 1


def _full_day_profile(tmp_path):
    import json
    path = tmp_path / "measured_costs_20260914_broker.json"
    path.write_text(json.dumps({"symbols": {s: {"backtest_spread_pips": 0.4, "hours_observed": 24} for s in SYMBOLS}}),
                    encoding="utf-8")
    return path


def test_portfolio_data_is_fetched_into_memory_and_trimmed_to_the_fixed_range(tmp_path):
    calls = []

    def fake_fetch(symbol, timeframe, start, end):
        calls.append((symbol, timeframe, start, end))
        inside = _bars(3, offset=0)
        before = {**inside[0], "timestamp": "2010-12-30T22:00:00+00:00"}
        after = {**inside[0], "timestamp": CONFIG.data_end + "T00:00:00+00:00"}
        return [after, inside[1], before, inside[0], inside[2], inside[1]]  # unsorted, with a duplicate

    data = pp.fetch_portfolio_data(CONFIG, _full_day_profile(tmp_path), fetch=fake_fetch)

    assert sorted(calls) == sorted((s, "D1", CONFIG.data_start, CONFIG.data_end) for s in SYMBOLS)
    for symbol in SYMBOLS:
        assert [b["timestamp"] for b in data.bars[symbol]] == [b["timestamp"] for b in _bars(3)]
        assert data.bars_sha256[symbol] == pp.bars_fingerprint(data.bars[symbol])
    assert data.spreads_pips == {s: 0.4 for s in SYMBOLS}


def _rollover_profile(tmp_path):
    import json
    hours = {str(h): {"samples": 600, "median": 0.2, "p90": 12.0 if h == 21 else (0.6 if h == 23 else 0.3)}
             for h in range(24)}
    path = tmp_path / "measured_costs_20260914_broker.json"
    path.write_text(json.dumps({"symbols": {s: {"backtest_spread_pips": 12.0, "hours_observed": 24, "hours": hours}
                                            for s in SYMBOLS}}), encoding="utf-8")
    return path


def test_spreads_above_the_live_cap_are_refused_before_any_test_runs(tmp_path):
    with pytest.raises(ValueError, match="spread cap"):
        pp.fetch_portfolio_data(CONFIG, _rollover_profile(tmp_path), fetch=lambda *a: _bars(3))


def test_execution_hours_charge_the_spread_after_the_rollover(tmp_path):
    config = pp.PortfolioConfig(**{**CONFIG.__dict__, "execution_hours_utc": (22, 23), "execution_rule": "after rollover"})

    data = pp.fetch_portfolio_data(config, _rollover_profile(tmp_path), fetch=lambda *a: _bars(3))

    assert data.spreads_pips == {s: 0.6 for s in SYMBOLS}


def test_per_symbol_commission_and_spread_cap_reach_the_costed_backtest(monkeypatch):
    captured = {}

    def fake_backtest(**kwargs):
        captured.update(kwargs)
        from types import SimpleNamespace
        return SimpleNamespace(trades=[])

    monkeypatch.setattr(pp, "run_costed_backtest", fake_backtest)
    data = pp.PortfolioData(bars={"US500": []}, bars_sha256={}, spreads_pips={"US500": 1.4}, cost_profile_path=None,
                            cost_profile_sha256=None, commissions_rt_usd={"US500": 0.0}, spread_caps_pips={"US500": 2.8})

    pp.run_symbol_trades([], _bars(10), "US500", DEFINITION.factory(), {"channel_bars": 20, "target_r": 2.0},
                         data.costs_for("US500"), CONFIG)

    assert captured["assumed_spread_pips"] == 1.4
    assert captured["risk_config"].commission_per_lot_round_turn_usd == 0.0
    assert captured["risk_config"].max_spread_pips == 2.8
    assert captured["risk_config"].slippage_pips_per_side == 0.10    # default unless set

    pp.run_symbol_trades([], _bars(10), "US500", DEFINITION.factory(), {"channel_bars": 20, "target_r": 2.0},
                         pp.SymbolCosts(0.0, 0.0, 100.0, 0.0), CONFIG)
    assert captured["risk_config"].slippage_pips_per_side == 0.0 and captured["assumed_spread_pips"] == 0.0


def test_without_per_symbol_costs_the_risk_config_defaults_apply(monkeypatch):
    captured = {}

    def fake_backtest(**kwargs):
        captured.update(kwargs)
        from types import SimpleNamespace
        return SimpleNamespace(trades=[])

    monkeypatch.setattr(pp, "run_costed_backtest", fake_backtest)
    pp.run_symbol_trades([], _bars(10), "EURUSD", DEFINITION.factory(), {"channel_bars": 20, "target_r": 2.0}, 0.3, CONFIG)

    from app.forex_v2.risk import RiskConfig
    assert captured["risk_config"] == RiskConfig()


def test_broker_specs_set_commissions_and_capped_spreads(tmp_path, monkeypatch):
    import json
    from app.forex_v2 import risk

    monkeypatch.setattr(risk, "_RESEARCH_SPECS", {})
    entries = {"EURUSD": {"quote_asset": "USD", "commission": 300, "commission_type": 2, "precise_trading_commission_rate": 1},
               "US500": {"quote_asset": "USD", "base_asset": "US500", "lot_size_raw": 100, "min_lots": 0.1, "lot_step": 0.1,
                         "max_volume_raw": 50_000, "pip_size": 1.0, "commission": 0, "commission_type": 1}}
    monkeypatch.setattr(pp.instrument_specs, "load_specs", lambda: entries)
    hours = {str(h): {"samples": 600, "median": 0.5, "p90": 1.5} for h in (22, 23)}
    profile = tmp_path / "measured_costs_20260914_multiasset_broker.json"
    profile.write_text(json.dumps({"symbols": {s: {"backtest_spread_pips": 1.5, "hours_observed": 2, "hours": hours}
                                               for s in ("EURUSD", "US500")}}), encoding="utf-8")
    config = pp.PortfolioConfig(**{**CONFIG.__dict__, "symbols": ("EURUSD", "US500"), "execution_hours_utc": (22, 23),
                                   "broker_instrument_specs": True, "spread_cap_multiple": 2.0})

    data = pp.fetch_portfolio_data(config, profile, fetch=lambda *a: _bars(3))

    assert data.commissions_rt_usd == {"EURUSD": 6.0, "US500": 0.0}
    assert data.spread_caps_pips == {"EURUSD": 3.0, "US500": 3.0}
    assert "US500" not in risk.FX_USD_MAJOR_SPECS and risk.resolve_spec("US500") is not None


def test_a_project_cost_profile_is_recorded_relative_to_the_project_however_it_is_given(tmp_path):
    from pathlib import Path

    inside = pp.PROJECT_ROOT / "data" / "broker" / "measured_costs_20260914_broker.json"

    # The first series recorded "data\\broker\\..."; an absolute path must not change their preregistrations.
    assert pp.recorded_path(inside) == str(Path("data/broker/measured_costs_20260914_broker.json"))
    assert pp.recorded_path(tmp_path / "p.json") == str(tmp_path / "p.json")


def _daily(timestamp, low, high, volume=100):
    return {"timestamp": timestamp, "open": low, "high": high, "low": low, "close": high, "volume": volume}


def test_weekend_stub_bars_are_merged_into_the_next_trading_day_and_flat_ones_dropped():
    bars = [
        _daily("2011-01-06T22:00:00+00:00", 1.30, 1.32),             # Thursday open: Friday's trading day
        _daily("2011-01-07T22:00:00+00:00", 1.31, 1.31, volume=2),   # Friday open, flat: after-close ghost
        _daily("2011-01-08T22:00:00+00:00", 1.29, 1.305, volume=40), # Saturday open: Sunday-evening stub
        _daily("2011-01-09T22:00:00+00:00", 1.30, 1.33),             # Sunday open: Monday's trading day
    ]

    out, counts = pp.normalize_daily_bars(bars)

    assert [b["timestamp"] for b in out] == ["2011-01-06T22:00:00+00:00", "2011-01-09T22:00:00+00:00"]
    monday = out[1]
    assert (monday["open"], monday["high"], monday["low"], monday["volume"]) == (1.29, 1.33, 1.29, 140)
    assert counts == {"merged_weekend_bars": 1, "dropped_weekend_bars": 1}


def test_an_undeclared_gap_in_broker_history_stops_the_fetch(tmp_path):
    def gapped(symbol, timeframe, start, end):
        return _bars(10) + _bars(10, offset=40)

    with pytest.raises(ValueError, match="symbol_data_starts"):
        pp.fetch_portfolio_data(CONFIG, _full_day_profile(tmp_path), fetch=gapped)


def test_a_declared_later_start_excludes_the_gap(tmp_path):
    config = pp.PortfolioConfig(**{**CONFIG.__dict__, "symbol_data_starts": tuple(
        (s, (START + timedelta(days=40)).date().isoformat(), "gap in history") for s in SYMBOLS)})

    def gapped(symbol, timeframe, start, end):
        return _bars(10) + _bars(10, offset=40)

    data = pp.fetch_portfolio_data(config, _full_day_profile(tmp_path), fetch=gapped)

    declared = (START + timedelta(days=40)).date().isoformat()
    for bars in data.bars.values():
        assert bars and all(b["timestamp"] >= declared for b in bars)
        assert pp.daily_gaps(bars) == []


def test_a_failed_broker_fetch_stops_the_run(tmp_path):
    def failing_fetch(symbol, timeframe, start, end):
        raise RuntimeError("cTrader fetch failed")

    with pytest.raises(RuntimeError, match="fetch failed"):
        pp.fetch_portfolio_data(CONFIG, _full_day_profile(tmp_path), fetch=failing_fetch)


# --- discipline ---

def test_running_without_a_preregistration_is_refused():
    with pytest.raises(RuntimeError, match="no preregistration"):
        pp.run_portfolio_experiment(DEFINITION, CONFIG, _data(), trade_runner=FakeTrades(_data()))


def test_changed_data_cannot_reuse_a_preregistration():
    pp.preregister(DEFINITION, CONFIG, _data())

    with pytest.raises(ValueError, match="different content"):
        pp.preregister(DEFINITION, CONFIG, _data(EURUSD="a-different-file"))


def test_an_experiment_cannot_be_run_twice():
    data = _data()
    _run(data, FakeTrades(data, train="lose"))

    with pytest.raises(RuntimeError, match="already been run"):
        pp.run_portfolio_experiment(DEFINITION, CONFIG, data, trade_runner=FakeTrades(data))


# --- swaps and outside rates ---

def test_swaps_are_added_to_each_trades_result(monkeypatch):
    from types import SimpleNamespace

    trade = SimpleNamespace(entry_index=1, exit_index=4, side="SELL", lots=0.5, entry_fill_price=1.1,
                            risk_amount_usd=50.0, result_r=-0.2, exit_reason="TIME")
    monkeypatch.setattr(pp, "run_costed_backtest", lambda **kwargs: SimpleNamespace(trades=[trade]))
    seen = {}

    class Financing:
        def trade_usd(self, side, lots, price, days):
            seen.update(side=side, lots=lots, price=price, days=len(days))
            return 25.0

    bars = _bars(6)
    [with_swap] = pp.run_symbol_trades(bars[:1], bars[1:], "EURUSD", DEFINITION.factory(), {"channel_bars": 20, "target_r": 2.0},
                                       pp.SymbolCosts(0.3, financing=Financing()), CONFIG)
    [without] = pp.run_symbol_trades(bars[:1], bars[1:], "EURUSD", DEFINITION.factory(), {"channel_bars": 20, "target_r": 2.0},
                                     pp.SymbolCosts(0.3), CONFIG)

    assert with_swap["result_r"] == pytest.approx(-0.2 + 0.5) and with_swap["swap_r"] == pytest.approx(0.5)
    assert seen == {"side": "SELL", "lots": 0.5, "price": 1.1, "days": 3} and with_swap["rollovers"] == 3
    assert without["result_r"] == -0.2 and "swap_r" not in without


def test_outside_rates_and_swap_models_are_fetched_fingerprinted_and_preregistered(tmp_path, monkeypatch):
    import json
    from dataclasses import replace

    entries = {"EURUSD": {"quote_asset": "USD", "base_asset": "EUR", "commission": 300, "commission_type": 2,
                          "precise_trading_commission_rate": 1, "swap_long": -0.7, "swap_short": 0.16, "pip_size": 0.0001,
                          "units_per_lot": 100000.0, "swap_calculation_type": 0, "swap_rollover3_days": 3,
                          "charge_swap_at_weekends": False, "swap_period": 24}}
    monkeypatch.setattr(pp.instrument_specs, "load_specs", lambda: entries)
    hours = {str(h): {"samples": 600, "median": 0.3, "p90": 0.3} for h in (22, 23)}
    profile = tmp_path / "measured_costs_20260914_broker.json"
    profile.write_text(json.dumps({"symbols": {"EURUSD": {"backtest_spread_pips": 0.3, "hours_observed": 2, "hours": hours}}}),
                       encoding="utf-8")
    config = replace(CONFIG, symbols=("EURUSD",), execution_hours_utc=(22, 23), broker_instrument_specs=True,
                     external_rates="fred_3m_interbank", swap_model=True, bar_features="interest_rates")
    fake_rates = {"EUR": [["2010-01", 1.0]], "USD": [["2010-01", 3.0]]}

    data = pp.fetch_portfolio_data(config, profile, fetch=lambda *a: _bars(3), fetch_rates=lambda series: fake_rates)

    model = data.swap_models["EURUSD"]
    assert model.markup == pytest.approx(-(-0.7 + 0.16) / 2 * 360 * 0.0001 / 1.0 * 100)
    assert model.triple_weekday == 2 and data.costs_for("EURUSD").financing is model
    body = pp._preregistration_body(DEFINITION, config, data, pp.calendar_split({"EURUSD": _bars(2000)}, config))
    assert body["external_data"]["sha256"] == data.external_rates_sha256
    assert body["costs"]["swap_model"]["triple_swap_weekday"] == {"EURUSD": 2}
    assert body["known_limitations"][0].startswith("Swaps are modelled")

    with pytest.raises(ValueError, match="needs external rates"):
        pp.fetch_portfolio_data(replace(config, external_rates=""), profile, fetch=lambda *a: _bars(3))


def test_outside_daily_series_are_fetched_fingerprinted_and_preregistered(tmp_path):
    import json
    from dataclasses import replace

    hours = {str(h): {"samples": 600, "median": 0.3, "p90": 0.3} for h in range(24)}
    profile = tmp_path / "measured_costs_20260914_broker.json"
    profile.write_text(json.dumps({"symbols": {s: {"backtest_spread_pips": 0.3, "hours_observed": 24, "hours": hours}
                                               for s in SYMBOLS}}), encoding="utf-8")
    config = replace(CONFIG, external_daily=("VIX",), bar_features="fred_daily")

    data = pp.fetch_portfolio_data(config, profile, fetch=lambda *a: _bars(3),
                                   fetch_daily=lambda series: {"VIX": [["2011-01-03", 17.6]]})

    assert data.feature_input("fred_daily")["VIX"].value(pp.parse_ts("2011-01-05T00:00:00+00:00").date()) == 17.6
    body = pp._preregistration_body(DEFINITION, config, data, pp.calendar_split(_data().bars, config))
    assert body["external_daily_data"]["series"] == {"VIX": "VIXCLS"}
    assert body["external_daily_data"]["sha256"] == data.external_daily_sha256
    with pytest.raises(ValueError, match="Unknown outside daily series"):
        pp.fetch_portfolio_data(replace(config, external_daily=("OIL",)), profile, fetch=lambda *a: _bars(3))


def test_cftc_positioning_is_fetched_by_year_fingerprinted_and_preregistered(tmp_path):
    import json
    from dataclasses import replace

    hours = {str(h): {"samples": 600, "median": 0.3, "p90": 0.3} for h in range(24)}
    profile = tmp_path / "measured_costs_20260914_broker.json"
    profile.write_text(json.dumps({"symbols": {s: {"backtest_spread_pips": 0.3, "hours_observed": 24, "hours": hours}
                                               for s in SYMBOLS}}), encoding="utf-8")
    config = replace(CONFIG, external_cot=True, cot_first_year=2008, bar_features="cot_positioning")
    years = []

    def fake_cot(requested):
        years.extend(requested)
        return {"EUR": [["2011-01-04", 0.3]]}

    data = pp.fetch_portfolio_data(config, profile, fetch=lambda *a: _bars(3), fetch_cot=fake_cot)

    assert years == list(range(2008, int(CONFIG.data_end[:4]) + 1))
    assert data.feature_input("cot_positioning")["EUR"].value(pp.parse_ts("2011-01-10T00:00:00+00:00").date()) == 0.3
    body = pp._preregistration_body(DEFINITION, config, data, pp.calendar_split(_data().bars, config))
    assert body["cot_data"]["first_year"] == 2008 and body["cot_data"]["sha256"] == data.external_cot_sha256


def test_index_cfds_get_percentage_financing_and_unknown_swap_types_are_refused(monkeypatch):
    entries = {"US500": {"quote_asset": "USD", "base_asset": "US500", "swap_long": -6.15, "swap_short": 1.15,
                         "swap_calculation_type": 1, "swap_rollover3_days": 5, "charge_swap_at_weekends": False,
                         "swap_period": 24, "units_per_lot": 1.0, "pip_size": 1.0},
               "GER40": {"quote_asset": "EUR", "base_asset": "DE40", "swap_long": -5.0, "swap_short": 1.0,
                         "swap_calculation_type": 1, "swap_rollover3_days": 5, "swap_period": 24, "units_per_lot": 1.0}}
    monkeypatch.setattr(pp.instrument_specs, "load_specs", lambda: entries)
    from dataclasses import replace
    from app.quant import external_rates, swap_model

    as_of = external_rates.RatesAsOf({"USD": [["2010-01", 3.0]]}, 0, 3)
    [model] = pp.build_swap_models(replace(CONFIG, symbols=("US500",)), {"US500": _bars(3)}, as_of).values()

    assert isinstance(model, swap_model.IndexFinancingModel)
    assert (model.markup, model.triple_weekday) == (pytest.approx(2.5), 4)
    with pytest.raises(ValueError, match="not modelled"):
        pp.build_swap_models(replace(CONFIG, symbols=("GER40",)), {"GER40": _bars(3)}, as_of)


# --- bar features ---

def test_bar_features_reach_the_trades_but_not_the_preregistered_data(monkeypatch):
    from dataclasses import replace
    import json
    from app.quant import bar_features

    monkeypatch.setitem(bar_features.REGISTRY, "tagged",
                        lambda bars, external=None: {s: [{**b, "tag": s} for b in bs] for s, bs in bars.items()})
    monkeypatch.setitem(bar_features.DESCRIPTIONS, "tagged", "test feature")
    config = replace(CONFIG, bar_features="tagged")
    data = _data()
    seen = []

    def runner(warmup, evaluation, symbol, factory, params, costs, config):
        seen.append(evaluation[0].get("tag") == symbol)
        return FakeTrades(data, train="lose")(warmup, evaluation, symbol, factory, params, costs, config)

    path = pp.preregister(DEFINITION, config, data)
    pp.run_portfolio_experiment(DEFINITION, config, data, trade_runner=runner, walk_forward_runner=_walk_forward())

    assert seen and all(seen)
    assert "tag" not in data.bars["EURUSD"][0]
    assert json.loads(path.read_text(encoding="utf-8"))["bar_features"] == {"name": "tagged", "description": "test feature"}


# --- multiple testing ---

def test_with_the_multiple_testing_guard_an_insignificant_locked_result_is_rejected():
    from dataclasses import replace
    import json

    config = replace(CONFIG, require_multiple_testing_significance=True)
    data = _data()
    path = pp.preregister(DEFINITION, config, data)

    outcome = pp.run_portfolio_experiment(DEFINITION, config, data, trade_runner=FakeTrades(data),
                                          walk_forward_runner=_walk_forward())

    # 48 locked trades averaging +0.2R pass the ordinary gate but are not significant.
    locked = outcome.stages[-1]
    assert outcome.stage_reached == "LOCKED_OUT_OF_SAMPLE" and outcome.decision == "REJECTED"
    assert any("Not significant" in reason for reason in locked.reasons)
    assert locked.metrics["multiple_testing"]["experiments_counted"] == 1
    assert "Bonferroni" in json.loads(path.read_text(encoding="utf-8"))["gates"]["LOCKED_OUT_OF_SAMPLE"]["multiple_testing"]


def test_without_the_guard_the_preregistration_has_no_multiple_testing_rule():
    import json

    path = pp.preregister(DEFINITION, CONFIG, _data())

    assert "multiple_testing" not in json.loads(path.read_text(encoding="utf-8"))["gates"]["LOCKED_OUT_OF_SAMPLE"]


# --- stage gating ---

def test_an_edge_from_one_symbol_fails_breadth_before_validation():
    data = _data()
    trades = FakeTrades(data, strong_symbol="EURUSD")

    outcome = _run(data, trades)

    train = outcome.stages[0]
    assert outcome.decision == "REJECTED" and outcome.stage_reached == "TRAIN"
    assert train.metrics["combos"][0]["expectancy_r"] > 0  # pooled, it looks profitable
    assert any("Breadth" in reason for reason in train.reasons)
    assert set(trades.stages) == {"TRAIN"}


def test_losing_validation_stops_before_walk_forward():
    data = _data()
    calls = []

    outcome = _run(data, FakeTrades(data, validation="lose"), _walk_forward(calls=calls))

    assert outcome.stage_reached == "VALIDATION"
    assert calls == []


def test_failed_walk_forward_leaves_the_locked_data_untouched():
    data = _data()
    trades = FakeTrades(data)

    outcome = _run(data, trades, _walk_forward(positive=False))

    assert outcome.stage_reached == "WALK_FORWARD" and outcome.decision == "REJECTED"
    assert "LOCKED" not in trades.stages
    assert not locked_oos_guard.has_been_consumed(pp.candidate_id_for(DEFINITION, CONFIG))


def test_a_candidate_passing_everything_uses_its_one_locked_look():
    data = _data()

    outcome = _run(data, FakeTrades(data))

    assert outcome.decision == "ACCEPTED"
    assert locked_oos_guard.has_been_consumed(pp.candidate_id_for(DEFINITION, CONFIG))
    locked = [r for r in strategy_registry.get_results("test-trend", "1.0.0") if r["test_type"].startswith("LOCKED_OUT_OF_SAMPLE")]
    assert locked[-1]["scorecard"]["validated"] is True
    assert locked[-1]["symbol"] == "ALL"
