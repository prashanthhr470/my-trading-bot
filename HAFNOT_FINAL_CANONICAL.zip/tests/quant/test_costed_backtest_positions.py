"""
The engine records a trade for every signal even while an earlier one is still
open. These tests pin the max_open_positions limit that makes a backtest respect
the live one-position-per-symbol rule.
"""

import pytest

from app.quant.costed_backtest import MAX_OPEN_POSITIONS_REASON, run_costed_backtest


def _rising_bars(count):
    # Price rises 1.0 per bar, so a +4 target is hit exactly 4 bars after entry and a -2 stop never is.
    return [
        {"open": 2000.0 + i, "high": 2000.5 + i, "low": 1999.5 + i, "close": 2000.0 + i}
        for i in range(count)
    ]


def _every_bar_valid(visible_bars, index):
    close = visible_bars[-1]["close"]
    return {"direction": "BUY", "entry": close, "stop_loss": close - 2.0, "take_profit": close + 4.0}


def _odd_valid_even_rejected(visible_bars, index):
    close = visible_bars[-1]["close"]
    if index % 2:
        return {"direction": "BUY", "entry": close, "stop_loss": close - 2.0, "take_profit": close + 4.0}
    # A 400-dollar stop cannot be sized above the 0.01 minimum lot, so risk sizing rejects it.
    return {"direction": "BUY", "entry": close, "stop_loss": close - 400.0, "take_profit": close + 4.0}


def test_default_is_one_position_per_symbol_like_live_trading():
    result = run_costed_backtest(_rising_bars(40), _every_bar_valid, "XAUUSD")

    for earlier, later in zip(result.trades, result.trades[1:]):
        assert later.entry_index >= earlier.exit_index
    assert result.rejection_reasons[MAX_OPEN_POSITIONS_REASON] > 0


def test_unlimited_mode_reproduces_the_historical_overlapping_behaviour():
    result = run_costed_backtest(_rising_bars(40), _every_bar_valid, "XAUUSD", max_open_positions=None)

    assert result.accepted_trade_count > 10
    overlapping = sum(
        1 for earlier, later in zip(result.trades, result.trades[1:])
        if later.entry_index < earlier.exit_index
    )
    assert overlapping > 0
    assert MAX_OPEN_POSITIONS_REASON not in result.rejection_reasons


def test_one_position_limit_never_holds_overlapping_trades():
    result = run_costed_backtest(_rising_bars(40), _every_bar_valid, "XAUUSD", max_open_positions=1)

    for earlier, later in zip(result.trades, result.trades[1:]):
        assert later.entry_index >= earlier.exit_index
    assert [t.entry_index for t in result.trades][:3] == [0, 4, 8]
    assert result.rejection_reasons[MAX_OPEN_POSITIONS_REASON] > 0


def test_a_trade_rejected_by_risk_sizing_does_not_occupy_the_slot():
    result = run_costed_backtest(_rising_bars(40), _odd_valid_even_rejected, "XAUUSD", max_open_positions=1)

    # Had the rejected bar-0 trade taken the slot until bar 4, the first accepted entry would be bar 5.
    assert result.trades[0].entry_index == 1
    assert result.trades[1].entry_index == 5
    assert result.rejection_reasons.get("POSITION_BELOW_MIN_LOT", 0) > 0 or any(
        "LOT" in reason for reason in result.rejection_reasons
    )


def test_invalid_limit_is_refused():
    with pytest.raises(ValueError):
        run_costed_backtest(_rising_bars(10), _every_bar_valid, "XAUUSD", max_open_positions=0)
