"""Walk-forward generalised beyond the EMA strategy: any factory, custom selection, position limits."""

from app.quant.walk_forward import highest_expectancy, parameter_combinations, run_walk_forward


def _rising_bars(count):
    return [
        {"open": 2000.0 + i, "high": 2000.5 + i, "low": 1999.5 + i, "close": 2000.0 + i}
        for i in range(count)
    ]


def _factory(params):
    target = params["target"]
    if target == 6.0:
        raise ValueError("invalid combination for this test")

    def provider(visible_bars, index):
        if index % 10:
            return None
        close = visible_bars[-1]["close"]
        return {"direction": "BUY", "entry": close, "stop_loss": close - 2.0, "take_profit": close + target}

    return provider


def test_parameter_combinations_expand_the_grid():
    assert parameter_combinations(None) == [{}]
    assert parameter_combinations({"a": [1, 2], "b": [3]}) == [{"a": 1, "b": 3}, {"a": 2, "b": 3}]


def test_walk_forward_accepts_any_strategy_factory():
    result = run_walk_forward(
        _rising_bars(600), "XAUUSD",
        param_grid={"target": [4.0, 8.0]},
        in_sample_bars=200, out_of_sample_bars=80,
        signal_provider_factory=_factory,
    )

    assert len(result.windows) == 5
    for window in result.windows:
        assert window.in_sample_size == 200
        assert window.out_of_sample_size == 80
        assert window.chosen_params["target"] in (4.0, 8.0)
        assert window.out_of_sample_trade_count > 0


def test_invalid_combinations_are_skipped_and_never_chosen():
    result = run_walk_forward(
        _rising_bars(600), "XAUUSD",
        param_grid={"target": [6.0, 4.0]},
        in_sample_bars=200, out_of_sample_bars=80,
        signal_provider_factory=_factory,
    )

    assert result.windows
    assert all(window.chosen_params["target"] == 4.0 for window in result.windows)


def test_custom_selector_is_honoured():
    always_eight = lambda scored: next(p for p, _, _ in scored if p["target"] == 8.0)

    result = run_walk_forward(
        _rising_bars(600), "XAUUSD",
        param_grid={"target": [4.0, 8.0]},
        in_sample_bars=200, out_of_sample_bars=80,
        signal_provider_factory=_factory,
        select_params=always_eight,
    )

    assert all(window.chosen_params["target"] == 8.0 for window in result.windows)


def test_highest_expectancy_ignores_combinations_without_trades():
    scored = [({"a": 1}, None, 0), ({"a": 2}, 0.1, 30), ({"a": 3}, 0.4, 30)]
    assert highest_expectancy(scored) == {"a": 3}
    assert highest_expectancy([({"a": 1}, None, 0)]) is None
