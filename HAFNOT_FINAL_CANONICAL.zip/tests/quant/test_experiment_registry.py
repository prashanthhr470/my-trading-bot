import pytest

from app.quant import experiment_registry as er


@pytest.fixture(autouse=True)
def _tmp_experiments(tmp_path, monkeypatch):
    monkeypatch.setattr(er, "EXPERIMENTS_FILE", tmp_path / "experiments.jsonl")
    yield


def _record(experiment_id, decision, **overrides):
    payload = dict(
        experiment_id=experiment_id,
        hypothesis="Test hypothesis",
        strategy_id="test-strategy",
        strategy_version="1.0.0",
        symbols=["XAUUSD"],
        timeframe="H1",
        parameters={"x": 1},
        result={"net_pnl_usd": -10.0},
        decision=decision,
    )
    payload.update(overrides)
    return er.record_experiment(**payload)


def test_record_and_list_round_trips():
    _record("exp-1", "REJECTED")
    _record("exp-2", "ACCEPTED")

    experiments = er.list_experiments()
    assert len(experiments) == 2
    assert experiments[0]["experiment_id"] == "exp-1"
    assert experiments[1]["decision"] == "ACCEPTED"


def test_invalid_decision_is_refused():
    with pytest.raises(ValueError):
        _record("exp-bad", "LOOKS_GREAT")


def test_rejected_experiments_are_preserved_not_hidden():
    for i in range(5):
        _record(f"exp-{i}", "REJECTED", result={"net_pnl_usd": -100.0 * i})

    experiments = er.list_experiments()
    assert len(experiments) == 5
    assert all(e["decision"] == "REJECTED" for e in experiments)


def test_empty_registry_does_not_claim_no_experiments_were_run():
    report = er.selection_bias_report()
    assert report.experiment_count == 0
    assert report.family_wise_error_probability is None
    assert "does NOT mean no experiments were run" in report.interpretation


def test_family_wise_error_grows_with_experiment_count():
    for i in range(20):
        _record(f"exp-{i}", "REJECTED")

    report = er.selection_bias_report(alpha=0.05)

    assert report.experiment_count == 20
    # 1 - 0.95^20 = 0.6415
    assert report.family_wise_error_probability == pytest.approx(0.6415, abs=1e-3)
    assert report.bonferroni_alpha == pytest.approx(0.0025)
    assert report.expected_false_positives == pytest.approx(1.0)


def test_no_accepted_experiments_means_no_selection_problem():
    for i in range(10):
        _record(f"exp-{i}", "REJECTED")

    report = er.selection_bias_report()
    assert report.accepted_count == 0
    assert "no winner was chosen" in report.interpretation


def test_single_winner_among_many_is_called_indistinguishable_from_noise():
    # 40 experiments at alpha=0.05 -> 2.0 expected false positives, so a
    # single acceptance must NOT be treated as a real finding.
    for i in range(39):
        _record(f"exp-{i}", "REJECTED")
    _record("exp-winner", "ACCEPTED", result={"net_pnl_usd": 900.0})

    report = er.selection_bias_report(alpha=0.05)

    assert report.accepted_count == 1
    assert report.expected_false_positives == pytest.approx(2.0)
    assert "NOT distinguishable from noise" in report.interpretation


def test_many_survivors_beyond_chance_is_encouraging_but_not_conclusive():
    for i in range(10):
        _record(f"exp-rej-{i}", "REJECTED")
    for i in range(5):
        _record(f"exp-acc-{i}", "ACCEPTED")

    # 15 experiments -> 0.75 expected false positives; 5 accepted exceeds that.
    report = er.selection_bias_report(alpha=0.05)

    assert report.accepted_count == 5
    assert "more survivors than chance" in report.interpretation
    assert "not conclusive" in report.interpretation


def test_counts_split_across_all_three_decisions():
    _record("a", "ACCEPTED")
    _record("b", "REJECTED")
    _record("c", "INCONCLUSIVE")

    report = er.selection_bias_report()
    assert (report.accepted_count, report.rejected_count, report.inconclusive_count) == (1, 1, 1)
