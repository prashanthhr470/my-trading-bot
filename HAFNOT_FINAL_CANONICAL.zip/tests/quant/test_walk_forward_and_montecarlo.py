import json
from pathlib import Path

import pytest

from app.quant.costed_backtest import run_costed_backtest
from app.quant.monte_carlo import resample_trade_sequence
from app.quant.robustness import run_robustness_sweep
from app.quant.strategy_adapter import make_signal_provider
from app.quant.walk_forward import run_walk_forward

DATA_FILE = Path(__file__).resolve().parents[2] / "data" / "xauusd_historical_batch10.json"


def _real_bars():
    data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    return data["H4"]["bars"]


@pytest.mark.skipif(not DATA_FILE.exists(), reason="real historical data file not present")
def test_walk_forward_runs_on_real_data_and_windows_are_disjoint():

    bars = _real_bars()

    result = run_walk_forward(
        bars=bars,
        symbol="XAUUSD",
        param_grid={"fast_ema_period": [8, 13], "slow_ema_period": [21, 34]},
        in_sample_bars=200,
        out_of_sample_bars=80,
    )

    assert result.symbol == "XAUUSD"
    assert len(result.windows) >= 1

    for window in result.windows:
        assert window.in_sample_size == 200
        assert window.out_of_sample_size == 80
        # Chosen params must be one of the grid combinations actually tried.
        assert window.chosen_params["fast_ema_period"] in (8, 13)
        assert window.chosen_params["slow_ema_period"] in (21, 34)

    # positive_window_fraction/mean_expectancy must not raise even if some
    # windows produced no trades (expectancy None is filtered, not crashed).
    _ = result.positive_window_fraction
    _ = result.mean_out_of_sample_expectancy_r


def test_monte_carlo_resamples_a_real_pnl_sequence_deterministically():

    # A real (small, synthetic-for-this-test-only) sequence of trade PnLs -
    # deliberately not a fabricated "looks good" curve, just numbers with
    # both wins and losses to exercise drawdown/ruin math.
    pnl_sequence = [120.0, -80.0, 150.0, -200.0, 90.0, -60.0, 300.0, -150.0]

    result_a = resample_trade_sequence(pnl_sequence, starting_equity_usd=10_000.0, trials=500, seed=42)
    result_b = resample_trade_sequence(pnl_sequence, starting_equity_usd=10_000.0, trials=500, seed=42)

    # Same seed must reproduce identical output (auditable, not flaky).
    assert result_a == result_b

    assert result_a.trial_count == 500
    assert result_a.final_equity_p05 <= result_a.final_equity_p50 <= result_a.final_equity_p95
    assert 0.0 <= result_a.probability_of_ruin <= 1.0
    assert result_a.max_drawdown_p50_usd >= 0.0


def test_monte_carlo_handles_empty_sequence_without_crashing():
    result = resample_trade_sequence([], starting_equity_usd=10_000.0)
    assert result.trial_count == 0
    assert result.final_equity_p50 == 10_000.0


@pytest.mark.skipif(not DATA_FILE.exists(), reason="real historical data file not present")
def test_robustness_sweep_runs_a_real_parameter_grid_on_real_data():

    bars = _real_bars()

    result = run_robustness_sweep(
        bars=bars,
        symbol="XAUUSD",
        param_grid={"fast_ema_period": [8, 13], "slow_ema_period": [21, 34]},
    )

    assert result.symbol == "XAUUSD"
    assert len(result.results) == 4  # 2x2 grid
    assert 0.0 <= result.profitable_fraction <= 1.0
