"""
Daily trend families: Donchian channel breakout and time-series momentum. Both
must use only closed, visible bars, place stop and target at fixed ATR/R
distances, and refuse bad parameters.
"""

import pytest

from app.quant import donchian_trend_strategy as donchian
from app.quant import time_series_momentum_strategy as tsmom
from app.quant.features import average_true_range, fixed_r_levels


def _bar(close, spread=1.0):
    return {"open": close, "high": close + spread, "low": close - spread, "close": close}


def _flat(count, price=100.0):
    return [_bar(price) for _ in range(count)]


# --- shared level helper ---

def test_fixed_r_levels_place_stop_and_target_on_the_right_sides():
    assert fixed_r_levels("BUY", 100.0, 2.0, 3.0) == (98.0, 106.0)
    assert fixed_r_levels("SELL", 100.0, 2.0, 3.0) == (102.0, 94.0)


# --- Donchian ---

PARAMS = dict(channel_bars=10, stop_atr=2.0, atr_period=5, target_r=3.0)


def test_a_close_above_the_prior_channel_buys_with_atr_stop_and_r_target():
    bars = _flat(10) + [_bar(105.0)]

    signal = donchian.evaluate(bars, **PARAMS)

    atr = average_true_range(bars[-6:], 5)
    assert signal["direction"] == "BUY"
    assert signal["channel_high"] == 101.0
    assert signal["stop_loss"] == pytest.approx(105.0 - 2.0 * atr)
    assert signal["take_profit"] == pytest.approx(105.0 + 3.0 * 2.0 * atr)


def test_a_close_below_the_prior_channel_sells():
    assert donchian.evaluate(_flat(10) + [_bar(95.0)], **PARAMS)["direction"] == "SELL"


def test_a_close_inside_the_channel_does_nothing():
    assert donchian.evaluate(_flat(10) + [_bar(100.5)], **PARAMS) is None


def test_the_current_bar_never_defines_its_own_channel():
    # The current bar's own high is 106; only the prior bars (high 101) form the channel.
    assert donchian.evaluate(_flat(10) + [_bar(105.0)], **PARAMS)["channel_high"] == 101.0


def test_too_little_history_does_nothing():
    assert donchian.evaluate(_flat(9) + [_bar(105.0)], **PARAMS) is None


def test_donchian_refuses_bad_parameters():
    with pytest.raises(ValueError):
        donchian.make_signal_provider(channel_bars=1)
    with pytest.raises(ValueError):
        donchian.make_signal_provider(target_r=0)
    with pytest.raises(ValueError):
        donchian.make_signal_provider(not_a_parameter=3)


def test_donchian_provider_uses_only_the_bars_it_is_given():
    bars = _flat(10) + [_bar(105.0)] + [_bar(50.0)] * 5
    provider = donchian.make_signal_provider(**PARAMS)

    assert provider(bars[:11], 10) == donchian.evaluate(bars[:11], **PARAMS)


# --- time-series momentum ---

MOMENTUM = dict(lookback=10, stop_atr=2.0, atr_period=5, target_r=3.0)


def test_a_higher_close_than_lookback_bars_ago_buys():
    bars = [_bar(100.0 + i) for i in range(11)]

    signal = tsmom.evaluate(bars, **MOMENTUM)

    assert signal["direction"] == "BUY"
    assert signal["lookback_return"] == pytest.approx(110.0 / 100.0 - 1.0)
    assert signal["take_profit"] - signal["entry"] == pytest.approx(3.0 * (signal["entry"] - signal["stop_loss"]))


def test_a_lower_close_sells_and_an_equal_close_does_nothing():
    assert tsmom.evaluate([_bar(110.0 - i) for i in range(11)], **MOMENTUM)["direction"] == "SELL"
    assert tsmom.evaluate(_flat(11), **MOMENTUM) is None


def test_momentum_needs_the_full_lookback():
    assert tsmom.evaluate([_bar(100.0 + i) for i in range(10)], **MOMENTUM) is None


def test_momentum_refuses_bad_parameters():
    with pytest.raises(ValueError):
        tsmom.make_signal_provider(lookback=0)
    with pytest.raises(ValueError):
        tsmom.make_signal_provider(stop_atr=-1)
