import uuid

import pytest

from app.quant import promotion


def _fresh_candidate():
    candidate_id = f"test-{uuid.uuid4().hex[:8]}"
    candidate = promotion.create_candidate(candidate_id, "EURUSD", {"fast_ema_period": 8})
    yield candidate
    # Cleanup: remove the JSON file this test created.
    promotion._path(candidate_id).unlink(missing_ok=True)


@pytest.fixture
def candidate():
    yield from _fresh_candidate()


def test_new_candidate_starts_at_research(candidate):
    assert candidate.current_stage == "RESEARCH"
    assert candidate.history == []


def test_candidate_persists_and_reloads(candidate):
    reloaded = promotion.load_candidate(candidate.candidate_id)
    assert reloaded.candidate_id == candidate.candidate_id
    assert reloaded.symbol == "EURUSD"


def test_cannot_create_duplicate_candidate_id(candidate):
    with pytest.raises(ValueError):
        promotion.create_candidate(candidate.candidate_id, "EURUSD", {})


def test_submit_stage_result_wrong_stage_is_rejected_with_error(candidate):
    # Candidate is at RESEARCH, not BACKTEST - RESEARCH has no gate of its
    # own (it is the entry stage), so submitting BACKTEST evidence while
    # still at RESEARCH must raise rather than silently skip ahead.
    with pytest.raises(ValueError):
        promotion.submit_stage_result(
            candidate,
            "BACKTEST",
            trades=[{"pnl_usd": 10.0, "result_r": 0.5}],
            initial_equity=10_000.0,
        )


def test_failing_gate_moves_candidate_to_rejected_and_stays_there(candidate):
    # Manually advance past RESEARCH by editing current_stage, since
    # RESEARCH itself has no gate to pass through in this test.
    candidate.current_stage = "BACKTEST"

    # Too few trades and a losing sample - must fail the BACKTEST gate.
    losing_trades = [{"pnl_usd": -10.0, "result_r": -1.0} for _ in range(5)]

    result = promotion.submit_stage_result(
        candidate, "BACKTEST", trades=losing_trades, initial_equity=10_000.0,
    )

    assert result.current_stage == "REJECTED"
    assert result.history[-1]["passed"] is False

    # A rejected candidate cannot be advanced further.
    with pytest.raises(ValueError):
        promotion.submit_stage_result(
            result, "BACKTEST", trades=losing_trades, initial_equity=10_000.0,
        )


def test_passing_gate_advances_candidate_to_next_stage(candidate):
    candidate.current_stage = "BACKTEST"

    # 100 wins + 20 losses: a mixed sample (an all-wins sample makes
    # profit_factor undefined - see summarize_trades - and correctly fails
    # the gate, as covered by test_failing_gate... above with an
    # all-losses sample). Comfortably clears every BACKTEST threshold.
    trades = (
        [{"pnl_usd": 50.0, "result_r": 1.0} for _ in range(100)]
        + [{"pnl_usd": -10.0, "result_r": -0.2} for _ in range(20)]
    )

    result = promotion.submit_stage_result(
        candidate, "BACKTEST", trades=trades, initial_equity=10_000.0,
    )

    assert result.current_stage == "OUT_OF_SAMPLE"
    assert result.history[-1]["passed"] is True


# --- Phase J: CONTINUOUS_MONITORING / REVIEW_REQUIRED backward transitions ---

def test_new_trades_allowed_true_for_mid_pipeline_stages(candidate):
    assert promotion.new_trades_allowed(candidate) is True


def test_enter_continuous_monitoring_requires_validated_stage(candidate):
    with pytest.raises(ValueError):
        promotion.enter_continuous_monitoring(candidate)

    candidate.current_stage = "VALIDATED"
    result = promotion.enter_continuous_monitoring(candidate)
    assert result.current_stage == "CONTINUOUS_MONITORING"
    assert promotion.new_trades_allowed(result) is True


def test_flag_performance_degradation_moves_to_review_required(candidate):
    candidate.current_stage = "VALIDATED"
    promotion.enter_continuous_monitoring(candidate)

    result = promotion.flag_performance_degradation(
        candidate,
        reasons=["Rolling expectancy fell below validated baseline for 3 consecutive weeks."],
        evidence={"rolling_expectancy_r": -0.05, "validated_expectancy_r": 0.08},
    )

    assert result.current_stage == "REVIEW_REQUIRED"
    assert promotion.new_trades_allowed(result) is False


def test_flag_performance_degradation_allowed_from_demo_forward_directly():
    """The spec's own example: DEMO PERFORMANCE DEGRADES -> REVIEW_REQUIRED,
    without necessarily having reached full VALIDATED/CONTINUOUS_MONITORING first."""

    candidate_id = f"test-{uuid.uuid4().hex[:8]}"
    candidate = promotion.create_candidate(candidate_id, "EURUSD", {})
    candidate.current_stage = "DEMO_FORWARD"

    try:
        result = promotion.flag_performance_degradation(
            candidate, reasons=["Demo drawdown exceeded validated maximum."], evidence={},
        )
        assert result.current_stage == "REVIEW_REQUIRED"
    finally:
        promotion._path(candidate_id).unlink(missing_ok=True)


def test_review_required_is_terminal_like_rejected(candidate):
    candidate.current_stage = "VALIDATED"
    promotion.enter_continuous_monitoring(candidate)
    promotion.flag_performance_degradation(candidate, reasons=["degraded"], evidence={})

    with pytest.raises(ValueError):
        promotion.flag_performance_degradation(candidate, reasons=["again"], evidence={})


def test_degradation_cannot_be_flagged_from_research_stage(candidate):
    # RESEARCH is not in DEGRADABLE_STAGES - degradation only applies once
    # a candidate has actually been trading forward (paper/demo/monitored).
    with pytest.raises(ValueError):
        promotion.flag_performance_degradation(candidate, reasons=["n/a"], evidence={})


def test_no_automatic_reactivation_after_review_required(candidate):
    """Phase L: strategy modification must return to a NEW candidate_id,
    never mutate a REVIEW_REQUIRED candidate back into a tradeable stage."""

    candidate.current_stage = "VALIDATED"
    promotion.enter_continuous_monitoring(candidate)
    result = promotion.flag_performance_degradation(candidate, reasons=["degraded"], evidence={})

    assert result.current_stage == "REVIEW_REQUIRED"
    # No function in this module moves a candidate OUT of REVIEW_REQUIRED -
    # confirmed by absence of any such API; new_trades_allowed stays False
    # for this candidate_id permanently.
    assert promotion.new_trades_allowed(result) is False
