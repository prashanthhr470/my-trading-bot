"""
Market-structure strategies: swings are confirmed only after their right-hand bars
close, the pullback and break-retest setups fire on the exact rules, and SELL mirrors BUY.
"""

import pytest

from app.quant import market_structure_pullback_strategy as pullback
from app.quant import structure_break_retest_strategy as retest
from app.quant.features import average_true_range
from app.quant.market_structure import SwingTracker


def _bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c}


def _mirror(bars, pivot=30.0):
    return [_bar(pivot - b["open"], pivot - b["low"], pivot - b["high"], pivot - b["close"]) for b in bars]


def test_a_swing_is_confirmed_only_after_its_right_hand_bars_close():
    bars = [_bar(1, h, 0.5, 1) for h in (1, 2, 5, 2, 1, 1)]
    tracker = SwingTracker(2)

    tracker.update(bars, 3)
    assert tracker.highs == []
    tracker.update(bars, 4)
    assert tracker.highs == [(2, 5.0)]


def test_the_tracker_catches_up_when_bars_are_skipped_and_restarts_on_a_new_replay():
    bars = [_bar(1, h, l, 1) for h, l in ((11, 9), (13, 10), (12, 8), (15, 9), (14, 8.5), (14.5, 9.5), (14, 9.6))]
    stepwise, jumped = SwingTracker(1), SwingTracker(1)
    for last in range(len(bars)):
        stepwise.update(bars, last)
    jumped.update(bars, len(bars) - 1)

    # Bar 5 (14.5) is a swing high too: above bar 4, and bar 6 has closed at or below it.
    assert stepwise.highs == jumped.highs == [(1, 13.0), (3, 15.0), (5, 14.5)]
    assert stepwise.lows == jumped.lows == [(2, 8.0), (4, 8.5)]
    jumped.update(bars, 1)
    assert jumped.highs == [] and jumped.lows == []


# Higher highs 13 -> 15, higher lows 8 -> 8.5, then a bullish rejection at the 8.5 low.
UPTREND = [
    _bar(10, 11, 9, 10), _bar(10, 13, 10, 12), _bar(12, 12, 8, 9), _bar(9, 15, 9, 14),
    _bar(14, 14, 8.5, 9), _bar(9, 14.5, 9.5, 10), _bar(9.0, 9.8, 8.6, 9.6),
]
PULLBACK_RULES = {"zone_atr": 0.1, "stop_atr": 0.5, "atr_period": 2, "target_r": 2.0}


def test_a_rejected_pullback_to_the_higher_low_is_bought_with_the_stop_below_it():
    signal = pullback.evaluate(UPTREND, SwingTracker(1), **PULLBACK_RULES)
    atr = average_true_range(UPTREND[-3:], 2)

    assert signal["direction"] == "BUY"
    assert signal["structure_level"] == 8.5
    assert signal["stop_loss"] == pytest.approx(8.5 - 0.5 * atr)
    assert signal["take_profit"] == pytest.approx(9.6 + 2.0 * (9.6 - signal["stop_loss"]))


def test_no_pullback_trade_without_a_bullish_rejection():
    bearish = UPTREND[:-1] + [_bar(9.7, 9.8, 8.6, 9.0)]

    assert pullback.evaluate(bearish, SwingTracker(1), **PULLBACK_RULES) is None


def test_the_pullback_sell_mirrors_the_buy():
    signal = pullback.evaluate(_mirror(UPTREND), SwingTracker(1), **PULLBACK_RULES)

    assert signal["direction"] == "SELL"
    assert signal["structure_level"] == pytest.approx(21.5)


# Swing high 13 at bar 1, broken by the close at bar 3, held, then retested and rejected.
BREAK = [
    _bar(10, 11, 9, 10.5), _bar(10.5, 13, 10, 12.5), _bar(12.5, 12, 11, 11.5),
    _bar(12.6, 14, 12.5, 13.5), _bar(13.5, 14.5, 13.2, 14.0), _bar(13.8, 14.2, 13.1, 14.1),
]
RETEST_RULES = {"retest_bars": 20, "zone_atr": 0.5, "stop_atr": 0.5, "atr_period": 2, "target_r": 2.0}


def test_a_held_break_retested_and_rejected_is_bought_with_the_stop_below_the_level():
    signal = retest.evaluate(BREAK, SwingTracker(1), **RETEST_RULES)
    atr = average_true_range(BREAK[-3:], 2)

    assert signal["direction"] == "BUY"
    assert signal["structure_level"] == 13.0
    assert signal["stop_loss"] == pytest.approx(13.0 - 0.5 * atr)


def test_no_retest_trade_when_price_closed_back_below_the_level():
    failed = BREAK[:4] + [_bar(13.5, 13.6, 12.7, 12.9), BREAK[5]]

    assert retest.evaluate(failed, SwingTracker(1), **RETEST_RULES) is None


def test_no_retest_trade_when_the_break_is_older_than_retest_bars():
    assert retest.evaluate(BREAK, SwingTracker(1), **{**RETEST_RULES, "retest_bars": 1}) is None


def test_the_retest_sell_mirrors_the_buy():
    signal = retest.evaluate(_mirror(BREAK), SwingTracker(1), **RETEST_RULES)

    assert signal["direction"] == "SELL"
    assert signal["structure_level"] == pytest.approx(17.0)


def test_providers_build_from_their_defaults():
    for module in (pullback, retest):
        provider = module.make_signal_provider(**module.DEFAULTS)
        assert provider(UPTREND, len(UPTREND) - 1) is None or provider(UPTREND, len(UPTREND) - 1)["direction"]
