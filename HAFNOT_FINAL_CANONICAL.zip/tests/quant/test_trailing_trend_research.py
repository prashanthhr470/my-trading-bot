"""
Trailing-exit trend research: the costed backtest must price a trailing trade at
the price it actually left (not its distant target), the strategies must emit the
trailing distance only when asked, and the v2 series must differ from v1 only in
its exits.
"""

from dataclasses import replace

import pytest

import hafnot_run_research_pipeline as runner
from app.forex_v2.risk import RiskConfig
from app.quant import donchian_trend_strategy as donchian
from app.quant import time_series_momentum_strategy as tsmom
from app.quant.costed_backtest import run_costed_backtest
from app.quant.features import average_true_range


def _bar(close, spread=1.0):
    return {"open": close, "high": close + spread, "low": close - spread, "close": close}


def test_a_trailing_trade_is_costed_at_its_real_exit_not_its_distant_target():
    signal = {"direction": "BUY", "entry": 2000.0, "stop_loss": 1990.0, "take_profit": 2100.0, "trailing_stop_distance": 10.0}
    bars = [{"open": 2000, "high": 2000, "low": 2000, "close": 2000},
            {"open": 2001, "high": 2030, "low": 2001, "close": 2029},
            {"open": 2029, "high": 2029, "low": 2015, "close": 2016}]

    result = run_costed_backtest(bars, lambda v, i: signal if i == 0 else None, "XAUUSD",
                                 risk_config=RiskConfig(slippage_pips_per_side=0.0), assumed_spread_pips=0.0)

    [trade] = result.trades
    assert trade.exit_fill_price == pytest.approx(2020.0)
    assert trade.result_r > 0


def test_strategies_emit_a_trailing_distance_only_when_asked():
    bars = [_bar(100.0) for _ in range(10)] + [_bar(105.0)]
    fixed = donchian.evaluate(bars, channel_bars=10, stop_atr=2.0, atr_period=5, target_r=3.0)
    trailing = donchian.evaluate(bars, channel_bars=10, stop_atr=2.0, atr_period=5, target_r=10.0, trail_atr=3.0)
    atr = average_true_range(bars[-6:], 5)

    assert "trailing_stop_distance" not in fixed
    assert trailing["trailing_stop_distance"] == pytest.approx(3.0 * atr)
    assert trailing["entry"] - trailing["stop_loss"] == pytest.approx(3.0 * atr)

    rising = [_bar(100.0 + i) for i in range(11)]
    momentum = tsmom.evaluate(rising, lookback=10, stop_atr=2.0, atr_period=5, target_r=10.0, trail_atr=2.0)
    assert momentum["trailing_stop_distance"] == pytest.approx(momentum["entry"] - momentum["stop_loss"])


def test_negative_trailing_distance_is_refused():
    with pytest.raises(ValueError):
        donchian.make_signal_provider(trail_atr=-1.0)
    with pytest.raises(ValueError):
        tsmom.make_signal_provider(trail_atr=-1.0)


def test_the_trailing_series_differs_from_v1_only_in_its_exits():
    v1, _ = runner.PORTFOLIO_SERIES["portfolio-d1-v1"]
    v2, families = runner.PORTFOLIO_SERIES["portfolio-d1-v2-trailing"]

    assert replace(v2, series=v1.series, close_open_trades_at_slice_end=False) == v1
    assert v2.close_open_trades_at_slice_end is True
    for family in families:
        assert min(family.param_grid["trail_atr"]) > 0
        assert family.fixed_params["target_r"] >= 1.5
        assert not set(family.param_grid) & set(family.fixed_params)
        assert family.strategy_id not in {f.strategy_id for f in runner.DAILY_TREND_FAMILIES}
