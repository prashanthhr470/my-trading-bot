"""
The 2026-09-14 idea batch: the engine's time exit, cross-market bar features, and the
currency-strength, weekday-hour seasonality and shock-day continuation rules.
"""

from datetime import datetime, timedelta, timezone

import pytest

from app.backtest.engine import BacktestEngine
from app.quant import bar_features
from app.quant import currency_strength_strategy as strength
from app.quant import shock_day_continuation_strategy as shock
from app.quant import weekday_hour_seasonality_strategy as seasonality
from app.quant.features import average_true_range


def _bar(o, h, l, c, **extra):
    return {"open": o, "high": h, "low": l, "close": c, **extra}


# --- engine time exit ---

def _once(signal):
    return lambda visible, index: signal if index == 0 else None


FLAT = [_bar(1.0, 1.01, 0.99, 1.0), _bar(1.0, 1.02, 0.99, 1.015), _bar(1.015, 1.03, 1.0, 1.02)]


def test_a_time_exit_closes_at_the_close_of_the_holding_bar():
    signal = {"direction": "BUY", "entry": 1.0, "stop_loss": 0.95, "take_profit": 1.5, "exit_after_bars": 1}

    [trade] = BacktestEngine().run(FLAT, _once(signal), "EURUSD")["trades"]

    assert trade["exit_reason"] == "TIME" and trade["exit_index"] == 1
    assert trade["exit_price"] == 1.015 and trade["result_r"] == pytest.approx(0.3)


def test_the_stop_still_wins_before_the_time_exit_and_no_hold_keeps_the_old_behaviour():
    stopped = {"direction": "BUY", "entry": 1.0, "stop_loss": 0.995, "take_profit": 1.5, "exit_after_bars": 2}
    [trade] = BacktestEngine().run(FLAT, _once(stopped), "EURUSD")["trades"]
    assert trade["exit_reason"] == "STOP" and trade["exit_index"] == 1

    no_hold = {"direction": "BUY", "entry": 1.0, "stop_loss": 0.95, "take_profit": 1.5}
    assert BacktestEngine().run(FLAT, _once(no_hold), "EURUSD")["trades"] == []


# --- bar features ---

def _fx_bars(closes_by_pair, timestamps):
    return {pair: [_bar(c, c * 1.01, c * 0.99, c, timestamp=t) for c, t in zip(closes, timestamps)]
            for pair, closes in closes_by_pair.items()}


TIMES = ["2020-01-01T22:00:00+00:00", "2020-01-02T22:00:00+00:00"]
CLOSES = {"EURUSD": [1.0, 1.02], "GBPUSD": [1.0, 1.01], "AUDUSD": [1.0, 0.99], "NZDUSD": [1.0, 0.98],
          "USDJPY": [100.0, 103.0], "USDCHF": [1.0, 1.0], "USDCAD": [1.0, 1.005]}


def test_currency_strength_features_are_same_day_closes_on_copies():
    original = _fx_bars(CLOSES, TIMES)
    original["XAUUSD"] = [_bar(1, 1, 1, 1, timestamp=TIMES[1])]

    enriched = bar_features.enrich("currency_strength", original)

    assert enriched["EURUSD"][1]["fx_closes"]["USDJPY"] == 103.0
    assert enriched["XAUUSD"][0]["fx_closes"]["EURUSD"] == 1.02 and enriched["XAUUSD"][0]["symbol"] == "XAUUSD"
    assert "fx_closes" not in original["EURUSD"][1]
    with pytest.raises(ValueError, match="missing"):
        bar_features.enrich("currency_strength", {"EURUSD": original["EURUSD"]})


# --- currency strength ---
# EUR +2%, GBP +1%, AUD -1%, NZD -2%, JPY -3%, CHF 0, CAD -0.5%  ->  USD about +0.5%.
# Ranked: EUR, GBP, USD, CHF, CAD, AUD, NZD, JPY.

@pytest.mark.parametrize("pair, expected", [("EURUSD", "BUY"), ("GBPUSD", "BUY"), ("NZDUSD", "SELL"),
                                            ("USDJPY", "BUY"), ("USDCHF", None), ("AUDUSD", None)])
def test_the_strongest_currencies_are_bought_and_the_weakest_sold_against_usd(pair, expected):
    enriched = bar_features.enrich("currency_strength", _fx_bars(CLOSES, TIMES))

    signal = strength.evaluate(enriched[pair], lookback=1, top_k=2, atr_period=1, trail_atr=3.0, target_r=10.0)

    assert (signal or {}).get("direction") == expected
    if signal:
        assert signal["trailing_stop_distance"] == pytest.approx(3.0 * average_true_range(enriched[pair][-2:], 1))


def test_no_strength_signal_when_a_major_is_missing_that_day():
    enriched = bar_features.enrich("currency_strength", _fx_bars(CLOSES, TIMES))
    del enriched["EURUSD"][1]["fx_closes"]["USDCAD"]

    assert strength.evaluate(enriched["EURUSD"], lookback=1, top_k=2, atr_period=1, trail_atr=3.0, target_r=10.0) is None


# --- weekday-hour seasonality ---

def _h4_bars(weeks, winner_slot):
    start = datetime(2026, 1, 5, 1, tzinfo=timezone.utc)
    bars = []
    for i in range(weeks * 42):
        opened = start + timedelta(hours=4 * i)
        up = seasonality.slot_of(opened) == winner_slot
        close = (1.001 if i % 2 else 1.0006) if up else 1.0
        bars.append(_bar(1.0, 1.002, 0.998, close, timestamp=opened.isoformat()))
    return bars


RULES = {"lookback_weeks": 10, "min_t": 1.5, "stop_atr": 1.0, "atr_period": 2, "target_r": 10.0, "hold_bars": 1,
         "bar_minutes": 240}


def test_a_persistently_rising_slot_is_bought_for_one_bar():
    winner = seasonality.slot_of(datetime(2026, 1, 7, 13, tzinfo=timezone.utc))
    bars = _h4_bars(12, winner)
    provider = seasonality.make_signal_provider(**RULES)
    signals = {i: provider(bars[:i + 1], i) for i in range(len(bars))}

    decisions = [i for i, s in signals.items() if s]
    assert decisions, "expected a signal before the winning slot"
    for i in decisions:
        opened = datetime.fromisoformat(bars[i]["timestamp"])
        assert seasonality.slot_of(opened + timedelta(hours=4)) == winner
        assert signals[i]["direction"] == "BUY" and signals[i]["exit_after_bars"] == 1
    # Needs at least half of lookback_weeks samples: nothing in the first five weeks.
    assert min(decisions) >= 5 * 42 - 1


def test_a_multi_bar_window_records_its_return_under_its_first_bars_slot_once_closed():
    bars = _h4_bars(1, (0, 0))
    bars[3] = {**bars[3], "open": 2.0}
    bars[5] = {**bars[5], "close": 3.0}
    history = seasonality.SlotHistory(4, window_bars=3)

    history.update(bars, 4)
    assert sum(len(v) for v in history.returns.values()) == 3          # windows ending at bars 2, 3, 4
    history.update(bars, 5)
    slot = seasonality.slot_of(datetime.fromisoformat(bars[3]["timestamp"]))
    assert history.returns[slot][-1] == pytest.approx(__import__("math").log(3.0 / 2.0))


def test_a_one_bar_window_is_each_bars_own_return():
    bars = _h4_bars(1, (0, 0))
    bars[2] = {**bars[2], "open": 1.0, "close": 1.5}
    one, default = seasonality.SlotHistory(4, window_bars=1), seasonality.SlotHistory(4)
    one.update(bars, 10)
    default.update(bars, 10)

    assert dict(one.returns) == dict(default.returns)
    slot = seasonality.slot_of(datetime.fromisoformat(bars[2]["timestamp"]))
    assert list(one.returns[slot]) == pytest.approx([__import__("math").log(1.5)])


def test_seasonality_history_restarts_on_a_new_replay():
    history = seasonality.SlotHistory(4)
    bars = _h4_bars(2, (0, 0))
    history.update(bars, 50)
    history.update(bars, 3)

    assert sum(len(v) for v in history.returns.values()) == 4


# --- shock-day continuation ---

CALM = [_bar(1.0, 1.005, 0.995, 1.0) for _ in range(21)]


def test_a_shock_day_closing_near_its_high_is_bought_with_the_stop_at_its_low():
    signal = shock.evaluate(CALM + [_bar(1.0, 1.04, 0.998, 1.035)], shock_atr=2.0, close_zone=0.25, atr_period=20, target_r=2.0)

    assert signal["direction"] == "BUY" and signal["stop_loss"] == pytest.approx(0.998)
    assert signal["take_profit"] == pytest.approx(1.035 + 2 * (1.035 - 0.998))


def test_no_shock_trade_for_a_normal_day_or_a_mid_range_close():
    assert shock.evaluate(CALM + [_bar(1.0, 1.006, 0.995, 1.005)], shock_atr=2.0, close_zone=0.25, atr_period=20, target_r=2.0) is None
    assert shock.evaluate(CALM + [_bar(1.0, 1.04, 0.998, 1.02)], shock_atr=2.0, close_zone=0.25, atr_period=20, target_r=2.0) is None


def test_the_shock_sell_mirrors_the_buy():
    signal = shock.evaluate(CALM + [_bar(1.0, 1.002, 0.96, 0.965)], shock_atr=2.0, close_zone=0.25, atr_period=20, target_r=2.0)

    assert signal["direction"] == "SELL" and signal["stop_loss"] == pytest.approx(1.002)
