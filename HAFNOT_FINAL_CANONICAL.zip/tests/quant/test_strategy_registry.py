import uuid

import pytest

from app.quant import strategy_registry as registry


def _spec(strategy_id=None, version="1.0.0"):
    return registry.StrategySpec(
        strategy_id=strategy_id or f"test-{uuid.uuid4().hex[:8]}",
        version=version,
        family=registry.StrategyFamily.BREAKOUT.value,
        entry_rules="Close breaks Asian session high/low by >=10% of range during London window.",
        exit_rules="Fixed stop-loss/take-profit, no trailing.",
        stop_loss_logic="Tight buffer (15% of Asian range) back inside the broken level.",
        take_profit_logic="Measured move: entry +/- Asian range size.",
        timeframe="H1",
        symbols=["XAUUSD"],
        session_conditions="London window (07:00-10:00 UTC) only.",
        regime_conditions="None applied.",
        parameters={"min_breakout_fraction": 0.10, "stop_buffer_fraction": 0.15},
        transaction_cost_assumptions="app.forex_v2.risk default RiskConfig (spread cap 2.0 pips, slippage 0.10 pips/side, $7/lot commission).",
        risk_model="app.forex_v2.risk.size_position, 0.5% equity risk per trade.",
        signal_provider_module="app.quant.asian_range_breakout_strategy",
        signal_provider_factory="make_signal_provider",
    )


@pytest.fixture(autouse=True)
def _use_tmp_registry(tmp_path, monkeypatch):
    monkeypatch.setattr(registry, "SPECS_DIR", tmp_path / "specs")
    monkeypatch.setattr(registry, "RESULTS_DIR", tmp_path / "results")
    yield


def test_register_and_load_round_trips():
    spec = _spec("breakout-asian-range", "1.0.0")
    registry.register_strategy(spec)

    loaded = registry.load_strategy("breakout-asian-range", "1.0.0")
    assert loaded.strategy_id == "breakout-asian-range"
    assert loaded.family == registry.StrategyFamily.BREAKOUT.value
    assert loaded.parameters["min_breakout_fraction"] == 0.10


def test_cannot_overwrite_without_explicit_flag():
    spec = _spec("dup-test", "1.0.0")
    registry.register_strategy(spec)

    with pytest.raises(ValueError):
        registry.register_strategy(spec)

    registry.register_strategy(spec, overwrite=True)  # does not raise


def test_load_missing_strategy_raises():
    with pytest.raises(FileNotFoundError):
        registry.load_strategy("does-not-exist", "1.0.0")


def test_list_strategies_returns_all_registered():
    registry.register_strategy(_spec("list-test-a"))
    registry.register_strategy(_spec("list-test-b"))

    ids = {s.strategy_id for s in registry.list_strategies()}
    assert "list-test-a" in ids
    assert "list-test-b" in ids


def test_build_signal_provider_reinstantiates_real_callable():
    spec = _spec("real-callable-test")
    registry.register_strategy(spec)
    loaded = registry.load_strategy("real-callable-test", "1.0.0")

    provider = loaded.build_signal_provider()
    assert callable(provider)


def test_record_and_get_results_appends_never_overwrites():
    registry.register_strategy(_spec("results-test"))

    registry.record_result(
        "results-test", "1.0.0",
        test_type="IN_SAMPLE", symbol="XAUUSD",
        scorecard={"trade_count": 12, "net_pnl_usd": -43.46, "win_rate": 0.333},
    )
    registry.record_result(
        "results-test", "1.0.0",
        test_type="OUT_OF_SAMPLE", symbol="XAUUSD",
        scorecard={"trade_count": 1, "net_pnl_usd": -41.35, "win_rate": 0.0},
    )

    results = registry.get_results("results-test", "1.0.0")
    assert len(results) == 2
    assert results[0]["test_type"] == "IN_SAMPLE"
    assert results[1]["test_type"] == "OUT_OF_SAMPLE"
    # A losing result must be recorded as-is, not hidden or overwritten.
    assert results[1]["scorecard"]["net_pnl_usd"] == -41.35


def test_get_results_for_unregistered_strategy_returns_empty_not_error():
    assert registry.get_results("never-registered", "1.0.0") == []
