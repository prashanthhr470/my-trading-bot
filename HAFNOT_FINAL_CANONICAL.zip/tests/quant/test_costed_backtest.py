from app.quant.costed_backtest import run_costed_backtest, is_costable_symbol


def _bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c}


def test_unsupported_symbol_is_reported_not_silently_costed():
    result = run_costed_backtest(
        bars=[_bar(1, 1, 1, 1)],
        signal_provider=lambda bars, i: None,
        symbol="GBPJPY",
    )
    assert result.supported is False
    assert result.accepted_trade_count == 0


def test_one_winning_trade_compounds_equity_after_realistic_costs():
    # A simple synthetic price path: flat, then a clean rally that clears
    # a take-profit above entry without ever touching a stop below it.
    bars = [
        _bar(1.1000, 1.1005, 1.0995, 1.1000),  # index 0: signal fires here
        _bar(1.1000, 1.1020, 1.0998, 1.1015),
        _bar(1.1015, 1.1085, 1.1005, 1.1080),  # take-profit (1.1080) touched
    ]

    def signal_provider(visible_bars, index):
        if index == 0:
            return {
                "direction": "BUY",
                "entry": 1.1000,
                "stop_loss": 1.0960,
                # 80 pip reward vs 40 pip risk = nominal 2.0R, comfortably
                # above the 1.5R minimum even after entry/exit slippage
                # erodes the costed reward:risk on both legs.
                "take_profit": 1.1080,
            }
        return None

    assert is_costable_symbol("EURUSD")

    result = run_costed_backtest(
        bars=bars,
        signal_provider=signal_provider,
        symbol="EURUSD",
        starting_equity_usd=10_000.0,
    )

    assert result.supported is True
    assert result.raw_signal_count == 1
    assert result.accepted_trade_count == 1
    trade = result.trades[0]
    assert trade.side == "BUY"
    # Net PnL must be strictly less than the raw (uncosted) reward, because
    # spread + slippage + commission are all subtracted.
    raw_reward_usd = (1.1080 - 1.1000) * 100_000 * trade.lots
    assert trade.net_pnl_usd < raw_reward_usd
    assert trade.result_r > 0
    assert result.ending_equity_usd == 10_000.0 + trade.net_pnl_usd


def test_stopped_out_trade_loses_at_most_the_risk_budget():
    bars = [
        _bar(1.1000, 1.1002, 1.0998, 1.1000),
        _bar(1.1000, 1.1001, 1.0975, 1.0980),  # stop-loss (1.0980) touched
    ]

    def signal_provider(visible_bars, index):
        if index == 0:
            return {
                "direction": "BUY",
                "entry": 1.1000,
                "stop_loss": 1.0980,
                "take_profit": 1.1040,
            }
        return None

    result = run_costed_backtest(
        bars=bars,
        signal_provider=signal_provider,
        symbol="EURUSD",
        starting_equity_usd=10_000.0,
    )

    assert result.accepted_trade_count == 1
    trade = result.trades[0]
    assert trade.net_pnl_usd < 0
    assert trade.result_r < 0
    # Losing slightly MORE than 1R is expected (slippage/commission widen
    # a loss beyond the nominal risk budget) but it should be in the same
    # order of magnitude, not wildly larger.
    assert trade.net_pnl_usd > -2 * trade.risk_amount_usd
