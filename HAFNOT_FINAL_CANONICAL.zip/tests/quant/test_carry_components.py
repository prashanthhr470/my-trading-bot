"""
Carry research components: as-of interest rates without look-ahead, the swap model's
arithmetic against the broker's own swaps, and the carry signal.
"""

from datetime import date, datetime, timedelta, timezone

import pytest

from app.quant import external_rates as er
from app.quant import fx_carry_strategy as carry
from app.quant import swap_model as sm

CSV = "observation_date,IR3TIB01USM156N\n2020-01-01,1.9\n2020-02-01,1.7\n2020-03-01,.\n2020-04-01,1.1\n"


def test_fred_csv_is_parsed_skipping_missing_values_and_refusing_empty_series():
    rates = er.fetch_fred_monthly({"USD": "IR3TIB01USM156N"}, download=lambda url: CSV)

    assert rates == {"USD": [["2020-01", 1.9], ["2020-02", 1.7], ["2020-04", 1.1]]}
    assert len(er.fingerprint(rates)) == 64
    with pytest.raises(ValueError, match="no values"):
        er.fetch_fred_monthly({"EUR": "X"}, download=lambda url: "observation_date,X\n2020-01-01,.\n")


def test_a_months_value_is_known_only_after_the_publication_lag():
    rates = er.RatesAsOf({"USD": [["2020-01", 1.9], ["2020-02", 1.7], ["2020-04", 1.1]]}, lag_months=2, max_age_months=3)

    assert rates.rate("USD", date(2020, 2, 28)) is None          # January not yet published
    assert rates.rate("USD", date(2020, 3, 1)) == 1.9
    assert rates.rate("USD", date(2020, 5, 15)) == 1.7           # March missing: February is the latest known
    assert rates.rate("USD", date(2020, 6, 1)) == 1.1
    assert rates.rate("USD", date(2020, 7, 31)) == 1.1           # April, three months old
    assert rates.rate("USD", date(2020, 8, 1)) is None           # too stale to use
    assert rates.rate("EUR", date(2020, 6, 1)) is None


# EURUSD, 14 Sep 2026: swap long -0.7, short +0.16 pips a night at 1.15975.

def test_the_markup_and_implied_differential_come_from_the_brokers_two_swaps():
    assert sm.markup_pct(-0.7, 0.16, 0.0001, 1.15975) == pytest.approx(0.8381, abs=1e-3)
    assert sm.implied_differential_pct(-0.7, 0.16, 0.0001, 1.15975) == pytest.approx(-1.3348, abs=1e-3)


def _model(base, quote, rates, markup=0.8):
    return sm.SwapModel(base + quote, base, quote, 100_000, markup, er.RatesAsOf(rates, 0, 3), triple_weekday=2)


RATES = {"EUR": [["2026-01", 2.0]], "USD": [["2026-01", 4.0]], "JPY": [["2026-01", 1.0]]}


def test_a_short_eurusd_earns_the_differential_less_the_markup_and_wednesday_counts_three():
    model = _model("EUR", "USD", RATES)
    monday, wednesday = date(2026, 1, 12), date(2026, 1, 14)

    assert model.night_pct("SELL", monday) == pytest.approx(2.0 - 0.8)
    assert model.night_pct("BUY", monday) == pytest.approx(-2.0 - 0.8)
    usd = model.trade_usd("SELL", 1.0, 1.10, [monday, wednesday])
    assert usd == pytest.approx(100_000 * 1.10 * 1.2 / 100 / 360 * (1 + 3))


def test_usd_base_notional_is_the_units_and_unknown_rates_charge_only_the_markup():
    model = _model("USD", "JPY", RATES)
    assert model.trade_usd("BUY", 0.5, 150.0, [date(2026, 1, 12)]) == pytest.approx(50_000 * (3.0 - 0.8) / 100 / 360)
    assert model.night_pct("BUY", date(2026, 6, 1)) == pytest.approx(-0.8)          # rates stale by June
    with pytest.raises(ValueError):
        sm.SwapModel("EURGBP", "EUR", "GBP", 100_000, 0.8, er.RatesAsOf(RATES, 0, 3), 2)


def _daily(n, start=datetime(2026, 1, 11, 22, tzinfo=timezone.utc)):
    return [{"timestamp": (start + timedelta(days=i)).isoformat()} for i in range(n)]


def test_rollovers_follow_the_exit_type():
    bars = _daily(6)   # bars open Sun 22:00 UTC (Mon trading day) ... Fri trading day

    assert sm.rollover_days(bars, 0, 3, "STOP") == [date(2026, 1, 13), date(2026, 1, 14)]
    assert sm.rollover_days(bars, 0, 3, "TIME") == [date(2026, 1, 13), date(2026, 1, 14), date(2026, 1, 15)]
    assert sm.triple_weekday_from_broker(3) == 2
    with pytest.raises(ValueError):
        sm.triple_weekday_from_broker(0)


def test_interest_rate_features_are_the_as_of_rates_on_each_bars_trading_day():
    from app.quant import bar_features

    as_of = er.RatesAsOf({"USD": [["2026-01", 4.0]], "EUR": [["2026-01", 2.0]]}, lag_months=0, max_age_months=3)
    bars = {"EURUSD": [{"timestamp": "2026-01-12T22:00:00+00:00", "close": 1.1}]}

    [bar] = bar_features.enrich("interest_rates", bars, as_of)["EURUSD"]

    assert bar["symbol"] == "EURUSD" and bar["rates"] == {"USD": 4.0, "EUR": 2.0}
    with pytest.raises(ValueError, match="needs as-of rates"):
        bar_features.enrich("interest_rates", bars)


@pytest.mark.parametrize("pair, rates, expected", [
    ("EURUSD", {"EUR": 2.0, "USD": 4.0}, "SELL"), ("USDJPY", {"USD": 4.0, "JPY": 1.0}, "BUY"),
    ("AUDUSD", {"AUD": 4.2, "USD": 4.0}, None), ("GBPUSD", {"GBP": None, "USD": 4.0}, None),
])
def test_carry_holds_the_higher_yielder_when_the_differential_is_large_enough(pair, rates, expected):
    bars = [{"open": 1.0, "high": 1.01, "low": 0.99, "close": 1.0, "symbol": pair, "rates": rates} for _ in range(3)]

    signal = carry.evaluate(bars, min_diff_pct=1.0, stop_atr=5.0, atr_period=2, target_r=10.0, hold_bars=21)

    assert (signal or {}).get("direction") == expected
    if signal:
        assert signal["exit_after_bars"] == 21
