import pytest

from app.quant.data_split import chronological_split


def test_split_is_chronological_and_non_overlapping():
    bars = list(range(100))
    split = chronological_split(bars, in_sample_fraction=0.7)

    assert split.in_sample == bars[:70]
    assert split.out_of_sample == bars[70:]
    assert split.in_sample + split.out_of_sample == bars
    assert split.split_index == 70


def test_rejects_invalid_fraction():
    with pytest.raises(ValueError):
        chronological_split([1, 2, 3], in_sample_fraction=1.0)
    with pytest.raises(ValueError):
        chronological_split([1, 2, 3], in_sample_fraction=0.0)
