"""
Month-end fix flows: month-to-date index returns only from completed daily closes, the
London decision hour on the right day (and the mid-month control), and the dollar-flow direction.
"""

from datetime import date, datetime, timedelta, timezone

import pytest

from app.quant import bar_features
from app.quant import month_end_fix_strategy as fix

UTC = timezone.utc


def _daily(rows):
    """rows: (UTC open time, close)."""
    return [{"timestamp": t.isoformat(), "open": c, "high": c, "low": c, "close": c} for t, c in rows]


# Daily index bars open 21:00 UTC (17:00 New York, summer) for the next trading date.
US500 = _daily([(datetime(2026, 6, 29, 21, tzinfo=UTC), 100.0),     # session Tue 30 Jun: June's last close
                (datetime(2026, 7, 27, 21, tzinfo=UTC), 103.0),     # session Tue 28 Jul
                (datetime(2026, 7, 28, 21, tzinfo=UTC), 104.0)])    # session Wed 29 Jul, closes 21:00 UTC on 29 Jul


def test_month_to_date_uses_only_closes_completed_before_the_moment():
    table = bar_features._month_to_date_table(US500)

    assert bar_features.month_to_date_return(table, datetime(2026, 7, 29, 12, tzinfo=UTC)) == pytest.approx(0.03)
    assert bar_features.month_to_date_return(table, datetime(2026, 7, 30, 9, tzinfo=UTC)) == pytest.approx(0.04)
    assert bar_features.month_to_date_return(table, datetime(2026, 6, 30, 22, tzinfo=UTC)) is None   # no earlier month
    assert bar_features.month_to_date_return(table, datetime(2026, 8, 10, 9, tzinfo=UTC)) is None    # stale


def test_the_feature_attaches_symbol_and_month_to_date_returns():
    hourly = {"EURUSD": [{"timestamp": "2026-07-30T09:00:00+00:00", "close": 1.1}]}
    [bar] = bar_features.enrich("month_end_equity", hourly, {"US500": US500})["EURUSD"]

    assert bar["symbol"] == "EURUSD" and bar["equity_mtd"]["US500"] == pytest.approx(0.04)
    with pytest.raises(ValueError, match="needs feature index bars"):
        bar_features.enrich("month_end_equity", hourly)


def test_calendar_days():
    assert fix.last_weekday_of_month(date(2026, 1, 5)) == date(2026, 1, 30)      # 31 Jan is a Saturday
    assert fix.last_weekday_of_month(date(2026, 12, 1)) == date(2026, 12, 31)
    assert fix.mid_month_weekday(date(2026, 2, 3)) == date(2026, 2, 13)          # 15 Feb is a Sunday


def _hourly(close_utc, symbol, us, foreign_name, foreign, n=26):
    bars = [{"timestamp": (close_utc - timedelta(hours=n - i)).isoformat(), "open": 1.1, "high": 1.102, "low": 1.098,
             "close": 1.1, "symbol": symbol, "equity_mtd": {"US500": us, foreign_name: foreign}} for i in range(n)]
    return bars


RULES = {"threshold_pct": 1.0, "hours_before_fix": 4, "fix_hour": 16, "stop_atr": 3.0, "atr_period": 24,
         "target_r": 10.0, "bar_minutes": 60, "mid_month_placebo": 0}
# Friday 31 Jul 2026 is July's last weekday; London is UTC+1, so the bar closing 12:00 London closes 11:00 UTC.
DECISION = datetime(2026, 7, 31, 11, tzinfo=UTC)


def test_us_outperformance_sells_the_dollar_into_the_fix():
    eur = fix.evaluate(_hourly(DECISION, "EURUSD", 0.04, "EUSTX50", 0.01), **RULES)
    jpy = fix.evaluate(_hourly(DECISION, "USDJPY", 0.04, "JPN225", 0.01), **RULES)

    assert eur["direction"] == "BUY" and jpy["direction"] == "SELL"
    assert eur["exit_after_bars"] == 4 and eur["us_minus_foreign_mtd_pct"] == pytest.approx(3.0)


def test_us_underperformance_buys_the_dollar_and_small_gaps_do_nothing():
    assert fix.evaluate(_hourly(DECISION, "GBPUSD", -0.02, "UK100", 0.01), **RULES)["direction"] == "SELL"
    assert fix.evaluate(_hourly(DECISION, "GBPUSD", 0.015, "UK100", 0.01), **RULES) is None        # 0.5 points


def test_only_the_decision_hour_on_the_right_day_trades():
    assert fix.evaluate(_hourly(DECISION + timedelta(hours=1), "EURUSD", 0.04, "EUSTX50", 0.01), **RULES) is None
    assert fix.evaluate(_hourly(DECISION - timedelta(days=1), "EURUSD", 0.04, "EUSTX50", 0.01), **RULES) is None
    mid_month = datetime(2026, 7, 15, 11, tzinfo=UTC)                                               # Wednesday 15 Jul
    placebo = {**RULES, "mid_month_placebo": 1}
    assert fix.evaluate(_hourly(mid_month, "EURUSD", 0.04, "EUSTX50", 0.01), **placebo)["direction"] == "BUY"
    assert fix.evaluate(_hourly(DECISION, "EURUSD", 0.04, "EUSTX50", 0.01), **placebo) is None
