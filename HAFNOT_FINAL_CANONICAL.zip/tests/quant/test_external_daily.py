"""
Daily outside series (FRED VIX): parsed without missing days, known only after the lag,
weekends bridged but stale values refused.
"""

from datetime import date

import pytest

from app.quant import external_daily as ed

CSV = "observation_date,VIXCLS\n2026-01-08,15.0\n2026-01-09,16.0\n2026-01-12,.\n2026-01-13,30.0\n"


def test_fred_daily_csv_is_parsed_without_missing_days():
    values = ed.fetch_fred_daily({"VIX": "VIXCLS"}, download=lambda url: CSV)

    assert values == {"VIX": [["2026-01-08", 15.0], ["2026-01-09", 16.0], ["2026-01-13", 30.0]]}
    with pytest.raises(ValueError, match="no values"):
        ed.fetch_fred_daily({"VIX": "X"}, download=lambda url: "observation_date,X\n2026-01-08,.\n")


def test_the_fred_daily_feature_attaches_only_a_known_window_per_trading_day():
    from app.quant import bar_features

    vix = ed.DailyAsOf([["2026-01-08", 15.0], ["2026-01-09", 16.0], ["2026-01-13", 30.0]], lag_days=1, max_age_days=5)
    bars = {"US500": [{"timestamp": "2026-01-12T22:00:00+00:00", "close": 6000.0},     # session Tue 13 Jan
                      {"timestamp": "2026-01-13T22:00:00+00:00", "close": 6010.0}]}    # session Wed 14 Jan

    first, second = bar_features.enrich("fred_daily", bars, {"VIX": vix})["US500"]

    assert first["daily"] == {"VIX": [15.0, 16.0]} and second["daily"] == {"VIX": [15.0, 16.0, 30.0]}
    assert first["symbol"] == "US500"
    with pytest.raises(ValueError, match="needs as-of daily series"):
        bar_features.enrich("fred_daily", bars)


def test_a_vix_spike_above_its_average_buys_the_index():
    from app.quant import index_vix_spike_strategy as spike

    def bars(history):
        return [{"open": 100, "high": 101, "low": 99, "close": 100, "daily": {"VIX": history}} for _ in range(3)]

    rules = {"spike_pct": 0.35, "hold_bars": 10, "lookback": 4, "stop_atr": 3.0, "atr_period": 2, "target_r": 10.0}
    signal = spike.evaluate(bars([20, 20, 20, 20, 27.0]), **rules)

    assert signal["direction"] == "BUY" and signal["exit_after_bars"] == 10 and signal["vix_base"] == 20
    assert spike.evaluate(bars([20, 20, 20, 20, 26.9]), **rules) is None          # 34.5% above: not enough
    assert spike.evaluate(bars([20, 20, 27.0]), **rules) is None                  # too little history


def test_values_are_known_only_after_the_lag_and_weekends_are_bridged():
    vix = ed.DailyAsOf(ed.fetch_fred_daily({"VIX": "VIXCLS"}, download=lambda url: CSV)["VIX"], lag_days=1, max_age_days=5)

    assert vix.value(date(2026, 1, 9)) == 15.0            # Friday's own close is not yet known on Friday
    assert vix.value(date(2026, 1, 12)) == 16.0           # Monday uses Friday
    assert vix.value(date(2026, 1, 13)) == 16.0           # Monday missing; Tuesday's own close not yet known
    assert vix.value(date(2026, 1, 14)) == 30.0
    assert vix.value(date(2026, 1, 20)) is None           # seven days old: stale
    assert vix.history(date(2026, 1, 14), 2) == [16.0, 30.0]
    assert vix.history(date(2026, 1, 20), 2) == []
