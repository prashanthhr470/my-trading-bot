"""
cTrader trendbars are bid prices, so a real round trip pays the whole spread
once: a BUY at the ask on entry, a SELL at the ask when it buys back. The legacy
model charges half the assumed spread at entry for both. These tests pin both.
"""

import pytest

from app.forex_v2.risk import RiskConfig
from app.quant.costed_backtest import run_costed_backtest

NO_SLIPPAGE = RiskConfig(slippage_pips_per_side=0.0)
SPREAD_PIPS = 1.7  # XAUUSD pip = 0.1, so the spread is $0.17


def _bars(step):
    return [
        {"open": 2000.0 + step * i, "high": 2000.5 + step * i + (abs(step) if step > 0 else 0),
         "low": 1999.5 + step * i - (abs(step) if step < 0 else 0), "close": 2000.0 + step * i}
        for i in range(12)
    ]


def _once(signal):
    def provider(visible_bars, index):
        return signal if index == 0 else None
    return provider


BUY = {"direction": "BUY", "entry": 2000.0, "stop_loss": 1990.0, "take_profit": 2030.0}
SELL = {"direction": "SELL", "entry": 2000.0, "stop_loss": 2010.0, "take_profit": 1970.0}


def _trade(bars, signal, **kwargs):
    result = run_costed_backtest(bars, _once(signal), "XAUUSD", risk_config=NO_SLIPPAGE,
                                 assumed_spread_pips=SPREAD_PIPS, **kwargs)
    [trade] = result.trades
    return trade


def test_bid_bars_buy_pays_the_whole_spread_on_entry():
    trade = _trade(_bars(+5.0), BUY, bid_bars=True)

    assert trade.entry_fill_price == pytest.approx(2000.17)
    assert trade.exit_fill_price == pytest.approx(2030.0)


def test_bid_bars_sell_pays_the_whole_spread_when_buying_back():
    trade = _trade(_bars(-5.0), SELL, bid_bars=True)

    assert trade.entry_fill_price == pytest.approx(2000.0)
    assert trade.exit_fill_price == pytest.approx(1970.17)


def test_both_directions_pay_the_same_spread_once():
    buy = _trade(_bars(+5.0), BUY, bid_bars=True)
    sell = _trade(_bars(-5.0), SELL, bid_bars=True)

    buy_move = buy.exit_fill_price - buy.entry_fill_price
    sell_move = sell.entry_fill_price - sell.exit_fill_price
    assert buy_move == pytest.approx(sell_move) == pytest.approx(30.0 - 0.17)


def test_the_legacy_default_is_unchanged():
    trade = _trade(_bars(+5.0), BUY)

    # Half of the assumed spread at entry, nothing at exit.
    assert trade.entry_fill_price == pytest.approx(2000.085)
    assert trade.exit_fill_price == pytest.approx(2030.0)


def test_a_sell_whose_target_is_inside_the_spread_is_refused():
    tight = {"direction": "SELL", "entry": 2000.0, "stop_loss": 2000.1, "take_profit": 1999.9}
    result = run_costed_backtest(_bars(-5.0), _once(tight), "XAUUSD", risk_config=NO_SLIPPAGE,
                                 assumed_spread_pips=SPREAD_PIPS, bid_bars=True)

    assert result.trades == []
    assert result.rejected_trade_count == 1
