"""
Liquidity levels on New York trading days, and the sweep-reversal and run-continuation
rules at the previous day's extremes, with SELL mirroring BUY.
"""

from datetime import datetime, timedelta, timezone

import pytest

from app.quant import liquidity_run_continuation_strategy as run_strategy
from app.quant import liquidity_sweep_reversal_strategy as sweep_strategy
from app.quant.features import average_true_range
from app.quant.liquidity_levels import LiquidityLevels, trading_day

# Winter: New York = UTC-5, so 22:00 UTC is the 17:00 rollover. Monday 12 Jan 2026 22:00 UTC opens Tuesday's session.
DAY_OPENS = [datetime(2026, 1, 12, 22, tzinfo=timezone.utc) + timedelta(days=d) for d in range(3)]


def _session(day, rows):
    return [{"timestamp": (DAY_OPENS[day] + timedelta(hours=4 * i)).isoformat(), "open": o, "high": h, "low": l, "close": c}
            for i, (o, h, l, c) in enumerate(rows)]


DAY1 = _session(0, [(1.000, 1.004, 0.998, 1.002), (1.002, 1.006, 1.000, 1.004), (1.004, 1.008, 1.002, 1.006),
                    (1.006, 1.010, 1.004, 1.008), (1.008, 1.012, 1.006, 1.010), (1.010, 1.012, 1.008, 1.010)])
DAY2 = _session(1, [(o + 0.01, h + 0.01, l + 0.01, c + 0.01) for (o, h, l, c) in
                    [(b["open"], b["high"], b["low"], b["close"]) for b in DAY1]])


def _mirror(bars, pivot=2.03):
    return [{**b, "open": pivot - b["open"], "high": pivot - b["low"], "low": pivot - b["high"], "close": pivot - b["close"]}
            for b in bars]


def test_trading_days_turn_at_the_new_york_rollover_and_weekends_join_monday():
    assert trading_day(datetime(2026, 1, 12, 21, 59, tzinfo=timezone.utc)).isoformat() == "2026-01-12"
    assert trading_day(datetime(2026, 1, 12, 22, 0, tzinfo=timezone.utc)).isoformat() == "2026-01-13"
    assert trading_day(datetime(2026, 7, 13, 21, 0, tzinfo=timezone.utc)).isoformat() == "2026-07-14"   # EDT
    assert trading_day(datetime(2026, 1, 11, 18, 0, tzinfo=timezone.utc)).isoformat() == "2026-01-12"   # Sunday stub


def test_levels_expose_only_completed_days():
    bars = DAY1 + DAY2 + _session(2, [(1.020, 1.030, 1.015, 1.025)])
    levels = LiquidityLevels()

    levels.update(bars, len(DAY1) - 1)
    assert levels.prev_day_high is None
    levels.update(bars, len(DAY1))
    assert (levels.prev_day_high, levels.prev_day_low) == (1.012, 0.998)
    levels.update(bars, len(bars) - 1)
    assert (levels.prev_day_high, levels.prev_day_low) == pytest.approx((1.022, 1.008))
    assert list(levels.daily_closes) == pytest.approx([1.010, 1.020])
    assert levels.bias(2) == 1 and levels.day_start_index == len(DAY1) + len(DAY2)


SWEEP_DAY = _session(2, [(1.020, 1.022, 1.012, 1.014), (1.014, 1.016, 1.010, 1.011), (1.011, 1.013, 1.005, 1.012)])
SWEEP_RULES = {"bias_days": 2, "target_r": 2.0, "stop_buffer_atr": 0.1, "atr_period": 2}


def test_a_first_sweep_of_yesterdays_low_in_an_uptrend_is_bought():
    bars = DAY1 + DAY2 + SWEEP_DAY
    signal = sweep_strategy.evaluate(bars, LiquidityLevels(), **SWEEP_RULES)
    atr = average_true_range(bars[-3:], 2)

    assert signal["direction"] == "BUY" and signal["liquidity_level"] == "previous_day_low"
    assert signal["stop_loss"] == pytest.approx(1.005 - 0.1 * atr)


def test_no_sweep_trade_when_the_level_was_already_taken_today():
    taken = SWEEP_DAY[:1] + _session(2, [(1.020, 1.022, 1.012, 1.014), (1.014, 1.016, 1.007, 1.011)])[1:] + SWEEP_DAY[2:]

    assert sweep_strategy.evaluate(DAY1 + DAY2 + taken, LiquidityLevels(), **SWEEP_RULES) is None


def test_the_sweep_sell_mirrors_the_buy():
    signal = sweep_strategy.evaluate(_mirror(DAY1 + DAY2 + SWEEP_DAY), LiquidityLevels(), **SWEEP_RULES)

    assert signal["direction"] == "SELL" and signal["liquidity_level"] == "previous_day_high"


RUN_DAY = _session(2, [(1.020, 1.021, 1.016, 1.018), (1.018, 1.026, 1.017, 1.024), (1.024, 1.027, 1.023, 1.025),
                       (1.025, 1.026, 1.0225, 1.0255)])
RUN_RULES = {"bias_days": 2, "target_r": 2.0, "retest_bars": 16, "zone_atr": 0.25, "stop_atr": 0.5, "atr_period": 2}


def test_a_held_break_of_yesterdays_high_retested_in_an_uptrend_is_bought():
    bars = DAY1 + DAY2 + RUN_DAY
    signal = run_strategy.evaluate(bars, LiquidityLevels(), **RUN_RULES)
    atr = average_true_range(bars[-3:], 2)

    assert signal["direction"] == "BUY" and signal["liquidity_level"] == "previous_day_high"
    assert signal["stop_loss"] == pytest.approx(1.022 - 0.5 * atr)


def test_no_continuation_trade_when_price_closed_back_below_the_level():
    failed = RUN_DAY[:2] + [{**RUN_DAY[2], "close": 1.021}] + RUN_DAY[3:]

    assert run_strategy.evaluate(DAY1 + DAY2 + failed, LiquidityLevels(), **RUN_RULES) is None


def test_the_continuation_sell_mirrors_the_buy():
    signal = run_strategy.evaluate(_mirror(DAY1 + DAY2 + RUN_DAY), LiquidityLevels(), **RUN_RULES)

    assert signal["direction"] == "SELL" and signal["liquidity_level"] == "previous_day_low"


def test_providers_track_levels_bar_by_bar():
    bars = DAY1 + DAY2 + SWEEP_DAY
    provider = sweep_strategy.make_signal_provider(**SWEEP_RULES)
    signals = [provider(bars[:i + 1], i) for i in range(len(bars))]

    assert [s["direction"] for s in signals if s] == ["BUY"]
    assert callable(run_strategy.make_signal_provider(**run_strategy.DEFAULTS))
