"""
Index anomaly research: percentage-type index financing, dip-in-uptrend, turn of the month,
and the unconditional-long benchmark.
"""

from datetime import date, datetime, timedelta, timezone

import pytest

from app.quant import external_rates as er
from app.quant import index_dip_strategy as dip
from app.quant import index_unconditional_long_strategy as baseline
from app.quant import swap_model as sm
from app.quant import turn_of_month_strategy as tom


# US500, 15 Sep 2026: swap long -6.15 %, short +1.15 % a year.

def test_the_index_markup_and_implied_rate_come_from_the_brokers_percentages():
    assert sm.percentage_markup(-6.15, 1.15) == pytest.approx(2.5)
    assert sm.percentage_implied_rate(-6.15, 1.15) == pytest.approx(3.65)


def test_index_longs_pay_the_usd_rate_plus_markup_and_friday_counts_three():
    rates = er.RatesAsOf({"USD": [["2026-01", 4.0]]}, lag_months=0, max_age_months=3)
    model = sm.IndexFinancingModel("US500", 1.0, 2.5, rates, triple_weekday=4)
    thursday, friday = date(2026, 1, 15), date(2026, 1, 16)

    assert model.night_pct("BUY", thursday) == pytest.approx(-6.5)
    assert model.night_pct("SELL", thursday) == pytest.approx(1.5)
    usd = model.trade_usd("BUY", 0.3, 6000.0, [thursday, friday])
    assert usd == pytest.approx(0.3 * 6000.0 * -6.5 / 100 / 360 * (1 + 3))
    with pytest.raises(ValueError, match="no as-of USD rate"):
        model.night_pct("BUY", date(2026, 9, 1))


def _bars(closes, start=datetime(2025, 1, 5, 22, tzinfo=timezone.utc)):
    return [{"timestamp": (start + timedelta(days=i)).isoformat(), "open": c, "high": c + 1, "low": c - 1, "close": c}
            for i, c in enumerate(closes)]


RULES = {"dip_days": 3, "hold_bars": 5, "trend_days": 10, "stop_atr": 3.0, "atr_period": 2, "target_r": 10.0}


def test_a_new_three_day_closing_low_above_the_average_is_bought_for_five_days():
    # 11 bars (trend_days + 1); the last 10 closes average 107.35, and 110 is below each of the previous three.
    bars = _bars([98, 100, 102, 104, 106, 108, 110, 112, 111, 110.5, 110])

    signal = dip.evaluate(bars, **RULES)

    assert signal["direction"] == "BUY" and signal["exit_after_bars"] == 5


def test_no_dip_trade_below_the_average_or_without_a_new_low():
    assert dip.evaluate(_bars([122, 120, 118, 116, 114, 112, 110, 108, 107, 106, 105]), **RULES) is None   # below mean
    assert dip.evaluate(_bars([98, 100, 102, 104, 106, 108, 110, 112, 111, 109, 110]), **RULES) is None    # 109 lower
    assert dip.evaluate(_bars([100, 102, 104, 106, 108, 110, 112, 111, 110.5, 110]), **RULES) is None      # too few bars


def test_weekdays_left_in_month_counts_calendar_weekdays():
    assert tom.weekdays_left_in_month(date(2026, 1, 30)) == 0     # Friday, last weekday of January
    assert tom.weekdays_left_in_month(date(2026, 1, 29)) == 1
    assert tom.weekdays_left_in_month(date(2026, 2, 26)) == 1     # Thursday; Friday 27 is the last weekday


def test_turn_of_month_enters_on_the_kth_last_weekday_session():
    # Bars open 17:00 New York (22:00 UTC in January) the evening before their session date.
    start = datetime(2026, 1, 19, 22, tzinfo=timezone.utc)            # session Tue 20 Jan
    bars = [{"timestamp": (start + timedelta(days=i)).isoformat(), "open": 1.0, "high": 1.01, "low": 0.99, "close": 1.0}
            for i in range(12)]
    rules = {"hold_bars": 4, "stop_atr": 3.0, "atr_period": 2, "target_r": 10.0}

    sessions = {k: [bars[i]["timestamp"] for i in range(3, len(bars))
                    if tom.evaluate(bars[:i + 1], days_before_month_end=k, **rules)] for k in (1, 2)}

    assert [s[:10] for s in sessions[1]] == ["2026-01-29"]            # opens Thu 29 Jan 22:00 UTC -> session Fri 30 Jan
    assert [s[:10] for s in sessions[2]] == ["2026-01-28"]


def test_the_benchmark_buys_every_close():
    signal = baseline.evaluate(_bars([100, 101, 102]), hold_bars=5, stop_atr=3.0, atr_period=2, target_r=10.0)

    assert signal["direction"] == "BUY" and signal["exit_after_bars"] == 5
