"""
The daily trend portfolio series as the runner declares it: every symbol costable,
every grid combination a valid strategy, and a target that stays above the live
1.5 reward:risk floor.
"""

import hafnot_run_research_pipeline as runner
from app.forex_v2.risk import FX_USD_MAJOR_SPECS
from app.quant.walk_forward import parameter_combinations


def test_every_portfolio_symbol_has_a_cost_model():
    from app.forex_v2 import instrument_specs

    for config, _ in runner.PORTFOLIO_SERIES.values():
        assert config.timeframe in ("D1", "H4", "H1", "M15")
        if config.broker_instrument_specs:
            # Raises if any non-FX symbol lacks a USD-quoted broker specification.
            research = instrument_specs.research_specs_for(config.symbols)
            assert set(research) | (set(config.symbols) & set(FX_USD_MAJOR_SPECS)) == set(config.symbols)
        else:
            assert set(config.symbols) <= set(FX_USD_MAJOR_SPECS)


def test_the_multi_asset_series_only_changes_universe_costs_and_hypothesis_text():
    v2, v2_families = runner.PORTFOLIO_SERIES["portfolio-d1-v2-trailing"]
    v3, v3_families = runner.PORTFOLIO_SERIES["portfolio-d1-v3-multiasset"]

    assert (v3.execution_hours_utc, v3.close_open_trades_at_slice_end, v3.data_start, v3.data_end) == \
           (v2.execution_hours_utc, v2.close_open_trades_at_slice_end, v2.data_start, v2.data_end)
    assert v3.broker_instrument_specs and v3.spread_cap_multiple == 2.0
    for old, new in zip(v2_families, v3_families):
        assert (new.strategy_id, new.module, new.param_grid, new.fixed_params) == \
               (old.strategy_id, old.module, old.param_grid, old.fixed_params)
        assert "not independent" in new.hypothesis


def test_every_portfolio_series_pins_the_cost_profile_it_was_measured_with():
    from app.quant import cost_profile

    for name, (config, _) in runner.PORTFOLIO_SERIES.items():
        assert (cost_profile.PROFILE_DIR / config.cost_profile_file).is_file(), name
    # The FX series were preregistered against the first profile; a newer one must not become their default.
    for name in ("portfolio-d1-v1", "portfolio-d1-v2-trailing"):
        assert runner.PORTFOLIO_SERIES[name][0].cost_profile_file == "measured_costs_20260914_broker.json"


def test_every_grid_combination_builds_a_strategy():
    for family in runner.DAILY_TREND_FAMILIES:
        factory = family.factory(timeframe_minutes=1440)
        for params in parameter_combinations(family.param_grid):
            assert callable(factory(params))


def test_every_h4_structure_combination_builds_a_filtered_strategy():
    from app.quant import signal_filters

    for family in runner.H4_STRUCTURE_FAMILIES:
        signal_filters.validate_filter(family.signal_filter)
        assert family.signal_filter == {"type": "exclude_new_york_hours", "hours": [17]}
        assert min(family.param_grid["target_r"]) >= 2.0
        factory = family.factory(timeframe_minutes=240)
        for params in parameter_combinations(family.param_grid):
            assert callable(factory(params))


def test_the_idea_batch_series_build_and_require_the_multiple_testing_guard():
    from app.quant import signal_filters, strategy_registry
    from app.quant.bar_features import FX_MAJORS

    for name, families in (("portfolio-d1-v4-currency-strength", runner.CURRENCY_STRENGTH_FAMILIES),
                           ("portfolio-h4-v2-seasonality", runner.SEASONALITY_FAMILIES),
                           ("portfolio-d1-v5-shock-continuation", runner.SHOCK_FAMILIES)):
        config, series_families = runner.PORTFOLIO_SERIES[name]
        assert series_families is families and config.require_multiple_testing_significance
        for family in families:
            strategy_registry.StrategyFamily(family.family)
            signal_filters.validate_filter(family.signal_filter)
            factory = family.factory(timeframe_minutes=signal_filters.TIMEFRAME_MINUTES[config.timeframe])
            for params in parameter_combinations(family.param_grid):
                assert callable(factory(params))

    currency = runner.PORTFOLIO_SERIES["portfolio-d1-v4-currency-strength"][0]
    assert currency.symbols == FX_MAJORS and currency.bar_features == "currency_strength"
    seasonal = runner.PORTFOLIO_SERIES["portfolio-h4-v2-seasonality"][0]
    assert seasonal.timeframe == "H4" and seasonal.warmup_bars >= 104 * 30


def test_the_day_window_seasonality_series_changes_only_the_window_and_stop():
    old_config, [old] = runner.PORTFOLIO_SERIES["portfolio-h4-v2-seasonality"]
    config, [new] = runner.PORTFOLIO_SERIES["portfolio-h4-v3-seasonality-day-window"]

    assert config == old_config.__class__(**{**old_config.__dict__, "series": config.series})
    assert new.param_grid == old.param_grid and new.module == old.module and new.signal_filter == old.signal_filter
    assert {k: v for k, v in new.fixed_params.items() if k not in ("hold_bars", "stop_atr")} == \
           {k: v for k, v in old.fixed_params.items() if k not in ("hold_bars", "stop_atr")}
    assert (new.fixed_params["hold_bars"], new.fixed_params["stop_atr"]) == (6, 2.5)
    assert "CHOSEN AFTER LOOKING AT TRAINING DATA" in new.hypothesis
    factory = new.factory(timeframe_minutes=240)
    for params in parameter_combinations(new.param_grid):
        assert callable(factory(params))


def test_the_cot_series_uses_positioning_with_swaps_and_tests_both_readings():
    from app.quant import strategy_registry
    from app.quant.bar_features import FX_MAJORS

    carry, _ = runner.PORTFOLIO_SERIES["portfolio-d1-v6-carry"]
    config, families = runner.PORTFOLIO_SERIES["portfolio-d1-v9-cot-positioning"]
    assert config == carry.__class__(**{**carry.__dict__, "series": config.series, "bar_features": "cot_positioning",
                                        "external_cot": True, "cot_first_year": 2006})
    assert config.symbols == FX_MAJORS and config.swap_model and config.require_multiple_testing_significance
    assert [f.strategy_id for f in families] == ["cot-crowding-reversal", "cot-positioning-momentum"]
    for family in families:
        strategy_registry.StrategyFamily(family.family)
        factory = family.factory(timeframe_minutes=1440)
        for params in parameter_combinations(family.param_grid):
            assert callable(factory(params))


def test_the_month_end_fix_series_has_its_mid_month_control_and_signal_only_indices():
    from app.quant import month_end_fix_strategy as fix
    from app.quant import strategy_registry

    config, (rule, control) = runner.PORTFOLIO_SERIES["portfolio-h1-v1-month-end-fix"]
    assert config.timeframe == "H1" and config.bar_features == "month_end_equity"
    assert set(config.symbols) == set(fix.PAIRS) and not set(config.feature_symbols) & set(config.symbols)
    assert set(config.feature_symbols) == {fix.US_INDEX, *fix.CURRENCY_INDEX.values()}
    assert config.require_multiple_testing_significance and not config.swap_model
    assert (rule.fixed_params["mid_month_placebo"], control.fixed_params["mid_month_placebo"]) == (0, 1)
    assert rule.param_grid == control.param_grid and "CONTROL" in control.hypothesis
    for family in (rule, control):
        strategy_registry.StrategyFamily(family.family)
        factory = family.factory(timeframe_minutes=60)
        for params in parameter_combinations(family.param_grid):
            assert callable(factory(params))


def test_the_vix_spike_series_differs_from_the_index_series_only_in_its_outside_signal():
    old, _ = runner.PORTFOLIO_SERIES["portfolio-d1-v7-index-anomalies"]
    config, [family] = runner.PORTFOLIO_SERIES["portfolio-d1-v8-vix-spike"]

    assert config == old.__class__(**{**old.__dict__, "series": config.series, "external_daily": ("VIX",),
                                      "bar_features": "fred_daily"})
    assert "CHOSEN AFTER SEEING" in family.hypothesis
    factory = family.factory(timeframe_minutes=1440)
    for params in parameter_combinations(family.param_grid):
        assert callable(factory(params))


def test_the_index_anomaly_series_includes_its_benchmark_and_requires_both_markets():
    from app.quant import strategy_registry

    config, families = runner.PORTFOLIO_SERIES["portfolio-d1-v7-index-anomalies"]
    assert config.symbols == ("US500", "US2000") and config.swap_model and config.external_rates
    assert (config.breadth_min_eligible_symbols, config.breadth_min_positive_fraction) == (2, 1.0)
    assert config.require_multiple_testing_significance
    assert [f.strategy_id for f in families] == ["index-dip-in-uptrend", "turn-of-month-long", "index-unconditional-long"]
    for family in families:
        strategy_registry.StrategyFamily(family.family)
        factory = family.factory(timeframe_minutes=1440)
        for params in parameter_combinations(family.param_grid):
            assert callable(factory(params))


def test_the_carry_series_models_swaps_from_outside_rates():
    from app.quant import strategy_registry
    from app.quant.bar_features import FX_MAJORS

    config, [family] = runner.PORTFOLIO_SERIES["portfolio-d1-v6-carry"]
    assert config.symbols == FX_MAJORS and config.timeframe == "D1"
    assert (config.bar_features, config.external_rates, config.swap_model) == ("interest_rates", "fred_3m_interbank", True)
    assert config.require_multiple_testing_significance and config.rates_lag_months >= 1
    strategy_registry.StrategyFamily(family.family)
    factory = family.factory(timeframe_minutes=1440)
    for params in parameter_combinations(family.param_grid):
        assert callable(factory(params))


def test_the_m15_liquidity_series_builds_with_its_rollover_filter_and_guard():
    from app.quant import signal_filters, strategy_registry

    config, families = runner.PORTFOLIO_SERIES["portfolio-m15-v1-liquidity"]
    assert config.timeframe == "M15" and config.require_multiple_testing_significance
    assert 21 not in config.execution_hours_utc and 22 not in config.execution_hours_utc
    assert config.warmup_bars >= 50 * 96
    for family in families:
        strategy_registry.StrategyFamily(family.family)
        assert family.signal_filter == {"type": "exclude_new_york_hours", "hours": [17, 18]}
        factory = family.factory(timeframe_minutes=15)
        for params in parameter_combinations(family.param_grid):
            assert callable(factory(params))


def test_targets_stay_above_the_live_reward_to_risk_floor():
    for family in runner.DAILY_TREND_FAMILIES:
        assert min(family.param_grid["target_r"]) >= 2.0


def test_the_daily_series_has_enough_walk_forward_windows():
    from app.quant import portfolio_pipeline as pp
    from app.quant.promotion import WALK_FORWARD_MIN_WINDOWS

    for config, _ in runner.PORTFOLIO_SERIES.values():
        dummy = {s: [{"timestamp": config.data_start + "T22:00:00+00:00"}] for s in config.symbols}
        windows = pp.walk_forward_windows(pp.calendar_split(dummy, config), config)
        assert len(windows) >= WALK_FORWARD_MIN_WINDOWS + 2


def test_the_daily_series_does_not_execute_in_the_rollover_hour():
    for config, _ in runner.PORTFOLIO_SERIES.values():
        assert config.execution_hours_utc and 21 not in config.execution_hours_utc
        assert "not modelled" in config.execution_rule


def test_portfolio_series_do_not_collide_with_per_symbol_series():
    assert not set(runner.PORTFOLIO_SERIES) & set(runner.SERIES)
