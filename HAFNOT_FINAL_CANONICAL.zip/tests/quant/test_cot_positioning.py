"""
CFTC positioning research: yearly TFF files parsed by contract code (either date header), the
as-of lag, the per-bar history window, and both strategies' directions.
"""

import io
import zipfile
from datetime import date

import pytest

from app.quant import bar_features, cot_crowding_strategy as crowding, cot_momentum_strategy as momentum
from app.quant import external_cot as ec
from app.quant.external_daily import DailyAsOf

HEADER_OLD = "Market_and_Exchange_Names,Report_Date_as_MM_DD_YYYY,CFTC_Contract_Market_Code,Open_Interest_All,Lev_Money_Positions_Long_All,Lev_Money_Positions_Short_All"
HEADER_NEW = HEADER_OLD.replace("Report_Date_as_MM_DD_YYYY", "Report_Date_as_YYYY-MM-DD")


def _zip(text):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr("FinFutYY.txt", text)
    return buffer.getvalue()


FILES = {
    2011: HEADER_OLD + "\n" + "\n".join([
        '"EURO FX - CHICAGO MERCANTILE EXCHANGE ",2011-01-04,099741,1000,400,100',
        '"BRITISH POUND STERLING - CHICAGO MERCANTILE EXCHANGE ",2011-01-04,096742,500,50,150',
        '"S&P 500 STOCK INDEX - CHICAGO MERCANTILE EXCHANGE",2011-01-04,13874A,9000,1,1',
    ] + [f'"X",2011-01-04,{code},100,10,10' for code in ("097741", "092741", "090741", "232741", "112741")]),
    2012: HEADER_NEW + "\n" + '"BRITISH POUND - CHICAGO MERCANTILE EXCHANGE",01/03/2012,096742,800,400,0',
}


def test_tff_files_are_parsed_by_contract_code_under_either_date_header():
    cot = ec.fetch_cot([2011, 2012], download=lambda url: _zip(FILES[int(url[-8:-4])]))

    assert cot["EUR"] == [["2011-01-04", 0.3]]
    assert cot["GBP"] == [["2011-01-04", -0.2], ["2012-01-03", 0.5]]
    assert set(cot) == set(ec.CONTRACT_CODES) and len(ec.fingerprint(cot)) == 64
    with pytest.raises(ValueError, match="no reports"):
        ec.fetch_cot([2012], download=lambda url: _zip(FILES[2012]))


def test_early_years_come_from_the_combined_archive_and_single_year_files_take_precedence():
    combined = HEADER_OLD + "\n" + "\n".join(
        ['"EURO FX - CHICAGO MERCANTILE EXCHANGE",1/4/2011 12:00:00 AM,099741,1000,100,100',
         '"EURO FX - CHICAGO MERCANTILE EXCHANGE",1/6/2009 12:00:00 AM,099741,1000,600,100']
        + [f'"X",1/6/2009 12:00:00 AM,{code},100,10,10' for code in ("096742", "097741", "092741", "090741", "232741", "112741")])
    requested = []

    def download(url):
        requested.append(url)
        return _zip(combined if url == ec.CFTC_TFF_COMBINED_URL else FILES[int(url[-8:-4])])

    cot = ec.fetch_cot([2009, 2011], download=download)

    assert requested == [ec.CFTC_TFF_COMBINED_URL, ec.CFTC_TFF_URL.format(year=2011)]
    assert cot["EUR"] == [["2009-01-06", 0.5], ["2011-01-04", 0.3]]     # 2011 from the single-year file, not 0.0


def test_a_report_is_known_from_the_following_monday_and_bars_carry_only_a_window():
    series = DailyAsOf([["2026-01-06", 0.1], ["2026-01-13", 0.2]], lag_days=6, max_age_days=13)

    assert series.value(date(2026, 1, 11)) is None and series.value(date(2026, 1, 12)) == 0.1
    assert series.value(date(2026, 1, 19)) == 0.2
    bars = {"EURUSD": [{"timestamp": "2026-01-18T22:00:00+00:00", "close": 1.1}]}          # session Mon 19 Jan
    [bar] = bar_features.enrich("cot_positioning", bars, {"EUR": series})["EURUSD"]
    assert bar["symbol"] == "EURUSD" and bar["cot"] == {"EUR": [0.1, 0.2]}
    with pytest.raises(ValueError, match="needs as-of CFTC series"):
        bar_features.enrich("cot_positioning", bars)


def _bars(symbol, currency, history):
    return [{"open": 1.0, "high": 1.01, "low": 0.99, "close": 1.0, "symbol": symbol, "cot": {currency: history}}
            for _ in range(3)]


CROWD = {"extreme": 0.10, "hold_bars": 10, "lookback_weeks": 20, "stop_atr": 3.0, "atr_period": 2, "target_r": 10.0}


@pytest.mark.parametrize("symbol, currency, latest, expected", [
    ("EURUSD", "EUR", 0.99, "SELL"),     # funds crowded long EUR -> sell EUR
    ("EURUSD", "EUR", -0.99, "BUY"),
    ("USDJPY", "JPY", 0.99, "BUY"),      # crowded long JPY -> sell JPY = buy USDJPY
    ("EURUSD", "EUR", 0.0, None),
])
def test_crowding_fades_extreme_positions(symbol, currency, latest, expected):
    history = [(-1) ** i * i / 100 for i in range(19)] + [latest]

    signal = crowding.evaluate(_bars(symbol, currency, history), **CROWD)

    assert (signal or {}).get("direction") == expected


MOMENTUM = {"change_weeks": 1, "hold_bars": 10, "lookback_weeks": 10, "z_min": 1.0, "stop_atr": 3.0, "atr_period": 2,
            "target_r": 10.0}


def test_momentum_follows_an_unusually_large_change_in_positioning():
    calm = [0.0, 0.01] * 6                                       # changes alternate +-0.01

    assert momentum.evaluate(_bars("AUDUSD", "AUD", calm + [0.20]), **MOMENTUM)["direction"] == "BUY"
    assert momentum.evaluate(_bars("USDCAD", "CAD", calm + [-0.20]), **MOMENTUM)["direction"] == "BUY"   # selling CAD
    # A change of -0.005 is half a standard deviation: no trade. (A normal -0.01 change is exactly -1.0 and does trade.)
    assert momentum.evaluate(_bars("AUDUSD", "AUD", calm + [0.005]), **MOMENTUM) is None
    assert momentum.evaluate(_bars("AUDUSD", "AUD", calm + [0.0]), **MOMENTUM)["direction"] == "SELL"
    assert momentum.evaluate(_bars("AUDUSD", "AUD", calm[:5]), **MOMENTUM) is None                       # too short
