"""
Control-flow tests for the pre-registered research pipeline.

Backtests and walk-forward are injected so each stage's outcome is set exactly;
the real backtest engine is covered by its own tests. What matters here is the
discipline: preregistration first, no re-runs, neighbourhood selection, and the
locked out-of-sample data touched only by candidates that passed everything else.
"""

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from app.quant import experiment_registry, locked_oos_guard, research_pipeline as rp, strategy_registry

START = datetime(2020, 1, 1, tzinfo=timezone.utc)
CONFIG = rp.PipelineConfig(series="test-series", warmup_bars=10, min_train_trades=30)


@pytest.fixture(autouse=True)
def _isolated_storage(tmp_path, monkeypatch):
    monkeypatch.setattr(strategy_registry, "SPECS_DIR", tmp_path / "specs")
    monkeypatch.setattr(strategy_registry, "RESULTS_DIR", tmp_path / "results")
    monkeypatch.setattr(experiment_registry, "EXPERIMENTS_FILE", tmp_path / "experiments.jsonl")
    monkeypatch.setattr(locked_oos_guard, "LOCKED_OOS_DIR", tmp_path / "locked")
    monkeypatch.setattr(rp, "PREREGISTRATION_DIR", tmp_path / "prereg")
    yield


def _definition(**overrides):
    fields = dict(
        strategy_id="test-family", version="1.0.0", family="RANGE", hypothesis="test hypothesis",
        entry_rules="e", exit_rules="x", stop_loss_logic="s", take_profit_logic="t",
        session_conditions="none", regime_conditions="none",
        module="app.quant.range_fade_strategy",
        param_grid={"range_bars": [24, 48, 96], "max_efficiency_ratio": [0.2, 0.3, 0.4]},
        fixed_params={"entry_zone": 0.1},
    )
    fields.update(overrides)
    return rp.FamilyDefinition(**fields)


BARS = [{"timestamp": (START + timedelta(hours=i)).isoformat(), "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0}
        for i in range(1000)]


def _winning(count=40):
    return [{"pnl_usd": 60.0 if i % 2 == 0 else -40.0, "result_r": 1.2 if i % 2 == 0 else -0.8} for i in range(count)]


def _losing(count=40):
    return [{"pnl_usd": 40.0 if i % 2 == 0 else -60.0, "result_r": 0.8 if i % 2 == 0 else -1.2} for i in range(count)]


class FakeTrades:
    """Returns chosen trade lists per slice and records which slices were evaluated."""

    def __init__(self, train=_winning, validation=_winning, locked=_winning):
        self.train, self.validation, self.locked = train, validation, locked
        self.slices = []

    def __call__(self, warmup, evaluation, symbol, factory, params, config):
        if evaluation[0] is BARS[0]:
            self.slices.append("TRAIN")
            return self.train()
        if evaluation[0] is BARS[500]:
            self.slices.append("VALIDATION")
            return self.validation()
        self.slices.append("LOCKED")
        return self.locked()


def _walk_forward(positive=True):
    expectancy = 0.2 if positive else -0.2
    windows = [SimpleNamespace(window_index=i, chosen_params={}, in_sample_expectancy_r=0.2,
                               out_of_sample_expectancy_r=expectancy, out_of_sample_trade_count=40,
                               out_of_sample_net_pnl_usd=100.0) for i in range(4)]
    result = SimpleNamespace(windows=windows, positive_window_fraction=1.0 if positive else 0.0,
                             mean_out_of_sample_expectancy_r=expectancy)
    return lambda *args, **kwargs: result


def _run(trades, walk_forward=None, definition=None):
    definition = definition or _definition()
    rp.preregister(definition, "EURUSD", CONFIG)
    return rp.run_experiment(definition, "EURUSD", CONFIG, bars=BARS, trade_runner=trades,
                             walk_forward_runner=walk_forward or _walk_forward())


# --- neighbourhood selection ---

def test_neighbourhood_selection_prefers_a_plateau_over_an_isolated_peak():
    grid = {"a": [1, 2, 3], "b": [1, 2, 3]}
    scored = []
    for a in grid["a"]:
        for b in grid["b"]:
            expectancy = 1.0 if (a, b) == (3, 3) else (0.2 if a <= 2 and b <= 2 else -0.5)
            scored.append(({"a": a, "b": b}, expectancy, 100))

    chosen = rp.neighbourhood_select(grid, scored, min_trades=30)

    assert chosen != {"a": 3, "b": 3}
    assert chosen["a"] <= 2 and chosen["b"] <= 2


def test_neighbourhood_selection_ignores_thinly_traded_combinations():
    grid = {"a": [1, 2]}
    scored = [({"a": 1}, 5.0, 3), ({"a": 2}, 0.1, 50)]
    assert rp.neighbourhood_select(grid, scored, min_trades=30) == {"a": 2}
    assert rp.neighbourhood_select(grid, [({"a": 1}, 5.0, 3)], min_trades=30) is None


# --- preregistration and re-runs ---

def test_running_without_preregistration_is_refused():
    with pytest.raises(RuntimeError, match="preregistration"):
        rp.run_experiment(_definition(), "EURUSD", CONFIG, bars=BARS, trade_runner=FakeTrades(),
                          walk_forward_runner=_walk_forward())


def test_identical_preregistration_is_kept_with_its_original_timestamp():
    path = rp.preregister(_definition(), "EURUSD", CONFIG)
    first = path.read_text(encoding="utf-8")
    rp.preregister(_definition(), "EURUSD", CONFIG)
    assert path.read_text(encoding="utf-8") == first


def test_changing_criteria_after_preregistration_is_refused():
    rp.preregister(_definition(), "EURUSD", CONFIG)
    with pytest.raises(ValueError, match="different content"):
        rp.preregister(_definition(param_grid={"range_bars": [24, 48], "max_efficiency_ratio": [0.3]}), "EURUSD", CONFIG)


def test_an_experiment_cannot_be_run_twice():
    _run(FakeTrades(train=_losing))
    with pytest.raises(RuntimeError, match="already been run"):
        rp.run_experiment(_definition(), "EURUSD", CONFIG, bars=BARS, trade_runner=FakeTrades(),
                          walk_forward_runner=_walk_forward())


# --- stage gating ---

def test_losing_training_results_stop_before_validation():
    trades = FakeTrades(train=_losing)
    outcome = _run(trades)

    assert outcome.decision == "REJECTED"
    assert outcome.stage_reached == "TRAIN"
    assert "VALIDATION" not in trades.slices and "LOCKED" not in trades.slices
    assert not locked_oos_guard.has_been_consumed(rp.candidate_id_for(_definition(), "EURUSD", CONFIG))


def test_validation_failure_leaves_the_locked_data_untouched():
    trades = FakeTrades(validation=_losing)
    outcome = _run(trades)

    assert outcome.decision == "REJECTED"
    assert outcome.stage_reached == "VALIDATION"
    assert "LOCKED" not in trades.slices
    assert not locked_oos_guard.has_been_consumed(rp.candidate_id_for(_definition(), "EURUSD", CONFIG))


def test_walk_forward_failure_leaves_the_locked_data_untouched():
    trades = FakeTrades()
    outcome = _run(trades, walk_forward=_walk_forward(positive=False))

    assert outcome.stage_reached == "WALK_FORWARD"
    assert outcome.decision == "REJECTED"
    assert "LOCKED" not in trades.slices


def test_candidate_passing_everything_is_accepted_and_uses_its_one_locked_look():
    trades = FakeTrades()
    outcome = _run(trades)

    assert outcome.decision == "ACCEPTED"
    assert outcome.stage_reached == "LOCKED_OUT_OF_SAMPLE"
    assert trades.slices.count("LOCKED") == 1
    assert locked_oos_guard.has_been_consumed(rp.candidate_id_for(_definition(), "EURUSD", CONFIG))

    locked = [r for r in strategy_registry.get_results("test-family", "1.0.0")
              if r["test_type"] == "LOCKED_OUT_OF_SAMPLE_TEST_SERIES"]
    assert locked and locked[0]["scorecard"]["validated"] is True


def test_locked_failure_is_recorded_as_not_validated():
    outcome = _run(FakeTrades(locked=_losing))

    assert outcome.decision == "REJECTED"
    assert outcome.stage_reached == "LOCKED_OUT_OF_SAMPLE"
    locked = [r for r in strategy_registry.get_results("test-family", "1.0.0")
              if r["test_type"] == "LOCKED_OUT_OF_SAMPLE_TEST_SERIES"]
    assert locked[0]["scorecard"]["validated"] is False


def test_every_run_is_recorded_once_in_the_experiment_registry():
    _run(FakeTrades(train=_losing))

    experiments = experiment_registry.list_experiments()
    assert len(experiments) == 1
    assert experiments[0]["decision"] == "REJECTED"
    assert experiments[0]["result"]["stage_reached"] == "TRAIN"


def test_training_and_validation_pair_in_the_scorecard_design():
    _run(FakeTrades(validation=_losing))

    test_types = {r["test_type"] for r in strategy_registry.get_results("test-family", "1.0.0")}
    assert {"IN_SAMPLE_TEST_SERIES", "OUT_OF_SAMPLE_TEST_SERIES"} <= test_types


def test_a_parameter_both_tuned_and_fixed_is_refused():
    with pytest.raises(ValueError, match="both tuned and fixed"):
        _definition(fixed_params={"range_bars": 24}).factory()
