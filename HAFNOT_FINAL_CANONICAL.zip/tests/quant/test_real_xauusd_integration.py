"""
Integration test against the ONE real historical dataset that exists in
this project (data/xauusd_historical_batch10.json, ~740 H4 bars). This is
not a claim of profitability - see hafnot_research_xauusd_demo.py at the
project root for the honest, human-readable report. This test only proves
the pipeline runs end-to-end against real, non-synthetic prices without
crashing and produces internally consistent output.
"""

import json
from pathlib import Path

import pytest

from app.quant.costed_backtest import run_costed_backtest
from app.quant.data_split import chronological_split
from app.quant.strategy_adapter import make_signal_provider

DATA_FILE = Path(__file__).resolve().parents[2] / "data" / "xauusd_historical_batch10.json"


@pytest.mark.skipif(not DATA_FILE.exists(), reason="real historical data file not present")
def test_costed_backtest_runs_on_real_h4_gold_bars_without_lookahead_errors():

    data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    bars = data["H4"]["bars"]

    assert len(bars) > 100

    result = run_costed_backtest(
        bars=bars,
        signal_provider=make_signal_provider(),
        symbol="XAUUSD",
        starting_equity_usd=10_000.0,
    )

    assert result.supported is True
    # No assertion on profitability - only that the pipeline produced a
    # internally consistent result over real data.
    assert result.accepted_trade_count + result.rejected_trade_count == result.raw_signal_count
    for trade in result.trades:
        assert trade.entry_index < trade.exit_index


@pytest.mark.skipif(not DATA_FILE.exists(), reason="real historical data file not present")
def test_in_sample_out_of_sample_split_is_disjoint_on_real_data():

    data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    bars = data["H4"]["bars"]

    split = chronological_split(bars, in_sample_fraction=0.7)

    in_sample_result = run_costed_backtest(
        bars=split.in_sample,
        signal_provider=make_signal_provider(),
        symbol="XAUUSD",
    )
    out_of_sample_result = run_costed_backtest(
        bars=split.out_of_sample,
        signal_provider=make_signal_provider(),
        symbol="XAUUSD",
    )

    assert in_sample_result.supported and out_of_sample_result.supported
    # Both halves must independently run without error; either can have
    # zero trades depending on the strategy's setup frequency in that
    # window - that is real information, not a test failure.
