"""
No tests existed for app.quant.robustness before this - confirmed by
searching tests/ for "robustness" prior to writing this file. These cover
the generalization that lets run_robustness_sweep take ANY strategy's
signal_provider_factory (not just the EMA trend strategy it was
hardcoded to), plus the basic sweep-and-aggregate behavior.
"""

from datetime import datetime, timedelta, timezone

from app.quant.robustness import run_robustness_sweep


def _trending_bars(n, start, *, step=0.5):
    bars = []
    price = 100.0
    for i in range(n):
        ts = start + timedelta(hours=i)
        bars.append({
            "timestamp": ts.isoformat(),
            "open": price, "high": price + 1.0, "low": price - 1.0, "close": price,
        })
        price += step
    return bars


def _always_none_provider_factory(params):
    def provider(visible_bars, index):
        return None
    return provider


def _fixed_signal_provider_factory(params):
    """A fake strategy family whose only 'parameter' controls whether it fires at all."""

    def provider(visible_bars, index):
        if not params.get("enabled", True):
            return None
        if index != len(visible_bars) - 1 or index < 50:
            return None
        price = visible_bars[index]["close"]
        return {
            "direction": "BUY",
            "entry": price,
            "stop_loss": price - 2.0,
            "take_profit": price + 4.0,
        }
    return provider


def test_sweep_with_custom_signal_provider_factory_runs_for_every_combo():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _trending_bars(200, start)

    result = run_robustness_sweep(
        bars, "EURUSD",
        param_grid={"enabled": [True, False]},
        signal_provider_factory=_fixed_signal_provider_factory,
    )

    assert len(result.results) == 2
    params_tried = [r.params for r in result.results]
    assert {"enabled": True} in params_tried
    assert {"enabled": False} in params_tried


def test_disabled_variant_produces_zero_trades_not_an_error():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _trending_bars(200, start)

    result = run_robustness_sweep(
        bars, "EURUSD",
        param_grid={"enabled": [False]},
        signal_provider_factory=_fixed_signal_provider_factory,
    )

    assert result.results[0].trade_count == 0
    assert result.results[0].net_pnl_usd == 0.0


def test_profitable_fraction_is_zero_when_nothing_ever_fires():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _trending_bars(200, start)

    result = run_robustness_sweep(
        bars, "EURUSD",
        param_grid={"x": [1, 2, 3]},
        signal_provider_factory=_always_none_provider_factory,
    )

    assert result.profitable_fraction == 0.0
    assert result.best is None


def test_invalid_combo_is_skipped_not_fatal():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _trending_bars(200, start)

    def factory(params):
        if params["x"] == 2:
            raise ValueError("invalid combination")
        return _always_none_provider_factory(params)

    result = run_robustness_sweep(
        bars, "EURUSD",
        param_grid={"x": [1, 2, 3]},
        signal_provider_factory=factory,
    )

    # Only x=1 and x=3 should have produced a result; x=2 was skipped.
    assert len(result.results) == 2


def test_default_factory_is_the_ema_trend_strategy_when_none_given():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _trending_bars(150, start)

    # Should not raise - exercises the backward-compatible default path
    # (app.forex_v2.strategy.StrategyConfig via app.quant.strategy_adapter).
    result = run_robustness_sweep(
        bars, "EURUSD",
        param_grid={"fast_ema_period": [5], "slow_ema_period": [21]},
    )

    assert len(result.results) == 1
