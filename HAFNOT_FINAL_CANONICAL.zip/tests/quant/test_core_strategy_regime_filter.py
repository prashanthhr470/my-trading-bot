"""
Tests for the Phase 10 regime-filter wiring in app.quant.core_strategy.

The liquidity-sweep+FVG detection logic itself (_try_direction) is already
covered elsewhere and is complex to trigger from scratch here, so these
tests monkeypatch it to return a fixed candidate signal and isolate what
this wiring is actually responsible for: attaching regime info to a found
signal, and optionally gating on it. This keeps the test focused on the
new code path instead of re-deriving a full sweep/FVG bar sequence.
"""

from datetime import datetime, timedelta, timezone

import app.quant.core_strategy as core_strategy
from app.quant.regime_lookup import RegimeLookup


def _bar(ts, price):
    return {"timestamp": ts.isoformat(), "open": price, "high": price + 0.5, "low": price - 0.5, "close": price}


def _make_bars(n, start):
    return [_bar(start + timedelta(minutes=15 * i), 100.0) for i in range(n)]


def _fake_signal(**_kwargs):
    return {
        "direction": "BUY",
        "entry": 100.0,
        "stop_loss": 99.0,
        "take_profit": 102.0,
    }


def _uptrend_h4_bars(n, start):
    bars = []
    price = 100.0
    for i in range(n):
        ts = start + timedelta(hours=4 * i)
        bars.append({"timestamp": ts.isoformat(), "open": price, "high": price + 0.5, "low": price - 0.5, "close": price})
        price += 1.0
    return bars


def test_evaluate_tags_signal_with_regime_when_lookup_given(monkeypatch):
    start = datetime(2026, 1, 6, 6, 0, tzinfo=timezone.utc)  # within London window
    bars = _make_bars(400, start)

    monkeypatch.setattr(core_strategy, "_try_direction", lambda *a, **k: _fake_signal())

    h4_bars = _uptrend_h4_bars(60, start - timedelta(days=10))
    lookup = RegimeLookup(h4_bars)

    signal = core_strategy.evaluate(bars, require_session_window=False, regime_lookup=lookup)

    assert signal is not None
    assert "regime" in signal
    assert signal["regime"]["trend"] == "TREND_BULL"


def test_evaluate_without_regime_lookup_has_no_regime_key(monkeypatch):
    start = datetime(2026, 1, 6, 6, 0, tzinfo=timezone.utc)
    bars = _make_bars(400, start)

    monkeypatch.setattr(core_strategy, "_try_direction", lambda *a, **k: _fake_signal())

    signal = core_strategy.evaluate(bars, require_session_window=False)

    assert signal is not None
    assert "regime" not in signal


def test_require_regime_blocks_signal_when_regime_does_not_match(monkeypatch):
    start = datetime(2026, 1, 6, 6, 0, tzinfo=timezone.utc)
    bars = _make_bars(400, start)

    monkeypatch.setattr(core_strategy, "_try_direction", lambda *a, **k: _fake_signal())

    h4_bars = _uptrend_h4_bars(60, start - timedelta(days=10))
    lookup = RegimeLookup(h4_bars)  # regime will be TREND_BULL at this point

    signal = core_strategy.evaluate(
        bars, require_session_window=False, regime_lookup=lookup,
        require_regime={"TREND_BEAR"},
    )

    assert signal is None


def test_require_regime_allows_signal_when_regime_matches(monkeypatch):
    start = datetime(2026, 1, 6, 6, 0, tzinfo=timezone.utc)
    bars = _make_bars(400, start)

    monkeypatch.setattr(core_strategy, "_try_direction", lambda *a, **k: _fake_signal())

    h4_bars = _uptrend_h4_bars(60, start - timedelta(days=10))
    lookup = RegimeLookup(h4_bars)

    signal = core_strategy.evaluate(
        bars, require_session_window=False, regime_lookup=lookup,
        require_regime={"TREND_BULL"},
    )

    assert signal is not None
    assert signal["regime"]["trend"] == "TREND_BULL"


def test_make_signal_provider_passes_regime_lookup_through(monkeypatch):
    start = datetime(2026, 1, 6, 6, 0, tzinfo=timezone.utc)
    bars = _make_bars(400, start)

    monkeypatch.setattr(core_strategy, "_try_direction", lambda *a, **k: _fake_signal())

    h4_bars = _uptrend_h4_bars(60, start - timedelta(days=10))
    lookup = RegimeLookup(h4_bars)

    provider = core_strategy.make_signal_provider(
        require_session_window=False, regime_lookup=lookup, require_regime={"TREND_BULL"},
    )
    signal = provider(bars, len(bars) - 1)

    assert signal is not None
    assert signal["regime"]["trend"] == "TREND_BULL"
