from datetime import datetime, timedelta, timezone

import pytest

from app.quant.data_split import three_way_chronological_split
from app.quant.locked_oos_guard import (
    LockedOutOfSampleAlreadyConsumed,
    consume_locked_out_of_sample,
    has_been_consumed,
    load_consumption,
)


def _bars(n):
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    return [
        {"timestamp": (start + timedelta(hours=i)).isoformat(), "close": 100.0 + i}
        for i in range(n)
    ]


# --- three_way_chronological_split ---

def test_three_way_split_covers_all_bars_with_no_overlap():
    bars = _bars(1000)
    split = three_way_chronological_split(bars, train_fraction=0.5, validation_fraction=0.25)

    assert split.train + split.validation + split.locked_out_of_sample == bars
    assert len(split.train) > 0
    assert len(split.validation) > 0
    assert len(split.locked_out_of_sample) > 0


def test_three_way_split_is_chronological_not_random():
    bars = _bars(300)
    split = three_way_chronological_split(bars)

    assert split.train[-1]["timestamp"] < split.validation[0]["timestamp"]
    assert split.validation[-1]["timestamp"] < split.locked_out_of_sample[0]["timestamp"]


def test_three_way_split_rejects_fractions_leaving_no_room_for_locked_oos():
    bars = _bars(300)
    with pytest.raises(ValueError):
        three_way_chronological_split(bars, train_fraction=0.6, validation_fraction=0.5)


def test_three_way_split_rejects_invalid_fraction_bounds():
    bars = _bars(300)
    with pytest.raises(ValueError):
        three_way_chronological_split(bars, train_fraction=0.0)
    with pytest.raises(ValueError):
        three_way_chronological_split(bars, validation_fraction=1.5)


# --- locked_oos_guard ---

@pytest.fixture(autouse=True)
def _use_tmp_locked_oos_dir(tmp_path, monkeypatch):
    import app.quant.locked_oos_guard as guard
    monkeypatch.setattr(guard, "LOCKED_OOS_DIR", tmp_path / "locked_oos")
    yield


def test_first_consumption_succeeds_and_is_recorded():
    bars = _bars(50)
    assert not has_been_consumed("candidate-a")

    record = consume_locked_out_of_sample("candidate-a", bars, evidence={"net_pnl_usd": -12.5})

    assert has_been_consumed("candidate-a")
    assert record.candidate_id == "candidate-a"
    loaded = load_consumption("candidate-a")
    assert loaded.evidence == {"net_pnl_usd": -12.5}


def test_second_consumption_of_same_candidate_is_refused():
    bars = _bars(50)
    consume_locked_out_of_sample("candidate-b", bars, evidence={"net_pnl_usd": 10.0})

    with pytest.raises(LockedOutOfSampleAlreadyConsumed):
        consume_locked_out_of_sample("candidate-b", bars, evidence={"net_pnl_usd": 999.0})


def test_second_consumption_refused_even_with_different_slice():
    """
    The point of the guard is that a candidate gets ONE look at locked
    OOS - not one look per distinct data slice. A second attempt with
    different (e.g. extended) data must still be refused.
    """

    bars_v1 = _bars(50)
    bars_v2 = _bars(80)  # different fingerprint (more bars)

    consume_locked_out_of_sample("candidate-c", bars_v1, evidence={"net_pnl_usd": -5.0})

    with pytest.raises(LockedOutOfSampleAlreadyConsumed):
        consume_locked_out_of_sample("candidate-c", bars_v2, evidence={"net_pnl_usd": 50.0})


def test_different_candidate_ids_are_independent():
    bars = _bars(50)
    consume_locked_out_of_sample("candidate-d", bars, evidence={})
    # A different candidate_id (a genuinely new attempt) is unaffected.
    consume_locked_out_of_sample("candidate-e", bars, evidence={})

    assert has_been_consumed("candidate-d")
    assert has_been_consumed("candidate-e")
