from datetime import datetime, timedelta, timezone

from app.quant.regime_lookup import RegimeLookup


def _bar(ts, close, *, high=None, low=None):
    high = close + 0.5 if high is None else high
    low = close - 0.5 if low is None else low
    return {"timestamp": ts.isoformat(), "open": close, "high": high, "low": low, "close": close}


def _uptrend_bars(n, start_ts, *, step_hours=4, start_price=100.0, step=0.5):
    bars = []
    price = start_price
    for i in range(n):
        ts = start_ts + timedelta(hours=step_hours * i)
        bars.append(_bar(ts, price))
        price += step
    return bars


def _flat_bars(n, start_ts, *, step_hours=4, price=100.0):
    bars = []
    for i in range(n):
        ts = start_ts + timedelta(hours=step_hours * i)
        bars.append(_bar(ts, price))
    return bars


def test_uptrend_series_classified_as_trend_bull():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _uptrend_bars(120, start, step=1.0)

    lookup = RegimeLookup(bars)
    result = lookup.regime_at(bars[-1]["timestamp"] and datetime.fromisoformat(bars[-1]["timestamp"]))

    assert result["available"] is True
    assert result["trend"] == "TREND_BULL"


def test_downtrend_series_classified_as_trend_bear():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _uptrend_bars(120, start, step=-1.0, start_price=500.0)

    lookup = RegimeLookup(bars)
    result = lookup.regime_at(datetime.fromisoformat(bars[-1]["timestamp"]))

    assert result["trend"] == "TREND_BEAR"


def test_flat_series_classified_as_range():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _flat_bars(120, start)

    lookup = RegimeLookup(bars)
    result = lookup.regime_at(datetime.fromisoformat(bars[-1]["timestamp"]))

    assert result["trend"] == "RANGE"


def test_regime_at_is_anti_lookahead_safe():
    """
    A later, dramatic trend reversal must not be visible to a regime_at()
    query timestamped before that reversal happened - same anti-lookahead
    guarantee as H4TrendLookup.trend_at().
    """

    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    flat = _flat_bars(80, start)
    # Sharp reversal into a strong downtrend appended after the flat period.
    reversal_start = start + timedelta(hours=4 * 80)
    downtrend = _uptrend_bars(80, reversal_start, step=-3.0, start_price=100.0)
    bars = flat + downtrend

    lookup = RegimeLookup(bars)

    query_ts = datetime.fromisoformat(flat[-1]["timestamp"])
    result_before_reversal = lookup.regime_at(query_ts)

    assert result_before_reversal["trend"] in ("RANGE", "UNKNOWN")

    query_ts_after = datetime.fromisoformat(bars[-1]["timestamp"])
    result_after_reversal = lookup.regime_at(query_ts_after)
    assert result_after_reversal["trend"] == "TREND_BEAR"


def test_volatility_spike_classified_as_high():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    calm = _flat_bars(60, start)

    spike_start = start + timedelta(hours=4 * 60)
    spiky = []
    price = 100.0
    for i in range(30):
        ts = spike_start + timedelta(hours=4 * i)
        spiky.append(_bar(ts, price, high=price + 20, low=price - 20))

    bars = calm + spiky
    lookup = RegimeLookup(bars)

    result = lookup.regime_at(datetime.fromisoformat(bars[-1]["timestamp"]))
    assert result["volatility"] == "HIGH"


def test_regime_at_before_any_data_reports_unavailable():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = _flat_bars(50, start)
    lookup = RegimeLookup(bars)

    before_all_data = start - timedelta(days=365)
    result = lookup.regime_at(before_all_data)
    assert result["available"] is False
