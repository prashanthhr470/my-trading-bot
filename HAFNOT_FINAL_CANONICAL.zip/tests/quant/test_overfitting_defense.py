import pytest

from app.quant import overfitting_defense as od


# --- parameter sensitivity ---

def test_no_sweep_data_is_insufficient_not_passing():
    result = od.assess_parameter_sensitivity()
    assert result.verdict == "INSUFFICIENT_DATA"


def test_zero_percent_profitable_flagged_no_edge():
    result = od.assess_parameter_sensitivity(profitable_fraction=0.0, combos_tried=9)
    assert result.verdict == "NO_EDGE"
    assert result.flags


def test_isolated_peak_flagged_when_few_combos_profitable():
    result = od.assess_parameter_sensitivity(profitable_fraction=0.1, combos_tried=20)
    assert result.verdict == "ISOLATED_PEAK"
    assert result.flags


def test_majority_profitable_is_plateau_not_flagged():
    result = od.assess_parameter_sensitivity(profitable_fraction=0.65, combos_tried=20)
    assert result.verdict == "PLATEAU"
    assert result.flags == []


def test_high_parameter_count_flagged_regardless_of_plateau():
    result = od.assess_parameter_sensitivity(profitable_fraction=0.8, tuned_parameter_count=7)
    assert result.verdict == "PLATEAU"
    assert any("independently tuned" in f for f in result.flags)


# --- walk-forward stability ---

def test_too_few_windows_is_insufficient_data():
    result = od.assess_walk_forward_windows([
        {"out_of_sample_expectancy_r": 0.1, "out_of_sample_trade_count": 10},
    ])
    assert result.verdict == "INSUFFICIENT_DATA"


def test_mostly_negative_windows_flagged_unstable():
    windows = [
        {"out_of_sample_expectancy_r": -0.2, "out_of_sample_trade_count": 20},
        {"out_of_sample_expectancy_r": -0.1, "out_of_sample_trade_count": 22},
        {"out_of_sample_expectancy_r": 0.3, "out_of_sample_trade_count": 18},
        {"out_of_sample_expectancy_r": -0.15, "out_of_sample_trade_count": 21},
    ]
    result = od.assess_walk_forward_windows(windows)
    assert result.verdict == "UNSTABLE"
    assert result.positive_window_fraction == pytest.approx(0.25)


def test_consistent_positive_windows_with_stable_trade_counts_is_stable():
    windows = [
        {"out_of_sample_expectancy_r": 0.15, "out_of_sample_trade_count": 20},
        {"out_of_sample_expectancy_r": 0.20, "out_of_sample_trade_count": 21},
        {"out_of_sample_expectancy_r": 0.10, "out_of_sample_trade_count": 19},
        {"out_of_sample_expectancy_r": 0.18, "out_of_sample_trade_count": 22},
    ]
    result = od.assess_walk_forward_windows(windows)
    assert result.verdict == "STABLE"
    assert result.flags == []


def test_wildly_varying_trade_counts_flagged_even_if_all_positive():
    windows = [
        {"out_of_sample_expectancy_r": 0.1, "out_of_sample_trade_count": 2},
        {"out_of_sample_expectancy_r": 0.1, "out_of_sample_trade_count": 40},
        {"out_of_sample_expectancy_r": 0.1, "out_of_sample_trade_count": 3},
        {"out_of_sample_expectancy_r": 0.1, "out_of_sample_trade_count": 35},
    ]
    result = od.assess_walk_forward_windows(windows)
    assert result.verdict == "UNSTABLE"
    assert any("varies sharply" in f for f in result.flags)


def test_first_half_vs_second_half_sign_flip_flagged():
    windows = [
        {"out_of_sample_expectancy_r": 0.3, "out_of_sample_trade_count": 20},
        {"out_of_sample_expectancy_r": 0.25, "out_of_sample_trade_count": 20},
        {"out_of_sample_expectancy_r": -0.3, "out_of_sample_trade_count": 20},
        {"out_of_sample_expectancy_r": -0.25, "out_of_sample_trade_count": 20},
    ]
    result = od.assess_walk_forward_windows(windows)
    assert any("flips sign" in f for f in result.flags)


# --- trade concentration ---

def test_too_few_trades_is_insufficient_data():
    trades = [{"net_pnl_usd": 10.0}, {"net_pnl_usd": -5.0}]
    result = od.assess_trade_concentration(trades)
    assert result.verdict == "INSUFFICIENT_DATA"


def test_evenly_distributed_wins_not_flagged():
    trades = [{"net_pnl_usd": 10.0} for _ in range(10)] + [{"net_pnl_usd": -8.0} for _ in range(5)]
    result = od.assess_trade_concentration(trades)
    assert result.verdict == "DISTRIBUTED"
    assert result.flags == []


def test_profit_dominated_by_one_trade_flagged_concentrated():
    trades = [{"net_pnl_usd": 1000.0}] + [{"net_pnl_usd": 5.0} for _ in range(9)] + [{"net_pnl_usd": -20.0} for _ in range(5)]
    result = od.assess_trade_concentration(trades)
    assert result.verdict == "CONCENTRATED"
    assert any("Top 3" in f for f in result.flags)


def test_removing_best_trade_flips_to_loss_is_flagged():
    trades = [{"net_pnl_usd": 500.0}] + [{"net_pnl_usd": -50.0} for _ in range(9)]
    result = od.assess_trade_concentration(trades)
    assert any("depends entirely on one outlier" in f for f in result.flags)


# --- IS/OOS divergence (shared with scorecard) ---

def test_flag_is_oos_divergence_sign_flip():
    flags = od.flag_is_oos_divergence(
        in_sample_trades=10, in_sample_net_pnl_usd=1000.0,
        out_of_sample_trades=10, out_of_sample_net_pnl_usd=-100.0,
    )
    assert any("sign flip" in f.lower() for f in flags)
    assert any("divergence" in f.lower() for f in flags)


def test_flag_is_oos_divergence_no_flags_when_consistent():
    flags = od.flag_is_oos_divergence(
        in_sample_trades=10, in_sample_net_pnl_usd=100.0,
        out_of_sample_trades=10, out_of_sample_net_pnl_usd=95.0,
    )
    assert flags == []


# --- consolidated report ---

def test_report_with_no_evidence_at_all():
    report = od.build_overfitting_report()
    assert report.verdict == "INSUFFICIENT_EVIDENCE"
    assert report.not_yet_automated


def test_report_marks_brittle_when_any_subcheck_is_brittle():
    report = od.build_overfitting_report(profitable_fraction=0.05, combos_tried=20)
    assert report.verdict == "BRITTLE"
    assert report.flags


def test_report_marks_robust_only_when_all_supplied_checks_pass():
    windows = [
        {"out_of_sample_expectancy_r": 0.15, "out_of_sample_trade_count": 20},
        {"out_of_sample_expectancy_r": 0.20, "out_of_sample_trade_count": 21},
        {"out_of_sample_expectancy_r": 0.10, "out_of_sample_trade_count": 19},
    ]
    trades = [{"net_pnl_usd": 20.0} for _ in range(10)] + [{"net_pnl_usd": -10.0} for _ in range(4)]
    report = od.build_overfitting_report(
        profitable_fraction=0.7, combos_tried=20,
        walk_forward_windows=windows, trades=trades,
        in_sample_trades=20, in_sample_net_pnl_usd=100.0,
        out_of_sample_trades=20, out_of_sample_net_pnl_usd=95.0,
    )
    assert report.verdict == "ROBUST"
    assert report.flags == []
