"""
Filtered families in the research pipeline: the filter is recorded in the
preregistration (and absent for unfiltered families, so earlier series stay
byte-identical), applied by the factory, and kept by the registered spec.
"""

from dataclasses import replace
from datetime import datetime, timezone

import pytest

import app.quant.research_pipeline as rp
from app.quant import signal_filters

CONFIG = rp.PipelineConfig(series="test-series")
LONDON_ONLY = {"type": "session", "allowed_sessions": ["LONDON"]}
PARAMS = {"lookback": 3, "entry_z": 0.1}


def _definition(**overrides):
    fields = dict(
        strategy_id="test-mean-reversion", version="1.0.0", family="MEAN_REVERSION", hypothesis="test hypothesis",
        entry_rules="e", exit_rules="x", stop_loss_logic="s", take_profit_logic="t",
        session_conditions="None.", regime_conditions="None.",
        module="app.quant.mean_reversion_strategy",
        param_grid={"lookback": [3, 5], "entry_z": [0.1, 0.2]},
        fixed_params={"atr_period": 1, "stop_atr": 0.1, "min_reward_to_risk": 1.5},
    )
    fields.update(overrides)
    return rp.FamilyDefinition(**fields)


def _off_hours_bars():
    # Closing 21:00-23:00 UTC in January: London is closed; the last close is far below the mean.
    return [{"timestamp": datetime(2026, 1, 14, 20 + i, tzinfo=timezone.utc).isoformat(),
             "open": price, "high": price + 0.001, "low": price - 0.001, "close": price}
            for i, price in enumerate([1.0, 1.0, 0.9])]


def test_an_unfiltered_preregistration_has_no_filter_keys():
    body = rp._preregistration_body(_definition(), "EURUSD", CONFIG)

    assert "signal_filter" not in body
    assert "signal_filter_rule" not in body


def test_a_filtered_preregistration_records_the_filter_and_its_rule():
    body = rp._preregistration_body(_definition(signal_filter=LONDON_ONLY), "EURUSD", CONFIG)

    assert body["signal_filter"] == LONDON_ONLY
    assert body["signal_filter_rule"] == signal_filters.describe(LONDON_ONLY)


def test_an_invalid_filter_is_refused_before_anything_runs():
    with pytest.raises(ValueError):
        _definition(signal_filter={"type": "news"}).factory()


def test_the_factory_applies_the_filter_and_nothing_else():
    bars = _off_hours_bars()

    assert _definition().factory()(PARAMS)(bars, 2) is not None
    assert _definition(signal_filter=LONDON_ONLY).factory()(PARAMS)(bars, 2) is None


def test_a_filtered_family_is_registered_so_it_cannot_run_unfiltered(monkeypatch):
    captured = []
    monkeypatch.setattr(rp.strategy_registry, "register_strategy", lambda spec: captured.append(spec))

    rp._register_spec(_definition(signal_filter=LONDON_ONLY, fixed_params={**_definition().fixed_params, **PARAMS},
                                  param_grid={"x": [1]}), CONFIG, ["EURUSD"])

    [spec] = captured
    assert spec.signal_provider_module == "app.quant.signal_filters"
    assert spec.signal_provider_kwargs["signal_filter"] == LONDON_ONLY
    assert spec.build_signal_provider()(_off_hours_bars(), 2) is None


def test_the_runner_changes_nothing_but_the_filter():
    import hafnot_run_research_pipeline as runner

    assert all(family.signal_filter is None for family in runner.FAMILIES)
    assert len(runner.FILTERED_FAMILIES) == len(runner.FILTERS) * len(runner.FAMILIES)
    for variant in runner.FILTERED_FAMILIES:
        base = runner.BASE_OF[variant.strategy_id]
        assert (variant.module, variant.version, variant.family, variant.param_grid, variant.fixed_params) == \
               (base.module, base.version, base.family, base.param_grid, base.fixed_params)
        assert replace(variant, strategy_id=base.strategy_id, signal_filter=None, hypothesis=base.hypothesis,
                       session_conditions=base.session_conditions, regime_conditions=base.regime_conditions) == base
        signal_filters.validate_filter(variant.signal_filter)
