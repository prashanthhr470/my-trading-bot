"""
Signal filters for incremental-feature experiments: they may only remove
signals, must judge the session at the bar's CLOSE (timestamps are bar open
times), must be DST-correct, and the volatility regime must match
app.quant.regime_lookup label-for-label using only past bars.
"""

import random
from datetime import datetime, timedelta, timezone

import pytest

from app.quant import signal_filters as sf
from app.quant.regime_lookup import RegimeLookup

CANDIDATE = {"direction": "BUY", "entry": 1.0, "stop_loss": 0.99, "take_profit": 1.02}


def _always(visible_bars, index):
    return CANDIDATE


def _bar(opened_utc, price=1.0):
    return {"timestamp": opened_utc.isoformat(), "open": price, "high": price + 0.001, "low": price - 0.001, "close": price}


def _utc(*args):
    return datetime(*args, tzinfo=timezone.utc)


LIQUID = {"LONDON", "NEW_YORK"}


# --- session filter ---

def test_the_session_is_judged_when_the_bar_closes_not_when_it_opens():
    provider = sf.with_session_filter(_always, allowed_sessions=LIQUID, timeframe_minutes=60)

    # January: London opens 08:00 UTC. A bar opening 07:00 closes 08:00 - London is open at decision time.
    assert provider([_bar(_utc(2026, 1, 14, 7))], 0) == CANDIDATE
    # A bar opening 06:00 closes 07:00, before London opens.
    assert provider([_bar(_utc(2026, 1, 14, 6))], 0) is None


def test_the_session_follows_daylight_saving_time():
    provider = sf.with_session_filter(_always, allowed_sessions=LIQUID, timeframe_minutes=60)

    # The same 06:00 UTC bar: closed London in January, open London in July (BST opens 07:00 UTC).
    assert provider([_bar(_utc(2026, 1, 14, 6))], 0) is None
    assert provider([_bar(_utc(2026, 7, 15, 6))], 0) == CANDIDATE


def test_off_hours_is_its_own_session():
    # 23:00 UTC in January: Tokyo 08:00 (not yet open), London and New York closed.
    assert sf.sessions_at(_utc(2026, 1, 14, 23)) == frozenset({"OFF_HOURS"})
    assert sf.sessions_at(_utc(2026, 1, 14, 3)) == frozenset({"TOKYO"})


def test_a_filter_never_adds_a_signal():
    provider = sf.with_session_filter(lambda bars, i: None, allowed_sessions=sf.SESSION_NAMES, timeframe_minutes=60)
    assert provider([_bar(_utc(2026, 1, 14, 12))], 0) is None


# --- volatility regime ---

def _volatile_series(count=900, seed=7):
    rng = random.Random(seed)
    bars, price = [], 100.0
    start = _utc(2024, 1, 1)
    for i in range(count):
        scale = 0.2 if 300 <= i < 400 else (3.0 if 600 <= i < 650 else 1.0)
        move = rng.gauss(0, 0.5) * scale
        high = max(price, price + move) + abs(rng.gauss(0, 0.3)) * scale
        low = min(price, price + move) - abs(rng.gauss(0, 0.3)) * scale
        bars.append({"timestamp": (start + timedelta(hours=i)).isoformat(),
                     "open": price, "high": high, "low": low, "close": price + move})
        price += move
    return bars


def test_incremental_labels_match_regime_lookup_exactly():
    bars = _volatile_series()
    tracker = sf.VolatilityRegimeTracker()

    incremental = [tracker.label_at_end(bars[:i + 1]) for i in range(len(bars))]

    assert incremental == RegimeLookup(bars)._volatility
    assert {"HIGH", "LOW", "NORMAL", "UNKNOWN"} <= set(incremental)


def test_a_label_never_changes_when_later_bars_arrive():
    bars = _volatile_series()
    labels_now = [sf.VolatilityRegimeTracker().label_at_end(bars[:i + 1]) for i in (250, 620, 880)]
    full = RegimeLookup(bars)._volatility

    assert labels_now == [full[250], full[620], full[880]]


def test_the_tracker_starts_over_on_a_different_series():
    first, second = _volatile_series(seed=1), _volatile_series(seed=2)
    second = [{**bar, "timestamp": (_utc(2025, 1, 1) + timedelta(hours=i)).isoformat()} for i, bar in enumerate(second)]
    tracker = sf.VolatilityRegimeTracker()
    for i in range(700):
        tracker.label_at_end(first[:i + 1])

    labels = [tracker.label_at_end(second[:i + 1]) for i in range(700)]

    assert labels == RegimeLookup(second[:700])._volatility


def test_volatility_filter_drops_blocked_regimes_only():
    bars = _volatile_series()
    full = RegimeLookup(bars)._volatility
    provider = sf.with_volatility_filter(_always, blocked_labels={"HIGH", "UNKNOWN"})

    kept = [provider(bars[:i + 1], i) is not None for i in range(len(bars))]

    assert kept == [label not in {"HIGH", "UNKNOWN"} for label in full]


# --- specs ---

@pytest.mark.parametrize("spec", [
    {"type": "session", "allowed_sessions": []},
    {"type": "session", "allowed_sessions": ["SYDNEY"]},
    {"type": "session", "allowed_sessions": ["LONDON"], "extra": 1},
    {"type": "volatility_regime", "blocked_labels": ["EXTREME"]},
    {"type": "news"},
])
def test_invalid_filter_specs_are_refused(spec):
    with pytest.raises(ValueError):
        sf.validate_filter(spec)


def test_no_filter_returns_the_provider_unchanged():
    assert sf.apply_filter(_always, None, timeframe_minutes=60) is _always


def test_registry_factory_rebuilds_the_strategy_with_its_filter():
    from app.quant import mean_reversion_strategy

    params = dict(lookback=3, entry_z=0.1, atr_period=1, stop_atr=0.1)
    # Bars closing 21:00-23:00 UTC in January: London is closed.
    bars = [_bar(_utc(2026, 1, 14, 20 + i), price) for i, price in enumerate([1.0, 1.0, 0.9])]
    provider = sf.make_filtered_signal_provider(
        base_module="app.quant.mean_reversion_strategy",
        signal_filter={"type": "session", "allowed_sessions": ["LONDON"]},
        timeframe_minutes=60, **params,
    )

    # Control: the base strategy alone does signal on these bars, so the None below is the filter's doing.
    assert mean_reversion_strategy.make_signal_provider(**params)(bars, 2) is not None
    assert provider(bars, 2) is None

    with pytest.raises(ValueError):
        sf.make_filtered_signal_provider(base_module="app.quant.mean_reversion_strategy",
                                         signal_filter={"type": "session", "allowed_sessions": ["LONDON"]},
                                         timeframe_minutes=60, not_a_parameter=1)
