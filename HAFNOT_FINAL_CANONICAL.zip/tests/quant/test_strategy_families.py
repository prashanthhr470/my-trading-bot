"""
Unit tests for the four strategy families and their shared features.

Each family is exercised on small synthetic series built to trigger (and to not
trigger) its rules. The tests assert structure - direction, where the stop and
target sit, the reward:risk floor - and that the bar being broken is never used
to define the level it breaks.
"""

from datetime import datetime, timedelta, timezone

import pytest

from app.quant import (
    failed_breakout_strategy as failed,
    features,
    mean_reversion_strategy as meanrev,
    range_fade_strategy as rangefade,
    volatility_breakout_strategy as volbreak,
)

START = datetime(2026, 1, 5, tzinfo=timezone.utc)


def bar(index, close, high=None, low=None):
    return {
        "timestamp": (START + timedelta(hours=index)).isoformat(),
        "open": close,
        "high": close + 0.05 if high is None else high,
        "low": close - 0.05 if low is None else low,
        "close": close,
    }


def triangle(count, low=99.0, high=101.0, step=0.2, start_index=0):
    """Closes that walk up and down between two levels - choppy, range-bound."""
    out, price, direction = [], low, 1
    for i in range(count):
        out.append(bar(start_index + i, round(price, 4)))
        price += direction * step
        if price >= high or price <= low:
            direction *= -1
    return out


# --- features ---

def test_average_true_range_uses_previous_close_gaps():
    bars = [bar(0, 100.0), bar(1, 102.0, high=102.1, low=101.9)]
    # True range = max(0.2, |102.1 - 100|, |101.9 - 100|) = 2.1
    assert features.average_true_range(bars, 1) == pytest.approx(2.1)
    assert features.average_true_range(bars, 2) is None


def test_efficiency_ratio_extremes():
    assert features.efficiency_ratio([1, 2, 3, 4]) == pytest.approx(1.0)
    assert features.efficiency_ratio([1, 2, 1, 2, 1]) == pytest.approx(0.0)
    assert features.efficiency_ratio([5, 5, 5]) == 0.0


def test_reward_to_risk_rejects_invalid_structure():
    assert features.reward_to_risk("BUY", 100, 99, 102) == pytest.approx(2.0)
    assert features.reward_to_risk("SELL", 100, 101, 97) == pytest.approx(3.0)
    assert features.reward_to_risk("BUY", 100, 101, 102) is None
    assert features.reward_to_risk("SELL", 100, 101, 102) is None


def test_unknown_parameter_is_refused_rather_than_silently_defaulted():
    for module in (meanrev, volbreak, failed, rangefade):
        with pytest.raises(ValueError):
            module.make_signal_provider(not_a_real_parameter=1)


# --- mean reversion ---

def _mean_reversion_series(last_close):
    series = [bar(i, 100.0 + (0.2 if i % 2 else 0.0)) for i in range(60)]
    series.append(bar(60, last_close, high=100.2, low=last_close - 0.05))
    return series


def test_mean_reversion_buys_an_extreme_low_with_target_at_the_mean():
    bars = _mean_reversion_series(99.0)
    signal = meanrev.make_signal_provider()(bars, len(bars) - 1)

    assert signal["direction"] == "BUY"
    expected_mean = features.mean(features.closes(bars[-50:]))
    assert signal["take_profit"] == pytest.approx(expected_mean)
    assert signal["stop_loss"] < signal["entry"] < signal["take_profit"]
    assert signal["reward_to_risk"] >= 1.5


def test_mean_reversion_sells_an_extreme_high():
    bars = [bar(i, 100.0 + (0.2 if i % 2 else 0.0)) for i in range(60)]
    bars.append(bar(60, 101.2, high=101.25, low=100.0))

    signal = meanrev.make_signal_provider()(bars, len(bars) - 1)

    assert signal["direction"] == "SELL"
    assert signal["take_profit"] < signal["entry"] < signal["stop_loss"]


def test_mean_reversion_ignores_ordinary_moves():
    bars = _mean_reversion_series(100.1)
    assert meanrev.make_signal_provider()(bars, len(bars) - 1) is None


def test_mean_reversion_respects_the_reward_to_risk_floor():
    bars = _mean_reversion_series(99.0)
    assert meanrev.make_signal_provider(stop_atr=50.0)(bars, len(bars) - 1) is None


def test_mean_reversion_needs_enough_history():
    assert meanrev.make_signal_provider()(_mean_reversion_series(99.0)[:20], 19) is None


# --- volatility compression breakout ---

def _compression_series(breakout_close, box_high=100.2, box_low=99.8, current_high=None):
    wide = [bar(i, 100.0 + (1.5 if i % 2 else -1.5), high=102.0, low=98.0) for i in range(110)]
    box = [bar(110 + i, 100.0, high=box_high, low=box_low) for i in range(12)]
    current = bar(122, breakout_close, high=current_high if current_high is not None else breakout_close + 0.05)
    return wide + box + [current]


def test_compressed_box_breakout_buys_with_stop_at_box_midpoint():
    bars = _compression_series(100.5)
    signal = volbreak.make_signal_provider()(bars, len(bars) - 1)

    assert signal["direction"] == "BUY"
    assert signal["stop_loss"] == pytest.approx(100.0)
    assert signal["take_profit"] == pytest.approx(100.5 + 2.0 * 0.5)


def test_uncompressed_box_does_not_trade():
    bars = _compression_series(110.5, box_high=110.0, box_low=90.0)
    assert volbreak.make_signal_provider()(bars, len(bars) - 1) is None


def test_close_inside_the_box_does_not_trade():
    bars = _compression_series(100.1)
    assert volbreak.make_signal_provider()(bars, len(bars) - 1) is None


def test_breakout_bar_never_defines_its_own_box():
    # A huge spike high on the current bar must not move the box it is breaking.
    bars = _compression_series(100.5, current_high=150.0)
    signal = volbreak.make_signal_provider()(bars, len(bars) - 1)

    assert signal["box_high"] == pytest.approx(100.2)
    assert signal["stop_loss"] == pytest.approx(100.0)


# --- failed breakout ---

def _failed_breakout_series(direction):
    reference = triangle(40, low=95.0, high=105.0, step=0.5)[-24:]
    base = [bar(i, reference[0]["close"]) for i in range(20)]
    history = base + [dict(b, timestamp=(START + timedelta(hours=20 + i)).isoformat()) for i, b in enumerate(reference)]
    n = len(history)
    if direction == "SELL":
        breakout = bar(n, 105.5, high=105.8, low=104.9)
        current = bar(n + 1, 104.0, high=105.2, low=103.9)
    else:
        breakout = bar(n, 94.5, high=95.1, low=94.2)
        current = bar(n + 1, 96.0, high=96.1, low=94.8)
    return history + [breakout, current]


def test_failed_upside_breakout_sells_toward_the_range_midpoint():
    bars = _failed_breakout_series("SELL")
    signal = failed.make_signal_provider()(bars, len(bars) - 1)

    reference = bars[-26:-2]
    midpoint = (features.highest_high(reference) + features.lowest_low(reference)) / 2
    assert signal["direction"] == "SELL"
    assert signal["take_profit"] == pytest.approx(midpoint)
    assert signal["stop_loss"] > max(bars[-2]["high"], bars[-1]["high"])
    assert signal["reward_to_risk"] >= 1.5


def test_failed_downside_breakout_buys():
    bars = _failed_breakout_series("BUY")
    signal = failed.make_signal_provider()(bars, len(bars) - 1)

    assert signal["direction"] == "BUY"
    assert signal["stop_loss"] < min(bars[-2]["low"], bars[-1]["low"])


def test_breakout_that_holds_is_not_a_failure():
    bars = _failed_breakout_series("SELL")
    bars[-1] = bar(len(bars) - 1, 105.6, high=105.9, low=105.3)
    assert failed.make_signal_provider()(bars, len(bars) - 1) is None


# --- range fade ---

def test_range_fade_buys_near_the_bottom_of_a_choppy_range():
    history = triangle(80, low=99.0, high=101.0, step=0.2)
    bars = history + [bar(80, 99.1)]
    signal = rangefade.make_signal_provider()(bars, len(bars) - 1)

    reference = bars[-49:-1]
    midpoint = (features.highest_high(reference) + features.lowest_low(reference)) / 2
    assert signal["direction"] == "BUY"
    assert signal["take_profit"] == pytest.approx(midpoint)
    assert signal["stop_loss"] < features.lowest_low(reference)
    assert signal["efficiency_ratio"] <= 0.30


def test_range_fade_sells_near_the_top():
    history = triangle(80, low=99.0, high=101.0, step=0.2)
    bars = history + [bar(80, 100.95)]
    signal = rangefade.make_signal_provider()(bars, len(bars) - 1)

    assert signal["direction"] == "SELL"


def test_range_fade_stays_out_of_a_trend():
    trending = [bar(i, 100.0 + 0.2 * i) for i in range(80)]
    bars = trending + [bar(80, 100.0 + 0.2 * 49 + 0.1)]
    assert rangefade.make_signal_provider()(bars, len(bars) - 1) is None


def test_range_fade_ignores_the_middle_of_the_range():
    history = triangle(80, low=99.0, high=101.0, step=0.2)
    bars = history + [bar(80, 100.0)]
    assert rangefade.make_signal_provider()(bars, len(bars) - 1) is None


def test_range_fade_refuses_overlapping_entry_zones():
    with pytest.raises(ValueError):
        rangefade.make_signal_provider(entry_zone=0.5)
