"""
Forward tracking: only closed bars after the registration's start count, open trades are
not scored, the registration can never be rewritten, and the verdict waits for enough trades.
"""

import json
from datetime import datetime, timedelta, timezone

import pytest

import hafnot_forward_tracker as ft

NOW = datetime(2026, 12, 1, 12, tzinfo=timezone.utc)


def _bar(opened):
    return {"timestamp": opened.isoformat(), "open": 1, "high": 1, "low": 1, "close": 1}


def test_a_bar_still_forming_is_dropped():
    done, forming = _bar(NOW - timedelta(days=1, hours=1)), _bar(NOW - timedelta(hours=15))

    assert ft.closed_bars([done, forming], NOW) == [done]


def test_bars_split_at_the_registration_start():
    start = datetime(2026, 9, 15, 12, tzinfo=timezone.utc)
    bars = [_bar(start - timedelta(hours=15)), _bar(start + timedelta(hours=9)), _bar(start + timedelta(days=1, hours=9))]

    before, forward = ft.split_at_start(bars, start)

    assert before == bars[:1] and forward == bars[1:]


def test_open_trades_are_shown_but_not_scored():
    trades = [{"result_r": 1.0, "pnl_usd": 50.0, "exit_reason": "TIME"},
              {"result_r": -1.0, "pnl_usd": -50.0, "exit_reason": "STOP"},
              {"result_r": 0.4, "pnl_usd": 20.0, "exit_reason": "END_OF_DATA"}]

    scored = ft.score(trades)

    assert (scored["closed_trades"], scored["open_trades"], scored["net_r"], scored["open_marked_r"]) == (2, 1, 0.0, 0.4)


def test_the_verdict_waits_for_the_minimum_number_of_closed_trades():
    registration = {"verdict_rule": {"minimum_closed_trades": 30, "out_of_sample_gate": {}, "experiments_counted": 90}}
    trades = [{"result_r": 1.0, "pnl_usd": 50.0, "exit_reason": "TIME"}] * 29

    assert ft.verdict(registration, trades, {"expectancy_r": None})["status"] == "COLLECTING"


def test_a_registration_is_never_rewritten(tmp_path, monkeypatch):
    monkeypatch.setattr(ft, "build_registration", lambda now: {"start": now.isoformat()})

    path = ft.register(tmp_path, now=NOW)
    assert json.loads(path.read_text(encoding="utf-8"))["start"] == NOW.isoformat()
    with pytest.raises(SystemExit, match="never changed"):
        ft.register(tmp_path, now=NOW + timedelta(days=1))


def test_tracking_before_registration_is_blocked(tmp_path):
    with pytest.raises(SystemExit, match="Not registered"):
        ft.run(tmp_path, now=NOW)
