"""
OAuth scope: read-only by default, trading only when asked for explicitly, recorded
with the token so the DEMO verification can refuse to send an order a read-only
token cannot place (the 14 Sep attempt was refused with "TRADE permission required").
"""

import json
from urllib.parse import parse_qs, urlparse

import hafnot_verify_demo_execution as verify
from app.openapi.auth import oauth


def test_read_only_is_the_default_and_trading_must_be_asked_for():
    assert oauth.parse_args([]).scope == "accounts"
    assert oauth.parse_args(["--scope", "trading"]).scope == "trading"


def test_the_authorization_url_carries_the_requested_scope():
    url, _ = oauth.build_authorization_url("client", "http://127.0.0.1:5000/callback", scope="trading")

    assert parse_qs(urlparse(url).query)["scope"] == ["trading"]


def test_the_scope_is_saved_with_the_token(tmp_path, monkeypatch):
    monkeypatch.setattr(oauth, "TOKEN_FILE", tmp_path / "tokens.json")

    oauth.save_tokens({"accessToken": "a", "refreshToken": "r"}, scope="trading")

    assert json.loads((tmp_path / "tokens.json").read_text(encoding="utf-8"))["scope"] == "trading"


def test_verification_reads_the_token_scope(tmp_path):
    old = tmp_path / "old.json"
    old.write_text(json.dumps({"accessToken": "a"}), encoding="utf-8")
    trading = tmp_path / "trading.json"
    trading.write_text(json.dumps({"accessToken": "a", "scope": "trading"}), encoding="utf-8")

    assert verify.token_scope(old) == "accounts"        # saved before scopes were recorded: read-only
    assert verify.token_scope(trading) == "trading"
    assert verify.token_scope(tmp_path / "absent.json") == "missing"
