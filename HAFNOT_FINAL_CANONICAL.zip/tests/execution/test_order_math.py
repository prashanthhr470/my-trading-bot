"""
Order sizing and stop units against the broker's REAL symbol specifications
(data/broker/symbol_specs.json, fetched with ProtoOASymbolByIdReq). The first
worker would have sent 100 times the intended volume - or 0.
"""

import asyncio

import pytest

from app.openapi.execution import native_execution_client as client
from app.openapi.execution import order_math

EURUSD = dict(lot_size=10_000_000, min_volume=100_000, step_volume=100_000, max_volume=1_000_000_000)
XAUUSD = dict(lot_size=10_000, min_volume=100, step_volume=100, max_volume=500_000)


def test_the_minimum_lot_is_exactly_the_broker_minimum_volume():
    assert order_math.raw_volume(0.01, **EURUSD) == 100_000
    assert order_math.raw_volume(0.01, **XAUUSD) == 100


def test_one_lot_is_one_lot_not_one_hundred():
    assert order_math.raw_volume(1.0, **EURUSD) == 10_000_000
    assert order_math.raw_volume(1.0, **EURUSD) != 1.0 * EURUSD["lot_size"] * 100


def test_volume_rounds_down_to_the_step():
    assert order_math.raw_volume(0.019, **EURUSD) == 100_000
    assert order_math.raw_volume(0.25, **XAUUSD) == 2_500


@pytest.mark.parametrize("lots, spec", [(0.009, EURUSD), (0.0, EURUSD), (60.0, XAUUSD)])  # gold's maximum is 50 lots
def test_volume_outside_the_broker_bounds_is_refused(lots, spec):
    with pytest.raises(ValueError):
        order_math.raw_volume(lots, **spec)


def test_a_light_symbol_without_volume_fields_is_refused_not_sent_as_zero():
    with pytest.raises(ValueError, match="ProtoOASymbolByIdReq"):
        order_math.raw_volume(0.01, lot_size=0, min_volume=0, step_volume=0, max_volume=0)


def test_relative_stops_are_in_hundred_thousandths_of_the_price():
    assert order_math.relative_price_units(0.0050) == 500     # 50 EURUSD pips
    assert order_math.relative_price_units(0.50) == 50_000    # 50 USDJPY pips
    assert order_math.relative_price_units(5.0) == 500_000    # $5 on gold
    with pytest.raises(ValueError):
        order_math.relative_price_units(0.0)


def test_the_client_reads_the_result_file_the_worker_writes(tmp_path):
    request_file = tmp_path / "reconcile-123.request.json"

    # The worker writes request_file.with_suffix(request_file.suffix + ".result.json").
    worker_writes = request_file.with_suffix(request_file.suffix + ".result.json")
    assert client.result_path_for(request_file) == worker_writes
    assert worker_writes.name == "reconcile-123.request.json.result.json"


def test_orders_are_refused_while_demo_execution_is_not_enabled(monkeypatch):
    monkeypatch.delenv("DEMO_ORDER_EXECUTION_ENABLED", raising=False)

    result = asyncio.run(client.place_market_order(
        client_order_id="test", symbol="EURUSD", side="BUY", volume_lots=0.01,
        stop_loss_distance=0.005, take_profit_distance=0.01,
    ))

    assert result["status"] == "DISABLED"
