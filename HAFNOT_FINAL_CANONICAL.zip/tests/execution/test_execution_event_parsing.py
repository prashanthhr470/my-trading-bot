"""
Execution events from cTrader must parse without error. The first DEMO order (14 Sep)
filled on the broker, then the worker crashed reading "moneyDigits" from the event itself
- that field only exists on the deal and position. The worker needs ctrader_open_api,
which lives in .ctrader_venv, so the check runs there as a subprocess.
"""

import json
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
CTRADER_PYTHON = ROOT / ".ctrader_venv" / "Scripts" / "python.exe"

SCRIPT = r'''
import json, sys
sys.path.insert(0, ".")
from ctrader_open_api.messages import OpenApiMessages_pb2 as m, OpenApiModelMessages_pb2 as mm
from app.openapi.execution.native_order_execution import execution_details

def trade():
    t = mm.ProtoOATradeData(); t.symbolId = 1; t.volume = 100000; t.tradeSide = 1; return t

accepted = m.ProtoOAExecutionEvent(ctidTraderAccountId=1, executionType=2)
accepted.order.CopyFrom(mm.ProtoOAOrder(orderId=11, tradeData=trade(), orderType=1, orderStatus=1))

filled = m.ProtoOAExecutionEvent(ctidTraderAccountId=1, executionType=3)
filled.order.CopyFrom(mm.ProtoOAOrder(orderId=11, tradeData=trade(), orderType=1, orderStatus=2,
                                      executionPrice=1.15347, executedVolume=100000))
filled.position.CopyFrom(mm.ProtoOAPosition(positionId=7, tradeData=trade(), positionStatus=1, swap=0, price=1.15347,
                                            stopLoss=1.14847, takeProfit=1.16347, moneyDigits=2))
filled.deal.CopyFrom(mm.ProtoOADeal(dealId=99, orderId=11, positionId=7, volume=100000, filledVolume=100000, symbolId=1,
                                    createTimestamp=1, executionTimestamp=1, executionPrice=1.15347, tradeSide=1,
                                    dealStatus=2, commission=-3, moneyDigits=2))

closing = m.ProtoOAExecutionEvent(ctidTraderAccountId=1, executionType=3)
closing.deal.CopyFrom(mm.ProtoOADeal(dealId=100, orderId=12, positionId=7, volume=100000, filledVolume=100000, symbolId=1,
                                     createTimestamp=2, executionTimestamp=2, executionPrice=1.1536, tradeSide=2, dealStatus=2))

print(json.dumps([execution_details(e) for e in (accepted, filled, closing)]))
'''


@pytest.mark.skipif(not CTRADER_PYTHON.exists(), reason=".ctrader_venv not present")
def test_execution_events_parse_for_accepted_filled_and_closing_deals():
    completed = subprocess.run([str(CTRADER_PYTHON), "-c", SCRIPT], cwd=str(ROOT), capture_output=True, text=True, timeout=120)
    assert completed.returncode == 0, completed.stderr[-1500:]
    accepted, filled, closing = json.loads(completed.stdout.strip().splitlines()[-1])

    assert accepted["execution_type"] == "ORDER_ACCEPTED" and accepted["execution_price"] is None
    assert filled["execution_type"] == "ORDER_FILLED"
    assert (filled["execution_price"], filled["position_id"], filled["money_digits"]) == (1.15347, 7, 2)
    assert (filled["position_stop_loss"], filled["position_take_profit"], filled["deal_commission_raw"]) == (1.14847, 1.16347, -3)
    # A closing fill may carry only the deal: the price and position still come through.
    assert (closing["execution_price"], closing["position_id"]) == (1.1536, 7)
