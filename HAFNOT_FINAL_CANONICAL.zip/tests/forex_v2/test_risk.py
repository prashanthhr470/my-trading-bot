import pytest

from app.forex_v2.risk import (
    AccountState,
    FxQuote,
    PaperPosition,
    RiskConfig,
    TradeRequest,
    close_paper_position,
    evaluate_paper_trade,
    size_position,
)


def _config(**overrides):
    values = {
        "risk_per_trade_pct": 1.0,
        "max_total_open_risk_pct": 5.0,
        "daily_loss_limit_pct": 5.0,
        "max_positions": 3,
        "max_positions_per_symbol": 1,
        "min_reward_to_risk": 1.0,
        "max_spread_pips": 3.0,
        "slippage_pips_per_side": 0.0,
        "commission_per_lot_round_turn_usd": 0.0,
    }
    values.update(overrides)
    return RiskConfig(**values)


def _account(**overrides):
    values = {
        "equity_usd": 10_000.0,
        "day_start_equity_usd": 10_000.0,
    }
    values.update(overrides)
    return AccountState(**values)


def _eurusd_long_request():
    return TradeRequest(
        symbol="EURUSD",
        side="BUY",
        stop_loss=1.0992,
        take_profit=1.1022,
    )


def _eurusd_quote():
    return FxQuote(symbol="EURUSD", bid=1.1000, ask=1.1002)


def test_size_position_for_quote_usd_pair_uses_usd_risk_and_units():
    result = size_position(
        account_equity_usd=10_000.0,
        symbol="EURUSD",
        side="BUY",
        entry_price=1.1002,
        stop_loss=1.0992,
        config=_config(),
    )

    assert result.accepted
    assert result.reason == "OK"
    assert result.lots == pytest.approx(1.0)
    assert result.units == 100_000
    assert result.risk_amount_usd == pytest.approx(100.0)
    assert result.risk_amount_usd <= result.risk_budget_usd


def test_size_position_converts_usd_jpy_quote_currency_to_usd():
    result = size_position(
        account_equity_usd=10_000.0,
        symbol="USDJPY",
        side="BUY",
        entry_price=150.02,
        stop_loss=149.02,
        config=_config(),
    )

    # One lot loses 100,000 JPY at the stop, converted at 149.02 JPY/USD.
    assert result.accepted
    assert result.loss_per_lot_usd == pytest.approx(100_000 / 149.02)
    assert result.lots == pytest.approx(0.14)
    assert result.units == 14_000
    assert result.risk_amount_usd == pytest.approx(0.14 * 100_000 / 149.02)


def test_market_fill_models_spread_slippage_and_round_turn_commission():
    decision = evaluate_paper_trade(
        request=_eurusd_long_request(),
        quote=_eurusd_quote(),
        account=_account(),
        config=_config(
            slippage_pips_per_side=0.2,
            commission_per_lot_round_turn_usd=7.0,
        ),
    )

    assert decision.accepted
    assert decision.entry_fill_price == pytest.approx(1.10022)
    assert decision.stop_exit_price == pytest.approx(1.09918)
    assert decision.take_profit_exit_price == pytest.approx(1.10218)
    assert decision.sizing.loss_per_lot_usd == pytest.approx(111.0)
    assert decision.sizing.lots == pytest.approx(0.9)
    assert decision.sizing.risk_amount_usd == pytest.approx(99.9)
    assert decision.position.round_turn_commission_usd == pytest.approx(6.3)


def test_spread_cap_rejects_before_any_position_is_created():
    decision = evaluate_paper_trade(
        request=_eurusd_long_request(),
        quote=FxQuote(symbol="EURUSD", bid=1.1000, ask=1.1005),
        account=_account(),
        config=_config(max_spread_pips=2.0),
    )

    assert not decision.accepted
    assert decision.reason == "SPREAD_CAP"
    assert decision.position is None


def test_daily_loss_cap_counts_realized_loss_and_candidate_maximum_loss():
    decision = evaluate_paper_trade(
        request=_eurusd_long_request(),
        quote=_eurusd_quote(),
        account=_account(realized_pnl_today_usd=-150.0),
        config=_config(daily_loss_limit_pct=2.0),
    )

    assert not decision.accepted
    assert decision.reason == "DAILY_LOSS_CAP"


def test_total_open_risk_cap_includes_existing_position_risk():
    existing = PaperPosition(
        symbol="GBPUSD",
        side="BUY",
        lots=0.5,
        units=50_000,
        entry_fill_price=1.2500,
        stop_exit_price=1.2480,
        take_profit_exit_price=1.2540,
        risk_amount_usd=150.0,
        expected_reward_usd=200.0,
        round_turn_commission_usd=3.5,
    )
    decision = evaluate_paper_trade(
        request=_eurusd_long_request(),
        quote=_eurusd_quote(),
        account=_account(open_positions=(existing,)),
        config=_config(max_total_open_risk_pct=2.0),
    )

    assert not decision.accepted
    assert decision.reason == "TOTAL_OPEN_RISK_CAP"


def test_position_and_symbol_limits_are_checked_from_immutable_snapshot():
    existing = PaperPosition(
        symbol="EURUSD",
        side="SELL",
        lots=0.5,
        units=50_000,
        entry_fill_price=1.1000,
        stop_exit_price=1.1020,
        take_profit_exit_price=1.0960,
        risk_amount_usd=100.0,
        expected_reward_usd=200.0,
        round_turn_commission_usd=3.5,
    )
    decision = evaluate_paper_trade(
        request=_eurusd_long_request(),
        quote=_eurusd_quote(),
        account=_account(open_positions=(existing,)),
        config=_config(max_positions=3, max_positions_per_symbol=1),
    )

    assert not decision.accepted
    assert decision.reason == "MAX_SYMBOL_POSITIONS_REACHED"


def test_close_is_pure_and_applies_closing_slippage_and_reserved_commission():
    decision = evaluate_paper_trade(
        request=_eurusd_long_request(),
        quote=_eurusd_quote(),
        account=_account(),
        config=_config(
            slippage_pips_per_side=0.2,
            commission_per_lot_round_turn_usd=7.0,
        ),
    )
    position = decision.position

    close = close_paper_position(
        position=position,
        exit_price=1.1022,
        config=_config(
            slippage_pips_per_side=0.2,
            commission_per_lot_round_turn_usd=7.0,
        ),
    )

    assert close.accepted
    assert close.exit_fill_price == pytest.approx(1.10218)
    assert close.gross_pnl_usd == pytest.approx((1.10218 - 1.10022) * 90_000)
    assert close.net_pnl_usd == pytest.approx(close.gross_pnl_usd - 6.3)
    # The position itself remains an immutable pre-close risk record.
    assert position.entry_fill_price == pytest.approx(1.10022)


def test_unsupported_cross_pair_is_never_sized_in_a_usd_only_model():
    result = size_position(
        account_equity_usd=10_000.0,
        symbol="EURJPY",
        side="BUY",
        entry_price=160.0,
        stop_loss=159.0,
        config=_config(),
    )

    assert not result.accepted
    assert result.reason == "UNSUPPORTED_SYMBOL"
