import pytest

from app.forex_v2.metrics import (
    PromotionGate,
    evaluate_promotion,
    summarize_trades,
)


def test_summary_uses_closed_trade_pnl_and_tracks_drawdown():
    summary = summarize_trades(
        [
            {"pnl_usd": 100.0, "result_r": 1.0},
            {"pnl_usd": -50.0, "result_r": -0.5},
            {"pnl_usd": -100.0, "result_r": -1.0},
        ],
        initial_equity=10_000.0,
    )

    assert summary.trade_count == 3
    assert summary.win_rate == pytest.approx(1 / 3)
    assert summary.profit_factor == pytest.approx(2 / 3)
    assert summary.expectancy_r == pytest.approx(-1 / 6)
    assert summary.max_drawdown_usd == pytest.approx(150.0)
    assert summary.max_drawdown_percent == pytest.approx(150 / 10_100 * 100)
    assert summary.final_equity == pytest.approx(9_950.0)


def test_promotion_gate_does_not_treat_a_tiny_winning_sample_as_evidence():
    summary = summarize_trades(
        [{"pnl_usd": 100.0, "result_r": 1.0}],
        initial_equity=10_000.0,
    )

    decision = evaluate_promotion(
        summary,
        PromotionGate(minimum_closed_trades=10),
    )

    assert not decision.passed
    assert "closed trades" in decision.reasons[0]
