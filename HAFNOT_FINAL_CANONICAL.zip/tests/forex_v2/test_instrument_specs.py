"""
Research-only instruments beyond the FX majors and gold: contract specs and commissions
from the broker's own data, usable by the costed backtest, never by the live path.
"""

import pytest

from app.forex_v2 import instrument_specs as specs
from app.forex_v2 import risk
from app.forex_v2.risk import RiskConfig
from app.quant.costed_backtest import is_costable_symbol, run_costed_backtest

US500 = {"quote_asset": "USD", "base_asset": "US500", "lot_size_raw": 100, "min_lots": 0.1, "lot_step": 0.1,
         "max_volume_raw": 50_000, "pip_size": 1.0, "commission": 0, "commission_type": 1,
         "precise_trading_commission_rate": 0}
GER40 = {**US500, "quote_asset": "EUR", "base_asset": "DE30"}
EURUSD = {"quote_asset": "USD", "commission": 300, "commission_type": 2, "precise_trading_commission_rate": 300_000_000}


@pytest.fixture(autouse=True)
def _isolated_registry(monkeypatch):
    monkeypatch.setattr(risk, "_RESEARCH_SPECS", {})


def test_a_usd_quoted_index_gets_its_contract_from_broker_data():
    spec = specs.usd_quoted_spec("us500", US500)

    assert (spec.symbol, spec.quote_currency, spec.contract_size, spec.min_lot, spec.lot_step, spec.max_lot) == \
           ("US500", "USD", 1, 0.1, 0.1, 500.0)


def test_an_instrument_quoted_in_another_currency_is_refused():
    with pytest.raises(ValueError, match="not USD"):
        specs.usd_quoted_spec("GER40", GER40)


def test_commissions_follow_the_broker_listing():
    assert specs.round_turn_commission_usd("EURUSD", EURUSD) == 6.0   # $3 per lot per side, confirmed by a DEMO fill
    assert specs.round_turn_commission_usd("US500", US500) == 0.0
    with pytest.raises(ValueError, match="not modelled"):
        specs.round_turn_commission_usd("X", {"commission": 5, "commission_type": 3})


def test_built_in_symbols_are_not_rebuilt_and_unknown_ones_are_refused():
    assert specs.research_specs_for(["EURUSD", "US500"], {"US500": US500}) == {"US500": specs.usd_quoted_spec("US500", US500)}
    with pytest.raises(ValueError, match="no broker specification"):
        specs.research_specs_for(["NAS100"], {"US500": US500})


def test_a_registered_research_instrument_is_costable_but_never_a_live_spec():
    assert not is_costable_symbol("US500")

    risk.register_research_specs(specs.research_specs_for(["US500"], {"US500": US500}))

    assert is_costable_symbol("US500")
    assert "US500" not in risk.FX_USD_MAJOR_SPECS          # what the live adapter checks
    with pytest.raises(ValueError, match="built-in"):
        risk.register_research_specs({"EURUSD": risk.FX_USD_MAJOR_SPECS["EURUSD"]})


def test_the_costed_backtest_sizes_an_index_in_its_own_lot_steps():
    risk.register_research_specs(specs.research_specs_for(["US500"], {"US500": US500}))
    signal = {"direction": "BUY", "entry": 6000.0, "stop_loss": 5900.0, "take_profit": 6300.0}
    bars = [{"open": 6000, "high": 6000, "low": 6000, "close": 6000},
            {"open": 6010, "high": 6310, "low": 6005, "close": 6300}]

    result = run_costed_backtest(bars, lambda v, i: signal if i == 0 else None, "US500",
                                 risk_config=RiskConfig(commission_per_lot_round_turn_usd=0.0), assumed_spread_pips=0.5)

    [trade] = result.trades
    # $50 risk / ($100.5 loss per 1-unit lot) = 0.49 lots, rounded down to the 0.1 step.
    assert trade.lots == pytest.approx(0.4)
    assert trade.result_r > 0
