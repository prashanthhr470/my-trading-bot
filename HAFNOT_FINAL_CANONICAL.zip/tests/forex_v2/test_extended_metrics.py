import pytest

from app.forex_v2.metrics import MIN_TRADES_FOR_RATIOS, extended_metrics


def _trades(pnls):
    return [{"pnl_usd": p} for p in pnls]


def test_ratios_withheld_on_small_samples_rather_than_reported():
    """A Sharpe ratio from 12 trades is a number, not evidence."""

    result = extended_metrics(_trades([10.0, -5.0] * 6), initial_equity=10_000.0)

    assert result.trade_count == 12
    assert result.sample_sufficient_for_ratios is False
    assert result.sharpe_ratio is None
    assert result.sortino_ratio is None
    assert "withheld" in result.withheld_reason


def test_ratios_computed_once_the_sample_is_large_enough():
    pnls = [20.0, -10.0] * (MIN_TRADES_FOR_RATIOS // 2 + 2)
    result = extended_metrics(_trades(pnls), initial_equity=10_000.0)

    assert result.sample_sufficient_for_ratios is True
    assert result.sharpe_ratio is not None
    assert result.sortino_ratio is not None
    # Mean is positive here, so both ratios should be positive.
    assert result.sharpe_ratio > 0
    assert result.sortino_ratio > 0


def test_payoff_ratio_and_averages():
    result = extended_metrics(
        _trades([100.0, 100.0, -50.0, -50.0]), initial_equity=10_000.0
    )

    assert result.average_win_usd == pytest.approx(100.0)
    assert result.average_loss_usd == pytest.approx(-50.0)
    assert result.payoff_ratio == pytest.approx(2.0)


def test_consecutive_streaks_are_counted():
    # 3 losses in a row, then 2 wins in a row.
    result = extended_metrics(
        _trades([-10.0, -10.0, -10.0, 5.0, 5.0, -1.0]), initial_equity=10_000.0
    )

    assert result.max_consecutive_losses == 3
    assert result.max_consecutive_wins == 2


def test_longest_underwater_stretch_in_trades():
    # Up, then four trades below the peak before recovering above it.
    result = extended_metrics(
        _trades([100.0, -10.0, -10.0, -10.0, -10.0, 500.0]), initial_equity=10_000.0
    )

    assert result.longest_drawdown_trades == 4


def test_sortino_withheld_when_there_are_no_losses():
    pnls = [10.0] * (MIN_TRADES_FOR_RATIOS + 1)
    result = extended_metrics(_trades(pnls), initial_equity=10_000.0)

    assert result.sortino_ratio is None
    assert "Sortino undefined" in result.withheld_reason


def test_invalid_records_are_ignored_not_counted_as_trades():
    trades = [{"pnl_usd": 10.0}, {"no_pnl": 1}, {"pnl_usd": float("nan")}, {"pnl_usd": -4.0}]
    result = extended_metrics(trades, initial_equity=10_000.0)

    assert result.trade_count == 2


def test_empty_input_is_safe():
    result = extended_metrics([], initial_equity=10_000.0)

    assert result.trade_count == 0
    assert result.sharpe_ratio is None
    assert result.payoff_ratio is None
    assert result.max_consecutive_losses == 0
