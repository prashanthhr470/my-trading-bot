from datetime import datetime, timezone

import pytest

from app.forex_v2.data import aggregate_spot_quotes


def test_aggregates_mid_prices_and_spread_by_utc_bucket():
    quotes = [
        (datetime(2026, 1, 1, 10, 0, 2, tzinfo=timezone.utc), 1.1000, 1.1002),
        (datetime(2026, 1, 1, 10, 4, 59, tzinfo=timezone.utc), 1.1002, 1.1004),
        (datetime(2026, 1, 1, 10, 5, 0, tzinfo=timezone.utc), 1.1001, 1.1003),
    ]

    bars = aggregate_spot_quotes(quotes, timeframe_minutes=5)

    assert len(bars) == 2
    assert bars[0].timestamp == datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)
    assert bars[0].open == 1.1001
    assert bars[0].high == 1.1003
    assert bars[0].low == 1.1001
    assert bars[0].close == 1.1003
    assert bars[0].mean_spread == pytest.approx(0.0002)
    assert bars[1].open == 1.1002


def test_ignores_out_of_order_quotes_instead_of_reordering_them():
    quotes = [
        (datetime(2026, 1, 1, 10, 1, tzinfo=timezone.utc), 1.1000, 1.1002),
        (datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc), 1.0900, 1.0902),
    ]

    bars = aggregate_spot_quotes(quotes, timeframe_minutes=15)

    assert len(bars) == 1
    assert bars[0].low == 1.1001
