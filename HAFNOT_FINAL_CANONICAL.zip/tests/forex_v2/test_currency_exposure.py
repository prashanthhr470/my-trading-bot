"""
Position-count and total-risk caps cannot see that long EURUSD, long GBPUSD
and long AUDUSD are one stacked short-USD bet. These tests pin the
same-direction currency exposure cap and the shared portfolio_limit_problem
used by both the risk model and the paper account.
"""

from types import SimpleNamespace

import pytest

from app.forex_v2.risk import (
    AccountState,
    FxQuote,
    PaperPosition,
    RiskConfig,
    TradeRequest,
    currency_legs,
    currency_risk_exposure,
    evaluate_paper_trade,
    portfolio_limit_problem,
)


def _open(symbol, side, risk):
    return SimpleNamespace(symbol=symbol, side=side, risk_amount_usd=risk)


def _check(open_positions, symbol, side, risk=50.0, **config):
    return portfolio_limit_problem(
        open_positions=open_positions, symbol=symbol, side=side, risk_amount_usd=risk,
        equity_usd=10_000.0, config=RiskConfig(**config),
    )


def test_a_buy_is_long_the_base_and_short_the_quote():
    assert currency_legs("EURUSD", "BUY") == (("EUR", 1), ("USD", -1))
    assert currency_legs("USDJPY", "SELL") == (("USD", -1), ("JPY", 1))
    assert currency_legs("XAUUSD", "BUY") == (("XAU", 1), ("USD", -1))


def test_long_eurusd_and_long_gbpusd_are_both_short_usd():
    exposure = currency_risk_exposure([_open("EURUSD", "BUY", 50.0), _open("GBPUSD", "BUY", 50.0)])

    assert exposure["USD"] == pytest.approx(-100.0)
    assert exposure["EUR"] == pytest.approx(50.0)
    assert exposure["GBP"] == pytest.approx(50.0)


def test_a_second_same_direction_trade_up_to_the_cap_is_allowed():
    # Default cap: 1% of $10,000 = $100 same-direction exposure per currency.
    assert _check([_open("EURUSD", "BUY", 50.0)], "GBPUSD", "BUY") is None


def test_a_third_short_usd_trade_breaches_the_currency_cap():
    open_now = [_open("EURUSD", "BUY", 50.0), _open("GBPUSD", "BUY", 50.0)]

    assert _check(open_now, "AUDUSD", "BUY") == "CURRENCY_EXPOSURE_CAP"


def test_a_trade_that_offsets_the_exposure_is_allowed():
    open_now = [_open("EURUSD", "BUY", 50.0), _open("GBPUSD", "BUY", 50.0)]

    # Buying USDJPY is LONG USD: it reduces the short-USD stack.
    assert _check(open_now, "USDJPY", "BUY") is None


def test_a_lone_position_never_trips_the_currency_cap():
    assert _check([], "EURUSD", "BUY", risk=150.0, max_total_open_risk_pct=5.0) is None


def test_the_existing_caps_still_apply_first():
    assert _check([_open("EURUSD", "SELL", 10.0)] * 3, "USDCAD", "BUY") == "MAX_POSITIONS_REACHED"
    assert _check([_open("EURUSD", "SELL", 10.0)], "EURUSD", "BUY") == "MAX_SYMBOL_POSITIONS_REACHED"
    assert _check([_open("EURUSD", "BUY", 180.0)], "USDJPY", "BUY") == "TOTAL_OPEN_RISK_CAP"


def test_invalid_currency_cap_is_refused_by_config_validation():
    decision = evaluate_paper_trade(
        request=TradeRequest(symbol="EURUSD", side="BUY", stop_loss=1.0992, take_profit=1.1022),
        quote=FxQuote(symbol="EURUSD", bid=1.1000, ask=1.1002),
        account=AccountState(equity_usd=10_000.0, day_start_equity_usd=10_000.0),
        config=RiskConfig(max_currency_exposure_pct=0.0),
    )

    assert decision.reason == "INVALID_CURRENCY_EXPOSURE_CAP"


def _costed_open(symbol, risk):
    # evaluate_paper_trade accepts only its own position type in AccountState.
    return PaperPosition(
        symbol=symbol, side="BUY", lots=0.5, units=50_000, entry_fill_price=1.0000,
        stop_exit_price=0.9980, take_profit_exit_price=1.0040,
        risk_amount_usd=risk, expected_reward_usd=2 * risk, round_turn_commission_usd=3.5,
    )


def test_evaluate_paper_trade_rejects_a_stacked_currency_bet():
    decision = evaluate_paper_trade(
        request=TradeRequest(symbol="EURUSD", side="BUY", stop_loss=1.0992, take_profit=1.1022),
        quote=FxQuote(symbol="EURUSD", bid=1.1000, ask=1.1002),
        account=AccountState(
            equity_usd=10_000.0, day_start_equity_usd=10_000.0,
            open_positions=(_costed_open("GBPUSD", 50.0), _costed_open("AUDUSD", 50.0)),
        ),
        config=RiskConfig(max_spread_pips=3.0),
    )

    assert not decision.accepted
    assert decision.reason == "CURRENCY_EXPOSURE_CAP"
