"""
Forward paper trades now live in ONE portfolio account for all symbols; the
degradation monitor must read each symbol's trades from it.
"""

import json

import app.monitoring.degradation_monitor as dm


def _write_portfolio(directory, trades):
    (directory / "portfolio_account.json").write_text(json.dumps({"closed_trades": trades}), encoding="utf-8")


def test_each_symbol_gets_only_its_own_trades_from_the_portfolio_account(tmp_path, monkeypatch):
    monkeypatch.setattr(dm, "PAPER_DIR", tmp_path)
    _write_portfolio(tmp_path, [
        {"symbol": "EURUSD", "pnl": -10.0, "result_r": -1.0},
        {"symbol": "XAUUSD", "pnl": 20.0, "result_r": 2.0},
        {"symbol": "EURUSD", "pnl": 15.0, "result_r": 1.5},
    ])

    assert [t["pnl"] for t in dm._load_closed_trades("eurusd")] == [-10.0, 15.0]
    assert [t["pnl"] for t in dm._load_closed_trades("XAUUSD")] == [20.0]
    assert dm._load_closed_trades("GBPUSD") == []


def test_no_portfolio_account_means_no_forward_trades(tmp_path, monkeypatch):
    monkeypatch.setattr(dm, "PAPER_DIR", tmp_path)
    (tmp_path / "eurusd_account.json").write_text(
        json.dumps({"closed_trades": [{"symbol": "EURUSD", "pnl": 1.0}]}), encoding="utf-8",
    )

    # The retired per-symbol layout is not read.
    assert dm._load_closed_trades("EURUSD") == []
