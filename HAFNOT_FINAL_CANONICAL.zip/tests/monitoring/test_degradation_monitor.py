import uuid

import pytest

from app.monitoring import degradation_monitor as dm
from app.quant import promotion
from app.quant import strategy_registry as registry


def _spec(strategy_id):
    return registry.StrategySpec(
        strategy_id=strategy_id,
        version="1.0.0",
        family=registry.StrategyFamily.BREAKOUT.value,
        entry_rules="t", exit_rules="t", stop_loss_logic="t", take_profit_logic="t",
        timeframe="H1", symbols=["XAUUSD"], session_conditions="t", regime_conditions="t",
        parameters={}, transaction_cost_assumptions="t", risk_model="t",
        signal_provider_module="app.quant.asian_range_breakout_strategy",
        signal_provider_factory="make_signal_provider",
    )


@pytest.fixture(autouse=True)
def _tmp_registry(tmp_path, monkeypatch):
    monkeypatch.setattr(registry, "SPECS_DIR", tmp_path / "specs")
    monkeypatch.setattr(registry, "RESULTS_DIR", tmp_path / "results")
    yield


def _register_validated_baseline(strategy_id, *, expectancy=0.20, win_rate=0.45,
                                 profit_factor=1.4, drawdown=8.0, trades=40):
    registry.register_strategy(_spec(strategy_id), overwrite=True)
    registry.record_result(
        strategy_id, "1.0.0", test_type="OUT_OF_SAMPLE", symbol="XAUUSD",
        scorecard={
            "trade_count": trades, "expectancy_r": expectancy, "win_rate": win_rate,
            "profit_factor": profit_factor, "max_drawdown_percent": drawdown,
            "net_pnl_usd": 500.0, "validated": True,
        },
    )


def _trades(*, wins, losses, win_pnl=100.0, loss_pnl=-50.0, trailing_losses=0,
            win_r=1.0, loss_r=-1.0):
    """
    Wins and losses are INTERLEAVED, then `trailing_losses` are appended.
    Interleaving matters: an earlier version of this helper put every win
    first and every loss last, which gave each fixture a long artificial
    trailing losing streak and made the (correct) streak check fire in
    cases meant to be healthy. Real trade sequences alternate; only
    `trailing_losses` should control the streak under test.
    """

    win_records = [{"pnl": win_pnl, "result_r": win_r} for _ in range(wins)]
    loss_records = [{"pnl": loss_pnl, "result_r": loss_r} for _ in range(losses)]

    out = []
    for index in range(max(len(win_records), len(loss_records))):
        if index < len(win_records):
            out.append(win_records[index])
        if index < len(loss_records):
            out.append(loss_records[index])

    out.extend({"pnl": loss_pnl, "result_r": loss_r} for _ in range(trailing_losses))
    return out


# --- honesty guard 1: no validated baseline ---

def test_no_validated_baseline_reports_so_and_never_flags_degradation():
    registry.register_strategy(_spec("unvalidated"), overwrite=True)
    registry.record_result(
        "unvalidated", "1.0.0", test_type="OUT_OF_SAMPLE", symbol="XAUUSD",
        scorecard={"trade_count": 40, "expectancy_r": -0.5, "net_pnl_usd": -900.0},
    )

    report = dm.assess_symbol(
        "XAUUSD", strategy_id="unvalidated", strategy_version="1.0.0",
        closed_trades=_trades(wins=0, losses=40),
    )

    assert report.verdict == "NO_VALIDATED_BASELINE"
    assert report.degraded is False
    assert "not earned forward trading" in report.checks[0].detail


def test_baseline_must_be_out_of_sample_not_just_any_positive_result():
    registry.register_strategy(_spec("is-only"), overwrite=True)
    # A great IN-SAMPLE result must not qualify as a validated baseline.
    registry.record_result(
        "is-only", "1.0.0", test_type="IN_SAMPLE", symbol="XAUUSD",
        scorecard={"trade_count": 100, "expectancy_r": 0.9, "win_rate": 0.7, "net_pnl_usd": 9000.0},
    )

    assert dm.find_validated_baseline("is-only", "1.0.0") is None


def test_baseline_requires_minimum_trade_count():
    registry.register_strategy(_spec("tiny-oos"), overwrite=True)
    registry.record_result(
        "tiny-oos", "1.0.0", test_type="OUT_OF_SAMPLE", symbol="GBPUSD",
        scorecard={"trade_count": 2, "expectancy_r": 2.2, "win_rate": 1.0, "net_pnl_usd": 214.0},
    )

    # The 2-trade "100% win rate" result that fooled an earlier session
    # must not become a validated baseline.
    assert dm.find_validated_baseline("tiny-oos", "1.0.0") is None


# --- honesty guard 2: small forward samples ---

def test_small_forward_sample_never_flags_degradation_however_bad():
    _register_validated_baseline("small-sample")

    report = dm.assess_symbol(
        "XAUUSD", strategy_id="small-sample", strategy_version="1.0.0",
        closed_trades=_trades(wins=0, losses=3),
    )

    assert report.verdict == "INSUFFICIENT_DATA"
    assert report.degraded is False


# --- the actual checks ---

def test_healthy_forward_performance_is_not_flagged():
    _register_validated_baseline("healthy", expectancy=0.20, win_rate=0.45, drawdown=8.0)

    report = dm.assess_symbol(
        "XAUUSD", strategy_id="healthy", strategy_version="1.0.0",
        closed_trades=_trades(wins=14, losses=11, win_pnl=100.0, loss_pnl=-50.0),
    )

    assert report.verdict == "HEALTHY"
    assert report.degraded is False


def test_expectancy_decline_is_flagged():
    _register_validated_baseline("declining", expectancy=0.50, win_rate=0.50, drawdown=50.0)

    # All losses -> forward expectancy -1.0R, far below 0.50R baseline.
    report = dm.assess_symbol(
        "XAUUSD", strategy_id="declining", strategy_version="1.0.0",
        closed_trades=_trades(wins=0, losses=25),
    )

    assert report.degraded is True
    assert any(c.name == "expectancy_decline" and c.triggered for c in report.checks)


def test_profit_factor_collapse_is_flagged():
    # A baseline must be positive-expectancy to count as validated at all,
    # so it is kept low (0.01R) here - forward expectancy then stays within
    # tolerance and the profit-factor check is what is being exercised.
    _register_validated_baseline("pf-collapse", expectancy=0.01, win_rate=0.50, drawdown=90.0)

    report = dm.assess_symbol(
        "XAUUSD", strategy_id="pf-collapse", strategy_version="1.0.0",
        # Tiny wins, big losses -> gross profit 50 vs gross loss 2000.
        closed_trades=_trades(wins=5, losses=20, win_pnl=10.0, loss_pnl=-100.0,
                              win_r=0.05, loss_r=-0.05),
    )

    pf_check = next(c for c in report.checks if c.name == "profit_factor_collapse")
    assert pf_check.triggered is True


def test_losing_streak_judged_probabilistically_not_by_round_number():
    # At a 30% validated win rate, a 5-loss streak has probability
    # 0.7^5 = 0.168 - unremarkable, must NOT trigger.
    _register_validated_baseline("streak-low-wr", expectancy=0.01, win_rate=0.30, drawdown=90.0)

    report = dm.assess_symbol(
        "XAUUSD", strategy_id="streak-low-wr", strategy_version="1.0.0",
        closed_trades=_trades(wins=15, losses=5, trailing_losses=5,
                              win_r=0.05, loss_r=-0.05),
    )
    streak_check = next(c for c in report.checks if c.name == "unusual_losing_streak")
    assert streak_check.triggered is False

    # At an 80% validated win rate, the SAME 5-loss streak has probability
    # 0.2^5 = 0.00032 - genuinely unusual, must trigger.
    _register_validated_baseline("streak-high-wr", expectancy=0.01, win_rate=0.80, drawdown=90.0)

    report = dm.assess_symbol(
        "XAUUSD", strategy_id="streak-high-wr", strategy_version="1.0.0",
        closed_trades=_trades(wins=15, losses=5, trailing_losses=5,
                              win_r=0.05, loss_r=-0.05),
    )
    streak_check = next(c for c in report.checks if c.name == "unusual_losing_streak")
    assert streak_check.triggered is True


def test_abnormal_drawdown_is_flagged():
    _register_validated_baseline("dd", expectancy=0.01, win_rate=0.5, drawdown=2.0)

    # Heavy sustained losses blow well past the 2% * 1.5 tolerance.
    report = dm.assess_symbol(
        "XAUUSD", strategy_id="dd", strategy_version="1.0.0",
        closed_trades=_trades(wins=1, losses=24, win_pnl=10.0, loss_pnl=-200.0,
                              win_r=0.05, loss_r=-0.05),
    )

    dd_check = next(c for c in report.checks if c.name == "abnormal_drawdown")
    assert dd_check.triggered is True


# --- enforcement ---

def test_enforce_moves_a_degraded_candidate_to_review_required():
    _register_validated_baseline("enforce-me", expectancy=0.50, win_rate=0.5, drawdown=50.0)

    candidate_id = f"test-{uuid.uuid4().hex[:8]}"
    candidate = promotion.create_candidate(candidate_id, "XAUUSD", {})
    candidate.current_stage = "PAPER_FORWARD"
    promotion._save(candidate)

    try:
        report = dm.assess_symbol(
            "XAUUSD", strategy_id="enforce-me", strategy_version="1.0.0",
            closed_trades=_trades(wins=0, losses=25),
        )
        assert report.degraded is True

        new_stage = dm.enforce(report, candidate_id)
        assert new_stage == "REVIEW_REQUIRED"

        reloaded = promotion.load_candidate(candidate_id)
        assert promotion.new_trades_allowed(reloaded) is False
    finally:
        promotion._path(candidate_id).unlink(missing_ok=True)


def test_enforce_does_nothing_for_a_healthy_report():
    _register_validated_baseline("healthy-enforce")

    candidate_id = f"test-{uuid.uuid4().hex[:8]}"
    candidate = promotion.create_candidate(candidate_id, "XAUUSD", {})
    candidate.current_stage = "PAPER_FORWARD"
    promotion._save(candidate)

    try:
        report = dm.assess_symbol(
            "XAUUSD", strategy_id="healthy-enforce", strategy_version="1.0.0",
            closed_trades=_trades(wins=14, losses=11),
        )
        assert report.degraded is False
        assert dm.enforce(report, candidate_id) is None

        reloaded = promotion.load_candidate(candidate_id)
        assert reloaded.current_stage == "PAPER_FORWARD"
        assert promotion.new_trades_allowed(reloaded) is True
    finally:
        promotion._path(candidate_id).unlink(missing_ok=True)


def test_enforce_is_idempotent_on_an_already_quarantined_candidate():
    _register_validated_baseline("already-quarantined", expectancy=0.50, win_rate=0.5, drawdown=50.0)

    candidate_id = f"test-{uuid.uuid4().hex[:8]}"
    candidate = promotion.create_candidate(candidate_id, "XAUUSD", {})
    candidate.current_stage = "PAPER_FORWARD"
    promotion._save(candidate)

    try:
        report = dm.assess_symbol(
            "XAUUSD", strategy_id="already-quarantined", strategy_version="1.0.0",
            closed_trades=_trades(wins=0, losses=25),
        )

        assert dm.enforce(report, candidate_id) == "REVIEW_REQUIRED"
        # Second call must not raise - it reports the existing terminal stage.
        assert dm.enforce(report, candidate_id) == "REVIEW_REQUIRED"
    finally:
        promotion._path(candidate_id).unlink(missing_ok=True)
