import pytest

from app.monitoring.degradation_monitor import find_validated_baseline
from app.quant import strategy_registry as registry


@pytest.fixture(autouse=True)
def _tmp_registry(tmp_path, monkeypatch):
    monkeypatch.setattr(registry, "SPECS_DIR", tmp_path / "specs")
    monkeypatch.setattr(registry, "RESULTS_DIR", tmp_path / "results")
    registry.register_strategy(registry.StrategySpec(
        strategy_id="candidate", version="1.0.0", family=registry.StrategyFamily.RANGE.value,
        entry_rules="t", exit_rules="t", stop_loss_logic="t", take_profit_logic="t",
        timeframe="H1", symbols=["EURUSD"], session_conditions="t", regime_conditions="t",
        parameters={}, transaction_cost_assumptions="t", risk_model="t",
        signal_provider_module="app.quant.range_fade_strategy",
        signal_provider_factory="make_signal_provider",
    ))
    yield


def _record(test_type, **scorecard):
    registry.record_result("candidate", "1.0.0", test_type=test_type, symbol="EURUSD", scorecard=scorecard)


def test_a_positive_out_of_sample_result_alone_is_not_a_baseline():
    # Passing validation is not the same as passing walk-forward and the locked set.
    _record("OUT_OF_SAMPLE_PIPELINE_V1", trade_count=80, expectancy_r=0.3, win_rate=0.5)
    assert find_validated_baseline("candidate", "1.0.0") is None


def test_explicitly_unvalidated_result_is_not_a_baseline():
    _record("LOCKED_OUT_OF_SAMPLE_PIPELINE_V1", trade_count=80, expectancy_r=0.3, validated=False)
    assert find_validated_baseline("candidate", "1.0.0") is None


def test_pipeline_validated_locked_result_is_a_baseline():
    _record("LOCKED_OUT_OF_SAMPLE_PIPELINE_V1", trade_count=80, expectancy_r=0.3, win_rate=0.5, validated=True)

    baseline = find_validated_baseline("candidate", "1.0.0")

    assert baseline is not None
    assert baseline["expectancy_r"] == pytest.approx(0.3)
