from app.live.confirmation_layer import apply_live_confirmation


def _candidate(direction="BUY"):
    return {"direction": direction, "entry": 1.1000, "stop_loss": 1.0980, "take_profit": 1.1050}


def test_no_live_data_still_approves_by_default():
    result = apply_live_confirmation(_candidate())
    assert result.approved is True
    assert result.live_data_available == {
        "orderflow": False, "news": False, "sentiment": False, "spread": False,
    }


def test_high_risk_news_hard_blocks_regardless_of_everything_else():
    result = apply_live_confirmation(
        _candidate("BUY"),
        news_evidence={"status": "HIGH_RISK"},
        orderflow_evidence={"depth_imbalance": 0.9},
        sentiment_evidence={"available": True, "direction": "bullish"},
    )
    assert result.approved is False
    assert "HIGH_RISK" in result.reason


def test_stale_news_hard_blocks():
    result = apply_live_confirmation(_candidate("SELL"), news_evidence={"status": "STALE"})
    assert result.approved is False


def test_wide_spread_hard_blocks():
    result = apply_live_confirmation(_candidate(), current_spread_pips=6.0, max_spread_pips=3.0)
    assert result.approved is False


def test_narrow_spread_confirms():
    result = apply_live_confirmation(_candidate(), current_spread_pips=1.0, max_spread_pips=3.0)
    assert result.approved is True
    assert any("spread" in c.lower() for c in result.confirmations)


def test_agreeing_orderflow_is_noted_as_confirmation_not_required():
    result = apply_live_confirmation(_candidate("BUY"), orderflow_evidence={"depth_imbalance": 0.5})
    assert result.approved is True
    assert result.confirmations


def test_disagreeing_orderflow_does_not_block_by_default():
    result = apply_live_confirmation(_candidate("BUY"), orderflow_evidence={"depth_imbalance": -0.5})
    assert result.approved is True
    assert result.vetoes


def test_disagreeing_orderflow_blocks_when_required():
    result = apply_live_confirmation(
        _candidate("BUY"), orderflow_evidence={"depth_imbalance": -0.5},
        require_orderflow_confirmation=True,
    )
    assert result.approved is False


def test_missing_orderflow_blocks_when_required():
    result = apply_live_confirmation(_candidate("BUY"), require_orderflow_confirmation=True)
    assert result.approved is False


def test_sentiment_risk_override_is_treated_as_no_data():
    result = apply_live_confirmation(
        _candidate("BUY"),
        sentiment_evidence={"available": True, "direction": "bearish", "risk_override": True},
    )
    # risk_override means the sentiment engine itself flagged the reading
    # as unreliable - must not be treated as a confirming or vetoing
    # signal either way.
    assert result.approved is True
    assert not result.vetoes
    assert not result.confirmations
