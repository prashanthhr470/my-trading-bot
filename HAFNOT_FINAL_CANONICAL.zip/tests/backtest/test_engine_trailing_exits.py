"""
Trailing and end-of-data exits in the backtest engine. The trailing stop must be
checked before a bar moves it, gaps must fill at the open, and fixed stop/target
trades must exit exactly as before.
"""

import pytest

from app.backtest.engine import BacktestEngine


def _bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c}


def _once(signal):
    return lambda visible, index: signal if index == 0 else None


def _run(bars, signal, **kwargs):
    return BacktestEngine().run(bars, _once(signal), "EURUSD", **kwargs)["trades"]


BUY_TRAIL = {"direction": "BUY", "entry": 100.0, "stop_loss": 95.0, "take_profit": 200.0, "trailing_stop_distance": 5.0}
SELL_TRAIL = {"direction": "SELL", "entry": 100.0, "stop_loss": 105.0, "take_profit": 0.5, "trailing_stop_distance": 5.0}


def test_a_trailing_buy_locks_in_the_trend_and_exits_at_the_trailed_stop():
    bars = [_bar(100, 100, 100, 100),
            _bar(101, 108, 101, 107),   # stop was 95, not hit; the high 108 trails it to 103
            _bar(107, 110, 104, 109),   # 104 > 103, not hit; the high 110 trails it to 105
            _bar(106, 107, 104, 104)]   # low 104 <= 105: exit at 105

    [trade] = _run(bars, BUY_TRAIL)

    assert (trade["exit_price"], trade["exit_reason"], trade["exit_index"]) == (105.0, "STOP", 3)
    assert trade["result_r"] == pytest.approx(1.0)


def test_the_stop_is_checked_before_the_bar_that_would_move_it():
    # This bar reaches 120 but first trades down through the original 95 stop: stop first.
    bars = [_bar(100, 100, 100, 100), _bar(100, 120, 94, 118)]

    [trade] = _run(bars, BUY_TRAIL)

    assert (trade["exit_price"], trade["result_r"]) == (95.0, -1.0)


def test_a_gap_through_the_trailed_stop_fills_at_the_open():
    bars = [_bar(100, 100, 100, 100), _bar(101, 110, 101, 109), _bar(102, 103, 101, 102)]

    [trade] = _run(bars, BUY_TRAIL)

    # Trailed to 105, but the bar opened at 102: filled at 102, not at the better 105.
    assert trade["exit_price"] == 102.0
    assert trade["result_r"] == pytest.approx(0.4)


def test_a_trailing_sell_mirrors_the_buy():
    bars = [_bar(100, 100, 100, 100),
            _bar(99, 99, 92, 93),       # low 92 trails the stop down to 97
            _bar(93, 98, 91, 97)]       # high 98 >= 97: exit at 97

    [trade] = _run(bars, SELL_TRAIL)

    assert (trade["exit_price"], trade["exit_reason"]) == (97.0, "STOP")
    assert trade["result_r"] == pytest.approx(0.6)


def test_an_open_trade_is_dropped_by_default_and_closed_at_the_last_close_on_request():
    bars = [_bar(100, 100, 100, 100), _bar(101, 103, 101, 102), _bar(102, 104, 101, 103)]

    assert _run(bars, BUY_TRAIL) == []
    [trade] = _run(bars, BUY_TRAIL, close_open_at_end=True)
    assert (trade["exit_price"], trade["exit_reason"], trade["exit_index"]) == (103.0, "END_OF_DATA", 2)
    assert trade["result_r"] == pytest.approx(0.6)


def test_fixed_stop_and_target_trades_exit_exactly_as_before():
    fixed = {"direction": "BUY", "entry": 100.0, "stop_loss": 95.0, "take_profit": 110.0}
    target_bars = [_bar(100, 100, 100, 100), _bar(101, 111, 101, 110)]
    stop_bars = [_bar(100, 100, 100, 100), _bar(99, 112, 94, 100)]

    [won] = _run(target_bars, fixed)
    [lost] = _run(stop_bars, fixed)

    assert (won["result_r"], won["exit_price"], won["exit_reason"]) == (2.0, 110.0, "TAKE_PROFIT")
    assert (lost["result_r"], lost["exit_price"], lost["exit_reason"]) == (-1.0, 95.0, "STOP")


def test_a_non_positive_trailing_distance_is_ignored():
    bad = {**BUY_TRAIL, "trailing_stop_distance": 0}
    assert _run([_bar(100, 100, 100, 100), _bar(100, 120, 99, 118)], bad) == []
