"""
The engine hands strategies a view of the visible bars instead of a copy: it must behave
exactly like the old prefix list and must never expose a later bar.
"""

import pytest

from app.backtest.engine import BacktestEngine, _VisibleBars

BARS = [{"i": i, "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0} for i in range(10)]


@pytest.mark.parametrize("key", [0, 3, -1, -4, slice(None), slice(-3, None), slice(2, 5), slice(-5, -1),
                                 slice(None, None, -1), slice(1, 100), slice(-100, 2)])
def test_the_view_matches_the_prefix_list(key):
    view, prefix = _VisibleBars(BARS, 6), BARS[:6]

    assert view[key] == prefix[key]
    assert len(view) == len(prefix) and list(view) == prefix


def test_the_view_never_exposes_a_later_bar():
    view = _VisibleBars(BARS, 6)

    with pytest.raises(IndexError):
        view[6]
    with pytest.raises(IndexError):
        view[-7]
    assert view[4:100][-1]["i"] == 5


def test_the_provider_sees_only_bars_through_the_decision_bar():
    seen = []

    def provider(visible, index):
        seen.append((index, len(visible), visible[-1]["i"]))
        return None

    BacktestEngine().run(BARS, provider, "EURUSD")

    assert seen == [(i, i + 1, i) for i in range(10)]
