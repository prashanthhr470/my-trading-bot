﻿import json

from app.openapi.orderflow.order_book_engine import (
    OrderBookEngine
)

from app.openapi.footprint.footprint_engine import (
    FootprintEngine
)

from app.openapi.heatmap.heatmap_engine import (
    HeatmapEngine
)

from app.openapi.signals.orderflow_signal_engine import (
    OrderFlowSignalEngine
)


def sample_event():

    return {
        "timestamp": 1000,

        "newQuotes": [
            {
                "id": 1,
                "bid": 4485.60,
                "size": 1.0,
            },
            {
                "id": 2,
                "bid": 4485.48,
                "size": 1.5,
            },
            {
                "id": 3,
                "bid": 4485.36,
                "size": 2.5,
            },
            {
                "id": 4,
                "ask": 4485.68,
                "size": 1.0,
            },
            {
                "id": 5,
                "ask": 4485.79,
                "size": 1.5,
            },
            {
                "id": 6,
                "ask": 4485.91,
                "size": 2.5,
            },
        ],

        "deletedQuotes": [],
    }


def test_orderbook():

    engine = OrderBookEngine()

    snapshot = engine.process_event(
        sample_event()
    )

    assert snapshot.best_bid == 4485.60
    assert snapshot.best_ask == 4485.68
    assert snapshot.spread > 0
    assert snapshot.bid_depth > 0
    assert snapshot.ask_depth > 0


def test_deleted_quote_ids_are_integers():

    engine = OrderBookEngine()

    engine.process_event(
        sample_event()
    )

    engine.process_event(
        {
            "timestamp": 1001,
            "newQuotes": [],
            "deletedQuotes": [1, 4],
        }
    )

    assert 1 not in engine.bids
    assert 4 not in engine.asks


def test_footprint():

    engine = FootprintEngine()

    snapshot = engine.build(
        bids=[
            {
                "price": 4485.60,
                "size": 2.0,
            }
        ],
        asks=[
            {
                "price": 4485.68,
                "size": 1.0,
            }
        ],
    )

    assert len(snapshot.levels) == 2
    assert snapshot.total_bid_liquidity == 2.0
    assert snapshot.total_ask_liquidity == 1.0


def test_heatmap():

    engine = HeatmapEngine()

    snapshot = engine.update(
        bids=[
            {
                "price": 4485.60,
                "size": 2.0,
            }
        ],
        asks=[
            {
                "price": 4485.68,
                "size": 1.0,
            }
        ],
    )

    assert len(snapshot.cells) == 2


def test_signal():

    book = OrderBookEngine()

    snapshot = book.process_event(
        sample_event()
    )

    signal = OrderFlowSignalEngine().evaluate(
        snapshot
    )

    assert signal.direction in {
        "BULLISH",
        "BEARISH",
        "NEUTRAL",
    }

    assert -1.0 <= signal.score <= 1.0
    assert 0.0 <= signal.confidence <= 1.0
    assert signal.execution_allowed is False
