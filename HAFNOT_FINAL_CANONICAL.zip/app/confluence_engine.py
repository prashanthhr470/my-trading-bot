"""Deterministic confluence scoring.

Scoring is evidence aggregation, not a prediction model. Execution must remain
behind the existing decision/risk/safety gates.
"""
from __future__ import annotations
from typing import Any, Dict


def _direction_score(value: Any, direction: str) -> float:
    if not isinstance(value, str):
        return 0.0
    value = value.lower()
    return 1.0 if value == direction else (-1.0 if value in {"bullish", "bearish"} else 0.0)


def score_confluence(context: Dict[str, Any]) -> Dict[str, Any]:
    scores = {"bullish": 0.0, "bearish": 0.0}
    reasons = {"bullish": [], "bearish": []}
    regime = context.get("regime") or {}
    sentiment = context.get("sentiment") or {}
    structure = context.get("structure") or {}
    setup = context.get("setup") or {}

    for direction in scores:
        if regime.get("direction") == direction:
            scores[direction] += 2.0
            reasons[direction].append("Market regime agrees.")

        if sentiment.get("direction") == direction and not sentiment.get("risk_override"):
            scores[direction] += 1.0
            reasons[direction].append("Sentiment agrees.")

        if structure.get("structure") == direction or structure.get("type") == direction:
            scores[direction] += 2.0
            reasons[direction].append("Structure agrees.")

        if setup.get("direction") == direction:
            scores[direction] += 2.0
            reasons[direction].append("Setup direction agrees.")

    total = scores["bullish"] + scores["bearish"]
    if scores["bullish"] >= scores["bearish"] + 2 and scores["bullish"] >= 4:
        dominant = "bullish"
    elif scores["bearish"] >= scores["bullish"] + 2 and scores["bearish"] >= 4:
        dominant = "bearish"
    else:
        dominant = "neutral"

    strength = max(scores.values())
    confidence = "high" if strength >= 6 and total >= 6 else (
        "moderate" if strength >= 4 else "low"
    )

    # Session context is a caution/quality signal, not a directional one:
    # off-hours liquidity is thin, so a confluence read that would
    # otherwise be "high" is capped to "moderate" rather than silently
    # trusted at full strength. It never raises confidence, only caps it.
    session = context.get("session") or {}
    session_label = session.get("session_label")
    if session_label == "OFF_HOURS" and confidence == "high":
        confidence = "moderate"
        reasons[dominant if dominant in reasons else "bullish"].append(
            "Confidence capped: outside Tokyo/London/New York session hours."
        )

    return {
        "dominant_direction": dominant,
        "bullish_score": round(scores["bullish"], 2),
        "bearish_score": round(scores["bearish"], 2),
        "confidence": confidence,
        "session_label": session_label,
        "reasons": reasons,
        "trade_authorized": False,
        "reason": "Confluence score is advisory; deterministic risk and safety gates remain authoritative.",
    }
