from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any


# ============================================================
# TRADE PLAN RESULT
# ============================================================

@dataclass
class TradePlan:

    symbol: str

    status: str
    decision: str

    direction: str

    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]

    risk_percent: Optional[float]
    risk_amount: Optional[float]

    position_size: Optional[float]
    position_lots: Optional[float]

    reward_risk: Optional[float]

    broker_valid: bool

    execution_allowed: bool

    reason: str


# ============================================================
# SAFE WAIT / NO-TRADE PLAN
# ============================================================

def _wait_plan(
    symbol: str,
    decision: str,
    reason: str,
):
    """
    Create a safe WAIT / NO_TRADE plan.

    This function never permits execution.
    """

    return TradePlan(
        symbol=symbol,

        status="WAIT",
        decision=decision,

        direction="NONE",

        entry_price=None,
        stop_loss=None,
        take_profit=None,

        risk_percent=None,
        risk_amount=None,

        position_size=None,
        position_lots=None,

        reward_risk=None,

        broker_valid=False,

        execution_allowed=False,

        reason=reason,
    )


# ============================================================
# MAIN TRADE PLAN ENGINE
# ============================================================

def build_trade_plan(
    ai_decision: Dict[str, Any],
    validator_result: Dict[str, Any],
    gate_result: Dict[str, Any],
    setup_result: Dict[str, Any],
    risk_result=None,
    symbol: str = "XAUUSD",
):
    """
    Build the final deterministic trade plan.

    Pipeline:

        AI
        ↓
        Validator
        ↓
        Decision Gate
        ↓
        Setup Analyzer
        ↓
        Risk Management
        ↓
        Trade Plan

    This engine DOES NOT:

        - place orders
        - modify orders
        - close orders
        - call the broker
        - authorize broker execution

    execution_allowed is deliberately kept False.
    """

    # ========================================================
    # 1. AI DECISION CHECK
    # ========================================================

    if not isinstance(ai_decision, dict):

        return _wait_plan(
            symbol,
            "NO_TRADE",
            "AI decision is invalid.",
        )

    decision = ai_decision.get(
        "decision",
        "NO_TRADE",
    )

    # ========================================================
    # 2. AI VALIDATOR CHECK
    # ========================================================

    if not isinstance(
        validator_result,
        dict,
    ):

        return _wait_plan(
            symbol,
            "NO_TRADE",
            "AI validator result is unavailable.",
        )

    validator_valid = validator_result.get(
        "valid",
        False,
    )

    if not validator_valid:

        errors = validator_result.get(
            "errors",
            [],
        )

        if errors:

            reason = (
                "AI validator rejected the decision: "
                + "; ".join(
                    str(error)
                    for error in errors
                )
            )

        else:

            reason = (
                "AI validator rejected the decision."
            )

        return _wait_plan(
            symbol,
            "NO_TRADE",
            reason,
        )

    # ========================================================
    # 3. DECISION GATE
    # ========================================================

    if not isinstance(
        gate_result,
        dict,
    ):

        return _wait_plan(
            symbol,
            "NO_TRADE",
            "Decision gate result is unavailable.",
        )

    gated_decision = gate_result.get(
        "decision",
        "WAIT",
    )

    gate_status = gate_result.get(
        "gate_status",
        "REJECTED",
    )

    if gate_status != "PASSED":

        return _wait_plan(
            symbol,
            gated_decision,
            gate_result.get(
                "gate_reason",
                "Decision gate rejected the trade.",
            ),
        )

    # ========================================================
    # 4. ONLY TRADE CANDIDATES CAN CONTINUE
    # ========================================================

    if gated_decision not in {
        "BUY_CANDIDATE",
        "SELL_CANDIDATE",
    }:

        return _wait_plan(
            symbol,
            gated_decision,
            gate_result.get(
                "gate_reason",
                "No executable trading decision.",
            ),
        )

    # ========================================================
    # 5. SETUP RESULT CHECK
    # ========================================================

    if not isinstance(
        setup_result,
        dict,
    ):

        return _wait_plan(
            symbol,
            "WAIT",
            "Setup analyzer result is unavailable.",
        )

    setup_found = setup_result.get(
        "setup_found",
        False,
    )

    # ========================================================
    # 6. SETUP FOUND CHECK
    # ========================================================

    if not setup_found:

        warnings = setup_result.get(
            "warnings",
            [],
        )

        if warnings:

            reason = (
                "No valid trading setup found: "
                + "; ".join(
                    str(warning)
                    for warning in warnings
                )
            )

        else:

            reason = (
                "No valid trading setup found."
            )

        return _wait_plan(
            symbol,
            "WAIT",
            reason,
        )

    # ========================================================
    # 7. SETUP DIRECTION
    # ========================================================

    setup_direction = setup_result.get(
        "direction",
        "NONE",
    )

    # ========================================================
    # 8. SETUP QUALITY
    #
    # setup_analyzer.py uses "setup_quality".
    #
    # "quality" is retained as a compatibility fallback.
    # ========================================================

    setup_quality = setup_result.get(
        "setup_quality",
        setup_result.get(
            "quality",
            "LOW",
        ),
    )

    # ========================================================
    # 9. EXPECTED DIRECTION
    # ========================================================

    expected_direction = {
        "BUY_CANDIDATE": "BUY",
        "SELL_CANDIDATE": "SELL",
    }.get(
        gated_decision
    )

    # ========================================================
    # 10. DIRECTION CONSISTENCY
    # ========================================================

    if setup_direction != expected_direction:

        return _wait_plan(
            symbol,
            "NO_TRADE",
            (
                "Setup direction does not match "
                "the gated decision."
            ),
        )

    # ========================================================
    # 11. SETUP QUALITY
    # ========================================================

    if setup_quality not in {
        "HIGH",
        "MODERATE",
    }:

        return _wait_plan(
            symbol,
            "WAIT",
            "Setup quality is too low.",
        )

    # ========================================================
    # 12. RISK MANAGEMENT RESULT
    # ========================================================

    if risk_result is None:

        return _wait_plan(
            symbol,
            "WAIT",
            "Risk management result is unavailable.",
        )

    # ========================================================
    # 13. RISK ALLOWED
    # ========================================================

    if not getattr(
        risk_result,
        "allowed",
        False,
    ):

        return _wait_plan(
            symbol,
            "WAIT",
            getattr(
                risk_result,
                "reason",
                "Risk management rejected the trade.",
            ),
        )

    # ========================================================
    # 14. FINAL TRADE PLAN
    # ========================================================

    return TradePlan(

        symbol=symbol,

        status="READY",

        decision=gated_decision,

        direction=setup_direction,

        entry_price=risk_result.entry_price,

        stop_loss=risk_result.stop_loss,

        take_profit=risk_result.take_profit,

        risk_percent=None,

        risk_amount=risk_result.risk_amount,

        position_size=risk_result.position_size,

        position_lots=risk_result.position_lots,

        reward_risk=risk_result.reward_risk,

        broker_valid=True,

        # ====================================================
        # SAFETY
        # ====================================================
        #
        # Execution layer does not exist yet.
        #
        # Therefore this MUST remain False.
        #

        execution_allowed=False,

        reason=(
            "Trade plan passed AI validation, "
            "decision gate, setup validation and "
            "risk management."
        ),
    )


# ============================================================
# SERIALIZATION
# ============================================================

def trade_plan_to_dict(
    plan: TradePlan,
):
    """
    Convert TradePlan into a JSON-compatible dictionary.
    """

    return asdict(plan)