"""
HAFNOT AI TRADING AGENT
FINAL FUNDAMENTAL INTELLIGENCE ENGINE

This module builds deterministic macro/fundamental evidence for:
    USD, GBP, JPY, AUD

It does NOT:
    - place orders
    - generate BUY/SELL orders
    - pretend economic data is certainty
    - use DOM/footprint/order-flow data

It does:
    - collect Forex Factory calendar data
    - reconcile JSON and HTML
    - recover actual/forecast/previous values
    - classify economic events
    - score economic importance
    - calculate forecast surprise
    - compare actual with previous
    - calculate event-level evidence
    - calculate category-level evidence
    - calculate currency-level evidence
    - calculate relative currency strength
    - infer monetary-policy pressure
    - detect conflicting macro evidence
    - calculate upcoming event risk
    - calculate data quality
    - save a machine-readable fundamental snapshot
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from html import unescape
from typing import Any

import requests


# ============================================================================
# CONFIGURATION
# ============================================================================

FOREX_FACTORY_JSON_URL = (
    "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
)

FOREX_FACTORY_CALENDAR_URL = (
    "https://www.forexfactory.com/calendar"
)

SUPPORTED_CURRENCIES = (
    "USD",
    "GBP",
    "JPY",
    "AUD",
)

REQUEST_TIMEOUT = 20
CACHE_MAX_AGE_MINUTES = 60

CACHE_DIR = os.path.join(
    "data",
    "fundamental",
)

JSON_CACHE_FILE = os.path.join(
    CACHE_DIR,
    "forex_factory_json.json",
)

HTML_CACHE_FILE = os.path.join(
    CACHE_DIR,
    "forex_factory_calendar.html",
)

SNAPSHOT_FILE = os.path.join(
    CACHE_DIR,
    "fundamental_snapshot.json",
)

USER_AGENT = (
    "HAFNOT-AI-Trading-Agent/1.0"
)


# ============================================================================
# WEIGHTS
# ============================================================================

IMPACT_WEIGHT = {
    "HIGH": 3.0,
    "MEDIUM": 2.0,
    "LOW": 1.0,
    "HOLIDAY": 0.0,
    "OTHER": 0.5,
}

CONFIDENCE_WEIGHT = {
    "HIGH": 1.00,
    "MEDIUM": 0.65,
    "LOW": 0.30,
    "NONE": 0.00,
}

CATEGORY_WEIGHT = {
    "inflation": 1.30,
    "employment": 1.30,
    "central_bank": 1.40,
    "growth": 1.10,
    "business_activity": 0.95,
    "consumer": 0.90,
    "financial_conditions": 0.80,
    "credit": 0.70,
    "housing": 0.65,
    "trade": 0.60,
    "external_balance": 0.55,
    "commodities": 0.55,
    "government": 0.45,
    "other": 0.25,
}


# Economic importance is independent from Forex Factory's calendar impact.

IMPORTANCE_DEFAULT = 0.25
IMPORTANCE_LOW = 0.35
IMPORTANCE_MEDIUM = 0.60
IMPORTANCE_MEDIUM_HIGH = 0.80
IMPORTANCE_HIGH = 1.00


# ============================================================================
# CENTRAL BANK CONTEXT
# ============================================================================

POLICY_PROFILES = {
    "USD": {
        "central_bank": "Federal Reserve",
        "inflation_target": 2.0,
        "employment_focus": True,
        "policy_keywords": (
            "fomc",
            "federal reserve",
            "fed",
            "waller",
            "powell",
            "beige book",
        ),
    },
    "GBP": {
        "central_bank": "Bank of England",
        "inflation_target": 2.0,
        "employment_focus": True,
        "policy_keywords": (
            "boe",
            "bank of england",
            "mpc",
            "bailey",
            "bank rate",
        ),
    },
    "JPY": {
        "central_bank": "Bank of Japan",
        "inflation_target": 2.0,
        "employment_focus": False,
        "policy_keywords": (
            "boj",
            "bank of japan",
            "ueda",
            "policy rate",
            "monetary policy meeting",
        ),
    },
    "AUD": {
        "central_bank": "Reserve Bank of Australia",
        "inflation_target_low": 2.0,
        "inflation_target_high": 3.0,
        "employment_focus": True,
        "policy_keywords": (
            "rba",
            "reserve bank of australia",
            "cash rate",
            "bullock",
        ),
    },
}


# ============================================================================
# EVENT RULES
# ============================================================================

EVENT_RULES = {
    "inflation": (
        "cpi",
        "core cpi",
        "consumer price",
        "inflation",
        "ppi",
        "producer price",
        "pce price",
        "core pce",
        "price index",
        "import prices",
        "export prices",
        "shop price",
        "inflation gauge",
    ),

    "employment": (
        "nonfarm payroll",
        "non-farm payroll",
        "payroll",
        "employment",
        "unemployment",
        "jobless claims",
        "initial claims",
        "continuing claims",
        "claimant count",
        "job cuts",
        "redundancies",
        "average earnings",
        "wage",
        "wages",
        "labor cost",
        "labour cost",
        "employment change",
        "jobs change",
        "participation rate",
    ),

    "growth": (
        "gdp",
        "gross domestic product",
        "industrial production",
        "manufacturing production",
        "retail sales",
        "business inventories",
        "capital spending",
        "company operating profits",
        "construction output",
        "production",
        "personal income",
        "personal spending",
    ),

    "business_activity": (
        "pmi",
        "ism",
        "business confidence",
        "business activity",
        "services index",
        "manufacturing index",
        "industrial confidence",
        "economic sentiment",
    ),

    "consumer": (
        "retail sales",
        "consumer confidence",
        "consumer sentiment",
        "household spending",
        "consumer credit",
        "personal income",
        "personal spending",
        "shop price",
    ),

    "housing": (
        "housing",
        "house price",
        "hpi",
        "building approval",
        "building approvals",
        "building permit",
        "building permits",
        "housing starts",
        "home loans",
        "mortgage",
        "construction",
        "new home",
        "existing home",
    ),

    "credit": (
        "private sector credit",
        "bank lending",
        "loan",
        "credit",
        "money supply",
        "mortgage",
        "consumer credit",
        "lending",
        "broad money",
        "m2",
        "m3",
    ),

    "trade": (
        "trade balance",
        "goods trade",
        "exports",
        "imports",
        "trade",
        "merchandise trade",
    ),

    "external_balance": (
        "current account",
        "balance of payments",
        "net exports",
        "terms of trade",
    ),

    "commodities": (
        "commodity",
        "iron ore",
        "oil price",
        "crude",
        "energy price",
        "gold price",
    ),

    "government": (
        "budget",
        "fiscal",
        "government spending",
        "public debt",
        "debt to gdp",
        "tax",
        "treasury",
        "government bond",
    ),

    "financial_conditions": (
        "bond yield",
        "yield",
        "financial conditions",
        "credit conditions",
        "mortgage rate",
        "bond auction",
        "money market",
    ),

    "central_bank": (
        "fomc",
        "federal reserve",
        "fed",
        "bank of england",
        "boe",
        "mpc",
        "bank of japan",
        "boj",
        "rba",
        "reserve bank of australia",
        "cash rate",
        "bank rate",
        "policy rate",
        "central bank",
        "governor",
        "deputy governor",
        "minutes",
        "monetary policy",
        "beige book",
    ),
}


NEGATIVE_WHEN_HIGHER = (
    "unemployment",
    "unemployment rate",
    "jobless claims",
    "initial claims",
    "continuing claims",
    "claimant count change",
    "job cuts",
    "redundancies",
)


NON_DIRECTIONAL = (
    "holiday",
    "bank holiday",
    "speech",
    "speaks",
    "press conference",
    "statement",
    "minutes",
    "meeting",
    "auction",
    "g20",
    "summit",
)


IMPORTANCE_RULES = (
    (
        1.00,
        (
            "nonfarm payroll",
            "non-farm payroll",
            "nfp",
        ),
    ),
    (
        1.00,
        (
            "cpi",
            "consumer price index",
            "core cpi",
        ),
    ),
    (
        1.00,
        (
            "fomc rate",
            "fed interest rate",
            "federal funds rate",
        ),
    ),
    (
        1.00,
        (
            "boe interest rate",
            "bank rate decision",
            "mpc rate",
        ),
    ),
    (
        1.00,
        (
            "boj interest rate",
            "policy rate decision",
            "monetary policy meeting",
        ),
    ),
    (
        1.00,
        (
            "rba interest rate",
            "cash rate decision",
        ),
    ),
    (
        0.95,
        (
            "gdp",
            "gross domestic product",
        ),
    ),
    (
        0.90,
        (
            "unemployment",
            "employment change",
            "jobs change",
            "payroll",
        ),
    ),
    (
        0.85,
        (
            "retail sales",
            "average earnings",
            "wage",
            "wages",
        ),
    ),
    (
        0.85,
        (
            "pce price",
            "core pce",
            "pce deflator",
        ),
    ),
    (
        0.80,
        (
            "pmi",
            "ism manufacturing",
            "ism services",
            "services pmi",
            "manufacturing pmi",
        ),
    ),
    (
        0.80,
        (
            "industrial production",
            "manufacturing production",
        ),
    ),
    (
        0.75,
        (
            "trade balance",
            "current account",
            "goods trade",
        ),
    ),
    (
        0.70,
        (
            "building approvals",
            "building permits",
            "housing starts",
            "house price",
        ),
    ),
    (
        0.70,
        (
            "private sector credit",
            "money supply",
            "loan",
        ),
    ),
)


HAWKISH_WORDS = (
    "hawkish",
    "tightening",
    "tighten",
    "higher rates",
    "rate hike",
    "hikes",
    "restrictive",
    "inflation risk",
    "upside inflation",
    "persistent inflation",
    "strong inflation",
    "policy needs to remain tight",
)

DOVISH_WORDS = (
    "dovish",
    "easing",
    "ease",
    "rate cut",
    "cuts",
    "accommodative",
    "lower rates",
    "growth downside",
    "economic weakness",
    "downside risks",
    "slack",
)


# ============================================================================
# BASIC HELPERS
# ============================================================================

def _ensure_cache_directory() -> None:
    os.makedirs(
        CACHE_DIR,
        exist_ok=True,
    )


def _now() -> datetime:
    return datetime.now(
        timezone.utc
    )


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (
        TypeError,
        ValueError,
    ):
        return None


def _clamp(
    value: float,
    low: float = 0.0,
    high: float = 1.0,
) -> float:
    return max(
        low,
        min(
            high,
            float(value),
        ),
    )


def _round(
    value: Any,
    digits: int = 4,
) -> Any:
    if isinstance(
        value,
        (
            int,
            float,
        ),
    ):
        try:
            if math.isfinite(
                float(value)
            ):
                return round(
                    float(value),
                    digits,
                )
        except (
            TypeError,
            ValueError,
        ):
            pass
    return value


def _normalize_text(
    value: Any,
) -> str:
    text = unescape(
        str(
            value or ""
        )
    ).lower()

    text = re.sub(
        r"[^a-z0-9%+/.-]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def _clean_value(
    value: Any,
) -> Any:
    if value is None:
        return None

    if isinstance(
        value,
        str,
    ):
        value = unescape(
            value
        ).strip()

        if not value:
            return None

        if value in {
            "-",
            "—",
            "–",
            "n/a",
            "N/A",
            "None",
        }:
            return None

    return value


def _contains_any(
    text: str,
    patterns: tuple[str, ...] | list[str],
) -> bool:
    return any(
        pattern in text
        for pattern in patterns
    )


def _write_json(
    path: str,
    data: Any,
) -> None:
    _ensure_cache_directory()

    temporary = (
        f"{path}.tmp"
    )

    with open(
        temporary,
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            data,
            handle,
            indent=2,
            ensure_ascii=False,
        )

    os.replace(
        temporary,
        path,
    )


def _read_json(
    path: str,
) -> Any:
    try:
        with open(
            path,
            "r",
            encoding="utf-8",
        ) as handle:
            return json.load(
                handle
            )
    except (
        OSError,
        json.JSONDecodeError,
    ):
        return None


def _cache_age_minutes(
    path: str,
) -> float | None:
    try:
        return max(
            0.0,
            (
                time.time()
                - os.path.getmtime(
                    path
                )
            )
            / 60.0,
        )
    except OSError:
        return None


# ============================================================================
# DATE / NUMBER HELPERS
# ============================================================================

def _parse_datetime(
    value: Any,
) -> datetime | None:
    if value is None:
        return None

    text = str(
        value
    ).strip()

    if not text:
        return None

    candidates = (
        text,
        text.replace(
            "Z",
            "+00:00",
        ),
    )

    for candidate in candidates:
        try:
            dt = datetime.fromisoformat(
                candidate
            )

            if dt.tzinfo is None:
                dt = dt.replace(
                    tzinfo=timezone.utc
                )

            return dt.astimezone(
                timezone.utc
            )

        except ValueError:
            pass

    formats = (
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%S",
    )

    for fmt in formats:
        try:
            return datetime.strptime(
                text,
                fmt,
            ).replace(
                tzinfo=timezone.utc
            )
        except ValueError:
            pass

    return None


def _extract_event_datetime(
    event: dict[str, Any],
) -> datetime | None:
    for key in (
        "date",
        "datetime",
        "timestamp",
        "time",
    ):
        dt = _parse_datetime(
            event.get(key)
        )

        if dt is not None:
            return dt

    return None


def _parse_numeric(
    value: Any,
) -> float | None:
    value = _clean_value(
        value
    )

    if value is None:
        return None

    text = str(
        value
    ).strip().replace(
        ",",
        "",
    )

    # Examples such as:
    # 3.00|3.3
    # contain multiple fields and are not one numeric macro value.
    if "|" in text:
        return None

    match = re.search(
        r"\(?([+-]?\d+(?:\.\d+)?)\)?\s*([KMBT])?",
        text,
        re.I,
    )

    if not match:
        return None

    number = float(
        match.group(1)
    )

    if (
        text.startswith("(")
        and text.endswith(")")
    ):
        number = -number

    suffix = (
        match.group(2)
        or ""
    ).upper()

    multiplier = {
        "": 1.0,
        "K": 1e3,
        "M": 1e6,
        "B": 1e9,
        "T": 1e12,
    }[
        suffix
    ]

    return (
        number
        * multiplier
    )


def _value_suffix(
    value: Any,
) -> str:
    match = re.search(
        r"([KMBT])\s*$",
        str(
            value or ""
        ),
        re.I,
    )

    if not match:
        return ""

    return (
        match.group(1)
        or ""
    ).upper()


def _is_percentage(
    value: Any,
) -> bool:
    return "%" in str(
        value or ""
    )


def _format_number(
    value: Any,
    original: Any = None,
) -> str:
    number = _safe_float(
        value
    )

    if number is None:
        return "UNAVAILABLE"

    if (
        original is not None
        and _is_percentage(
            original
        )
    ):
        return f"{number:+.2f}%"

    suffix = _value_suffix(
        original
    )

    if suffix:
        scale = {
            "K": 1e3,
            "M": 1e6,
            "B": 1e9,
            "T": 1e12,
        }[
            suffix
        ]

        return (
            f"{number / scale:+.2f}"
            f"{suffix}"
        )

    return (
        f"{number:+.4f}"
        .rstrip("0")
        .rstrip(".")
    )


def _reference_scale(
    actual: Any,
    forecast: Any,
) -> float:
    actual_number = _parse_numeric(
        actual
    )

    forecast_number = _parse_numeric(
        forecast
    )

    return max(
        abs(
            actual_number or 0.0
        ),
        abs(
            forecast_number or 0.0
        ),
        1.0,
    )


# ============================================================================
# CLASSIFICATION
# ============================================================================

def classify_event_type(
    title: str,
) -> str:
    text = _normalize_text(
        title
    )

    if _contains_any(
        text,
        EVENT_RULES[
            "central_bank"
        ],
    ):
        return "central_bank"

    for category, patterns in EVENT_RULES.items():
        if _contains_any(
            text,
            patterns,
        ):
            return category

    return "other"


def normalize_impact(
    value: Any,
) -> str:
    text = _normalize_text(
        value
    ).upper()

    if "HIGH" in text:
        return "HIGH"

    if "MED" in text:
        return "MEDIUM"

    if "LOW" in text:
        return "LOW"

    if "HOLIDAY" in text:
        return "HOLIDAY"

    return "OTHER"


def impact_weight(
    impact: str,
) -> float:
    return IMPACT_WEIGHT.get(
        normalize_impact(
            impact
        ),
        0.5,
    )


def economic_importance(
    title: str,
    event_type: str,
    impact: str,
) -> tuple[float, str, str]:
    text = _normalize_text(
        title
    )

    for value, patterns in IMPORTANCE_RULES:
        if _contains_any(
            text,
            patterns,
        ):
            classification = (
                "RULE_HIGH"
                if value >= 0.9
                else "RULE_MEDIUM"
            )

            return (
                value,
                classification,
                "specific event rule",
            )

    if event_type == "central_bank":
        return (
            0.90,
            "CENTRAL_BANK",
            "central-bank event",
        )

    if impact == "HIGH":
        return (
            IMPORTANCE_MEDIUM_HIGH,
            "CALENDAR_HIGH",
            "high calendar impact",
        )

    if impact == "MEDIUM":
        return (
            IMPORTANCE_MEDIUM,
            "CALENDAR_MEDIUM",
            "medium calendar impact",
        )

    if event_type in {
        "inflation",
        "employment",
        "growth",
    }:
        return (
            IMPORTANCE_MEDIUM,
            "MACRO_CATEGORY",
            "core macro category",
        )

    if impact == "LOW":
        return (
            IMPORTANCE_LOW,
            "CALENDAR_LOW",
            "low calendar impact",
        )

    return (
        IMPORTANCE_DEFAULT,
        "DEFAULT",
        "no stronger importance rule",
    )


# ============================================================================
# SURPRISE / INTERPRETATION
# ============================================================================

def _direction_from_numeric(
    title: str,
    surprise_value: float | None,
) -> str:
    if (
        surprise_value is None
        or abs(
            surprise_value
        ) < 1e-12
    ):
        return "NEUTRAL"

    text = _normalize_text(
        title
    )

    if _contains_any(
        text,
        NEGATIVE_WHEN_HIGHER,
    ):
        return (
            "NEGATIVE"
            if surprise_value > 0
            else "POSITIVE"
        )

    if _contains_any(
        text,
        NON_DIRECTIONAL,
    ):
        return "NEUTRAL"

    return (
        "POSITIVE"
        if surprise_value > 0
        else "NEGATIVE"
    )


def determine_release_status(
    event_dt: datetime | None,
    actual: Any,
) -> str:
    if (
        _parse_numeric(
            actual
        ) is not None
    ):
        return "RELEASED"

    if (
        actual is not None
        and str(actual).strip()
        and "|" not in str(actual)
    ):
        return "RELEASED"

    if (
        event_dt is not None
        and event_dt
        < (
            _now()
            - timedelta(
                minutes=10
            )
        )
    ):
        return "PAST_UNCONFIRMED"

    return "UPCOMING"


def calculate_surprise(
    actual: Any,
    forecast: Any,
) -> dict[str, Any]:
    actual_number = _parse_numeric(
        actual
    )

    forecast_number = _parse_numeric(
        forecast
    )

    if (
        actual_number is None
        or forecast_number is None
    ):
        return {
            "direction": "UNAVAILABLE",
            "value": None,
            "formatted": "UNAVAILABLE",
        }

    value = (
        actual_number
        - forecast_number
    )

    if value > 0:
        direction = "POSITIVE"
    elif value < 0:
        direction = "NEGATIVE"
    else:
        direction = "NEUTRAL"

    return {
        "direction": direction,
        "value": value,
        "formatted": _format_number(
            value,
            actual,
        ),
    }


def calculate_surprise_strength(
    actual: Any,
    forecast: Any,
    title: str = "",
) -> dict[str, Any]:
    actual_number = _parse_numeric(
        actual
    )

    forecast_number = _parse_numeric(
        forecast
    )

    if (
        actual_number is None
        or forecast_number is None
    ):
        return {
            "value": None,
            "magnitude": "UNAVAILABLE",
            "normalized": 0.0,
        }

    difference = abs(
        actual_number
        - forecast_number
    )

    scale = _reference_scale(
        actual,
        forecast,
    )

    if (
        _is_percentage(actual)
        or _is_percentage(forecast)
    ):
        denominator = max(
            abs(
                forecast_number
            ),
            0.25,
        )
    else:
        denominator = scale

    normalized = _clamp(
        difference
        / denominator
    )

    if normalized >= 0.75:
        magnitude = "VERY_STRONG"
    elif normalized >= 0.45:
        magnitude = "STRONG"
    elif normalized >= 0.15:
        magnitude = "MODERATE"
    elif normalized > 0:
        magnitude = "WEAK"
    else:
        magnitude = "NONE"

    return {
        "value": difference,
        "magnitude": magnitude,
        "normalized": normalized,
    }


def compare_with_previous(
    actual: Any,
    previous: Any,
    title: str = "",
) -> dict[str, Any]:
    actual_number = _parse_numeric(
        actual
    )

    previous_number = _parse_numeric(
        previous
    )

    if (
        actual_number is None
        or previous_number is None
    ):
        return {
            "direction": "UNAVAILABLE",
            "value": None,
            "formatted": "UNAVAILABLE",
        }

    value = (
        actual_number
        - previous_number
    )

    if value > 0:
        direction = "HIGHER"
    elif value < 0:
        direction = "LOWER"
    else:
        direction = "UNCHANGED"

    return {
        "direction": direction,
        "value": value,
        "formatted": _format_number(
            value,
            actual,
        ),
    }


def calculate_recency_weight(
    event_dt: datetime | None,
    now: datetime | None = None,
) -> float:
    if event_dt is None:
        return 0.50

    now = now or _now()

    age_hours = max(
        0.0,
        (
            now - event_dt
        ).total_seconds()
        / 3600.0,
    )

    return max(
        0.25,
        math.exp(
            -age_hours
            / (
                24.0
                * 7.0
            )
        ),
    )


def _persistence_weight(
    event_dt: datetime | None,
) -> float:
    if event_dt is None:
        return 0.60

    age_days = max(
        0.0,
        (
            _now()
            - event_dt
        ).total_seconds()
        / 86400.0,
    )

    if age_days <= 1:
        return 1.00

    if age_days <= 3:
        return 0.90

    if age_days <= 7:
        return 0.75

    return 0.60


def _confidence_from_strength(
    strength: float,
    event_type: str,
    title: str,
) -> str:
    text = _normalize_text(
        title
    )

    if (
        event_type == "central_bank"
        and _contains_any(
            text,
            HAWKISH_WORDS
            + DOVISH_WORDS,
        )
    ):
        return "MEDIUM"

    if strength >= 0.65:
        return "HIGH"

    if strength >= 0.20:
        return "MEDIUM"

    if strength > 0:
        return "LOW"

    return "NONE"


def interpret_surprise(
    title: str,
    surprise: dict[str, Any],
    event_type: str,
) -> dict[str, Any]:
    value = surprise.get(
        "value"
    )

    if value is None:
        return {
            "currency_impact": "UNAVAILABLE",
            "confidence": "NONE",
            "reason": (
                "actual or forecast unavailable"
            ),
        }

    direction = _direction_from_numeric(
        title,
        value,
    )

    if event_type == "central_bank":
        text = _normalize_text(
            title
        )

        if _contains_any(
            text,
            HAWKISH_WORDS,
        ):
            direction = "POSITIVE"

        elif _contains_any(
            text,
            DOVISH_WORDS,
        ):
            direction = "NEGATIVE"

        else:
            direction = "NEUTRAL"

    if direction == "NEUTRAL":
        confidence = "LOW"
    elif event_type in {
        "inflation",
        "employment",
        "growth",
        "central_bank",
    }:
        confidence = "MEDIUM"
    else:
        confidence = "LOW"

    return {
        "currency_impact": direction,
        "confidence": confidence,
        "reason": (
            "event-specific macro interpretation"
        ),
    }


def calculate_event_score(
    impact: str,
    importance: float,
    surprise_strength: float,
    confidence: str,
    recency: float,
    direction: str,
    event_type: str,
) -> dict[str, Any]:
    if direction not in {
        "POSITIVE",
        "NEGATIVE",
    }:
        return {
            "score": 0.0,
            "magnitude": 0.0,
            "usable": False,
        }

    signed = (
        1.0
        if direction == "POSITIVE"
        else -1.0
    )

    impact_factor = _clamp(
        impact_weight(
            impact
        )
        / 3.0,
    )

    confidence_factor = (
        CONFIDENCE_WEIGHT.get(
            confidence,
            0.0,
        )
    )

    raw = (
        signed
        * importance
        * (
            0.35
            + 0.65
            * surprise_strength
        )
        * (
            0.35
            + 0.65
            * confidence_factor
        )
        * (
            0.35
            + 0.65
            * impact_factor
        )
        * recency
    )

    if (
        event_type == "central_bank"
        and surprise_strength == 0
        and confidence_factor > 0
    ):
        raw *= 0.75

    score = _clamp(
        raw,
        -1.0,
        1.0,
    )

    return {
        "score": score,
        "magnitude": abs(score),
        "usable": True,
    }


# ============================================================================
# EVENT NORMALIZATION
# ============================================================================

def _event_fingerprint(
    currency: str,
    title: str,
    event_dt: datetime | None,
) -> str:
    base = (
        f"{currency}|"
        f"{_normalize_text(title)}|"
        f"{event_dt.isoformat() if event_dt else ''}"
    )

    return hashlib.sha256(
        base.encode(
            "utf-8"
        )
    ).hexdigest()[:16]


def _normalize_event(
    event: dict[str, Any],
) -> dict[str, Any] | None:
    currency = _clean_value(
        event.get("country")
        or event.get("currency")
    )

    if not currency:
        return None

    currency = str(
        currency
    ).upper().strip()

    if currency not in SUPPORTED_CURRENCIES:
        return None

    title = _clean_value(
        event.get("title")
        or event.get("event")
        or event.get("name")
    )

    if not title:
        return None

    title = str(
        title
    ).strip()

    actual = _clean_value(
        event.get("actual")
    )

    forecast = _clean_value(
        event.get("forecast")
    )

    previous = _clean_value(
        event.get("previous")
    )

    impact = normalize_impact(
        event.get("impact")
    )

    event_dt = _extract_event_datetime(
        event
    )

    event_type = classify_event_type(
        title
    )

    (
        importance,
        importance_class,
        importance_reason,
    ) = economic_importance(
        title,
        event_type,
        impact,
    )

    release_status = (
        determine_release_status(
            event_dt,
            actual,
        )
    )

    surprise = calculate_surprise(
        actual,
        forecast,
    )

    strength = calculate_surprise_strength(
        actual,
        forecast,
        title,
    )

    previous_comparison = (
        compare_with_previous(
            actual,
            previous,
            title,
        )
    )

    interpretation = (
        interpret_surprise(
            title,
            surprise,
            event_type,
        )
    )

    recency = calculate_recency_weight(
        event_dt
    )

    event_score = calculate_event_score(
        impact=impact,
        importance=importance,
        surprise_strength=float(
            strength.get(
                "normalized",
                0.0,
            )
        ),
        confidence=interpretation.get(
            "confidence",
            "NONE",
        ),
        recency=recency,
        direction=interpretation.get(
            "currency_impact",
            "UNAVAILABLE",
        ),
        event_type=event_type,
    )

    text = _normalize_text(
        title
    )

    policy_signal = "NONE"

    if event_type == "central_bank":
        if _contains_any(
            text,
            HAWKISH_WORDS,
        ):
            policy_signal = "HAWKISH"

        elif _contains_any(
            text,
            DOVISH_WORDS,
        ):
            policy_signal = "DOVISH"

        else:
            policy_signal = "NEUTRAL"

    return {
        "id": _event_fingerprint(
            currency,
            title,
            event_dt,
        ),
        "currency": currency,
        "title": title,
        "event_type": event_type,
        "impact_normalized": impact,
        "economic_importance": _round(
            importance
        ),
        "economic_importance_class": (
            importance_class
        ),
        "economic_importance_reason": (
            importance_reason
        ),
        "datetime_utc": (
            event_dt.isoformat()
            if event_dt
            else None
        ),
        "actual": actual,
        "forecast": forecast,
        "previous": previous,
        "release_status": release_status,
        "surprise": surprise,
        "surprise_strength": {
            "value": _round(
                strength.get(
                    "value"
                )
            ),
            "magnitude": strength.get(
                "magnitude"
            ),
            "normalized": _round(
                strength.get(
                    "normalized",
                    0.0,
                )
            ),
        },
        "previous_comparison": (
            previous_comparison
        ),
        "fundamental_interpretation": (
            interpretation
        ),
        "policy_signal": policy_signal,
        "recency_weight": _round(
            recency
        ),
        "persistence_weight": _round(
            _persistence_weight(
                event_dt
            )
        ),
        "event_score": event_score,
        "data_quality": {
            "has_actual": (
                _parse_numeric(
                    actual
                )
                is not None
            ),
            "has_forecast": (
                _parse_numeric(
                    forecast
                )
                is not None
            ),
            "has_previous": (
                _parse_numeric(
                    previous
                )
                is not None
            ),
            "has_datetime": (
                event_dt is not None
            ),
            "single_numeric_value": not (
                actual is not None
                and "|"
                in str(actual)
            ),
        },
    }


# ============================================================================
# FOREX FACTORY DOWNLOAD
# ============================================================================

def _download_json_calendar() -> list[dict[str, Any]]:
    response = requests.get(
        FOREX_FACTORY_JSON_URL,
        timeout=REQUEST_TIMEOUT,
        headers={
            "User-Agent": USER_AGENT,
        },
    )

    response.raise_for_status()

    data = response.json()

    if not isinstance(
        data,
        list,
    ):
        raise ValueError(
            "Forex Factory JSON export is not a list"
        )

    _write_json(
        JSON_CACHE_FILE,
        data,
    )

    return data


def fetch_forex_factory_json() -> list[dict[str, Any]]:
    age = _cache_age_minutes(
        JSON_CACHE_FILE
    )

    if (
        age is not None
        and age <= CACHE_MAX_AGE_MINUTES
    ):
        cached = _read_json(
            JSON_CACHE_FILE
        )

        if isinstance(
            cached,
            list,
        ):
            return cached

    try:
        return _download_json_calendar()

    except Exception:
        cached = _read_json(
            JSON_CACHE_FILE
        )

        if isinstance(
            cached,
            list,
        ):
            return cached

        raise


def _download_calendar_html() -> str:
    response = requests.get(
        FOREX_FACTORY_CALENDAR_URL,
        timeout=REQUEST_TIMEOUT,
        headers={
            "User-Agent": USER_AGENT,
        },
    )

    response.raise_for_status()

    html = response.text

    _ensure_cache_directory()

    with open(
        HTML_CACHE_FILE,
        "w",
        encoding="utf-8",
    ) as handle:
        handle.write(
            html
        )

    return html


def fetch_forex_factory_html() -> str:
    age = _cache_age_minutes(
        HTML_CACHE_FILE
    )

    if (
        age is not None
        and age <= CACHE_MAX_AGE_MINUTES
    ):
        try:
            with open(
                HTML_CACHE_FILE,
                "r",
                encoding="utf-8",
            ) as handle:
                return handle.read()

        except OSError:
            pass

    try:
        return _download_calendar_html()

    except Exception:
        try:
            with open(
                HTML_CACHE_FILE,
                "r",
                encoding="utf-8",
            ) as handle:
                return handle.read()

        except OSError:
            raise


# ============================================================================
# HTML PARSING
# ============================================================================

def _strip_html(
    value: str,
) -> str:
    value = re.sub(
        r"<script.*?</script>",
        " ",
        value,
        flags=re.I | re.S,
    )

    value = re.sub(
        r"<style.*?</style>",
        " ",
        value,
        flags=re.I | re.S,
    )

    value = re.sub(
        r"<[^>]+>",
        " ",
        value,
    )

    return re.sub(
        r"\s+",
        " ",
        unescape(
            value
        ),
    ).strip()


def _extract_calendar_rows(
    html: str,
) -> list[str]:
    rows = re.findall(
        r"<tr[^>]*class=[\"'][^\"']*calendar__event[^\"']*[\"'][^>]*>.*?</tr>",
        html,
        flags=re.I | re.S,
    )

    if rows:
        return rows

    return re.findall(
        r"<tr[^>]*>.*?</tr>",
        html,
        flags=re.I | re.S,
    )


def _html_cell(
    row: str,
    class_fragment: str,
) -> str | None:
    pattern = (
        r"<td[^>]*class=[\"'][^\"']*"
        + re.escape(
            class_fragment
        )
        + r"[^\"']*[\"'][^>]*>(.*?)</td>"
    )

    match = re.search(
        pattern,
        row,
        flags=re.I | re.S,
    )

    if not match:
        return None

    return _strip_html(
        match.group(1)
    )


def _extract_html_events(
    html: str,
) -> list[dict[str, Any]]:
    events = []

    for row in _extract_calendar_rows(
        html
    ):
        currency = _html_cell(
            row,
            "calendar__currency",
        )

        title = _html_cell(
            row,
            "calendar__event",
        )

        actual = _html_cell(
            row,
            "calendar__actual",
        )

        forecast = _html_cell(
            row,
            "calendar__forecast",
        )

        previous = _html_cell(
            row,
            "calendar__previous",
        )

        impact_text = _html_cell(
            row,
            "calendar__impact",
        )

        if not currency or not title:
            continue

        currency = currency.upper().strip()

        if currency not in SUPPORTED_CURRENCIES:
            continue

        events.append(
            {
                "currency": currency,
                "title": title,
                "actual": actual,
                "forecast": forecast,
                "previous": previous,
                "impact": impact_text or "",
            }
        )

    return events


def _event_match_key(
    currency: str,
    title: str,
) -> tuple[str, str]:
    return (
        _normalize_text(
            currency
        ),
        _normalize_text(
            title
        ),
    )


def reconcile_events(
    json_events: list[dict[str, Any]],
    html_events: list[dict[str, Any]],
) -> tuple[
    list[dict[str, Any]],
    dict[str, Any],
]:
    html_index = {}

    for event in html_events:
        currency = event.get(
            "currency"
        )

        title = event.get(
            "title"
        )

        if currency and title:
            html_index[
                _event_match_key(
                    currency,
                    title,
                )
            ] = event

    reconciled = []

    matched = 0
    actual_recovered = 0
    forecast_recovered = 0
    previous_recovered = 0
    impact_recovered = 0

    for raw in json_events:
        event = dict(
            raw
        )

        currency = _clean_value(
            event.get(
                "country"
            )
            or event.get(
                "currency"
            )
        )

        title = _clean_value(
            event.get(
                "title"
            )
            or event.get(
                "event"
            )
            or event.get(
                "name"
            )
        )

        if not currency or not title:
            continue

        html_event = html_index.get(
            _event_match_key(
                str(currency),
                str(title),
            )
        )

        if html_event:
            matched += 1

            fields = (
                (
                    "actual",
                    "actual_recovered",
                ),
                (
                    "forecast",
                    "forecast_recovered",
                ),
                (
                    "previous",
                    "previous_recovered",
                ),
                (
                    "impact",
                    "impact_recovered",
                ),
            )

            for field, counter_name in fields:
                if (
                    not event.get(
                        field
                    )
                    and html_event.get(
                        field
                    )
                ):
                    event[
                        field
                    ] = html_event[
                        field
                    ]

                    if counter_name == (
                        "actual_recovered"
                    ):
                        actual_recovered += 1

                    elif counter_name == (
                        "forecast_recovered"
                    ):
                        forecast_recovered += 1

                    elif counter_name == (
                        "previous_recovered"
                    ):
                        previous_recovered += 1

                    elif counter_name == (
                        "impact_recovered"
                    ):
                        impact_recovered += 1

        normalized = _normalize_event(
            event
        )

        if normalized:
            reconciled.append(
                normalized
            )

    unique = {}

    for event in reconciled:
        unique[
            event["id"]
        ] = event

    return (
        list(
            unique.values()
        ),
        {
            "json_events": len(
                json_events
            ),
            "html_events": len(
                html_events
            ),
            "matched_events": matched,
            "actual_values_recovered": (
                actual_recovered
            ),
            "forecast_values_recovered": (
                forecast_recovered
            ),
            "previous_values_recovered": (
                previous_recovered
            ),
            "impact_values_recovered": (
                impact_recovered
            ),
            "duplicates_removed": (
                len(reconciled)
                - len(unique)
            ),
        },
    )


# ============================================================================
# CATEGORY INTELLIGENCE
# ============================================================================

def _weighted_direction(
    events: list[dict[str, Any]],
) -> tuple[
    float,
    float,
    float,
    int,
    int,
    int,
]:
    signed_sum = 0.0
    absolute_sum = 0.0
    confidence_sum = 0.0

    positive = 0
    negative = 0
    neutral = 0

    for event in events:
        score = (
            _safe_float(
                event.get(
                    "event_score",
                    {},
                ).get(
                    "score"
                )
            )
            or 0.0
        )

        magnitude = abs(
            score
        )

        signed_sum += score
        absolute_sum += magnitude

        confidence_sum += (
            CONFIDENCE_WEIGHT.get(
                event.get(
                    "fundamental_interpretation",
                    {},
                ).get(
                    "confidence",
                    "NONE",
                ),
                0.0,
            )
            * max(
                magnitude,
                0.01,
            )
        )

        if score > 0:
            positive += 1

        elif score < 0:
            negative += 1

        else:
            neutral += 1

    direction = (
        signed_sum
        / absolute_sum
        if absolute_sum > 0
        else 0.0
    )

    average_confidence = (
        confidence_sum
        / absolute_sum
        if absolute_sum > 0
        else 0.0
    )

    return (
        direction,
        absolute_sum,
        average_confidence,
        positive,
        negative,
        neutral,
    )


def _state_from_score(
    score: float,
    available: bool,
    confidence: float,
) -> str:
    if not available:
        return "UNAVAILABLE"

    threshold = (
        0.20
        if confidence >= 0.65
        else 0.30
    )

    if score >= threshold:
        return "POSITIVE"

    if score <= -threshold:
        return "NEGATIVE"

    return "NEUTRAL"


def _confidence_label(
    value: float,
) -> str:
    if value >= 0.75:
        return "HIGH"

    if value >= 0.50:
        return "MEDIUM"

    if value >= 0.20:
        return "LOW"

    return "NONE"


def _category_payload(
    events: list[dict[str, Any]],
) -> dict[str, Any]:
    (
        direction,
        evidence,
        average_confidence,
        positive,
        negative,
        neutral,
    ) = _weighted_direction(
        events
    )

    count = len(
        events
    )

    consistency = (
        abs(
            positive
            - negative
        )
        / max(
            positive
            + negative,
            1,
        )
    )

    breadth = _clamp(
        count / 5.0
    )

    confidence = _clamp(
        0.50
        * average_confidence
        + 0.25
        * consistency
        + 0.25
        * breadth
    )

    strength = _clamp(
        (
            evidence
            / max(
                count,
                1,
            )
        )
        * (
            0.50
            + 0.50
            * breadth
        )
    )

    return {
        "direction_score": _round(
            direction
        ),
        "strength": _round(
            strength
        ),
        "state": _state_from_score(
            direction,
            count > 0,
            confidence,
        ),
        "confidence": _confidence_label(
            confidence
        ),
        "confidence_score": _round(
            confidence
        ),
        "evidence_count": count,
        "positive_events": positive,
        "negative_events": negative,
        "neutral_events": neutral,
        "evidence_breadth": _round(
            breadth
        ),
        "weighted_evidence": _round(
            evidence
        ),
    }


# ============================================================================
# MONETARY POLICY PRESSURE
# ============================================================================

def _policy_pressure(
    currency: str,
    categories: dict[str, dict[str, Any]],
    events: list[dict[str, Any]],
) -> dict[str, Any]:
    def score(
        category: str,
    ) -> float:
        return float(
            categories.get(
                category,
                {},
            ).get(
                "direction_score",
                0.0,
            )
        )

    inflation = score(
        "inflation"
    )

    employment = score(
        "employment"
    )

    growth = score(
        "growth"
    )

    business = score(
        "business_activity"
    )

    consumer = score(
        "consumer"
    )

    policy_events = [
        event
        for event in events
        if event.get(
            "event_type"
        ) == "central_bank"
    ]

    pressure = (
        0.45
        * inflation
        + 0.25
        * employment
        + 0.15
        * growth
        + 0.10
        * business
        + 0.05
        * consumer
    )

    hawkish = sum(
        1
        for event in policy_events
        if event.get(
            "policy_signal"
        )
        == "HAWKISH"
    )

    dovish = sum(
        1
        for event in policy_events
        if event.get(
            "policy_signal"
        )
        == "DOVISH"
    )

    if hawkish or dovish:
        communication = (
            hawkish
            - dovish
        ) / max(
            hawkish
            + dovish,
            1,
        )

        pressure = (
            0.80
            * pressure
            + 0.20
            * communication
        )

    else:
        communication = 0.0

    pressure = _clamp(
        pressure,
        -1.0,
        1.0,
    )

    if pressure >= 0.20:
        stance = (
            "HAWKISH_PRESSURE"
        )

    elif pressure <= -0.20:
        stance = (
            "DOVISH_PRESSURE"
        )

    else:
        stance = (
            "NEUTRAL_PRESSURE"
        )

    available_inputs = sum(
        1
        for category in (
            "inflation",
            "employment",
            "growth",
            "business_activity",
        )
        if categories.get(
            category,
            {},
        ).get(
            "evidence_count",
            0,
        )
        > 0
    )

    confidence = _clamp(
        0.25
        * min(
            available_inputs
            / 4.0,
            1.0,
        )
        + 0.35
        * float(
            categories.get(
                "inflation",
                {},
            ).get(
                "confidence_score",
                0.0,
            )
        )
        + 0.20
        * float(
            categories.get(
                "employment",
                {},
            ).get(
                "confidence_score",
                0.0,
            )
        )
        + 0.20
        * float(
            categories.get(
                "growth",
                {},
            ).get(
                "confidence_score",
                0.0,
            )
        )
    )

    if communication > 0.10:
        communication_bias = "HAWKISH"

    elif communication < -0.10:
        communication_bias = "DOVISH"

    else:
        communication_bias = "NEUTRAL"

    return {
        "pressure": _round(
            pressure
        ),
        "stance": stance,
        "confidence": _confidence_label(
            confidence
        ),
        "confidence_score": _round(
            confidence
        ),
        "communication_bias": (
            communication_bias
        ),
        "policy_event_count": len(
            policy_events
        ),
        "mandate_context": (
            POLICY_PROFILES[
                currency
            ]
        ),
        "explanation": (
            "macro evidence mapped to "
            "policy pressure; not a rate forecast"
        ),
    }


# ============================================================================
# CURRENCY SCORE
# ============================================================================

def calculate_currency_scores(
    events: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    result = {}

    for currency in SUPPORTED_CURRENCIES:
        released = [
            event
            for event in events
            if (
                event.get(
                    "currency"
                )
                == currency
                and event.get(
                    "release_status"
                )
                == "RELEASED"
                and event.get(
                    "event_score",
                    {},
                ).get(
                    "usable"
                )
            )
        ]

        categories = {}

        for category in CATEGORY_WEIGHT:
            category_events = [
                event
                for event in released
                if event.get(
                    "event_type"
                )
                == category
            ]

            payload = _category_payload(
                category_events
            )

            payload[
                "category"
            ] = category

            categories[
                category
            ] = payload

        weighted_sum = 0.0
        weight_total = 0.0

        positive_categories = 0
        negative_categories = 0

        for category, data in categories.items():
            evidence = float(
                data.get(
                    "weighted_evidence",
                    0.0,
                )
            )

            if evidence <= 0:
                continue

            weight = (
                CATEGORY_WEIGHT[
                    category
                ]
                * (
                    0.40
                    + 0.60
                    * _clamp(
                        evidence
                        / 3.0
                    )
                )
            )

            weighted_sum += (
                float(
                    data[
                        "direction_score"
                    ]
                )
                * weight
            )

            weight_total += weight

            if data[
                "state"
            ] == "POSITIVE":
                positive_categories += 1

            elif data[
                "state"
            ] == "NEGATIVE":
                negative_categories += 1

        overall_direction = (
            weighted_sum
            / weight_total
            if weight_total
            else 0.0
        )

        category_confidences = [
            float(
                data[
                    "confidence_score"
                ]
            )
            for data in categories.values()
            if data.get(
                "evidence_count",
                0,
            )
            > 0
        ]

        average_category_confidence = (
            sum(
                category_confidences
            )
            / len(
                category_confidences
            )
            if category_confidences
            else 0.0
        )

        breadth = _clamp(
            len(
                category_confidences
            )
            / 5.0
        )

        if (
            positive_categories
            and negative_categories
        ):
            conflict_state = (
                "CONFLICTING"
            )

            conflict_penalty = _clamp(
                min(
                    positive_categories,
                    negative_categories,
                )
                / max(
                    positive_categories
                    + negative_categories,
                    1,
                )
            )

        else:
            conflict_state = "ALIGNED"
            conflict_penalty = 0.0

        overall_confidence_score = _clamp(
            0.45
            * average_category_confidence
            + 0.30
            * breadth
            + 0.25
            * (
                1.0
                - conflict_penalty
            )
        )

        # Sparse evidence cannot become high confidence.
        if len(released) < 3:
            overall_confidence_score = min(
                overall_confidence_score,
                0.49,
            )

        elif len(released) < 6:
            overall_confidence_score = min(
                overall_confidence_score,
                0.69,
            )

        confidence = _confidence_label(
            overall_confidence_score
        )

        if overall_direction >= 0.20:
            state = "POSITIVE"

        elif overall_direction <= -0.20:
            state = "NEGATIVE"

        elif released:
            state = "NEUTRAL"

        else:
            state = "UNAVAILABLE"

        policy = _policy_pressure(
            currency,
            categories,
            released,
        )

        result[
            currency
        ] = {
            "score": _round(
                overall_direction
            ),
            "strength": _round(
                abs(
                    overall_direction
                )
            ),
            "state": state,
            "confidence": confidence,
            "confidence_score": _round(
                overall_confidence_score
            ),
            "conflict_state": (
                conflict_state
            ),
            "conflict_penalty": _round(
                conflict_penalty
            ),
            "released_events": len(
                released
            ),
            "evidence_breadth": _round(
                breadth
            ),
            "categories": categories,
            "monetary_policy": policy,
        }

    return result


# ============================================================================
# RELATIVE CURRENCY STRENGTH
# ============================================================================

def calculate_relative_strength(
    currency_scores: dict[
        str,
        dict[str, Any],
    ],
) -> dict[str, Any]:
    scores = {
        currency: float(
            currency_scores.get(
                currency,
                {},
            ).get(
                "score",
                0.0,
            )
        )
        for currency
        in SUPPORTED_CURRENCIES
    }

    ranking = sorted(
        scores.items(),
        key=lambda item: item[1],
        reverse=True,
    )

    ranks = {
        currency: index + 1
        for index, (
            currency,
            _,
        )
        in enumerate(
            ranking
        )
    }

    pairs = {}

    for base in SUPPORTED_CURRENCIES:
        for quote in SUPPORTED_CURRENCIES:
            if base == quote:
                continue

            raw = (
                scores[base]
                - scores[quote]
            )

            if raw > 0.15:
                direction = (
                    "BASE_STRONGER"
                )

            elif raw < -0.15:
                direction = (
                    "QUOTE_STRONGER"
                )

            else:
                direction = "BALANCED"

            pairs[
                f"{base}{quote}"
            ] = {
                "relative_score": _round(
                    raw / 2.0
                ),
                "base_score": _round(
                    scores[base]
                ),
                "quote_score": _round(
                    scores[quote]
                ),
                "direction": direction,
            }

    return {
        "ranking": [
            {
                "currency": currency,
                "score": _round(
                    score
                ),
                "rank": ranks[
                    currency
                ],
            }
            for currency, score
            in ranking
        ],
        "pairs": pairs,
    }


# ============================================================================
# EVENT RISK
# ============================================================================

def calculate_event_risk(
    events: list[dict[str, Any]],
) -> dict[str, Any]:
    now = _now()

    upcoming = []

    for event in events:
        if event.get(
            "release_status"
        ) != "UPCOMING":
            continue

        event_dt = _parse_datetime(
            event.get(
                "datetime_utc"
            )
        )

        if event_dt is None:
            continue

        minutes = (
            event_dt
            - now
        ).total_seconds() / 60.0

        if minutes < -10:
            continue

        upcoming.append(
            (
                minutes,
                event,
            )
        )

    high = [
        event
        for minutes, event
        in upcoming
        if (
            0
            <= minutes
            <= 1440
            and event.get(
                "impact_normalized"
            )
            == "HIGH"
        )
    ]

    medium = [
        event
        for minutes, event
        in upcoming
        if (
            0
            <= minutes
            <= 1440
            and event.get(
                "impact_normalized"
            )
            == "MEDIUM"
        )
    ]

    imminent_high = [
        event
        for minutes, event
        in upcoming
        if (
            0
            <= minutes
            <= 120
            and event.get(
                "impact_normalized"
            )
            == "HIGH"
        )
    ]

    imminent_medium = [
        event
        for minutes, event
        in upcoming
        if (
            0
            <= minutes
            <= 120
            and event.get(
                "impact_normalized"
            )
            == "MEDIUM"
        )
    ]

    times = sorted(
        minutes
        for minutes, _
        in upcoming
        if (
            0
            <= minutes
            <= 180
        )
    )

    clusters = 0

    if times:
        clusters = 1

        for previous, current in zip(
            times,
            times[1:],
        ):
            if (
                current
                - previous
                > 30
            ):
                clusters += 1

    if imminent_high:
        level = "EXTREME"

    elif high:
        level = "HIGH"

    elif (
        imminent_medium
        or clusters >= 3
    ):
        level = "MEDIUM"

    else:
        level = "LOW"

    return {
        "risk_level": level,
        "high_count": len(
            high
        ),
        "medium_count": len(
            medium
        ),
        "imminent_high_count": len(
            imminent_high
        ),
        "imminent_medium_count": len(
            imminent_medium
        ),
        "three_hour_event_count": len(
            times
        ),
        "clusters": clusters,
        "upcoming_events": [
            {
                "currency": event.get(
                    "currency"
                ),
                "title": event.get(
                    "title"
                ),
                "impact": event.get(
                    "impact_normalized"
                ),
                "importance": event.get(
                    "economic_importance"
                ),
                "minutes_to_release": round(
                    max(
                        0.0,
                        minutes,
                    ),
                    1,
                ),
                "datetime_utc": event.get(
                    "datetime_utc"
                ),
            }
            for minutes, event
            in sorted(
                upcoming,
                key=lambda item: item[0],
            )[:20]
        ],
    }


# ============================================================================
# DATA QUALITY
# ============================================================================

def calculate_data_quality(
    events: list[dict[str, Any]],
    reconciliation: dict[str, Any],
) -> dict[str, Any]:
    released = [
        event
        for event in events
        if event.get(
            "release_status"
        )
        == "RELEASED"
    ]

    actual_count = sum(
        1
        for event in released
        if event.get(
            "data_quality",
            {},
        ).get(
            "has_actual"
        )
    )

    forecast_count = sum(
        1
        for event in events
        if event.get(
            "data_quality",
            {},
        ).get(
            "has_forecast"
        )
    )

    datetime_count = sum(
        1
        for event in events
        if event.get(
            "data_quality",
            {},
        ).get(
            "has_datetime"
        )
    )

    duplicate_removed = int(
        reconciliation.get(
            "duplicates_removed",
            0,
        )
    )

    malformed = sum(
        1
        for event in events
        if not event.get(
            "data_quality",
            {},
        ).get(
            "single_numeric_value",
            True,
        )
    )

    actual_ratio = (
        actual_count
        / max(
            len(released),
            1,
        )
    )

    datetime_ratio = (
        datetime_count
        / max(
            len(events),
            1,
        )
    )

    score = _clamp(
        0.45
        * actual_ratio
        + 0.35
        * datetime_ratio
        + 0.20
        * (
            1.0
            if duplicate_removed == 0
            else 0.90
        )
    )

    if score >= 0.80:
        label = "HIGH"

    elif score >= 0.55:
        label = "MEDIUM"

    else:
        label = "LOW"

    return {
        "score": _round(
            score
        ),
        "label": label,
        "released_events": len(
            released
        ),
        "actual_values": actual_count,
        "forecast_values": forecast_count,
        "datetime_values": datetime_count,
        "malformed_composite_values": malformed,
        "duplicates_removed": duplicate_removed,
        "json_events": reconciliation.get(
            "json_events",
            0,
        ),
        "html_events": reconciliation.get(
            "html_events",
            0,
        ),
        "matched_events": reconciliation.get(
            "matched_events",
            0,
        ),
    }


# ============================================================================
# EVENT CLUSTERS
# ============================================================================

def detect_event_clusters(
    events: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    dated = []

    for event in events:
        event_dt = _parse_datetime(
            event.get(
                "datetime_utc"
            )
        )

        if event_dt is not None:
            dated.append(
                (
                    event_dt,
                    event,
                )
            )

    dated.sort(
        key=lambda item: item[0]
    )

    clusters = []
    current = []

    for item in dated:
        if (
            not current
            or (
                item[0]
                - current[-1][0]
            ).total_seconds()
            <= 3600
        ):
            current.append(
                item
            )

        else:
            if len(current) >= 2:
                clusters.append(
                    current
                )

            current = [
                item
            ]

    if len(current) >= 2:
        clusters.append(
            current
        )

    return [
        {
            "start": cluster[
                0
            ][0].isoformat(),
            "end": cluster[
                -1
            ][0].isoformat(),
            "count": len(
                cluster
            ),
            "currencies": sorted(
                {
                    event[
                        "currency"
                    ]
                    for _, event
                    in cluster
                }
            ),
            "events": [
                event[
                    "title"
                ]
                for _, event
                in cluster
            ],
        }
        for cluster in clusters
    ]


# ============================================================================
# FUNDAMENTAL SNAPSHOT
# ============================================================================

def build_fundamental_snapshot(
    events: list[dict[str, Any]],
    reconciliation: dict[str, Any],
) -> dict[str, Any]:
    currency_scores = (
        calculate_currency_scores(
            events
        )
    )

    return {
        "generated_at_utc": (
            _now().isoformat()
        ),
        "engine_version": (
            "FINAL-MACRO-1.0"
        ),
        "supported_currencies": list(
            SUPPORTED_CURRENCIES
        ),
        "currency_scores": (
            currency_scores
        ),
        "relative_currency_strength": (
            calculate_relative_strength(
                currency_scores
            )
        ),
        "event_risk": (
            calculate_event_risk(
                events
            )
        ),
        "event_clusters": (
            detect_event_clusters(
                events
            )
        ),
        "data_quality": (
            calculate_data_quality(
                events,
                reconciliation,
            )
        ),
        "events": events,
        "reconciliation": (
            reconciliation
        ),
        "sources": {
            "calendar_json": (
                FOREX_FACTORY_JSON_URL
            ),
            "calendar_html": (
                FOREX_FACTORY_CALENDAR_URL
            ),
            "central_bank_context": {
                "USD": (
                    "Federal Reserve mandate context"
                ),
                "GBP": (
                    "Bank of England mandate context"
                ),
                "JPY": (
                    "Bank of Japan price-stability context"
                ),
                "AUD": (
                    "Reserve Bank of Australia mandate context"
                ),
            },
        },
        "limitations": [
            (
                "Forex Factory is the primary "
                "calendar source in this subsystem."
            ),
            (
                "Calendar impact and economic "
                "importance are separate scores."
            ),
            (
                "Central-bank pressure is an "
                "inference from available evidence."
            ),
            (
                "Currency fundamental state is "
                "not a BUY/SELL signal."
            ),
            (
                "No centralized forex order-flow, "
                "DOM or footprint information is "
                "used here."
            ),
            (
                "Current policy rates are not "
                "hard-coded."
            ),
        ],
    }


# ============================================================================
# PUBLIC CALENDAR FUNCTION
# ============================================================================

def fetch_forex_factory_calendar() -> tuple[
    list[dict[str, Any]],
    dict[str, Any],
]:
    json_events = (
        fetch_forex_factory_json()
    )

    html = (
        fetch_forex_factory_html()
    )

    html_events = (
        _extract_html_events(
            html
        )
    )

    filtered_json = [
        event
        for event in json_events
        if str(
            event.get(
                "country"
            )
            or event.get(
                "currency"
            )
            or ""
        ).upper()
        in SUPPORTED_CURRENCIES
    ]

    return reconcile_events(
        filtered_json,
        html_events,
    )


def summarize_calendar(
    events: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "total": len(
            events
        ),
        "currency_counts": dict(
            Counter(
                event.get(
                    "currency"
                )
                for event in events
            )
        ),
        "impact_counts": dict(
            Counter(
                event.get(
                    "impact_normalized"
                )
                for event in events
            )
        ),
        "event_type_counts": dict(
            Counter(
                event.get(
                    "event_type"
                )
                for event in events
            )
        ),
        "release_status_counts": dict(
            Counter(
                event.get(
                    "release_status"
                )
                for event in events
            )
        ),
        "surprise_counts": dict(
            Counter(
                event.get(
                    "surprise",
                    {},
                ).get(
                    "direction"
                )
                for event in events
            )
        ),
        "currency_impact_counts": dict(
            Counter(
                event.get(
                    "fundamental_interpretation",
                    {},
                ).get(
                    "currency_impact"
                )
                for event in events
            )
        ),
    }


# ============================================================================
# CLI TEST
# ============================================================================

def _print_event(
    event: dict[str, Any],
) -> None:
    surprise = event.get(
        "surprise",
        {},
    )

    strength = event.get(
        "surprise_strength",
        {},
    )

    previous = event.get(
        "previous_comparison",
        {},
    )

    interpretation = event.get(
        "fundamental_interpretation",
        {},
    )

    score = event.get(
        "event_score",
        {},
    )

    print()

    print(
        f"{event['currency']} | "
        f"{event['title']}"
    )

    print(
        f"  Type: "
        f"{event['event_type']}"
    )

    print(
        f"  Calendar impact: "
        f"{event['impact_normalized']}"
    )

    print(
        f"  Economic importance: "
        f"{event['economic_importance']:.2f} "
        f"[{event['economic_importance_class']}]"
    )

    print(
        f"  Actual: "
        f"{event['actual']}"
    )

    print(
        f"  Forecast: "
        f"{event['forecast']}"
    )

    print(
        f"  Previous: "
        f"{event['previous']}"
    )

    print(
        f"  Surprise: "
        f"{surprise.get('direction')} "
        f"({surprise.get('formatted')})"
    )

    print(
        f"  Surprise strength: "
        f"{strength.get('magnitude')} "
        f"({strength.get('normalized')})"
    )

    print(
        f"  Vs previous: "
        f"{previous.get('direction')} "
        f"({previous.get('formatted')})"
    )

    print(
        f"  Currency impact: "
        f"{interpretation.get('currency_impact')}"
    )

    print(
        f"  Confidence: "
        f"{interpretation.get('confidence')}"
    )

    print(
        f"  Event score: "
        f"{score.get('score', 0.0):+.4f}"
    )


def main() -> None:
    print(
        "=" * 78
    )

    print(
        "HAFNOT AI TRADING AGENT"
    )

    print(
        "FINAL FUNDAMENTAL INTELLIGENCE ENGINE"
    )

    print(
        "=" * 78
    )

    try:
        events, reconciliation = (
            fetch_forex_factory_calendar()
        )

    except Exception as exc:
        print(
            "ERROR: unable to obtain "
            f"Forex Factory calendar: {exc}"
        )
        return

    summary = (
        summarize_calendar(
            events
        )
    )

    snapshot = (
        build_fundamental_snapshot(
            events,
            reconciliation,
        )
    )

    _write_json(
        SNAPSHOT_FILE,
        snapshot,
    )

    print()

    print(
        "Total AUD, GBP, JPY, USD events: "
        f"{len(events)}"
    )

    print(
        "HTML events extracted: "
        f"{reconciliation['html_events']}"
    )

    print(
        "Matched JSON/HTML events: "
        f"{reconciliation['matched_events']}"
    )

    print(
        "Actual values recovered: "
        f"{reconciliation['actual_values_recovered']}"
    )

    print(
        "Duplicates removed: "
        f"{reconciliation['duplicates_removed']}"
    )

    print()

    print(
        "Release status:"
    )

    print(
        summary[
            "release_status_counts"
        ]
    )

    print()

    print(
        "Surprise counts:"
    )

    print(
        summary[
            "surprise_counts"
        ]
    )

    print()

    print(
        "Currency impact counts:"
    )

    print(
        summary[
            "currency_impact_counts"
        ]
    )

    print()

    print(
        "Event type counts:"
    )

    print(
        summary[
            "event_type_counts"
        ]
    )

    print(
        "\n"
        + "-"
        * 78
    )

    print(
        "MULTI-DIMENSIONAL CURRENCY FUNDAMENTALS"
    )

    print(
        "-"
        * 78
    )

    for currency, data in (
        snapshot[
            "currency_scores"
        ].items()
    ):
        print()

        print(
            currency
        )

        print(
            f"  Overall direction score: "
            f"{data['score']:+.4f}"
        )

        print(
            f"  Overall strength: "
            f"{data['strength']:.4f}"
        )

        print(
            f"  State: "
            f"{data['state']}"
        )

        print(
            f"  Confidence: "
            f"{data['confidence']}"
        )

        print(
            f"  Conflict: "
            f"{data['conflict_state']}"
        )

        print(
            f"  Evidence breadth: "
            f"{data['evidence_breadth']:.4f}"
        )

        print(
            f"  Released usable events: "
            f"{data['released_events']}"
        )

        print(
            "  Categories:"
        )

        for (
            category,
            category_data,
        ) in data[
            "categories"
        ].items():
            if (
                category_data[
                    "evidence_count"
                ]
                == 0
            ):
                continue

            print(
                f"    {category}: "
                f"direction="
                f"{category_data['direction_score']:+.4f} "
                f"strength="
                f"{category_data['strength']:.4f} "
                f"state="
                f"{category_data['state']} "
                f"confidence="
                f"{category_data['confidence']} "
                f"events="
                f"{category_data['evidence_count']}"
            )

        policy = data[
            "monetary_policy"
        ]

        print(
            "  Monetary policy pressure:"
        )

        print(
            f"    Pressure: "
            f"{policy['pressure']:+.4f}"
        )

        print(
            f"    Stance: "
            f"{policy['stance']}"
        )

        print(
            f"    Confidence: "
            f"{policy['confidence']}"
        )

        print(
            f"    Communication: "
            f"{policy['communication_bias']}"
        )

    print(
        "\n"
        + "-"
        * 78
    )

    print(
        "RELATIVE CURRENCY STRENGTH"
    )

    print(
        "-"
        * 78
    )

    for row in (
        snapshot[
            "relative_currency_strength"
        ][
            "ranking"
        ]
    ):
        print(
            f"  {row['rank']}. "
            f"{row['currency']}: "
            f"{row['score']:+.4f}"
        )

    print(
        "\n"
        + "-"
        * 78
    )

    print(
        "UPCOMING EVENT RISK"
    )

    print(
        "-"
        * 78
    )

    risk = snapshot[
        "event_risk"
    ]

    print(
        f"  Risk level: "
        f"{risk['risk_level']}"
    )

    print(
        f"  High-impact events: "
        f"{risk['high_count']}"
    )

    print(
        f"  Medium-impact events: "
        f"{risk['medium_count']}"
    )

    print(
        f"  Imminent high-impact events: "
        f"{risk['imminent_high_count']}"
    )

    print(
        f"  Three-hour event count: "
        f"{risk['three_hour_event_count']}"
    )

    print(
        f"  Event clusters: "
        f"{risk['clusters']}"
    )

    print(
        "\n"
        + "-"
        * 78
    )

    print(
        "DATA QUALITY"
    )

    print(
        "-"
        * 78
    )

    quality = snapshot[
        "data_quality"
    ]

    for key in (
        "score",
        "label",
        "released_events",
        "actual_values",
        "forecast_values",
        "datetime_values",
        "malformed_composite_values",
        "duplicates_removed",
    ):
        print(
            f"  {key}: "
            f"{quality[key]}"
        )

    print(
        "\n"
        + "-"
        * 78
    )

    print(
        "RELEASED EVENT ANALYSIS"
    )

    print(
        "-"
        * 78
    )

    released_events = [
        event
        for event in events
        if event.get(
            "release_status"
        )
        == "RELEASED"
    ]

    for event in released_events[
        :15
    ]:
        _print_event(
            event
        )

    print()

    print(
        "=" * 78
    )

    print(
        "Snapshot written to: "
        f"{SNAPSHOT_FILE}"
    )

    print(
        "FUNDAMENTAL ENGINE TEST COMPLETE"
    )

    print(
        "=" * 78
    )


if __name__ == "__main__":
    main()