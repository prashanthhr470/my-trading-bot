"""
HAFNOT AI TRADING AGENT
FUNDAMENTAL PAIR ENGINE

Purpose
-------
Converts individual currency fundamental strength into
pair-level fundamental pressure.

Supported currencies:
    USD, GBP, JPY, AUD

Supported pairs:
    USDJPY
    GBPUSD
    AUDUSD
    GBPJPY
    AUDJPY
    GBPAUD

Important
---------
This module does NOT place trades.

It only answers:

    "Which currency is fundamentally stronger/weaker?"

and then converts that into:

    "What is the fundamental pressure on this pair?"

Example:

    USD = -0.65
    JPY = +0.42

    USDJPY
        Base currency  = USD
        Quote currency = JPY

    Result:
        BEARISH

This is fundamental evidence only.
It must later be combined with:

    Technical structure
    Liquidity
    Market state
    Order flow / DOM
    News
    Risk
    AI reasoning
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ============================================================
# CONFIGURATION
# ============================================================

SUPPORTED_CURRENCIES = {
    "USD",
    "GBP",
    "JPY",
    "AUD",
}


SUPPORTED_PAIRS = {
    "USDJPY": ("USD", "JPY"),
    "GBPUSD": ("GBP", "USD"),
    "AUDUSD": ("AUD", "USD"),
    "GBPJPY": ("GBP", "JPY"),
    "AUDJPY": ("AUD", "JPY"),
    "GBPAUD": ("GBP", "AUD"),
}


SNAPSHOT_PATH = Path(
    "data/fundamental/fundamental_snapshot.json"
)


# ============================================================
# HELPERS
# ============================================================

def _safe_float(value: Any, default: float = 0.0) -> float:
    """
    Convert a value to float safely.
    """
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _clamp(
    value: float,
    minimum: float = -1.0,
    maximum: float = 1.0,
) -> float:
    """
    Clamp a number to a fixed range.
    """
    return max(
        minimum,
        min(maximum, value),
    )


def _normalize_pair(pair: str) -> str:
    """
    Normalize a currency pair.

    Examples:
        usd/jpy -> USDJPY
        GBPUSD -> GBPUSD
        gbp-usd -> GBPUSD
    """
    if not isinstance(pair, str):
        raise ValueError("Pair must be a string.")

    normalized = (
        pair.upper()
        .replace("/", "")
        .replace("-", "")
        .replace("_", "")
        .replace(" ", "")
    )

    if normalized not in SUPPORTED_PAIRS:
        raise ValueError(
            f"Unsupported pair: {pair}. "
            f"Supported pairs: "
            f"{', '.join(sorted(SUPPORTED_PAIRS))}"
        )

    return normalized


def _state_from_score(
    score: float,
    strong_threshold: float = 0.35,
    weak_threshold: float = 0.15,
) -> str:
    """
    Convert a directional score into a readable state.

    This intentionally uses thresholds instead of treating
    every non-zero number as a trade signal.
    """
    score = _clamp(score)

    if score >= strong_threshold:
        return "STRONG_POSITIVE"

    if score <= -strong_threshold:
        return "STRONG_NEGATIVE"

    if score >= weak_threshold:
        return "POSITIVE"

    if score <= -weak_threshold:
        return "NEGATIVE"

    return "NEUTRAL"


def _confidence_rank(value: str) -> int:
    """
    Convert confidence label to numeric rank.
    """
    mapping = {
        "NONE": 0,
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3,
    }

    return mapping.get(
        str(value).upper(),
        0,
    )


def _confidence_from_components(
    base_confidence: str,
    quote_confidence: str,
    strength: float,
    conflict: bool,
    breadth: float,
) -> str:
    """
    Calculate pair confidence conservatively.

    We do NOT allow a pair to become HIGH confidence merely
    because the mathematical score is large.

    Both currencies must have reasonably useful evidence.
    """

    base_rank = _confidence_rank(base_confidence)
    quote_rank = _confidence_rank(quote_confidence)

    minimum_rank = min(
        base_rank,
        quote_rank,
    )

    if minimum_rank == 0:
        return "NONE"

    if conflict:
        if minimum_rank >= 3 and strength >= 0.60:
            return "MEDIUM"

        if minimum_rank >= 2 and strength >= 0.35:
            return "LOW"

        return "LOW"

    if (
        minimum_rank >= 3
        and strength >= 0.60
        and breadth >= 0.75
    ):
        return "HIGH"

    if (
        minimum_rank >= 2
        and strength >= 0.35
        and breadth >= 0.50
    ):
        return "MEDIUM"

    return "LOW"


# ============================================================
# SNAPSHOT LOADING
# ============================================================

def load_fundamental_snapshot(
    path: str | Path = SNAPSHOT_PATH,
) -> dict[str, Any]:
    """
    Load the fundamental snapshot produced by
    fundamental_engine.py.
    """

    snapshot_path = Path(path)

    if not snapshot_path.exists():
        raise FileNotFoundError(
            f"Fundamental snapshot not found: "
            f"{snapshot_path}"
        )

    with snapshot_path.open(
        "r",
        encoding="utf-8",
    ) as file:
        snapshot = json.load(file)

    if not isinstance(snapshot, dict):
        raise ValueError(
            "Fundamental snapshot must be a JSON object."
        )

    if "currency_scores" not in snapshot:
        raise ValueError(
            "Fundamental snapshot does not contain "
            "'currency_scores'."
        )

    return snapshot


# ============================================================
# CURRENCY EXTRACTION
# ============================================================

def extract_currency_fundamentals(
    snapshot: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    """
    Extract the currency-level fundamental data.

    The current fundamental engine stores currency information
    under:

        snapshot["currency_scores"]

    Existing output includes:
        score
        state
        confidence
        released_events
        conflict_state
        categories
    """

    raw_scores = snapshot.get(
        "currency_scores",
        {},
    )

    if not isinstance(raw_scores, dict):
        raise ValueError(
            "'currency_scores' must be a dictionary."
        )

    result: dict[str, dict[str, Any]] = {}

    for currency in sorted(
        SUPPORTED_CURRENCIES
    ):
        raw = raw_scores.get(
            currency,
            {},
        )

        if not isinstance(raw, dict):
            raw = {}

        score = _safe_float(
            raw.get("score"),
            0.0,
        )

        state = str(
            raw.get(
                "state",
                "UNAVAILABLE",
            )
        ).upper()

        confidence = str(
            raw.get(
                "confidence",
                "NONE",
            )
        ).upper()

        conflict_state = str(
            raw.get(
                "conflict_state",
                "UNKNOWN",
            )
        ).upper()

        released_events = int(
            _safe_float(
                raw.get(
                    "released_events",
                    0,
                ),
                0.0,
            )
        )

        evidence_breadth = _safe_float(
            raw.get(
                "evidence_breadth",
                0.0,
            ),
            0.0,
        )

        result[currency] = {
            "score": round(
                _clamp(score),
                4,
            ),
            "state": state,
            "confidence": confidence,
            "conflict_state": conflict_state,
            "released_events": released_events,
            "evidence_breadth": round(
                _clamp(
                    evidence_breadth,
                    0.0,
                    1.0,
                ),
                4,
            ),
            "categories": raw.get(
                "categories",
                {},
            ),
            "monetary_policy": raw.get(
                "monetary_policy",
                {},
            ),
        }

    return result


# ============================================================
# PAIR CALCULATION
# ============================================================

def calculate_pair_fundamental(
    pair: str,
    currency_data: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """
    Calculate fundamental pressure for one currency pair.

    Formula:

        pair_score =
            base_currency_score
            - quote_currency_score

    Example:

        GBP = +0.46
        USD = -0.65

        GBPUSD =
            +0.46 - (-0.65)
            = +1.11

    The raw differential is then normalized to [-1, +1].

    Positive:
        base stronger than quote

    Negative:
        quote stronger than base
    """

    pair = _normalize_pair(pair)

    base_currency, quote_currency = (
        SUPPORTED_PAIRS[pair]
    )

    base = currency_data.get(
        base_currency,
        {},
    )

    quote = currency_data.get(
        quote_currency,
        {},
    )

    base_score = _safe_float(
        base.get("score"),
        0.0,
    )

    quote_score = _safe_float(
        quote.get("score"),
        0.0,
    )

    raw_differential = (
        base_score
        - quote_score
    )

    # The currency scores are themselves normalized.
    # Their difference can therefore reach approximately
    # [-2, +2].
    #
    # Divide by 2 to normalize the pair differential
    # into approximately [-1, +1].
    pair_score = _clamp(
        raw_differential / 2.0
    )

    absolute_strength = abs(
        pair_score
    )

    base_confidence = str(
        base.get(
            "confidence",
            "NONE",
        )
    ).upper()

    quote_confidence = str(
        quote.get(
            "confidence",
            "NONE",
        )
    ).upper()

    base_conflict = (
        str(
            base.get(
                "conflict_state",
                "",
            )
        ).upper()
        == "CONFLICTING"
    )

    quote_conflict = (
        str(
            quote.get(
                "conflict_state",
                "",
            )
        ).upper()
        == "CONFLICTING"
    )

    conflict = (
        base_conflict
        or quote_conflict
    )

    base_breadth = _safe_float(
        base.get(
            "evidence_breadth",
            0.0,
        ),
        0.0,
    )

    quote_breadth = _safe_float(
        quote.get(
            "evidence_breadth",
            0.0,
        ),
        0.0,
    )

    pair_breadth = min(
        _clamp(
            base_breadth,
            0.0,
            1.0,
        ),
        _clamp(
            quote_breadth,
            0.0,
            1.0,
        ),
    )

    # If the older snapshot does not contain breadth,
    # use released-event availability as a conservative
    # fallback.
    if pair_breadth == 0.0:
        base_events = int(
            _safe_float(
                base.get(
                    "released_events",
                    0,
                ),
                0.0,
            )
        )

        quote_events = int(
            _safe_float(
                quote.get(
                    "released_events",
                    0,
                ),
                0.0,
            )
        )

        base_breadth = min(
            base_events / 10.0,
            1.0,
        )

        quote_breadth = min(
            quote_events / 10.0,
            1.0,
        )

        pair_breadth = min(
            base_breadth,
            quote_breadth,
        )

    # --------------------------------------------------------
    # Direction
    # --------------------------------------------------------

    if pair_score >= 0.20:
        direction = "BULLISH"

    elif pair_score <= -0.20:
        direction = "BEARISH"

    else:
        direction = "NEUTRAL"

    # --------------------------------------------------------
    # State
    # --------------------------------------------------------

    if pair_score >= 0.50:
        state = "STRONG_BULLISH"

    elif pair_score >= 0.20:
        state = "BULLISH"

    elif pair_score <= -0.50:
        state = "STRONG_BEARISH"

    elif pair_score <= -0.20:
        state = "BEARISH"

    else:
        state = "NEUTRAL"

    # --------------------------------------------------------
    # Confidence
    # --------------------------------------------------------

    confidence = _confidence_from_components(
        base_confidence=base_confidence,
        quote_confidence=quote_confidence,
        strength=absolute_strength,
        conflict=conflict,
        breadth=pair_breadth,
    )

    # --------------------------------------------------------
    # Relative strength labels
    # --------------------------------------------------------

    if base_score > quote_score:
        stronger_currency = base_currency
        weaker_currency = quote_currency

    elif quote_score > base_score:
        stronger_currency = quote_currency
        weaker_currency = base_currency

    else:
        stronger_currency = None
        weaker_currency = None

    # --------------------------------------------------------
    # Data availability
    # --------------------------------------------------------

    data_available = (
        base_confidence != "NONE"
        and quote_confidence != "NONE"
    )

    if not data_available:
        direction = "UNAVAILABLE"
        state = "UNAVAILABLE"
        confidence = "NONE"

    return {
        "pair": pair,
        "base_currency": base_currency,
        "quote_currency": quote_currency,

        "base_score": round(
            _clamp(base_score),
            4,
        ),

        "quote_score": round(
            _clamp(quote_score),
            4,
        ),

        "raw_differential": round(
            raw_differential,
            4,
        ),

        "score": round(
            pair_score,
            4,
        ),

        "strength": round(
            absolute_strength,
            4,
        ),

        "direction": direction,
        "state": state,
        "confidence": confidence,

        "stronger_currency": (
            stronger_currency
        ),

        "weaker_currency": (
            weaker_currency
        ),

        "conflict": conflict,

        "base_conflict": base_conflict,
        "quote_conflict": quote_conflict,

        "evidence_breadth": round(
            pair_breadth,
            4,
        ),

        "base_released_events": int(
            _safe_float(
                base.get(
                    "released_events",
                    0,
                ),
                0.0,
            )
        ),

        "quote_released_events": int(
            _safe_float(
                quote.get(
                    "released_events",
                    0,
                ),
                0.0,
            )
        ),

        "data_available": data_available,
    }


# ============================================================
# ALL PAIRS
# ============================================================

def calculate_all_pair_fundamentals(
    currency_data: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """
    Calculate fundamental pressure for every supported pair.
    """

    result = {}

    for pair in SUPPORTED_PAIRS:
        result[pair] = (
            calculate_pair_fundamental(
                pair,
                currency_data,
            )
        )

    return result


# ============================================================
# PAIR RANKING
# ============================================================

def rank_pairs(
    pair_data: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """
    Rank pairs by absolute fundamental strength.

    Strongest directional differential appears first.
    """

    ranked = []

    for pair, data in pair_data.items():
        if not data.get(
            "data_available",
            False,
        ):
            continue

        ranked.append(
            dict(data)
        )

    ranked.sort(
        key=lambda item: item.get(
            "strength",
            0.0,
        ),
        reverse=True,
    )

    for index, item in enumerate(
        ranked,
        start=1,
    ):
        item["rank"] = index

    return ranked


# ============================================================
# TRADE-USEFUL FILTER
# ============================================================

def get_actionable_pair_bias(
    pair_data: dict[str, Any],
    minimum_strength: float = 0.20,
) -> dict[str, Any]:
    """
    Convert pair fundamentals into a conservative
    trading-bias classification.

    IMPORTANT:

    This does NOT mean BUY or SELL.

    It only means:

        FUNDAMENTAL LONG PRESSURE
        FUNDAMENTAL SHORT PRESSURE
        NO FUNDAMENTAL EDGE
    """

    if not pair_data.get(
        "data_available",
        False,
    ):
        return {
            "bias": "UNAVAILABLE",
            "actionable": False,
            "reason": (
                "Fundamental data unavailable "
                "for one or both currencies."
            ),
        }

    score = _safe_float(
        pair_data.get(
            "score",
            0.0,
        )
    )

    strength = abs(score)

    confidence = str(
        pair_data.get(
            "confidence",
            "NONE",
        )
    ).upper()

    conflict = bool(
        pair_data.get(
            "conflict",
            False,
        )
    )

    if strength < minimum_strength:
        return {
            "bias": "NO_EDGE",
            "actionable": False,
            "reason": (
                "Currency differential is too small."
            ),
        }

    if confidence == "NONE":
        return {
            "bias": "NO_EDGE",
            "actionable": False,
            "reason": (
                "Fundamental confidence unavailable."
            ),
        }

    if score > 0:
        bias = "LONG_PRESSURE"

    else:
        bias = "SHORT_PRESSURE"

    # Conflict does not automatically reverse the signal.
    # It reduces how much the evidence can be trusted.
    if conflict:
        return {
            "bias": bias,
            "actionable": False,
            "reason": (
                "Directional fundamental pressure exists, "
                "but one or both currencies have conflicting "
                "macro evidence."
            ),
        }

    return {
        "bias": bias,
        "actionable": True,
        "reason": (
            "Base and quote currency fundamentals show "
            "a meaningful relative-strength differential."
        ),
    }


# ============================================================
# FINAL FUNDAMENTAL PAIR SNAPSHOT
# ============================================================

def build_pair_fundamental_snapshot(
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    """
    Build the pair-level fundamental snapshot.
    """

    currency_data = (
        extract_currency_fundamentals(
            snapshot
        )
    )

    pair_data = (
        calculate_all_pair_fundamentals(
            currency_data
        )
    )

    ranked_pairs = rank_pairs(
        pair_data
    )

    actionable = {}

    for pair, data in pair_data.items():
        actionable[pair] = (
            get_actionable_pair_bias(
                data
            )
        )

    return {
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),

        "source": {
            "type": "fundamental_engine",
            "snapshot": str(
                SNAPSHOT_PATH
            ),
        },

        "currency_fundamentals": (
            currency_data
        ),

        "pair_fundamentals": (
            pair_data
        ),

        "ranked_pairs": (
            ranked_pairs
        ),

        "actionable_bias": (
            actionable
        ),
    }


# ============================================================
# SAVE
# ============================================================

def save_pair_fundamental_snapshot(
    snapshot: dict[str, Any],
    path: str | Path = (
        "data/fundamental/"
        "pair_fundamental_snapshot.json"
    ),
) -> Path:
    """
    Save pair-level fundamental intelligence.
    """

    output_path = Path(path)

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            snapshot,
            file,
            indent=2,
            ensure_ascii=False,
        )

    return output_path


# ============================================================
# DISPLAY
# ============================================================

def print_pair_report(
    snapshot: dict[str, Any],
) -> None:
    """
    Print a human-readable pair report.
    """

    print()
    print("=" * 78)
    print("HAFNOT AI TRADING AGENT")
    print("PAIR-LEVEL FUNDAMENTAL INTELLIGENCE")
    print("=" * 78)

    print()
    print("-" * 78)
    print("PAIR FUNDAMENTAL PRESSURE")
    print("-" * 78)

    pair_data = snapshot.get(
        "pair_fundamentals",
        {},
    )

    actionable = snapshot.get(
        "actionable_bias",
        {},
    )

    for pair in SUPPORTED_PAIRS:
        data = pair_data.get(
            pair,
            {},
        )

        action = actionable.get(
            pair,
            {},
        )

        print()
        print(pair)

        print(
            f"  Base:       "
            f"{data.get('base_currency')}"
        )

        print(
            f"  Quote:      "
            f"{data.get('quote_currency')}"
        )

        print(
            f"  Base score: "
            f"{data.get('base_score', 0.0):+.4f}"
        )

        print(
            f"  Quote score:"
            f" {data.get('quote_score', 0.0):+.4f}"
        )

        print(
            f"  Differential:"
            f" {data.get('raw_differential', 0.0):+.4f}"
        )

        print(
            f"  Pair score: "
            f"{data.get('score', 0.0):+.4f}"
        )

        print(
            f"  Strength:   "
            f"{data.get('strength', 0.0):.4f}"
        )

        print(
            f"  Direction:   "
            f"{data.get('direction', 'UNKNOWN')}"
        )

        print(
            f"  State:       "
            f"{data.get('state', 'UNKNOWN')}"
        )

        print(
            f"  Confidence:  "
            f"{data.get('confidence', 'NONE')}"
        )

        print(
            f"  Conflict:    "
            f"{data.get('conflict', False)}"
        )

        print(
            f"  Bias:        "
            f"{action.get('bias', 'UNKNOWN')}"
        )

        print(
            f"  Actionable:  "
            f"{action.get('actionable', False)}"
        )

        print(
            f"  Reason:      "
            f"{action.get('reason', '')}"
        )

    print()
    print("-" * 78)
    print("RANKED FUNDAMENTAL OPPORTUNITIES")
    print("-" * 78)

    for item in snapshot.get(
        "ranked_pairs",
        [],
    ):
        print(
            f"{item['rank']}. "
            f"{item['pair']} "
            f"| {item['direction']} "
            f"| score={item['score']:+.4f} "
            f"| strength={item['strength']:.4f} "
            f"| confidence={item['confidence']}"
        )

    print()
    print("=" * 78)


# ============================================================
# STANDALONE TEST
# ============================================================

def main() -> None:
    """
    Standalone test.

    Reads the fundamental snapshot generated by
    fundamental_engine.py.

    No broker.
    No cTrader.
    No order.
    No execution.
    """

    print(
        "Loading fundamental snapshot..."
    )

    fundamental_snapshot = (
        load_fundamental_snapshot()
    )

    pair_snapshot = (
        build_pair_fundamental_snapshot(
            fundamental_snapshot
        )
    )

    output_path = (
        save_pair_fundamental_snapshot(
            pair_snapshot
        )
    )

    print_pair_report(
        pair_snapshot
    )

    print()
    print(
        f"Snapshot written to: "
        f"{output_path}"
    )

    print()
    print(
        "PAIR FUNDAMENTAL ENGINE TEST COMPLETE"
    )


if __name__ == "__main__":
    main()