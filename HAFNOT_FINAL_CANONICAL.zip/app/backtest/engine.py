from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Callable, Any, Optional


class _VisibleBars:
    """
    Read-only view of bars[:end], handed to the strategy on every bar instead of a copy.

    Copying the prefix made each replay quadratic in the number of bars - harmless on
    daily history, prohibitive on 15-minute history. The view exposes exactly the same
    bars: indexing past the decision bar raises IndexError, slicing is clamped to it.
    """

    __slots__ = ("_bars", "_end")

    def __init__(self, bars: list, end: int):
        self._bars = bars
        self._end = end

    def __len__(self) -> int:
        return self._end

    def __getitem__(self, key):
        if isinstance(key, slice):
            start, stop, step = key.indices(self._end)
            if step > 0:
                return self._bars[start:stop:step]
            # A reversed slice's stop of -1 means "before the first bar", which the list would read as its last bar.
            return [self._bars[index] for index in range(start, stop, step)]
        index = key.__index__()
        if index < 0:
            index += self._end
        if not 0 <= index < self._end:
            raise IndexError("bar index outside the visible bars")
        return self._bars[index]

    def __iter__(self):
        bars = self._bars
        for index in range(self._end):
            yield bars[index]


@dataclass
class BacktestTrade:
    symbol: str
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    result_r: float
    entry_index: int
    exit_index: int
    # The price the trade left at and why. Fixed stop/target trades exit exactly at
    # one of those two levels; trailing and end-of-data exits can be anywhere.
    exit_price: Optional[float] = None
    exit_reason: str = ""


class BacktestEngine:
    """
    Deterministic OHLC replay engine.

    SAFETY:
    - Never calls a broker.
    - Never places orders.
    - Signal provider receives ONLY candles available
      at the current decision index.
    - Future candles are never exposed to signal generation.

    A signal may carry `trailing_stop_distance` (price units, fixed at entry): the
    stop then follows the best price reached since entry at that distance. On each
    bar the stop is checked BEFORE that bar moves it, and a bar opening beyond the
    stop fills at its open - never at a better price than was available.

    A signal may also carry `exit_after_bars` (an integer >= 1): a trade the stop or
    target has not closed is closed at the close of that many bars after entry (TIME).
    """

    def __init__(
        self,
        initial_equity: float = 10000.0,
        risk_percent: float = 1.0,
    ):
        self.initial_equity = float(initial_equity)
        self.risk_percent = float(risk_percent)

    @staticmethod
    def _trade_result(
        direction,
        entry,
        stop,
        target,
        bar,
    ):
        high = float(bar["high"])
        low = float(bar["low"])

        if direction == "BUY":
            # Conservative ambiguity rule:
            # if SL and TP are both touched in the same bar,
            # assume SL happened first.
            if low <= stop:
                return -1.0

            if high >= target:
                return (target - entry) / (entry - stop)

        elif direction == "SELL":
            # Conservative ambiguity rule.
            if high >= stop:
                return -1.0

            if low <= target:
                return (entry - target) / (stop - entry)

        return None

    @staticmethod
    def _trailing_exit(direction, stop_level, target, bar) -> Optional[tuple[float, str]]:
        opened = float(bar["open"])
        high = float(bar["high"])
        low = float(bar["low"])

        if direction == "BUY":
            if low <= stop_level:
                return min(opened, stop_level), "STOP"
            if high >= target:
                return target, "TAKE_PROFIT"
        else:
            if high >= stop_level:
                return max(opened, stop_level), "STOP"
            if low <= target:
                return target, "TAKE_PROFIT"
        return None

    def _replay(self, symbol, direction, entry, stop, target, trail, bars, index, close_open_at_end, hold=None):
        risk = entry - stop if direction == "BUY" else stop - entry

        def trade(result_r, exit_index, exit_price, reason):
            return BacktestTrade(
                symbol=symbol, direction=direction, entry=entry, stop_loss=stop, take_profit=target,
                result_r=result_r, entry_index=index, exit_index=exit_index,
                exit_price=exit_price, exit_reason=reason,
            )

        level, extreme = stop, entry

        for exit_index in range(index + 1, len(bars)):
            bar = bars[exit_index]

            if trail is None:
                result = self._trade_result(direction, entry, stop, target, bar)
                if result is not None:
                    stopped = result == -1.0
                    return trade(result, exit_index, stop if stopped else target, "STOP" if stopped else "TAKE_PROFIT")
            else:
                hit = self._trailing_exit(direction, level, target, bar)
                if hit is not None:
                    price, reason = hit
                    result = (price - entry) / risk if direction == "BUY" else (entry - price) / risk
                    return trade(result, exit_index, price, reason)

                if direction == "BUY":
                    extreme = max(extreme, float(bar["high"]))
                    level = max(level, extreme - trail)
                else:
                    extreme = min(extreme, float(bar["low"]))
                    level = min(level, extreme + trail)

            if hold is not None and exit_index - index >= hold:
                price = float(bar["close"])
                result = (price - entry) / risk if direction == "BUY" else (entry - price) / risk
                return trade(result, exit_index, price, "TIME")

        if close_open_at_end and index + 1 < len(bars):
            price = float(bars[-1]["close"])
            result = (price - entry) / risk if direction == "BUY" else (entry - price) / risk
            return trade(result, len(bars) - 1, price, "END_OF_DATA")

        return None

    def run(
        self,
        bars,
        signal_provider: Callable[[list, int], Any],
        symbol: str,
        *,
        close_open_at_end: bool = False,
    ):
        """
        close_open_at_end: close a trade still open after the last bar at that bar's
        close (END_OF_DATA) instead of dropping it. Dropping silently removes the
        longest-held trades - for a trend strategy, often the largest winners.
        """

        trades = []

        bars = list(bars)

        for index in range(len(bars)):
            # ==================================================
            # CRITICAL ANTI-LOOKAHEAD RULE
            # ==================================================
            # The signal provider sees candles ONLY through
            # the current decision candle.
            # ==================================================

            visible_bars = _VisibleBars(bars, index + 1)

            signal = signal_provider(
                visible_bars,
                index,
            )

            if not signal:
                continue

            direction = signal.get(
                "direction",
                "NONE",
            )

            if direction not in {"BUY", "SELL"}:
                continue

            try:
                entry = float(signal["entry"])
                stop = float(signal["stop_loss"])
                target = float(signal["take_profit"])
                trail = signal.get("trailing_stop_distance")
                trail = float(trail) if trail is not None else None
                hold = signal.get("exit_after_bars")
                hold = int(hold) if hold is not None else None
            except (KeyError, TypeError, ValueError):
                continue

            if trail is not None and trail <= 0:
                continue
            if hold is not None and hold < 1:
                continue

            if direction == "BUY":
                if not stop < entry < target:
                    continue

            elif direction == "SELL":
                if not target < entry < stop:
                    continue

            # ==================================================
            # FORWARD REPLAY
            # ==================================================

            trade = self._replay(symbol, direction, entry, stop, target, trail, bars, index, close_open_at_end, hold=hold)
            if trade is not None:
                trades.append(trade)

        return {
            "symbol": symbol,
            "initial_equity": self.initial_equity,
            "risk_percent": self.risk_percent,
            "trades": [
                asdict(trade)
                for trade in trades
            ],
            "r_multiples": [
                trade.result_r
                for trade in trades
            ],
            "broker_calls": 0,
            "live_execution": False,
            "paper_trading": True,
            "lookahead_protected": True,
        }
