# ============================================================
# HAFNOT AI TRADING AGENT
# cTRADER MARKET DATA ENGINE
# ============================================================
#
# Responsibilities:
#
#   cTrader MCP
#        ↓
#   Spot Prices
#        ↓
#   Symbol Details
#        ↓
#   Historical OHLC
#        ↓
#   Data Normalization
#        ↓
#   Data Quality Validation
#        ↓
#   Market Snapshot
#
# IMPORTANT:
#
# This module does NOT manufacture:
#
#   - Tick data
#   - Order-flow data
#   - DOM data
#   - Footprint data
#   - Delta data
#   - Heatmap data
#
# Those are explicitly marked UNAVAILABLE until a real
# data source is connected.
#
# ============================================================

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from app.ctrader.mcp_client import connect


# ============================================================
# CONFIGURATION
# ============================================================

TIMEFRAMES = {
    # Requested historical range in hours.
    #
    # These are intentionally larger than the minimum required
    # for technical analysis so indicators and structure have
    # enough historical context.
    "m5": 72,
    "m15": 72,
    "h1": 240,
    "h4": 960,
    "d1": 7200,
}


# Maximum number of bars allowed by the cTrader MCP tool.
MAX_BARS_PER_REQUEST = 1000


# Maximum acceptable age for the latest candle before the
# timeframe is considered stale.
STALE_MULTIPLIER = 3


# ============================================================
# GENERIC HELPERS
# ============================================================

def _safe_float(value: Any) -> Optional[float]:
    """
    Convert a value to float safely.
    """

    try:
        if value is None:
            return None

        return float(value)

    except (TypeError, ValueError):
        return None


def _safe_int(value: Any) -> Optional[int]:
    """
    Convert a value to int safely.
    """

    try:
        if value is None:
            return None

        return int(value)

    except (TypeError, ValueError):
        return None


def _parse_timestamp(value: Any) -> Optional[datetime]:
    """
    Convert common timestamp representations into a timezone-aware
    UTC datetime.

    Supported examples:

        2026-09-02T12:30:00Z
        2026-09-02T12:30:00+00:00
        Unix seconds
        Unix milliseconds
    """

    if value is None:
        return None

    # --------------------------------------------------------
    # Numeric timestamp
    # --------------------------------------------------------

    if isinstance(value, (int, float)):

        try:
            number = float(value)

            # Milliseconds
            if number > 10_000_000_000:
                return datetime.fromtimestamp(
                    number / 1000.0,
                    tz=timezone.utc,
                )

            # Seconds
            return datetime.fromtimestamp(
                number,
                tz=timezone.utc,
            )

        except (TypeError, ValueError, OverflowError):
            return None

    # --------------------------------------------------------
    # String timestamp
    # --------------------------------------------------------

    text = str(value).strip()

    if not text:
        return None

    # Numeric string
    try:

        number = float(text)

        if number > 10_000_000_000:
            return datetime.fromtimestamp(
                number / 1000.0,
                tz=timezone.utc,
            )

        if number > 1_000_000_000:
            return datetime.fromtimestamp(
                number,
                tz=timezone.utc,
            )

    except ValueError:
        pass

    # ISO format
    try:

        normalized = text.replace(
            "Z",
            "+00:00",
        )

        parsed = datetime.fromisoformat(
            normalized
        )

        if parsed.tzinfo is None:

            parsed = parsed.replace(
                tzinfo=timezone.utc
            )

        return parsed.astimezone(
            timezone.utc
        )

    except ValueError:
        return None


def _timestamp_key(value: Any) -> str:
    """
    Produce a stable timestamp key for duplicate detection.
    """

    parsed = _parse_timestamp(value)

    if parsed is not None:
        return parsed.isoformat()

    return str(value)


# ============================================================
# MCP JSON EXTRACTION
# ============================================================

def _extract_json_content(result) -> List[Any]:
    """
    Extract JSON objects/arrays from MCP text content.

    cTrader MCP responses are returned through content blocks.
    """

    extracted = []

    for content in getattr(
        result,
        "content",
        [],
    ):

        if not hasattr(
            content,
            "text",
        ):
            continue

        text = content.text

        if not text:
            continue

        try:

            extracted.append(
                json.loads(text)
            )

        except json.JSONDecodeError:

            continue

    return extracted


# ============================================================
# BAR EXTRACTION
# ============================================================

def extract_bars(result) -> List[Dict[str, Any]]:
    """
    Extract the bars array from an MCP tool response.

    Supports:

        {"bars": [...]}

    and nested responses where possible.
    """

    payloads = _extract_json_content(
        result
    )

    for data in payloads:

        if isinstance(
            data,
            dict,
        ):

            bars = data.get(
                "bars"
            )

            if isinstance(
                bars,
                list,
            ):

                return bars

            # ------------------------------------------------
            # Nested result
            # ------------------------------------------------

            nested = data.get(
                "result"
            )

            if isinstance(
                nested,
                dict,
            ):

                nested_bars = nested.get(
                    "bars"
                )

                if isinstance(
                    nested_bars,
                    list,
                ):

                    return nested_bars

    return []


# ============================================================
# SPOT EXTRACTION
# ============================================================

def extract_spot(result) -> List[Dict[str, Any]]:
    """
    Extract spot-price records from an MCP response.
    """

    payloads = _extract_json_content(
        result
    )

    records = []

    for data in payloads:

        if isinstance(
            data,
            dict,
        ):

            # Direct spot object
            if (
                "bid" in data
                or "ask" in data
            ):

                records.append(
                    data
                )
                continue

            # Nested result
            nested = data.get(
                "result"
            )

            if isinstance(
                nested,
                dict,
            ):

                if (
                    "bid" in nested
                    or "ask" in nested
                ):

                    records.append(
                        nested
                    )
                    continue

            # Nested spot list
            nested_spot = data.get(
                "spot"
            )

            if isinstance(
                nested_spot,
                list,
            ):

                for item in nested_spot:

                    if isinstance(
                        item,
                        dict,
                    ):

                        records.append(
                            item
                        )

    return records


# ============================================================
# BAR NORMALIZATION
# ============================================================

def normalize_bars(
    bars: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Normalize and validate historical OHLC bars.

    The downstream technical-analysis engine expects the original
    bar dictionaries, so normalized bars retain the original
    fields while adding normalized values where possible.
    """

    normalized = []

    invalid_count = 0
    duplicate_count = 0

    seen_timestamps = set()

    for raw_bar in bars:

        if not isinstance(
            raw_bar,
            dict,
        ):

            invalid_count += 1
            continue

        # ----------------------------------------------------
        # Timestamp
        # ----------------------------------------------------

        timestamp = (
            raw_bar.get("timestamp")
            or raw_bar.get("time")
            or raw_bar.get("date")
        )

        timestamp_key = _timestamp_key(
            timestamp
        )

        if timestamp_key in seen_timestamps:

            duplicate_count += 1
            continue

        seen_timestamps.add(
            timestamp_key
        )

        # ----------------------------------------------------
        # OHLC
        # ----------------------------------------------------

        open_price = _safe_float(
            raw_bar.get("open")
        )

        high_price = _safe_float(
            raw_bar.get("high")
        )

        low_price = _safe_float(
            raw_bar.get("low")
        )

        close_price = _safe_float(
            raw_bar.get("close")
        )

        # ----------------------------------------------------
        # Validate OHLC
        # ----------------------------------------------------

        if any(
            value is None
            for value in (
                open_price,
                high_price,
                low_price,
                close_price,
            )
        ):

            invalid_count += 1
            continue

        if high_price < low_price:

            invalid_count += 1
            continue

        if high_price < max(
            open_price,
            close_price,
        ):

            invalid_count += 1
            continue

        if low_price > min(
            open_price,
            close_price,
        ):

            invalid_count += 1
            continue

        # ----------------------------------------------------
        # Preserve original record
        # ----------------------------------------------------

        bar = dict(
            raw_bar
        )

        bar["open"] = open_price
        bar["high"] = high_price
        bar["low"] = low_price
        bar["close"] = close_price

        normalized.append(
            bar
        )

    # --------------------------------------------------------
    # Chronological ordering
    # --------------------------------------------------------

    normalized.sort(
        key=lambda item: (
            _parse_timestamp(
                item.get(
                    "timestamp",
                    item.get("time"),
                )
            )
            or datetime.min.replace(
                tzinfo=timezone.utc
            )
        )
    )

    return {
        "bars": normalized,
        "raw_count": len(bars),
        "valid_count": len(normalized),
        "invalid_count": invalid_count,
        "duplicate_count": duplicate_count,
    }


# ============================================================
# CANDLE INTERVAL
# ============================================================

def timeframe_delta(
    timeframe: str,
) -> Optional[timedelta]:
    """
    Return the expected candle interval.
    """

    mapping = {
        "m1": timedelta(minutes=1),
        "m5": timedelta(minutes=5),
        "m15": timedelta(minutes=15),
        "m30": timedelta(minutes=30),
        "h1": timedelta(hours=1),
        "h4": timedelta(hours=4),
        "d1": timedelta(days=1),
    }

    return mapping.get(
        timeframe.lower()
    )


# ============================================================
# BAR GAP ANALYSIS
# ============================================================

def analyze_bar_gaps(
    bars: List[Dict[str, Any]],
    timeframe: str,
) -> Dict[str, Any]:
    """
    Detect unusually large gaps between consecutive candles.

    This does NOT automatically mark normal market closures as
    data errors. It simply reports them for downstream awareness.
    """

    expected = timeframe_delta(
        timeframe
    )

    if expected is None:
        return {
            "gap_count": 0,
            "largest_gap_seconds": 0.0,
            "gaps": [],
        }

    timestamps = []

    for bar in bars:

        parsed = _parse_timestamp(
            bar.get(
                "timestamp",
                bar.get("time"),
            )
        )

        if parsed is not None:
            timestamps.append(
                parsed
            )

    timestamps.sort()

    gaps = []
    largest_gap = 0.0

    # A gap larger than 3 expected candles is worth reporting.
    threshold = expected.total_seconds() * 3

    for previous, current in zip(
        timestamps,
        timestamps[1:],
    ):

        seconds = (
            current - previous
        ).total_seconds()

        if seconds > threshold:

            largest_gap = max(
                largest_gap,
                seconds,
            )

            gaps.append(
                {
                    "from": previous.isoformat(),
                    "to": current.isoformat(),
                    "gap_seconds": seconds,
                    "gap_hours": round(
                        seconds / 3600.0,
                        4,
                    ),
                }
            )

    return {
        "gap_count": len(gaps),
        "largest_gap_seconds": round(
            largest_gap,
            2,
        ),
        "gaps": gaps,
    }


# ============================================================
# TIMEFRAME QUALITY
# ============================================================

def assess_timeframe_quality(
    bars: List[Dict[str, Any]],
    timeframe: str,
    requested_start: datetime,
    requested_end: datetime,
    invalid_count: int,
    duplicate_count: int,
    gap_analysis: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Assess the quality and freshness of one timeframe.
    """

    expected = timeframe_delta(
        timeframe
    )

    latest_timestamp = None
    oldest_timestamp = None

    if bars:

        latest_timestamp = _parse_timestamp(
            bars[-1].get(
                "timestamp",
                bars[-1].get("time"),
            )
        )

        oldest_timestamp = _parse_timestamp(
            bars[0].get(
                "timestamp",
                bars[0].get("time"),
            )
        )

    # --------------------------------------------------------
    # Freshness
    # --------------------------------------------------------

    now = datetime.now(
        timezone.utc
    )

    age_seconds = None
    stale = True

    if latest_timestamp is not None:

        age_seconds = max(
            0.0,
            (
                now - latest_timestamp
            ).total_seconds(),
        )

        if expected is not None:

            stale = (
                age_seconds
                > expected.total_seconds()
                * STALE_MULTIPLIER
            )

        else:

            stale = False

    # --------------------------------------------------------
    # Coverage
    # --------------------------------------------------------

    coverage_hours = 0.0

    if (
        oldest_timestamp is not None
        and latest_timestamp is not None
    ):

        coverage_hours = max(
            0.0,
            (
                latest_timestamp
                - oldest_timestamp
            ).total_seconds()
            / 3600.0,
        )

    # --------------------------------------------------------
    # Quality state
    # --------------------------------------------------------

    if not bars:

        quality = "UNAVAILABLE"

    elif invalid_count > 0:

        quality = "DEGRADED"

    elif duplicate_count > 0:

        quality = "DEGRADED"

    elif stale:

        quality = "STALE"

    elif gap_analysis.get(
        "gap_count",
        0,
    ) > 0:

        quality = "GOOD_WITH_GAPS"

    else:

        quality = "GOOD"

    return {
        "quality": quality,
        "bar_count": len(bars),
        "oldest_timestamp": (
            oldest_timestamp.isoformat()
            if oldest_timestamp
            else None
        ),
        "latest_timestamp": (
            latest_timestamp.isoformat()
            if latest_timestamp
            else None
        ),
        "age_seconds": (
            round(
                age_seconds,
                2,
            )
            if age_seconds is not None
            else None
        ),
        "stale": stale,
        "coverage_hours": round(
            coverage_hours,
            4,
        ),
        "requested_start": (
            requested_start.isoformat()
        ),
        "requested_end": (
            requested_end.isoformat()
        ),
        "invalid_count": invalid_count,
        "duplicate_count": duplicate_count,
        "gap_count": gap_analysis.get(
            "gap_count",
            0,
        ),
        "largest_gap_seconds": gap_analysis.get(
            "largest_gap_seconds",
            0.0,
        ),
    }


# ============================================================
# SNAPSHOT DATA CAPABILITIES
# ============================================================

def build_data_capabilities() -> Dict[str, Any]:
    """
    Explicitly describe what the current data layer provides.

    Missing microstructure data is marked unavailable rather than
    inferred from candles.
    """

    return {
        "spot": True,
        "ohlc": True,
        "historical_ohlc": True,
        "symbol_details": True,
        "trading_sessions": True,
        "news": True,

        # ----------------------------------------------------
        # NOT AVAILABLE FROM CURRENT MCP TOOLSET
        # ----------------------------------------------------

        "ticks": False,
        "tick_history": False,
        "market_depth": False,
        "dom": False,
        "order_book": False,
        "footprint": False,
        "delta": False,
        "volume_profile": False,
        "heatmap": False,

        "microstructure_status": (
            "UNAVAILABLE"
        ),

        "microstructure_reason": (
            "The current cTrader MCP toolset does not expose "
            "tick history or market-depth/order-book data."
        ),
    }


# ============================================================
# LIVE SPOT NORMALIZATION
# ============================================================

def normalize_spot(
    spot_records: List[Dict[str, Any]],
    symbol: str,
) -> Dict[str, Any]:
    """
    Normalize the live spot quote.
    """

    if not spot_records:

        raise RuntimeError(
            f"No spot price returned for {symbol}."
        )

    # Prefer a record containing both bid and ask.
    selected = None

    for record in spot_records:

        bid = _safe_float(
            record.get("bid")
        )

        ask = _safe_float(
            record.get("ask")
        )

        if (
            bid is not None
            and ask is not None
        ):

            selected = record
            break

    if selected is None:

        raise RuntimeError(
            f"Unable to normalize live {symbol} spot."
        )

    bid = _safe_float(
        selected.get("bid")
    )

    ask = _safe_float(
        selected.get("ask")
    )

    spread = None

    if (
        bid is not None
        and ask is not None
    ):

        spread = ask - bid

    return {
        "symbol": symbol,
        "bid": bid,
        "ask": ask,
        "spread": spread,
        "high": _safe_float(
            selected.get("high")
        ),
        "low": _safe_float(
            selected.get("low")
        ),
        "open": _safe_float(
            selected.get("open")
        ),
        "raw": selected,
    }


# ============================================================
# MAIN MARKET SNAPSHOT
# ============================================================

async def get_market_snapshot(
    symbol: str = "XAUUSD",
) -> Dict[str, Any]:
    """
    Build the complete current market snapshot.

    Current sources:

        - cTrader MCP spot prices
        - cTrader MCP symbol details
        - cTrader MCP historical trendbars

    The returned structure remains compatible with the current
    main.py while adding data-quality and capability metadata.
    """

    end_time = datetime.now(
        timezone.utc
    )

    capabilities = (
        build_data_capabilities()
    )

    async with connect() as session:

        # ====================================================
        # 1. CURRENT MARKET PRICE
        # ====================================================

        print(
            f"Requesting live {symbol} spot..."
        )

        spot_result = await session.call_tool(
            "get_spot_prices",
            {
                "symbolName": symbol
            }
        )

        spot_records = extract_spot(
            spot_result
        )

        normalized_spot = normalize_spot(
            spot_records,
            symbol,
        )

        # ====================================================
        # 2. SYMBOL DETAILS
        # ====================================================

        print(
            f"Requesting {symbol} symbol details..."
        )

        symbol_details_result = (
            await session.call_tool(
                "get_symbol_details",
                {
                    "symbolName": symbol
                }
            )
        )

        symbol_details_payloads = (
            _extract_json_content(
                symbol_details_result
            )
        )

        symbol_details = None

        for payload in (
            symbol_details_payloads
        ):

            if isinstance(
                payload,
                dict,
            ):

                symbol_details = payload
                break

        # ====================================================
        # 3. SNAPSHOT BASE
        # ====================================================

        snapshot = {
            "symbol": symbol,
            "request_time": end_time.isoformat(),

            # Keep original spot list for compatibility.
            "spot": spot_records,

            # Add normalized spot.
            "normalized_spot": normalized_spot,

            # Add broker symbol information.
            "symbol_details": symbol_details,

            "timeframes": {},

            "data_quality": {
                "overall": "UNKNOWN",
                "timeframes": {},
            },

            "capabilities": capabilities,
        }

        # ====================================================
        # 4. HISTORICAL CANDLES
        # ====================================================

        for timeframe, hours in TIMEFRAMES.items():

            start_time = (
                end_time
                - timedelta(
                    hours=hours
                )
            )

            print(
                f"Requesting {timeframe} data..."
            )

            try:

                result = (
                    await session.call_tool(
                        "get_trendbars",
                        {
                            "symbolName": symbol,
                            "timeframe": timeframe,
                            "from": (
                                start_time.isoformat()
                            ),
                            "to": (
                                end_time.isoformat()
                            ),
                            "limit": (
                                MAX_BARS_PER_REQUEST
                            ),
                        }
                    )
                )

                raw_bars = extract_bars(
                    result
                )

                normalization = normalize_bars(
                    raw_bars
                )

                bars = normalization[
                    "bars"
                ]

                gap_analysis = (
                    analyze_bar_gaps(
                        bars,
                        timeframe,
                    )
                )

                quality = (
                    assess_timeframe_quality(
                        bars=bars,
                        timeframe=timeframe,
                        requested_start=start_time,
                        requested_end=end_time,
                        invalid_count=(
                            normalization[
                                "invalid_count"
                            ]
                        ),
                        duplicate_count=(
                            normalization[
                                "duplicate_count"
                            ]
                        ),
                        gap_analysis=gap_analysis,
                    )
                )

                latest_timestamp = None

                if bars:

                    latest_timestamp = (
                        bars[-1].get(
                            "timestamp",
                            bars[-1].get(
                                "time"
                            ),
                        )
                    )

                snapshot[
                    "timeframes"
                ][timeframe] = {

                    # Existing compatibility fields
                    "bars": bars,
                    "bar_count": len(bars),
                    "latest_timestamp": (
                        latest_timestamp
                    ),

                    # New quality metadata
                    "data_quality": quality,

                    "normalization": {
                        "raw_count": (
                            normalization[
                                "raw_count"
                            ]
                        ),
                        "valid_count": (
                            normalization[
                                "valid_count"
                            ]
                        ),
                        "invalid_count": (
                            normalization[
                                "invalid_count"
                            ]
                        ),
                        "duplicate_count": (
                            normalization[
                                "duplicate_count"
                            ]
                        ),
                    },

                    "gaps": gap_analysis,
                }

                snapshot[
                    "data_quality"
                ][
                    "timeframes"
                ][timeframe] = quality

            except Exception as error:

                print(
                    f"[WARNING] "
                    f"{timeframe} data request failed: "
                    f"{error}"
                )

                snapshot[
                    "timeframes"
                ][timeframe] = {

                    "bars": [],
                    "bar_count": 0,
                    "latest_timestamp": None,

                    "data_quality": {
                        "quality": "UNAVAILABLE",
                        "error": str(error),
                    },

                    "normalization": {
                        "raw_count": 0,
                        "valid_count": 0,
                        "invalid_count": 0,
                        "duplicate_count": 0,
                    },

                    "gaps": {
                        "gap_count": 0,
                        "largest_gap_seconds": 0.0,
                        "gaps": [],
                    },
                }

                snapshot[
                    "data_quality"
                ][
                    "timeframes"
                ][timeframe] = {
                    "quality": "UNAVAILABLE",
                    "error": str(error),
                }

        # ====================================================
        # 5. OVERALL DATA QUALITY
        # ====================================================

        qualities = []

        for timeframe_data in (
            snapshot[
                "data_quality"
            ][
                "timeframes"
            ].values()
        ):

            quality = (
                timeframe_data.get(
                    "quality"
                )
            )

            if quality:
                qualities.append(
                    quality
                )

        if not qualities:

            overall_quality = (
                "UNAVAILABLE"
            )

        elif all(
            quality == "GOOD"
            for quality in qualities
        ):

            overall_quality = "HIGH"

        elif any(
            quality == "UNAVAILABLE"
            for quality in qualities
        ):

            overall_quality = (
                "DEGRADED"
            )

        elif any(
            quality == "STALE"
            for quality in qualities
        ):

            overall_quality = (
                "DEGRADED"
            )

        else:

            overall_quality = "GOOD"

        snapshot[
            "data_quality"
        ][
            "overall"
        ] = overall_quality

        # ====================================================
        # 6. SNAPSHOT SUMMARY
        # ====================================================

        snapshot[
            "summary"
        ] = {

            "symbol": symbol,

            "timeframes_requested": list(
                TIMEFRAMES.keys()
            ),

            "timeframes_available": [
                timeframe
                for timeframe, data
                in snapshot[
                    "timeframes"
                ].items()
                if data.get(
                    "bar_count",
                    0,
                ) > 0
            ],

            "overall_data_quality": (
                overall_quality
            ),

            "spot_available": bool(
                normalized_spot.get(
                    "bid"
                ) is not None
                and normalized_spot.get(
                    "ask"
                ) is not None
            ),

            "microstructure_available": (
                False
            ),

            "order_flow_available": (
                False
            ),

            "depth_available": False,

            "footprint_available": (
                False
            ),

            "heatmap_available": (
                False
            ),
        }

        return snapshot