import json
from dataclasses import dataclass
from typing import Optional, Dict, Any

from app.ctrader.mcp_client import connect
from app.ctrader.symbol_info import get_symbol_spec


# ============================================================
# EXECUTION ADAPTER RESULT
# ============================================================

@dataclass
class BrokerExecutionResult:

    allowed: bool
    executed: bool

    symbol: str
    direction: str

    volume: Optional[float]
    volume_type: str

    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]

    stop_pips: Optional[float]
    target_pips: Optional[float]

    spread: Optional[float]

    reason: str


# ============================================================
# BROKER EXECUTION ADAPTER
# ============================================================

class BrokerExecutionAdapter:

    def __init__(
        self,
        dry_run: bool = True,
        max_spread: float = 5.0,
    ):

        self.dry_run = dry_run
        self.max_spread = max_spread

    # ========================================================
    # INTERNAL SPOT NORMALIZATION
    # ========================================================

    @staticmethod
    def _is_valid_spot(data, symbol):

        if not isinstance(data, dict):
            return False

        if "bid" not in data or "ask" not in data:
            return False

        try:

            bid = float(data["bid"])
            ask = float(data["ask"])

        except (
            TypeError,
            ValueError,
        ):

            return False

        if bid <= 0 or ask <= 0:
            return False

        # If symbol is supplied, validate it when available.
        returned_symbol = (
            data.get("symbolName")
            or data.get("symbol")
            or data.get("name")
        )

        if (
            returned_symbol is not None
            and returned_symbol != symbol
        ):

            return False

        return True

    # ========================================================
    # GET SPOT PRICE
    # ========================================================

    async def get_spot(
        self,
        symbol: str,
    ) -> Dict[str, Any]:

        async with connect() as session:

            # ------------------------------------------------
            # Try the current MCP schema first
            # ------------------------------------------------

            attempts = [
                {
                    "symbolNames": [symbol],
                },
                {
                    "symbolName": symbol,
                },
            ]

            last_error = None

            for arguments in attempts:

                try:

                    result = await session.call_tool(
                        "get_spot_prices",
                        arguments,
                    )

                except Exception as error:

                    last_error = error
                    continue

                # =================================================
                # PARSE MCP CONTENT
                # =================================================

                for content in result.content:

                    if not hasattr(
                        content,
                        "text",
                    ):

                        continue

                    text = content.text

                    if not isinstance(
                        text,
                        str,
                    ):

                        continue

                    text = text.strip()

                    if not text:
                        continue

                    # ------------------------------------------------
                    # JSON response
                    # ------------------------------------------------

                    try:

                        data = json.loads(text)

                    except json.JSONDecodeError:

                        # Some MCP servers may return text
                        # containing JSON. Ignore it safely.
                        continue

                    # =================================================
                    # DIRECT DICTIONARY
                    # =================================================

                    if isinstance(
                        data,
                        dict,
                    ):

                        if self._is_valid_spot(
                            data,
                            symbol,
                        ):

                            return data

                        # ------------------------------------------------
                        # Wrapped dictionary
                        # ------------------------------------------------

                        for key in (
                            "result",
                            "data",
                            "spot",
                            "price",
                            "prices",
                        ):

                            nested = data.get(key)

                            # --------------------------------------------
                            # Nested dictionary
                            # --------------------------------------------

                            if isinstance(
                                nested,
                                dict,
                            ):

                                if self._is_valid_spot(
                                    nested,
                                    symbol,
                                ):

                                    return nested

                                # symbol -> object
                                symbol_data = nested.get(
                                    symbol
                                )

                                if self._is_valid_spot(
                                    symbol_data,
                                    symbol,
                                ):

                                    return symbol_data

                            # --------------------------------------------
                            # Nested list
                            # --------------------------------------------

                            if isinstance(
                                nested,
                                list,
                            ):

                                for item in nested:

                                    if self._is_valid_spot(
                                        item,
                                        symbol,
                                    ):

                                        return item

                        # ------------------------------------------------
                        # Dictionary keyed by symbol
                        # ------------------------------------------------

                        symbol_data = data.get(
                            symbol
                        )

                        if self._is_valid_spot(
                            symbol_data,
                            symbol,
                        ):

                            return symbol_data

                    # =================================================
                    # LIST RESPONSE
                    # =================================================

                    elif isinstance(
                        data,
                        list,
                    ):

                        for item in data:

                            if self._is_valid_spot(
                                item,
                                symbol,
                            ):

                                return item

            if last_error is not None:

                raise RuntimeError(
                    f"Unable to retrieve spot price "
                    f"for {symbol}: {last_error}"
                )

        raise RuntimeError(
            f"No valid spot price returned for {symbol}."
        )

    # ========================================================
    # PRICE -> PIPS
    # ========================================================

    @staticmethod
    def price_distance_to_pips(
        price_distance: float,
        pip_size: float,
    ) -> float:

        if pip_size <= 0:

            raise ValueError(
                "pip_size must be greater than zero."
            )

        return abs(
            price_distance
        ) / pip_size

    # ========================================================
    # VALIDATE SL / TP
    # ========================================================

    @staticmethod
    def calculate_protection_pips(
        direction: str,
        entry_price: float,
        stop_loss: float,
        take_profit: float,
        pip_size: float,
    ):

        direction = direction.upper()

        if direction == "BUY":

            if stop_loss >= entry_price:

                raise ValueError(
                    "BUY stop-loss must be below entry."
                )

            if take_profit <= entry_price:

                raise ValueError(
                    "BUY take-profit must be above entry."
                )

        elif direction == "SELL":

            if stop_loss <= entry_price:

                raise ValueError(
                    "SELL stop-loss must be above entry."
                )

            if take_profit >= entry_price:

                raise ValueError(
                    "SELL take-profit must be below entry."
                )

        else:

            raise ValueError(
                "Direction must be BUY or SELL."
            )

        stop_pips = (
            BrokerExecutionAdapter
            .price_distance_to_pips(
                abs(
                    entry_price
                    - stop_loss
                ),
                pip_size,
            )
        )

        target_pips = (
            BrokerExecutionAdapter
            .price_distance_to_pips(
                abs(
                    take_profit
                    - entry_price
                ),
                pip_size,
            )
        )

        return (
            stop_pips,
            target_pips,
        )

    # ========================================================
    # VOLUME VALIDATION
    # ========================================================

    @staticmethod
    def validate_volume(
        volume: float,
        symbol_spec,
    ):

        if volume <= 0:

            raise ValueError(
                "Volume must be greater than zero."
            )

        if volume < symbol_spec.min_volume:

            raise ValueError(
                f"Volume {volume} is below "
                f"broker minimum {symbol_spec.min_volume}."
            )

        if volume > symbol_spec.max_volume:

            raise ValueError(
                f"Volume {volume} exceeds "
                f"broker maximum {symbol_spec.max_volume}."
            )

        step = symbol_spec.volume_step

        if step <= 0:

            raise ValueError(
                "Broker volume step is invalid."
            )

        # ------------------------------------------------
        # Floating point safe step validation
        # ------------------------------------------------

        quotient = volume / step

        nearest = round(quotient)

        tolerance = 1e-9

        if abs(
            quotient - nearest
        ) > tolerance:

            raise ValueError(
                f"Volume {volume} does not "
                f"follow broker volume step {step}."
            )

        return True

    # ========================================================
    # BUILD ORDER REQUEST
    # ========================================================

    @staticmethod
    def build_market_order_request(
        symbol: str,
        direction: str,
        volume: float,
        stop_pips: float,
        target_pips: float,
    ):

        direction = direction.upper()

        if direction == "BUY":

            side = "BUY"

        elif direction == "SELL":

            side = "SELL"

        else:

            raise ValueError(
                "Invalid order direction."
            )

        return {

            "symbolName": symbol,

            "side": side,

            "volume": volume,

            "volumeType": "UNITS",

            "stopLossPips": stop_pips,

            "takeProfitPips": target_pips,

            "label": "AI_TRADING_AGENT",

            "comment": "AI Trading Agent",
        }

    # ========================================================
    # VALIDATE TRADE PLAN
    # ========================================================

    async def validate_trade_plan(
        self,
        trade_plan,
    ):

        if trade_plan is None:

            return BrokerExecutionResult(
                False,
                False,
                "XAUUSD",
                "NONE",
                None,
                "UNITS",
                None,
                None,
                None,
                None,
                None,
                None,
                "Trade plan is unavailable.",
            )

        # ----------------------------------------------------
        # READY
        # ----------------------------------------------------

        if trade_plan.status != "READY":

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                None,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                "Trade plan is not READY.",
            )

        # ----------------------------------------------------
        # Decision
        # ----------------------------------------------------

        if trade_plan.decision not in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                None,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                "Trade decision is not executable.",
            )

        # ----------------------------------------------------
        # Broker validation
        # ----------------------------------------------------

        if not trade_plan.broker_valid:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                None,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                "Broker validation failed.",
            )

        # ----------------------------------------------------
        # Position size
        # ----------------------------------------------------

        if (
            trade_plan.position_size is None
            or trade_plan.position_size <= 0
        ):

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                None,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                "Invalid position size.",
            )

        # ----------------------------------------------------
        # Prices
        # ----------------------------------------------------

        if (
            trade_plan.entry_price is None
            or trade_plan.stop_loss is None
            or trade_plan.take_profit is None
        ):

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                None,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                "Entry, stop-loss or take-profit is missing.",
            )

        # ====================================================
        # LIVE BROKER INFORMATION
        # ====================================================

        try:

            spec = await get_symbol_spec(
                trade_plan.symbol
            )

            spot = await self.get_spot(
                trade_plan.symbol
            )

        except Exception as error:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                None,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                f"Broker data retrieval failed: {error}",
            )

        # ====================================================
        # VOLUME
        # ====================================================

        try:

            self.validate_volume(
                trade_plan.position_size,
                spec,
            )

        except Exception as error:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                trade_plan.position_size,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                str(error),
            )

        # ====================================================
        # SPREAD
        # ====================================================

        try:

            bid = float(
                spot["bid"]
            )

            ask = float(
                spot["ask"]
            )

        except (
            KeyError,
            TypeError,
            ValueError,
        ):

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                trade_plan.position_size,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                None,
                "Broker spot response contains invalid bid/ask.",
            )

        spread = ask - bid

        if spread < 0:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                trade_plan.position_size,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                spread,
                "Broker returned an invalid negative spread.",
            )

        if spread > self.max_spread:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                trade_plan.position_size,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                spread,
                (
                    f"Spread {spread} exceeds "
                    f"maximum allowed spread "
                    f"{self.max_spread}."
                ),
            )

        # ====================================================
        # SL / TP PIPS
        # ====================================================

        try:

            stop_pips, target_pips = (
                self.calculate_protection_pips(
                    trade_plan.direction,
                    trade_plan.entry_price,
                    trade_plan.stop_loss,
                    trade_plan.take_profit,
                    spec.pip_size,
                )
            )

        except Exception as error:

            return BrokerExecutionResult(
                False,
                False,
                trade_plan.symbol,
                trade_plan.direction,
                trade_plan.position_size,
                "UNITS",
                trade_plan.entry_price,
                trade_plan.stop_loss,
                trade_plan.take_profit,
                None,
                None,
                spread,
                str(error),
            )

        # ====================================================
        # ALL CHECKS PASSED
        # ====================================================

        return BrokerExecutionResult(
            True,
            False,
            trade_plan.symbol,
            trade_plan.direction,
            trade_plan.position_size,
            "UNITS",
            trade_plan.entry_price,
            trade_plan.stop_loss,
            trade_plan.take_profit,
            stop_pips,
            target_pips,
            spread,
            "Broker execution validation passed.",
        )

    # ========================================================
    # EXECUTE
    # ========================================================

    async def execute(
        self,
        trade_plan,
    ):

        validation = await self.validate_trade_plan(
            trade_plan
        )

        if not validation.allowed:

            return validation

        # ====================================================
        # DRY RUN
        # ====================================================

        if self.dry_run:

            return BrokerExecutionResult(
                True,
                False,
                validation.symbol,
                validation.direction,
                validation.volume,
                validation.volume_type,
                validation.entry_price,
                validation.stop_loss,
                validation.take_profit,
                validation.stop_pips,
                validation.target_pips,
                validation.spread,
                (
                    "DRY RUN: broker validation passed. "
                    "No order was placed."
                ),
            )

        # ====================================================
        # LIVE EXECUTION DISABLED
        # ====================================================

        raise RuntimeError(
            "LIVE EXECUTION IS NOT ENABLED."
        )