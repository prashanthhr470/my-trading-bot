import json

from app.ctrader.mcp_client import connect

from app.risk_management import SymbolSpec


async def get_symbol_spec(
    symbol: str = "XAUUSD",
) -> SymbolSpec:

    async with connect() as session:

        result = await session.call_tool(
            "get_symbol_details",
            {
                "symbolName": symbol,
            },
        )

    for content in result.content:

        if not hasattr(content, "text"):
            continue

        data = json.loads(
            content.text
        )

        return SymbolSpec(
            symbol=data["name"],
            digits=float(
                data["digits"]
            ),
            pip_size=float(
                data["pipSize"]
            ),
            lot_size=float(
                data["lotSize"]
            ),
            min_volume=float(
                data["minVolume"]
            ),
            max_volume=float(
                data["maxVolume"]
            ),
            volume_step=float(
                data["volumeStep"]
            ),
        )

    raise RuntimeError(
        f"No symbol details returned for {symbol}."
    )