import asyncio

from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client


MCP_URL = "http://127.0.0.1:9876/mcp/"


async def main():
    print("Connecting to cTrader MCP...")

    async with streamable_http_client(MCP_URL) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:

            await session.initialize()

            print("Connected to cTrader MCP!")
            print("\nRequesting XAUUSD market data...")

            result = await session.call_tool(
                "get_spot_prices",
                {
                    "symbolName": "XAUUSD"
                }
            )

            print("\n===== XAUUSD MARKET DATA =====")

            for content in result.content:
                if hasattr(content, "text"):
                    print(content.text)
                else:
                    print(content)


if __name__ == "__main__":
    asyncio.run(main())