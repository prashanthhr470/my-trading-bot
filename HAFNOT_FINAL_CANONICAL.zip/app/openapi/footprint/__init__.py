﻿# HAFNOT module
