﻿"""
HAFNOT Footprint / Price-Level Engine.

This is a depth-footprint representation.

It does NOT fabricate aggressive buy/sell volume when cTrader
does not provide actual executed trade-side volume.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from collections import defaultdict, deque
from typing import Any
import math
import time


@dataclass
class PriceLevel:
    price: float
    bid_size: float
    ask_size: float
    total_size: float
    imbalance: float


@dataclass
class FootprintSnapshot:
    timestamp: float
    symbol: str
    levels: list[dict[str, Any]]

    total_bid_liquidity: float
    total_ask_liquidity: float
    book_delta_proxy: float
    cumulative_book_delta_proxy: float

    strongest_bid_level: dict[str, Any] | None
    strongest_ask_level: dict[str, Any] | None

    metadata: dict[str, Any]

    def to_dict(self):
        return asdict(self)


class FootprintEngine:

    def __init__(
        self,
        symbol: str = "XAUUSD",
        price_decimals: int = 2,
        max_history: int = 500,
    ):
        self.symbol = symbol
        self.price_decimals = price_decimals
        self.history = deque(maxlen=max_history)
        self.cumulative_delta = 0.0

    def build(
        self,
        bids: list[dict[str, Any]],
        asks: list[dict[str, Any]],
        timestamp: float | None = None,
    ) -> FootprintSnapshot:

        now = timestamp or time.time()

        levels: dict[float, dict[str, float]] = defaultdict(
            lambda: {
                "bid_size": 0.0,
                "ask_size": 0.0,
            }
        )

        for level in bids:
            price = round(
                float(level["price"]),
                self.price_decimals,
            )

            levels[price]["bid_size"] += float(
                level.get("size", 0.0)
            )

        for level in asks:
            price = round(
                float(level["price"]),
                self.price_decimals,
            )

            levels[price]["ask_size"] += float(
                level.get("size", 0.0)
            )

        result = []

        for price, values in sorted(levels.items()):

            bid = values["bid_size"]
            ask = values["ask_size"]

            total = bid + ask

            imbalance = (
                (bid - ask) / total
                if total > 0
                else 0.0
            )

            result.append(
                PriceLevel(
                    price=price,
                    bid_size=bid,
                    ask_size=ask,
                    total_size=total,
                    imbalance=imbalance,
                ).__dict__
            )

        total_bid = sum(
            x["bid_size"] for x in result
        )

        total_ask = sum(
            x["ask_size"] for x in result
        )

        book_delta = total_bid - total_ask

        self.cumulative_delta += book_delta

        strongest_bid = max(
            (
                x for x in result
                if x["bid_size"] > 0
            ),
            key=lambda x: x["bid_size"],
            default=None,
        )

        strongest_ask = max(
            (
                x for x in result
                if x["ask_size"] > 0
            ),
            key=lambda x: x["ask_size"],
            default=None,
        )

        snapshot = FootprintSnapshot(
            timestamp=now,
            symbol=self.symbol,
            levels=result,

            total_bid_liquidity=total_bid,
            total_ask_liquidity=total_ask,

            book_delta_proxy=book_delta,
            cumulative_book_delta_proxy=self.cumulative_delta,

            strongest_bid_level=strongest_bid,
            strongest_ask_level=strongest_ask,

            metadata={
                "type": "DEPTH_FOOTPRINT",
                "actual_trade_delta_available": False,
                "delta_is_book_liquidity_proxy": True,
            },
        )

        self.history.append(snapshot)

        return snapshot
