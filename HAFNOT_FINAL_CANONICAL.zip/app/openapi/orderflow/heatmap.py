from __future__ import annotations

from collections import deque
from typing import Any


class LiquidityHeatmap:
    """
    Time-series liquidity map.

    Each snapshot represents the actual observed depth book at that
    moment. It does not fabricate liquidity between observations.
    """

    def __init__(
        self,
        symbol: str,
        max_snapshots: int = 5000,
    ):
        self.symbol = symbol
        self.snapshots = deque(
            maxlen=max_snapshots
        )

    def ingest(
        self,
        snapshot: dict[str, Any],
    ) -> None:

        self.snapshots.append({
            "symbol": self.symbol,
            "timestamp": snapshot.get(
                "last_update"
            ),
            "bids": snapshot.get(
                "bids", []
            ),
            "asks": snapshot.get(
                "asks", []
            ),
        })

    def build(self) -> dict[str, Any]:

        return {
            "symbol": self.symbol,
            "snapshots": list(
                self.snapshots
            ),
            "snapshot_count": len(
                self.snapshots
            ),
            "available": bool(
                self.snapshots
            ),
        }
