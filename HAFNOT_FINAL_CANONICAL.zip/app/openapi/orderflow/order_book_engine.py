from __future__ import annotations

from typing import Any, Dict, Iterable, Mapping, Optional
from datetime import datetime, timezone


class OrderBookSnapshot(dict):
    """
    Dictionary-compatible Level-II snapshot.

    Supports:
        snapshot["best_bid"]
        snapshot.best_bid

    This represents resting cTrader Level-II liquidity.
    It is NOT executed trade delta.
    """

    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def to_dict(self) -> dict:
        return dict(self)


class OrderBookEngine:
    """
    Incremental cTrader Level-II order-book reconstruction.

    Canonical event contract:

        {
            "newQuotes": [
                {
                    "id": int,
                    "side": "BID" | "ASK",
                    "price": float,
                    "size": float
                }
            ],
            "deletedQuotes": [quote_id, ...]
        }

    Quote IDs are authoritative.

    This engine reconstructs RESTING Level-II liquidity.
    It does not create executed-volume delta.
    """

    def __init__(
        self,
        symbol: str = "XAUUSD",
        max_levels: int = 100,
        tick_size: Optional[float] = None,
        history_limit: int = 5000,
    ) -> None:

        self.symbol = symbol
        self.max_levels = max_levels
        self.tick_size = tick_size
        self.history_limit = max(1, int(history_limit))

        # quote_id -> normalized quote
        self.quotes: Dict[int, Dict[str, Any]] = {}

        # price -> aggregated resting size
        self.bids: Dict[float, float] = {}
        self.asks: Dict[float, float] = {}

        self.previous_snapshot: Optional[OrderBookSnapshot] = None

        # Public history expected by validator/intelligence layer.
        self.history: list[OrderBookSnapshot] = []

    # ========================================================
    # NORMALIZATION
    # ========================================================

    @staticmethod
    def _float(value: Any, default: float = 0.0) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _int(value: Any) -> Optional[int]:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _side(quote: Mapping[str, Any]) -> Optional[str]:

        side = quote.get("side")

        if side is not None:
            side = str(side).upper()

            if side in {"BID", "BUY"}:
                return "BID"

            if side in {"ASK", "SELL"}:
                return "ASK"

        if quote.get("bid") is not None:
            return "BID"

        if quote.get("ask") is not None:
            return "ASK"

        return None

    @classmethod
    def _quote_fields(
        cls,
        quote: Mapping[str, Any],
    ) -> Optional[Dict[str, Any]]:

        quote_id = cls._int(
            quote.get(
                "id",
                quote.get("quote_id"),
            )
        )

        if quote_id is None:
            return None

        side = cls._side(quote)

        if side is None:
            return None

        if quote.get("price") is not None:
            price = cls._float(quote.get("price"))
        elif side == "BID":
            price = cls._float(quote.get("bid"))
        else:
            price = cls._float(quote.get("ask"))

        size = cls._float(
            quote.get(
                "size",
                quote.get("volume", 0.0),
            )
        )

        if price <= 0 or size < 0:
            return None

        return {
            "id": quote_id,
            "side": side,
            "price": price,
            "size": size,
        }

    # ========================================================
    # LEVEL MANAGEMENT
    # ========================================================

    def _add_level(
        self,
        side: str,
        price: float,
        size: float,
    ) -> None:

        book = self.bids if side == "BID" else self.asks

        book[price] = book.get(price, 0.0) + size

        if book[price] <= 1e-12:
            book.pop(price, None)

    def _remove_level(
        self,
        side: str,
        price: float,
        size: float,
    ) -> None:

        book = self.bids if side == "BID" else self.asks

        current = book.get(price, 0.0)
        remaining = current - size

        if remaining <= 1e-12:
            book.pop(price, None)
        else:
            book[price] = remaining

    # ========================================================
    # QUOTE LIFECYCLE
    # ========================================================

    def _delete_quote(self, quote_id: Any) -> None:

        qid = self._int(quote_id)

        if qid is None:
            return

        previous = self.quotes.pop(qid, None)

        if previous is None:
            return

        self._remove_level(
            previous["side"],
            previous["price"],
            previous["size"],
        )

    def _upsert_quote(
        self,
        quote: Mapping[str, Any],
    ) -> None:

        normalized = self._quote_fields(quote)

        if normalized is None:
            return

        qid = normalized["id"]

        previous = self.quotes.get(qid)

        if previous is not None:

            self._remove_level(
                previous["side"],
                previous["price"],
                previous["size"],
            )

        self.quotes[qid] = normalized

        self._add_level(
            normalized["side"],
            normalized["price"],
            normalized["size"],
        )

    # ========================================================
    # CROSSED BOOK SAFETY
    # ========================================================

    def _sanitize_crossed_book(self) -> None:

        if not self.bids or not self.asks:
            return

        for _ in range(10000):

            if not self.bids or not self.asks:
                return

            best_bid = max(self.bids)
            best_ask = min(self.asks)

            if best_bid < best_ask:
                return

            crossed_bid_prices = [
                price
                for price in self.bids
                if price >= best_ask
            ]

            crossed_ask_prices = [
                price
                for price in self.asks
                if price <= best_bid
            ]

            if not crossed_bid_prices and not crossed_ask_prices:
                return

            for price in crossed_bid_prices:

                for qid, quote in list(self.quotes.items()):

                    if (
                        quote["side"] == "BID"
                        and quote["price"] == price
                    ):
                        self.quotes.pop(qid, None)

                self.bids.pop(price, None)

            for price in crossed_ask_prices:

                for qid, quote in list(self.quotes.items()):

                    if (
                        quote["side"] == "ASK"
                        and quote["price"] == price
                    ):
                        self.quotes.pop(qid, None)

                self.asks.pop(price, None)

        raise RuntimeError(
            "Crossed-book cleanup exceeded safety limit."
        )

    # ========================================================
    # METRICS
    # ========================================================

    @staticmethod
    def _depth(
        book: Mapping[float, float],
    ) -> float:

        return float(sum(book.values()))

    def _top_levels(
        self,
        book: Mapping[float, float],
        reverse: bool,
    ) -> list[tuple[float, float]]:

        return sorted(
            book.items(),
            key=lambda x: x[0],
            reverse=reverse,
        )[: self.max_levels]

    @staticmethod
    def _weighted_imbalance(
        bid_levels: Iterable[tuple[float, float]],
        ask_levels: Iterable[tuple[float, float]],
    ) -> float:

        bid_score = 0.0
        ask_score = 0.0

        for index, (_, size) in enumerate(bid_levels):
            bid_score += size / (index + 1)

        for index, (_, size) in enumerate(ask_levels):
            ask_score += size / (index + 1)

        total = bid_score + ask_score

        if total <= 0:
            return 0.0

        return (bid_score - ask_score) / total

    # ========================================================
    # SNAPSHOT
    # ========================================================

    def snapshot(
        self,
        timestamp: Optional[float] = None,
    ) -> OrderBookSnapshot:

        self._sanitize_crossed_book()

        best_bid = max(self.bids) if self.bids else None
        best_ask = min(self.asks) if self.asks else None

        if (
            best_bid is not None
            and best_ask is not None
            and best_bid >= best_ask
        ):
            best_bid = None
            best_ask = None

        spread = (
            best_ask - best_bid
            if best_bid is not None
            and best_ask is not None
            else None
        )

        total_bid_depth = self._depth(self.bids)
        total_ask_depth = self._depth(self.asks)
        total_depth = total_bid_depth + total_ask_depth

        if total_depth > 0:
            raw_imbalance = (
                total_bid_depth - total_ask_depth
            ) / total_depth
        else:
            raw_imbalance = 0.0

        bid_levels = self._top_levels(
            self.bids,
            reverse=True,
        )

        ask_levels = self._top_levels(
            self.asks,
            reverse=False,
        )

        weighted_imbalance = self._weighted_imbalance(
            bid_levels,
            ask_levels,
        )

        book_pressure = (
            0.5 * raw_imbalance
            + 0.5 * weighted_imbalance
        )

        previous = self.previous_snapshot

        if previous is None:
            previous_pressure = book_pressure
            previous_bid_depth = total_bid_depth
            previous_ask_depth = total_ask_depth
        else:
            previous_pressure = float(
                previous.get("book_pressure", 0.0)
            )
            previous_bid_depth = float(
                previous.get("bid_depth", 0.0)
            )
            previous_ask_depth = float(
                previous.get("ask_depth", 0.0)
            )

        short_term_book_momentum = (
            book_pressure - previous_pressure
        )

        bid_change = (
            total_bid_depth - previous_bid_depth
        )

        ask_change = (
            total_ask_depth - previous_ask_depth
        )

        # Resting-liquidity stacking/pulling proxies.
        stacking_score = (
            max(bid_change, 0.0)
            if previous is not None
            else 0.0
        )

        pulling_score = (
            max(-ask_change, 0.0)
            if previous is not None
            else 0.0
        )

        liquidity_migration = (
            bid_change - ask_change
            if previous is not None
            else 0.0
        )

        if total_depth > 0:
            absorption_proxy = min(
                1.0,
                abs(short_term_book_momentum)
                / max(total_depth, 1.0)
                * 100.0,
            )
        else:
            absorption_proxy = 0.0

        if total_depth > 0:
            exhaustion_proxy = min(
                1.0,
                1.0 / max(total_depth, 1.0),
            )
        else:
            exhaustion_proxy = 0.0

        confidence = 1.0

        if best_bid is None or best_ask is None:
            confidence = 0.0

        if spread is None or spread <= 0:
            confidence = 0.0

        if total_bid_depth <= 0 or total_ask_depth <= 0:
            confidence = 0.0

        if len(self.quotes) < 2:
            confidence = min(confidence, 0.5)

        # Canonical level representation for downstream engines.
        bid_level_records = [
            {
                "price": float(price),
                "size": float(size),
            }
            for price, size in bid_levels
        ]

        ask_level_records = [
            {
                "price": float(price),
                "size": float(size),
            }
            for price, size in ask_levels
        ]

        if timestamp is None:
            timestamp = datetime.now(
                timezone.utc
            ).timestamp()

        result = OrderBookSnapshot(
            {
                "symbol": self.symbol,
                "timestamp": float(timestamp),

                "best_bid": best_bid,
                "best_ask": best_ask,
                "spread": spread,

                "bid_depth": total_bid_depth,
                "ask_depth": total_ask_depth,

                "total_bid_depth": total_bid_depth,
                "total_ask_depth": total_ask_depth,

                "imbalance": raw_imbalance,
                "raw_imbalance": raw_imbalance,

                "weighted_imbalance":
                    weighted_imbalance,

                "book_pressure":
                    book_pressure,

                "short_term_book_momentum":
                    short_term_book_momentum,

                "stacking":
                    stacking_score,

                "stacking_score":
                    stacking_score,

                "pulling":
                    pulling_score,

                "pulling_score":
                    pulling_score,

                "liquidity_migration":
                    liquidity_migration,

                "absorption_proxy":
                    absorption_proxy,

                "exhaustion_proxy":
                    exhaustion_proxy,

                "confidence":
                    confidence,

                "quote_count":
                    len(self.quotes),

                "bid_levels":
                    bid_level_records,

                "ask_levels":
                    ask_level_records,

                "observed_data":
                    {
                        "bid_levels":
                            bid_level_records,
                        "ask_levels":
                            ask_level_records,
                        "quote_count":
                            len(self.quotes),
                        "best_bid":
                            best_bid,
                        "best_ask":
                            best_ask,
                        "spread":
                            spread,
                    },

                "data_type":
                    "resting_level_ii_liquidity",

                "trade_delta_available":
                    False,

                "true_trade_absorption_available":
                    False,

                "true_footprint_delta_available":
                    False,
            }
        )

        self.previous_snapshot = result

        self.history.append(result)

        if len(self.history) > self.history_limit:
            del self.history[
                :len(self.history) - self.history_limit
            ]

        return result

    # ========================================================
    # PUBLIC PROCESS API
    # ========================================================

    def process(
        self,
        event: Optional[Mapping[str, Any]] = None,
        timestamp: Optional[float] = None,
    ) -> OrderBookSnapshot:

        if event is None:
            return self.snapshot(timestamp=timestamp)

        deleted = event.get(
            "deletedQuotes",
            event.get("deleted", []),
        )

        if deleted is None:
            deleted = []

        if isinstance(deleted, Mapping):
            deleted = list(deleted.values())

        # Deletes first.
        for quote_id in deleted:

            if isinstance(quote_id, Mapping):
                quote_id = quote_id.get(
                    "id",
                    quote_id.get("quote_id"),
                )

            self._delete_quote(quote_id)

        new_quotes = event.get(
            "newQuotes",
            event.get("new_quotes", []),
        )

        if new_quotes is None:
            new_quotes = []

        if isinstance(new_quotes, Mapping):
            new_quotes = list(new_quotes.values())

        # Updates/additions second.
        for quote in new_quotes:

            if not isinstance(quote, Mapping):
                continue

            self._upsert_quote(quote)

        return self.snapshot(timestamp=timestamp)

    def process_event(
        self,
        event: Optional[Mapping[str, Any]] = None,
        timestamp: Optional[float] = None,
    ) -> OrderBookSnapshot:

        return self.process(
            event,
            timestamp=timestamp,
        )

    # ========================================================
    # RESET
    # ========================================================

    def reset(self) -> None:

        self.quotes.clear()
        self.bids.clear()
        self.asks.clear()

        self.previous_snapshot = None
        self.history.clear()
