from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any


@dataclass
class FootprintRow:
    price: float
    bid_volume: float
    ask_volume: float
    total_volume: float
    imbalance: float


class FootprintAggregator:
    """
    Footprint data model.

    This stores bid/ask depth liquidity by price.

    It deliberately distinguishes DEPTH liquidity from executed
    aggressor volume. A true trade-print footprint requires a
    suitable executed-tick/trade stream.
    """

    def __init__(self):
        self.rows = defaultdict(
            lambda: {
                "bid": 0.0,
                "ask": 0.0,
            }
        )

    def ingest_snapshot(
        self,
        snapshot: dict[str, Any],
    ) -> None:

        for level in snapshot.get("bids", []):
            price = float(level["price"])
            self.rows[price]["bid"] += float(
                level["size"]
            )

        for level in snapshot.get("asks", []):
            price = float(level["price"])
            self.rows[price]["ask"] += float(
                level["size"]
            )

    def build(self) -> list[dict[str, Any]]:

        output = []

        for price in sorted(self.rows):

            bid = self.rows[price]["bid"]
            ask = self.rows[price]["ask"]

            total = bid + ask

            imbalance = (
                (ask - bid) / total
                if total
                else 0.0
            )

            output.append({
                "price": price,
                "bid_volume": bid,
                "ask_volume": ask,
                "total_volume": total,
                "imbalance": imbalance,
                "source": "DEPTH",
                "executed_trade_volume": False,
            })

        return output
