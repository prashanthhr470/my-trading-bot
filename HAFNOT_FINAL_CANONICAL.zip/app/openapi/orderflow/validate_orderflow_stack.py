
from __future__ import annotations

import json
import os

from app.openapi.orderflow.depth_event_decoder import (
    decode,
    inspect,
)

from app.openapi.orderflow.hafnot_orderflow_intelligence import (
    HAFNOTOrderFlowIntelligence,
)


EVENT_FILE = (
    "data/openapi/xauusd_market_events.jsonl"
)




def _safe_observed_data(value):
    """
    Normalize intelligence result representations.

    Supports:
      - dictionary results
      - objects exposing observed_data
      - objects exposing data
      - raw values
    """

    if isinstance(value, dict):
        if "observed_data" in value:
            return value.get("observed_data")
        if "data" in value:
            return value.get("data")
        return value

    observed = getattr(value, "observed_data", None)

    if observed is not None:
        return observed

    data = getattr(value, "data", None)

    if data is not None:
        return data

    return value

def main():

    print("")
    print("=" * 70)
    print("HAFNOT ORDER FLOW - COMPLETE NATIVE LEVEL II REPLAY")
    print("=" * 70)

    if not os.path.exists(EVENT_FILE):

        print(
            "[FAIL] Event file not found:",
            EVENT_FILE
        )

        return 1

    engine = (
        HAFNOTOrderFlowIntelligence(
            symbol="XAUUSD"
        )
    )

    raw_records = 0
    decoded_events = 0
    decoded_quotes = 0
    decoded_bids = 0
    decoded_asks = 0
    deleted_quotes = 0
    skipped = 0
    failures = 0

    first_usable = None
    last_result = None

    with open(
        EVENT_FILE,
        "r",
        encoding="utf-8"
    ) as fh:

        for line_no, line in enumerate(
            fh,
            start=1
        ):

            line = line.strip()

            if not line:
                continue

            raw_records += 1

            try:

                raw = json.loads(
                    line
                )

            except Exception as exc:

                failures += 1

                print(
                    "[ERROR] JSON:",
                    line_no,
                    exc
                )

                continue

            event = decode(
                raw
            )

            if event is None:

                skipped += 1
                continue

            info = inspect(
                raw
            )

            decoded_events += 1

            decoded_quotes += len(info["quotes"])

            decoded_bids += len(info["bid_quotes"])

            decoded_asks += len(info["ask_quotes"])

            deleted_quotes += len(
                info["deletedQuotes"]
            )

            try:

                result = (
                    engine.process(
                        event
                    )
                )

                last_result = result

                book = result[
                    "order_book"
                ]

                signal = result[
                    "signal"
                ]

                usable = (
                    book.get(
                        "best_bid"
                    ) is not None
                    or
                    book.get(
                        "best_ask"
                    ) is not None
                    or
                    float(
                        book.get(
                            "total_bid_depth",
                            0
                        ) or 0
                    ) > 0
                    or
                    float(
                        book.get(
                            "total_ask_depth",
                            0
                        ) or 0
                    ) > 0
                )

                if usable and first_usable is None:

                    first_usable = result

                if decoded_events <= 5:

                    print("")
                    print(
                        f"DEPTH EVENT #{decoded_events}"
                    )

                    print(
                        "  Quotes     :",
                        info["quotes"]
                    )

                    print(
                        "  Bids       :",
                        info["bid_quotes"]
                    )

                    print(
                        "  Asks       :",
                        info["ask_quotes"]
                    )

                    print(
                        "  Best Bid   :",
                        book.get(
                            "best_bid"
                        )
                    )

                    print(
                        "  Best Ask   :",
                        book.get(
                            "best_ask"
                        )
                    )

                    print(
                        "  Spread     :",
                        book.get(
                            "spread"
                        )
                    )

                    print(
                        "  Bid Depth  :",
                        book.get(
                            "total_bid_depth"
                        )
                    )

                    print(
                        "  Ask Depth  :",
                        book.get(
                            "total_ask_depth"
                        )
                    )

                    print(
                        "  Imbalance  :",
                        book.get(
                            "weighted_imbalance"
                        )
                    )

                    print(
                        "  Pressure   :",
                        book.get(
                            "book_pressure"
                        )
                    )

                    print(
                        "  Signal     :",
                        signal.get(
                            "direction"
                        )
                    )

                    print(
                        "  Confidence :",
                        signal.get(
                            "confidence"
                        )
                    )

            except Exception as exc:

                failures += 1

                print(
                    "[ERROR] Processing line",
                    line_no,
                    type(exc).__name__,
                    exc
                )

    snapshots = len(
        engine.orderbook.history
    )

    heatmap_samples = len(
        getattr(
            engine.heatmap,
            "samples",
            []
        )
    )

    heatmap_levels = 0

    levels = getattr(
        engine.heatmap,
        "levels",
        None
    )

    if levels is not None:

        try:
            heatmap_levels = len(
                levels
            )
        except Exception:
            pass

    print("")
    print("=" * 70)
    print("RAW DATA DECODING")
    print("=" * 70)

    print(
        "Raw records        :",
        raw_records
    )

    print(
        "Decoded events     :",
        decoded_events
    )

    print(
        "Decoded quotes     :",
        decoded_quotes
    )

    print(
        "Decoded bids       :",
        decoded_bids
    )

    print(
        "Decoded asks       :",
        decoded_asks
    )

    print(
        "Deleted quotes     :",
        deleted_quotes
    )

    print(
        "Skipped            :",
        skipped
    )

    print(
        "Failures           :",
        failures
    )

    print("")
    print("=" * 70)
    print("INTELLIGENCE STACK")
    print("=" * 70)

    print(
        "Book snapshots     :",
        snapshots
    )

    print(
        "Heatmap samples    :",
        heatmap_samples
    )

    print(
        "Heatmap levels     :",
        heatmap_levels
    )

    print("")
    print("=" * 70)
    print("SAFETY")
    print("=" * 70)

    print(
        "DRY RUN        : TRUE"
    )

    print(
        "PAPER TRADING  : TRUE"
    )

    print(
        "LIVE EXECUTION : FALSE"
    )

    print(
        "BROKER ORDERS  : 0"
    )

    print(
        "AI DIRECT EXEC : FALSE"
    )

    print("")
    print("=" * 70)
    print("VERDICT")
    print("=" * 70)

    usable = (
        first_usable is not None
    )

    # --------------------------------------------------------
    # HARD DATA-QUALITY CHECKS
    # --------------------------------------------------------

    crossed_snapshots = 0
    valid_spreads = 0
    nonzero_bid_depth = 0
    nonzero_ask_depth = 0

    for snapshot in engine.orderbook.history:

        if snapshot.get(
            "crossed_book",
            False
        ):
            crossed_snapshots += 1

        if snapshot.get(
            "spread"
        ) is not None:

            valid_spreads += 1

        if float(
            snapshot.get(
                "total_bid_depth",
                0
            ) or 0
        ) > 0:

            nonzero_bid_depth += 1

        if float(
            snapshot.get(
                "total_ask_depth",
                0
            ) or 0
        ) > 0:

            nonzero_ask_depth += 1

    print("")
    print("=" * 70)
    print("ORDER BOOK DATA QUALITY")
    print("=" * 70)

    print(
        "Crossed snapshots  :",
        crossed_snapshots
    )

    print(
        "Valid spreads      :",
        valid_spreads
    )

    print(
        "Bid-depth snapshots:",
        nonzero_bid_depth
    )

    print(
        "Ask-depth snapshots:",
        nonzero_ask_depth
    )

    clean_book = (
        crossed_snapshots == 0
        and nonzero_bid_depth > 0
        and nonzero_ask_depth > 0
    )

    if (
        decoded_events > 0
        and decoded_quotes > 0
        and (
            decoded_bids > 0
            or decoded_asks > 0
        )
        and snapshots > 0
        and failures == 0
        and usable
        and clean_book
    ):

        print("")
        print(
            "[PASS] NATIVE cTRADER LEVEL II "
            "DATA RECONSTRUCTED"
        )

        if last_result:

            signal = last_result[
                "signal"
            ]

            print("")
            print(
                "FINAL ORDER-FLOW SIGNAL"
            )

            print(
                "  Direction :",
                signal.get(
                    "direction"
                )
            )

            print(
                "  Score     :",
                signal.get(
                    "score"
                )
            )

            print(
                "  Confidence:",
                signal.get(
                    "confidence"
                )
            )

        print("")
        print(
            "[PASS] HAFNOT ORDER-FLOW "
            "INTELLIGENCE PIPELINE"
        )

        print("")
        print(
            "LIVE EXECUTION = FALSE"
        )

        print(
            "BROKER ORDERS   = 0"
        )

        return 0

    print("")
    print(
        "[FAIL] Native Level II reconstruction "
        "is not yet usable."
    )

    print("")
    print(
        "The decoder statistics above identify "
        "the exact failing layer."
    )

    return 1


if __name__ == "__main__":
    raise SystemExit(
        main()
    )

