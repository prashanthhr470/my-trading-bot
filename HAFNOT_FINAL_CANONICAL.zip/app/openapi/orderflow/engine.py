from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


@dataclass
class FlowEvent:
    timestamp: str
    price: float
    size: float
    side: str
    source: str = "DEPTH"


class OrderFlowEngine:
    """
    Deterministic order-flow state.

    Important:
    cTrader depth events describe changes to the depth book.
    They are NOT automatically equivalent to exchange-traded
    aggressive buy/sell trade prints.

    Therefore this engine never labels inferred depth changes as
    actual executed market orders unless a valid trade-print source
    is supplied.
    """

    def __init__(self, symbol: str, max_events: int = 10000):
        self.symbol = symbol
        self.events = deque(maxlen=max_events)
        self.volume_by_price = defaultdict(float)
        self.bid_volume = 0.0
        self.ask_volume = 0.0

    def ingest_depth_snapshot(
        self,
        snapshot: dict[str, Any],
    ) -> None:

        timestamp = (
            snapshot.get("last_update")
            or datetime.now(
                timezone.utc
            ).isoformat()
        )

        for level in snapshot.get("bids", []):
            size = float(level["size"])
            price = float(level["price"])

            self.bid_volume += size
            self.volume_by_price[
                price
            ] += size

            self.events.append(
                FlowEvent(
                    timestamp=timestamp,
                    price=price,
                    size=size,
                    side="BID",
                )
            )

        for level in snapshot.get("asks", []):
            size = float(level["size"])
            price = float(level["price"])

            self.ask_volume += size
            self.volume_by_price[
                price
            ] += size

            self.events.append(
                FlowEvent(
                    timestamp=timestamp,
                    price=price,
                    size=size,
                    side="ASK",
                )
            )

    def summary(self) -> dict[str, Any]:

        total = (
            self.bid_volume
            + self.ask_volume
        )

        imbalance = (
            (self.bid_volume - self.ask_volume) / total
            if total
            else 0.0
        )

        return {
            "symbol": self.symbol,
            "events": len(self.events),
            "bid_volume": self.bid_volume,
            "ask_volume": self.ask_volume,
            "total_volume": total,
            "imbalance": imbalance,
            "volume_by_price": dict(
                self.volume_by_price
            ),
            "executed_trade_classification": False,
            "depth_based": True,
        }
