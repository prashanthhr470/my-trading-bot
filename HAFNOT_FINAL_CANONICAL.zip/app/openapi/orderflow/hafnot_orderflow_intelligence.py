"""
Unified HAFNOT Native Order Flow Intelligence.

Pipeline:

cTrader Level II
       ↓
OrderBookEngine
       ↓
FootprintEngine
       ↓
HeatmapEngine
       ↓
OrderFlowSignalEngine
       ↓
Evidence package

No execution.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import os
import time
from typing import Any

from app.openapi.orderflow.order_book_engine import (
    OrderBookEngine,
)

from app.openapi.footprint.footprint_engine import (
    FootprintEngine,
)

from app.openapi.heatmap.heatmap_engine import (
    HeatmapEngine,
)

from app.openapi.signals.orderflow_signal_engine import (
    OrderFlowSignalEngine,
)


class HAFNOTOrderFlowIntelligence:

    def __init__(
        self,
        symbol: str = "XAUUSD",
        output_dir: str = "data/openapi/orderflow",
    ):

        self.symbol = symbol
        self.output_dir = output_dir

        os.makedirs(
            output_dir,
            exist_ok=True,
        )

        self.orderbook = OrderBookEngine(
            symbol=symbol
        )

        self.footprint = FootprintEngine(
            symbol=symbol
        )

        self.heatmap = HeatmapEngine(
            symbol=symbol
        )

        self.signal_engine = (
            OrderFlowSignalEngine()
        )

        self.events_path = os.path.join(
            output_dir,
            "orderflow_intelligence.jsonl",
        )

    # ========================================================
    # TIMESTAMP NORMALIZATION
    # ========================================================

    @staticmethod
    def _timestamp(value: Any) -> float:

        if value is None:
            return time.time()

        if isinstance(value, (int, float)):
            return float(value)

        text = str(value).strip()

        if not text:
            return time.time()

        try:
            return float(text)
        except ValueError:
            pass

        normalized = text.replace(
            "Z",
            "+00:00",
        )

        try:
            dt = datetime.fromisoformat(
                normalized
            )

            if dt.tzinfo is None:
                dt = dt.replace(
                    tzinfo=timezone.utc
                )

            return dt.timestamp()

        except ValueError as exc:
            raise ValueError(
                f"Unsupported event timestamp: {value!r}"
            ) from exc

    # ========================================================
    # PROCESS
    # ========================================================

    def process(
        self,
        event: dict,
    ) -> dict:

        timestamp = self._timestamp(
            event.get(
                "timestamp",
                time.time(),
            )
        )

        orderbook_snapshot = (
            self.orderbook.process_event(
                event,
                timestamp=timestamp,
            )
        )

        observed = orderbook_snapshot.get(
            "observed_data",
            {},
        )

        bids = observed.get(
            "bid_levels",
            orderbook_snapshot.get(
                "bid_levels",
                [],
            ),
        )

        asks = observed.get(
            "ask_levels",
            orderbook_snapshot.get(
                "ask_levels",
                [],
            ),
        )

        footprint_snapshot = (
            self.footprint.build(
                bids=bids,
                asks=asks,
                timestamp=timestamp,
            )
        )

        heatmap_snapshot = (
            self.heatmap.update(
                bids=bids,
                asks=asks,
                timestamp=timestamp,
            )
        )

        signal = self.signal_engine.evaluate(
            orderbook=orderbook_snapshot,
            footprint=footprint_snapshot,
            heatmap=heatmap_snapshot,
        )

        result = {
            "timestamp": timestamp,
            "symbol": self.symbol,

            "order_book":
                orderbook_snapshot.to_dict(),

            "footprint":
                footprint_snapshot.to_dict(),

            "heatmap":
                heatmap_snapshot.to_dict(),

            "signal":
                signal.to_dict(),

            "safety": {
                "dry_run": True,
                "paper_trading": True,
                "live_execution": False,
                "broker_orders": 0,
                "ai_direct_execution": False,
            },

            "data_quality": {
                "native_ctrader_depth": True,
                "executed_trade_volume": False,
                "true_exchange_delta": False,
                "depth_footprint_proxy": True,
                "absorption_proxy": True,
            },
        }

        with open(
            self.events_path,
            "a",
            encoding="utf-8",
        ) as f:

            f.write(
                json.dumps(
                    result,
                    separators=(",", ":"),
                )
                + "\n"
            )

        return result

    # ========================================================
    # STATUS
    # ========================================================

    def status(self) -> dict:

        return {
            "symbol": self.symbol,

            "order_book_events":
                len(self.orderbook.history),

            "heatmap_price_levels":
                len(self.heatmap.samples),

            "cumulative_book_delta_proxy":
                self.footprint.cumulative_delta,

            "live_execution":
                False,

            "broker_orders":
                0,
        }
