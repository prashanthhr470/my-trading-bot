from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class OpenAPIConfig:
    client_id: str = ""
    client_secret: str = ""
    redirect_uri: str = ""
    access_token: str = ""
    refresh_token: str = ""
    account_id: int | None = None

    host: str = "live"
    symbol: str = "XAUUSD"

    # Absolute safety controls.
    live_execution: bool = False
    paper_trading: bool = True
    dry_run: bool = True


def load_config() -> OpenAPIConfig:
    """
    Load credentials exclusively from environment variables.

    No secrets are hard-coded into the source tree.
    """

    account_raw = os.getenv("CTRADER_ACCOUNT_ID", "").strip()

    account_id = None

    if account_raw:
        try:
            account_id = int(account_raw)
        except ValueError:
            account_id = None

    return OpenAPIConfig(
        client_id=os.getenv("CTRADER_CLIENT_ID", "").strip(),
        client_secret=os.getenv("CTRADER_CLIENT_SECRET", "").strip(),
        redirect_uri=os.getenv("CTRADER_REDIRECT_URI", "").strip(),
        access_token=os.getenv("CTRADER_ACCESS_TOKEN", "").strip(),
        refresh_token=os.getenv("CTRADER_REFRESH_TOKEN", "").strip(),
        account_id=account_id,
        host=os.getenv("CTRADER_OPENAPI_HOST", "live").strip() or "live",
        symbol=os.getenv("CTRADER_SYMBOL", "XAUUSD").strip() or "XAUUSD",
        live_execution=False,
        paper_trading=True,
        dry_run=True,
    )


def credentials_ready(config: OpenAPIConfig) -> bool:
    return bool(
        config.client_id
        and config.client_secret
        and config.redirect_uri
    )
