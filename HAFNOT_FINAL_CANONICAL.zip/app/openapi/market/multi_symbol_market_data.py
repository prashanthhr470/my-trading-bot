﻿from __future__ import annotations

import json
import os
import signal
import time
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

from twisted.internet import reactor
from twisted.internet.error import ConnectError

from ctrader_open_api import Client, EndPoints, TcpProtocol
from ctrader_open_api.messages.OpenApiMessages_pb2 import (
    ProtoOAApplicationAuthReq,
    ProtoOAApplicationAuthRes,
    ProtoOAAccountAuthReq,
    ProtoOAAccountAuthRes,
    ProtoOASymbolsListReq,
    ProtoOASymbolsListRes,
    ProtoOASubscribeSpotsReq,
    ProtoOASubscribeSpotsRes,
    ProtoOASubscribeLiveTrendbarReq,
    ProtoOASubscribeLiveTrendbarRes,
    ProtoOASubscribeDepthQuotesReq,
    ProtoOASubscribeDepthQuotesRes,
    ProtoOASpotEvent,
    ProtoOADepthEvent,
)

from ctrader_open_api import Protobuf

from ctrader_open_api.messages.OpenApiModelMessages_pb2 import (
    ProtoOATrendbarPeriod,
)

# ============================================================
# ROOT / CONFIG
# ============================================================

ROOT = Path(__file__).resolve().parents[3]

load_dotenv(ROOT / ".env")

TOKEN_FILE = (
    ROOT /
    "data" /
    "ctrader_oauth_tokens.json"
)

ACCOUNT_FILE = (
    ROOT /
    "data" /
    "ctrader_authorized_account.json"
)

DATA_ROOT = (
    ROOT /
    "data" /
    "openapi"
)

DATA_ROOT.mkdir(
    parents=True,
    exist_ok=True,
)

HOST_TYPE = (
    os.getenv(
        "CTRADER_OPENAPI_HOST",
        "demo",
    )
    .strip()
    .lower()
)

if HOST_TYPE not in {
    "demo",
    "live",
}:
    HOST_TYPE = "demo"

HOST = (
    EndPoints.PROTOBUF_LIVE_HOST
    if HOST_TYPE == "live"
    else EndPoints.PROTOBUF_DEMO_HOST
)

PORT = EndPoints.PROTOBUF_PORT

# ============================================================
# HARD SAFETY
# ============================================================

READ_ONLY = True
LIVE_EXECUTION = False
PAPER_TRADING = True
BROKER_ORDERS = 0

if LIVE_EXECUTION or BROKER_ORDERS != 0:
    raise RuntimeError(
        "CRITICAL SAFETY FAILURE"
    )

# ============================================================
# USER SYMBOL UNIVERSE
# ============================================================

TARGET_SYMBOLS = [
    "XAUUSD",
    "GBPUSD",
    "USDJPY",
    "AUDUSD",
    "GBPJPY",
    "AUDJPY",
    "GBPAUD",
]

# Additional major FX monitoring.
MONITOR_SYMBOLS = [
    "EURUSD",
    "USDCHF",
    "USDCAD",
    "NZDUSD",
]

ALL_SYMBOLS = list(
    dict.fromkeys(
        TARGET_SYMBOLS
        + MONITOR_SYMBOLS
    )
)

# ============================================================
# RUNTIME STATE
# ============================================================

client = None
connection_client = None

access_token = None
account_id = None

symbols = {}

selected_symbols = {}

application_authenticated = False
account_authenticated = False
symbols_received = False
spot_subscribed = False
trendbars_subscribed = set()
depth_subscribed = set()

spot_event_count = 0
trendbar_event_count = 0
depth_event_count = 0

last_prices = {}

depth_books = {}

# ============================================================
# HELPERS
# ============================================================

def now_iso():
    return datetime.now(
        timezone.utc
    ).isoformat()

def load_json(path):
    if not path.exists():
        return {}

    try:
        return json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {}

def safe_name(symbol):
    return symbol.lower()

def event_path(symbol):
    return (
        DATA_ROOT /
        f"{safe_name(symbol)}_market_events.jsonl"
    )

def depth_path(symbol):
    return (
        DATA_ROOT /
        f"{safe_name(symbol)}_depth_snapshot.json"
    )

def append_event(symbol, payload):
    path = event_path(symbol)

    with path.open(
        "a",
        encoding="utf-8",
    ) as f:
        f.write(
            json.dumps(
                payload,
                separators=(",", ":"),
            )
            + "\n"
        )

def price_from_relative(value):
    return float(value) / 100000.0

def size_from_relative(value):
    return float(value) / 100.0

# ============================================================
# SYMBOL LOOKUP
# ============================================================

def find_symbol(name):
    wanted = name.upper()

    exact = []

    for symbol in symbols.values():
        symbol_name = str(
            getattr(
                symbol,
                "symbolName",
                "",
            )
        ).upper()

        if symbol_name == wanted:
            exact.append(symbol)

    if exact:
        return exact[0]

    # Some brokers expose suffixes.
    for symbol in symbols.values():
        symbol_name = str(
            getattr(
                symbol,
                "symbolName",
                "",
            )
        ).upper()

        if (
            symbol_name.startswith(wanted)
            or symbol_name.endswith(wanted)
        ):
            return symbol

    return None

# ============================================================
# CONNECTION
# ============================================================

def on_connected(client_instance):
    global connection_client

    connection_client = client_instance

    print("")
    print(
        "[CONNECTED] cTrader Open API TCP connection"
    )

    request = ProtoOAApplicationAuthReq()

    request.clientId = os.getenv(
        "CTRADER_CLIENT_ID",
        "",
    )

    request.clientSecret = os.getenv(
        "CTRADER_CLIENT_SECRET",
        "",
    )

    client_instance.send(request)

    print(
        "[1] Application authentication sent"
    )

# ============================================================
# DISCONNECTED
# ============================================================

def on_disconnected(
    client_instance,
    reason,
):
    print("")
    print(
        "[DISCONNECTED]",
        reason,
    )

# ============================================================
# MESSAGE HANDLER
# ============================================================

def on_message(
    client_instance,
    message,
):
    global application_authenticated
    global account_authenticated
    global symbols_received
    global spot_subscribed

    global spot_event_count
    global trendbar_event_count
    global depth_event_count

    try:

        # ----------------------------------------------------
        # APPLICATION AUTH
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOAApplicationAuthRes().payloadType
        ):

            application_authenticated = True

            print(
                "[PASS] APPLICATION AUTHENTICATED"
            )

            request = ProtoOAAccountAuthReq()

            request.ctidTraderAccountId = int(
                account_id
            )

            request.accessToken = access_token

            client_instance.send(request)

            print(
                "[2] Account authentication sent"
            )

            return

        # ----------------------------------------------------
        # ACCOUNT AUTH
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOAAccountAuthRes().payloadType
        ):

            account_authenticated = True

            print(
                "[PASS] DEMO ACCOUNT AUTHENTICATED"
            )

            request = ProtoOASymbolsListReq()

            request.ctidTraderAccountId = int(
                account_id
            )

            request.includeArchivedSymbols = False

            client_instance.send(request)

            print(
                "[3] Symbol list requested"
            )

            return

        # ----------------------------------------------------
        # SYMBOL LIST
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOASymbolsListRes().payloadType
        ):

            response = Protobuf.extract(
                message
            )

            symbols.clear()

            for symbol in response.symbol:
                symbols[
                    int(symbol.symbolId)
                ] = symbol

            symbols_received = True

            print("")
            print(
                f"[PASS] SYMBOL LIST: "
                f"{len(symbols)} symbols"
            )

            print("")
            print(
                "[SYMBOL RESOLUTION]"
            )

            missing = []

            for name in ALL_SYMBOLS:

                found = find_symbol(name)

                if found is None:
                    missing.append(name)

                    print(
                        f"  [MISSING] {name}"
                    )

                    continue

                symbol_id = int(
                    found.symbolId
                )

                selected_symbols[
                    name
                ] = found

                print(
                    f"  [FOUND] "
                    f"{name} "
                    f"-> "
                    f"{getattr(found, 'symbolName', '')} "
                    f"ID={symbol_id}"
                )

            if not selected_symbols:
                raise RuntimeError(
                    "No requested symbols were found."
                )

            # ------------------------------------------------
            # SPOT: ALL SYMBOLS
            # ------------------------------------------------

            request = ProtoOASubscribeSpotsReq()

            request.ctidTraderAccountId = int(
                account_id
            )

            for symbol in selected_symbols.values():

                request.symbolId.append(
                    int(symbol.symbolId)
                )

            request.subscribeToSpotTimestamp = True

            client_instance.send(request)

            print("")
            print(
                "[4] SPOT SUBSCRIPTION SENT"
            )

            print(
                "    Symbols: "
                + ", ".join(
                    selected_symbols.keys()
                )
            )

            return

        # ----------------------------------------------------
        # SPOT SUBSCRIPTION RESPONSE
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOASubscribeSpotsRes().payloadType
        ):

            spot_subscribed = True

            print("")
            print(
                "[PASS] MULTI-SYMBOL SPOT LIVE"
            )

            # ------------------------------------------------
            # M1 + DEPTH PER SYMBOL
            # ------------------------------------------------

            for name, symbol in selected_symbols.items():

                symbol_id = int(
                    symbol.symbolId
                )

                # M1
                trendbar = (
                    ProtoOASubscribeLiveTrendbarReq()
                )

                trendbar.ctidTraderAccountId = int(
                    account_id
                )

                trendbar.symbolId = symbol_id

                trendbar.period = (
                    ProtoOATrendbarPeriod.Value(
                        "M1"
                    )
                )

                client_instance.send(
                    trendbar
                )

                # Level II
                depth = (
                    ProtoOASubscribeDepthQuotesReq()
                )

                depth.ctidTraderAccountId = int(
                    account_id
                )

                depth.symbolId.append(
                    symbol_id
                )

                client_instance.send(
                    depth
                )

            print(
                "[5] M1 + LEVEL II requests sent"
            )

            return

        # ----------------------------------------------------
        # TRENDBAR RESPONSE
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOASubscribeLiveTrendbarRes().payloadType
        ):

            print(
                "[PASS] M1 subscription acknowledged"
            )

            return

        # ----------------------------------------------------
        # DEPTH RESPONSE
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOASubscribeDepthQuotesRes().payloadType
        ):

            print(
                "[PASS] Level II subscription acknowledged"
            )

            return

        # ----------------------------------------------------
        # SPOT EVENT
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOASpotEvent().payloadType
        ):

            event = Protobuf.extract(
                message
            )

            spot_event_count += 1

            symbol_id = int(
                event.symbolId
            )

            symbol_name = None

            for name, symbol in selected_symbols.items():

                if (
                    int(symbol.symbolId)
                    == symbol_id
                ):
                    symbol_name = name
                    break

            if symbol_name is None:
                return

            data = {
                "type": "spot",
                "timestamp": now_iso(),
                "symbol": symbol_name,
                "symbolId": symbol_id,
            }

            if event.HasField("bid"):
                data["bid"] = (
                    price_from_relative(
                        event.bid
                    )
                )

            if event.HasField("ask"):
                data["ask"] = (
                    price_from_relative(
                        event.ask
                    )
                )

            append_event(
                symbol_name,
                data,
            )

            if (
                "bid" in data
                or "ask" in data
            ):

                last_prices[
                    symbol_name
                ] = {
                    "bid": data.get(
                        "bid"
                    ),
                    "ask": data.get(
                        "ask"
                    ),
                    "timestamp": data[
                        "timestamp"
                    ],
                }

                print(
                    "[SPOT] "
                    f"{symbol_name:<8} "
                    f"BID={data.get('bid', '-'):<12} "
                    f"ASK={data.get('ask', '-')}"
                )

            # ------------------------------------------------
            # TRENDBARS
            # ------------------------------------------------

            try:

                for bar in event.trendbar:

                    trendbar_event_count += 1

                    low = price_from_relative(
                        bar.low
                    )

                    bar_data = {
                        "type": "trendbar",
                        "timestamp": now_iso(),
                        "symbol": symbol_name,
                        "symbolId": symbol_id,
                        "open": price_from_relative(
                            bar.low
                            + bar.deltaOpen
                        ),
                        "high": price_from_relative(
                            bar.low
                            + bar.deltaHigh
                        ),
                        "low": low,
                        "close": price_from_relative(
                            bar.low
                            + bar.deltaClose
                        ),
                    }

                    append_event(
                        symbol_name,
                        bar_data,
                    )

            except Exception as exc:
                print(
                    "[TRENDbar WARNING]",
                    repr(exc),
                )

            return

        # ----------------------------------------------------
        # DEPTH EVENT
        # ----------------------------------------------------

        if (
            message.payloadType
            == ProtoOADepthEvent().payloadType
        ):

            event = Protobuf.extract(
                message
            )

            depth_event_count += 1

            symbol_id = int(
                event.symbolId
            )

            symbol_name = None

            for name, symbol in selected_symbols.items():

                if (
                    int(symbol.symbolId)
                    == symbol_id
                ):
                    symbol_name = name
                    break

            if symbol_name is None:
                return

            book = depth_books.setdefault(
                symbol_name,
                {
                    "quotes": {},
                    "bids": {},
                    "asks": {},
                },
            )

            new_quotes = []
            deleted_quotes = []

            # ------------------------------------------------
            # NEW QUOTES
            # ------------------------------------------------

            for quote in event.newQuotes:

                quote_id = int(
                    quote.id
                )

                size = size_from_relative(
                    quote.size
                )

                if quote.HasField("bid"):

                    price = price_from_relative(
                        quote.bid
                    )

                    previous = book[
                        "quotes"
                    ].get(
                        quote_id
                    )

                    if previous:
                        old_side = previous[
                            "side"
                        ]

                        if old_side == "BID":
                            book[
                                "bids"
                            ].pop(
                                quote_id,
                                None,
                            )

                        else:
                            book[
                                "asks"
                            ].pop(
                                quote_id,
                                None,
                            )

                    record = {
                        "id": quote_id,
                        "side": "BID",
                        "price": price,
                        "size": size,
                    }

                    book[
                        "quotes"
                    ][quote_id] = record

                    book[
                        "bids"
                    ][quote_id] = record

                    book[
                        "asks"
                    ].pop(
                        quote_id,
                        None,
                    )

                    new_quotes.append(
                        record
                    )

                elif quote.HasField("ask"):

                    price = price_from_relative(
                        quote.ask
                    )

                    previous = book[
                        "quotes"
                    ].get(
                        quote_id
                    )

                    if previous:
                        old_side = previous[
                            "side"
                        ]

                        if old_side == "BID":
                            book[
                                "bids"
                            ].pop(
                                quote_id,
                                None,
                            )

                        else:
                            book[
                                "asks"
                            ].pop(
                                quote_id,
                                None,
                            )

                    record = {
                        "id": quote_id,
                        "side": "ASK",
                        "price": price,
                        "size": size,
                    }

                    book[
                        "quotes"
                    ][quote_id] = record

                    book[
                        "asks"
                    ][quote_id] = record

                    book[
                        "bids"
                    ].pop(
                        quote_id,
                        None,
                    )

                    new_quotes.append(
                        record
                    )

            # ------------------------------------------------
            # DELETIONS
            # ------------------------------------------------

            for deleted in event.deletedQuotes:

                quote_id = int(
                    deleted
                )

                previous = book[
                    "quotes"
                ].pop(
                    quote_id,
                    None,
                )

                book[
                    "bids"
                ].pop(
                    quote_id,
                    None,
                )

                book[
                    "asks"
                ].pop(
                    quote_id,
                    None,
                )

                deleted_quotes.append(
                    {
                        "id": quote_id,
                        "previous": previous,
                    }
                )

            # ------------------------------------------------
            # SORT BOOK
            # ------------------------------------------------

            sorted_bids = sorted(
                [
                    {
                        "quote_id": qid,
                        "price": q["price"],
                        "size": q["size"],
                    }
                    for qid, q
                    in book["bids"].items()
                ],
                key=lambda x: x["price"],
                reverse=True,
            )

            sorted_asks = sorted(
                [
                    {
                        "quote_id": qid,
                        "price": q["price"],
                        "size": q["size"],
                    }
                    for qid, q
                    in book["asks"].items()
                ],
                key=lambda x: x["price"],
            )

            event_data = {
                "type": "depth",
                "timestamp": now_iso(),
                "symbol": symbol_name,
                "symbolId": symbol_id,
                "newQuotes": new_quotes,
                "deletedQuotes": deleted_quotes,
                "book": {
                    "bidCount": len(
                        sorted_bids
                    ),
                    "askCount": len(
                        sorted_asks
                    ),
                    "bids": sorted_bids[:100],
                    "asks": sorted_asks[:100],
                },
            }

            append_event(
                symbol_name,
                event_data,
            )

            snapshot = {
                "timestamp": now_iso(),
                "symbol": symbol_name,
                "symbolId": symbol_id,
                "bidCount": len(
                    sorted_bids
                ),
                "askCount": len(
                    sorted_asks
                ),
                "bids": sorted_bids,
                "asks": sorted_asks,
            }

            depth_path(
                symbol_name
            ).write_text(
                json.dumps(
                    snapshot,
                    indent=2,
                ),
                encoding="utf-8",
            )

            return

    except Exception as exc:

        print("")
        print(
            "[MESSAGE HANDLER ERROR]"
        )
        print(
            repr(exc)
        )
        print("")

# ============================================================
# SHUTDOWN
# ============================================================

def shutdown(*args):

    print("")
    print(
        "=" * 70
    )
    print(
        " HAFNOT MULTI-SYMBOL MARKET DATA SHUTDOWN"
    )
    print(
        "=" * 70
    )

    print(
        f"Spot events     : {spot_event_count}"
    )

    print(
        f"Trendbar events : {trendbar_event_count}"
    )

    print(
        f"Depth events    : {depth_event_count}"
    )

    try:
        if client is not None:
            client.stopService()
    except Exception:
        pass

    try:
        reactor.stop()
    except Exception:
        pass

# ============================================================
# MAIN
# ============================================================

def main():

    global client
    global access_token
    global account_id

    print("")
    print(
        "=" * 70
    )
    print(
        " HAFNOT NATIVE cTRADER MULTI-SYMBOL DATA ENGINE"
    )
    print(
        "=" * 70
    )

    print("")
    print(
        f"Environment : {HOST_TYPE.upper()}"
    )

    print(
        f"Endpoint    : {HOST}:{PORT}"
    )

    print(
        "Mode        : READ-ONLY"
    )

    print(
        "Execution   : DISABLED"
    )

    print("")
    print(
        "Target symbols:"
    )

    print(
        "  "
        + ", ".join(
            TARGET_SYMBOLS
        )
    )

    print("")
    print(
        "Monitor symbols:"
    )

    print(
        "  "
        + ", ".join(
            MONITOR_SYMBOLS
        )
    )

    token_data = load_json(
        TOKEN_FILE
    )

    access_token = str(
        token_data.get(
            "accessToken",
            "",
        )
    ).strip()

    if not access_token:
        raise RuntimeError(
            "cTrader access token missing."
        )

    account_data = load_json(
        ACCOUNT_FILE
    )

    account_id = int(
        account_data[
            "ctidTraderAccountId"
        ]
    )

    print("")
    print(
        f"Demo account: {account_id}"
    )

    print("")
    print(
        "SAFETY:"
    )
    print(
        "  READ ONLY       = TRUE"
    )
    print(
        "  PAPER TRADING   = TRUE"
    )
    print(
        "  LIVE EXECUTION  = FALSE"
    )
    print(
        "  BROKER ORDERS   = 0"
    )

    client = Client(
        HOST,
        PORT,
        TcpProtocol,
    )

    client.setConnectedCallback(
        on_connected
    )

    client.setDisconnectedCallback(
        on_disconnected
    )

    client.setMessageReceivedCallback(
        on_message
    )

    print("")
    print(
        "Starting persistent multi-symbol Open API service..."
    )

    client.startService()

    reactor.run()

# ============================================================
# SIGNALS
# ============================================================

if __name__ == "__main__":

    signal.signal(
        signal.SIGINT,
        shutdown,
    )

    signal.signal(
        signal.SIGTERM,
        shutdown,
    )

    main()
