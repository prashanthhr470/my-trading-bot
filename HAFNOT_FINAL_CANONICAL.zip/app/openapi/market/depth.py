from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


PRICE_SCALE = 100000.0
SIZE_SCALE = 100.0


@dataclass
class DepthLevel:
    quote_id: int
    price: float
    size: float
    side: str
    timestamp: str


@dataclass
class DepthBook:
    symbol: str
    bids: dict[int, DepthLevel] = field(default_factory=dict)
    asks: dict[int, DepthLevel] = field(default_factory=dict)
    last_update: str | None = None

    def apply_event(
        self,
        *,
        new_quotes: list[dict[str, Any]] | None = None,
        deleted_quotes: list[int] | None = None,
        digits: int = 5,
    ) -> None:

        timestamp = datetime.now(
            timezone.utc
        ).isoformat()

        for quote in new_quotes or []:

            quote_id = int(
                quote.get("id", 0)
            )

            raw_bid = quote.get("bid")
            raw_ask = quote.get("ask")
            raw_size = quote.get("size", 0)

            size = float(raw_size) / SIZE_SCALE

            if raw_bid is not None:
                price = round(
                    float(raw_bid) / PRICE_SCALE,
                    digits
                )

                self.bids[quote_id] = DepthLevel(
                    quote_id=quote_id,
                    price=price,
                    size=size,
                    side="BID",
                    timestamp=timestamp,
                )

            elif raw_ask is not None:
                price = round(
                    float(raw_ask) / PRICE_SCALE,
                    digits
                )

                self.asks[quote_id] = DepthLevel(
                    quote_id=quote_id,
                    price=price,
                    size=size,
                    side="ASK",
                    timestamp=timestamp,
                )

        for quote_id in deleted_quotes or []:
            self.bids.pop(int(quote_id), None)
            self.asks.pop(int(quote_id), None)

        self.last_update = timestamp

    def snapshot(self) -> dict[str, Any]:
        bids = sorted(
            (
                {
                    "id": x.quote_id,
                    "price": x.price,
                    "size": x.size,
                    "side": x.side,
                    "timestamp": x.timestamp,
                }
                for x in self.bids.values()
            ),
            key=lambda x: x["price"],
            reverse=True,
        )

        asks = sorted(
            (
                {
                    "id": x.quote_id,
                    "price": x.price,
                    "size": x.size,
                    "side": x.side,
                    "timestamp": x.timestamp,
                }
                for x in self.asks.values()
            ),
            key=lambda x: x["price"],
        )

        bid_volume = sum(
            x["size"] for x in bids
        )

        ask_volume = sum(
            x["size"] for x in asks
        )

        total = bid_volume + ask_volume

        imbalance = (
            (bid_volume - ask_volume) / total
            if total
            else 0.0
        )

        return {
            "symbol": self.symbol,
            "bids": bids,
            "asks": asks,
            "bid_volume": bid_volume,
            "ask_volume": ask_volume,
            "total_depth": total,
            "imbalance": imbalance,
            "last_update": self.last_update,
        }
