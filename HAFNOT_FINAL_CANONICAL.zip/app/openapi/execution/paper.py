from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class PaperOrderResult:
    accepted: bool
    executed: bool
    symbol: str
    direction: str
    volume: float
    reason: str


class OpenAPIPaperExecution:
    """
    Open API execution boundary.

    This object deliberately has NO live-order implementation.
    """

    LIVE_EXECUTION = False
    DRY_RUN = True

    async def execute(
        self,
        *,
        symbol: str,
        direction: str,
        volume: float,
        entry_price: float | None = None,
        stop_loss: float | None = None,
        take_profit: float | None = None,
    ) -> PaperOrderResult:

        return PaperOrderResult(
            accepted=True,
            executed=False,
            symbol=symbol,
            direction=direction,
            volume=volume,
            reason=(
                "PAPER ONLY: Open API execution boundary "
                "received request. No broker order was sent."
            ),
        )
