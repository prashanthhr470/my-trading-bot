"""
HAFNOT native cTrader OpenAPI order execution worker.

STATUS: NOT VERIFIED end to end - no order has ever been sent. The read-only path
(application + DEMO account authentication, RECONCILE) was verified against the DEMO
server on 2026-09-14. Before any order was sent, inspection against the installed
protobuf definitions found and fixed four defects in the first version of this file:
  1. Volume limits were read from ProtoOALightSymbol, which has no lotSize,
     minVolume, stepVolume or maxVolume - every value was 0. The full ProtoOASymbol
     is now fetched with ProtoOASymbolByIdReq.
  2. Volume was lots x lotSize x 100, but lotSize is already in hundredths of a unit:
     100 times the intended size. See app/openapi/execution/order_math.py.
  3. ProtoOAClosePositionReq requires a volume the worker never set. The position's
     volume is now read with RECONCILE first.
  4. The first execution event (ORDER_ACCEPTED) was taken as the result; a market
     order's fill arrives afterwards as ORDER_FILLED. The worker now waits for it.
Market-order stops are sent as relativeStopLoss / relativeTakeProfit distances.

Runs as a short-lived subprocess under .ctrader_venv (Python 3.12), invoked by
app/openapi/execution/native_execution_client.py.

Usage:
    <.ctrader_venv python> native_order_execution.py <request_file.json>

Request file (JSON), one of three actions:

    {"action": "PLACE_ORDER", "client_order_id": "...", "symbol": "EURUSD",
     "side": "BUY", "volume_lots": 0.01, "stop_loss_distance": 0.0050,
     "take_profit_distance": 0.0100}

    {"action": "CLOSE_POSITION", "position_id": 12345678}

    {"action": "RECONCILE"}

Result is written to <request_file>.result.json; the process exits after one request.

HARD SAFETY (all independently enforced):
  - PLACE_ORDER and CLOSE_POSITION refuse to run unless env DEMO_ORDER_EXECUTION_ENABLED=true.
  - Refuses any account where data/ctrader_authorized_account.json records isLive=true (or is unreadable).
  - Refuses if CTRADER_OPENAPI_HOST is not "demo"; only the DEMO host is ever contacted.
  - PLACE_ORDER volume is validated against the broker's real min/max/step for the symbol.
  - client_order_id is required for PLACE_ORDER and checked against a local idempotency
    ledger (data/openapi/execution/sent_orders.json) that survives restarts.
  - Symbols are matched by exact name only.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from twisted.internet import reactor
from ctrader_open_api import Client, EndPoints, Protobuf, TcpProtocol
from ctrader_open_api.messages.OpenApiMessages_pb2 import (
    ProtoOAApplicationAuthReq,
    ProtoOAApplicationAuthRes,
    ProtoOAAccountAuthReq,
    ProtoOAAccountAuthRes,
    ProtoOASymbolsListReq,
    ProtoOASymbolsListRes,
    ProtoOASymbolByIdReq,
    ProtoOASymbolByIdRes,
    ProtoOANewOrderReq,
    ProtoOAClosePositionReq,
    ProtoOAReconcileReq,
    ProtoOAReconcileRes,
    ProtoOAExecutionEvent,
    ProtoOAOrderErrorEvent,
    ProtoOAErrorRes,
)
from ctrader_open_api.messages.OpenApiModelMessages_pb2 import (
    ProtoOAExecutionType,
    ProtoOAOrderType,
    ProtoOATradeSide,
)

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / ".env")

from app.openapi.execution import order_math  # noqa: E402  (after the path insert)

TOKEN_FILE = ROOT / "data" / "ctrader_oauth_tokens.json"
ACCOUNT_FILE = ROOT / "data" / "ctrader_authorized_account.json"
LEDGER_FILE = ROOT / "data" / "openapi" / "execution" / "sent_orders.json"

REQUEST_TIMEOUT_SECONDS = 30
TERMINAL_FAILURES = {"ORDER_REJECTED", "ORDER_CANCELLED", "ORDER_EXPIRED"}


def _fail(reason: str) -> None:
    print(f"[FATAL] {reason}")
    sys.exit(1)


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def execution_details(event) -> dict:
    """
    A ProtoOAExecutionEvent as a plain dict. moneyDigits is read from the deal or the
    position - the event itself has no such field. Reading it from the event raised and
    ended the first DEMO order run (14 Sep) after the order had filled.
    """

    order = event.order if event.HasField("order") else None
    position = event.position if event.HasField("position") else None
    deal = event.deal if event.HasField("deal") else None
    money_digits = None
    if deal is not None and deal.HasField("moneyDigits"):
        money_digits = deal.moneyDigits
    elif position is not None and position.HasField("moneyDigits"):
        money_digits = position.moneyDigits
    return {
        "execution_type": ProtoOAExecutionType.Name(event.executionType),
        "order_id": order.orderId if order else None,
        "order_status": str(order.orderStatus) if order else None,
        "position_id": position.positionId if position else (deal.positionId if deal else None),
        "position_volume": position.tradeData.volume if position else None,
        "position_stop_loss": position.stopLoss if position and position.HasField("stopLoss") else None,
        "position_take_profit": position.takeProfit if position and position.HasField("takeProfit") else None,
        "deal_id": deal.dealId if deal else None,
        "executed_volume": order.executedVolume if order and order.HasField("executedVolume") else None,
        "execution_price": (order.executionPrice if order and order.HasField("executionPrice")
                            else (deal.executionPrice if deal and deal.HasField("executionPrice") else None)),
        "deal_commission_raw": deal.commission if deal and deal.HasField("commission") else None,
        "money_digits": money_digits,
    }


def _write_result(request_file: Path, result: dict) -> None:
    result_file = request_file.with_suffix(request_file.suffix + ".result.json")
    result_file.write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(f"[RESULT] Written to {result_file}")


class OrderWorker:

    def __init__(self, request: dict, request_file: Path):
        self.request = request
        self.request_file = request_file
        self.action = str(request.get("action", "")).upper()
        self.client = None
        self.access_token = ""
        self.account_id = None
        self.accepted = None
        self.done = False

    # ------------------------------------------------------------
    # SAFETY PRE-FLIGHT (before any network connection is opened)
    # ------------------------------------------------------------

    def preflight(self) -> None:
        if self.action not in {"PLACE_ORDER", "CLOSE_POSITION", "RECONCILE"}:
            _fail(f"Unknown action {self.action!r}.")

        # RECONCILE only reads what is open; placing or closing needs the explicit opt-in.
        if self.action != "RECONCILE":
            if os.getenv("DEMO_ORDER_EXECUTION_ENABLED", "false").strip().lower() != "true":
                _fail("DEMO_ORDER_EXECUTION_ENABLED is not 'true'. Refusing to connect.")

        host_type = os.getenv("CTRADER_OPENAPI_HOST", "demo").strip().lower()
        if host_type != "demo":
            _fail(f"CTRADER_OPENAPI_HOST={host_type!r}, not 'demo'. Refusing.")

        account_data = _load_json(ACCOUNT_FILE)
        if not account_data:
            _fail(f"Authorized account file missing/unreadable: {ACCOUNT_FILE}")
        if bool(account_data.get("isLive", True)):
            _fail("Authorized account is flagged isLive=true (or unknown). Refusing.")

        token_data = _load_json(TOKEN_FILE)
        self.access_token = str(token_data.get("accessToken", "")).strip()
        if not self.access_token:
            _fail("cTrader access token missing. Run app\\openapi\\auth\\oauth.py first.")
        self.account_id = int(account_data["ctidTraderAccountId"])

        if self.action == "PLACE_ORDER":
            if not self.request.get("client_order_id"):
                _fail("PLACE_ORDER requires client_order_id for idempotency.")
            if self.request["client_order_id"] in _load_json(LEDGER_FILE).get("sent_client_order_ids", []):
                _fail(f"client_order_id={self.request['client_order_id']!r} was already sent. Refusing a duplicate.")
            if str(self.request.get("side", "")).upper() not in ("BUY", "SELL"):
                _fail(f"Invalid side: {self.request.get('side')!r}")
            try:
                order_math.relative_price_units(self.request["stop_loss_distance"])
                order_math.relative_price_units(self.request["take_profit_distance"])
            except (KeyError, TypeError, ValueError) as exc:
                _fail(f"PLACE_ORDER needs positive stop_loss_distance and take_profit_distance: {exc}")

        if self.action == "CLOSE_POSITION":
            try:
                int(self.request["position_id"])
            except (KeyError, TypeError, ValueError):
                _fail("CLOSE_POSITION requires position_id.")

    def _record_sent(self, client_order_id: str) -> None:
        LEDGER_FILE.parent.mkdir(parents=True, exist_ok=True)
        ledger = _load_json(LEDGER_FILE)
        sent = ledger.get("sent_client_order_ids", [])
        sent.append(client_order_id)
        ledger["sent_client_order_ids"] = sent[-500:]
        LEDGER_FILE.write_text(json.dumps(ledger, indent=2), encoding="utf-8")

    # ------------------------------------------------------------
    # CONNECTION
    # ------------------------------------------------------------

    def start(self) -> None:
        self.preflight()
        self.client = Client(EndPoints.PROTOBUF_DEMO_HOST, EndPoints.PROTOBUF_PORT, TcpProtocol)
        self.client.setConnectedCallback(self.on_connected)
        self.client.setDisconnectedCallback(self.on_disconnected)
        self.client.setMessageReceivedCallback(self.on_message)
        reactor.callLater(REQUEST_TIMEOUT_SECONDS, self._on_timeout)
        self.client.startService()
        reactor.run()

    def _send(self, message) -> None:
        deferred = self.client.send(message)
        if hasattr(deferred, "addErrback"):
            deferred.addErrback(lambda failure: None)  # the library's 5 s timer; this worker has its own

    def _on_timeout(self) -> None:
        if not self.done:
            self._finish({"status": "TIMEOUT", "error": f"No terminal response within {REQUEST_TIMEOUT_SECONDS}s.",
                          "accepted": self.accepted})

    def _finish(self, result: dict) -> None:
        if self.done:
            return
        self.done = True
        result.setdefault("action", self.action)
        result.setdefault("environment", "demo")
        _write_result(self.request_file, result)
        try:
            reactor.stop()
        except Exception:
            pass

    def on_connected(self, client_instance) -> None:
        print("[CONNECTED] cTrader Open API TCP connection")
        request = ProtoOAApplicationAuthReq()
        request.clientId = os.getenv("CTRADER_CLIENT_ID", "")
        request.clientSecret = os.getenv("CTRADER_CLIENT_SECRET", "")
        self._send(request)

    def on_disconnected(self, client_instance, reason) -> None:
        if not self.done:
            self._finish({"status": "DISCONNECTED", "error": str(reason)})

    # ------------------------------------------------------------
    # MESSAGES
    # ------------------------------------------------------------

    def on_message(self, client_instance, message) -> None:
        try:
            kind = message.payloadType

            if kind == ProtoOAApplicationAuthRes().payloadType:
                print("[PASS] Application authenticated")
                request = ProtoOAAccountAuthReq()
                request.ctidTraderAccountId = self.account_id
                request.accessToken = self.access_token
                self._send(request)

            elif kind == ProtoOAAccountAuthRes().payloadType:
                print("[PASS] Account authenticated")
                if self.action == "PLACE_ORDER":
                    request = ProtoOASymbolsListReq()
                    request.ctidTraderAccountId = self.account_id
                    request.includeArchivedSymbols = False
                else:
                    request = ProtoOAReconcileReq()
                    request.ctidTraderAccountId = self.account_id
                self._send(request)

            elif kind == ProtoOASymbolsListRes().payloadType:
                wanted = str(self.request["symbol"]).upper()
                match = [s for s in Protobuf.extract(message).symbol if str(s.symbolName).upper() == wanted]
                if not match:
                    self._finish({"status": "ERROR", "error": f"Symbol not found by exact name: {wanted!r}"})
                    return
                request = ProtoOASymbolByIdReq()
                request.ctidTraderAccountId = self.account_id
                request.symbolId.append(int(match[0].symbolId))
                self._send(request)

            elif kind == ProtoOASymbolByIdRes().payloadType:
                symbols = list(Protobuf.extract(message).symbol)
                if not symbols:
                    self._finish({"status": "ERROR", "error": "Broker returned no symbol details."})
                    return
                self._place_order(symbols[0])

            elif kind == ProtoOAReconcileRes().payloadType:
                self._on_reconcile(Protobuf.extract(message))

            elif kind == ProtoOAExecutionEvent().payloadType:
                self._on_execution(Protobuf.extract(message))

            elif kind == ProtoOAOrderErrorEvent().payloadType:
                event = Protobuf.extract(message)
                self._finish({"status": "REJECTED", "error_code": event.errorCode, "description": event.description})

            elif kind == ProtoOAErrorRes().payloadType:
                error = Protobuf.extract(message)
                self._finish({"status": "ERROR", "error_code": error.errorCode,
                              "description": getattr(error, "description", "")})

        except Exception as exc:
            self._finish({"status": "ERROR", "error": f"{type(exc).__name__}: {exc}"})

    def _on_reconcile(self, response) -> None:
        positions = [{
            "position_id": p.positionId, "symbol_id": p.tradeData.symbolId, "volume": p.tradeData.volume,
            "side": ProtoOATradeSide.Name(p.tradeData.tradeSide), "entry_price": p.price,
            "stop_loss": p.stopLoss, "take_profit": p.takeProfit, "swap": p.swap, "commission": p.commission,
        } for p in response.position]

        if self.action == "RECONCILE":
            orders = [{"order_id": o.orderId, "position_id": o.positionId, "symbol_id": o.tradeData.symbolId,
                       "status": str(o.orderStatus)} for o in response.order]
            self._finish({"status": "OK", "positions": positions, "orders": orders})
            return

        position_id = int(self.request["position_id"])
        position = next((p for p in positions if p["position_id"] == position_id), None)
        if position is None:
            self._finish({"status": "ERROR", "error": f"Position {position_id} is not open on the account."})
            return
        request = ProtoOAClosePositionReq()
        request.ctidTraderAccountId = self.account_id
        request.positionId = position_id
        request.volume = int(position["volume"])
        print(f"[SEND] CLOSE_POSITION position_id={position_id} volume={position['volume']}")
        self._send(request)

    def _place_order(self, symbol) -> None:
        try:
            volume = order_math.raw_volume(
                float(self.request["volume_lots"]), lot_size=int(symbol.lotSize), min_volume=int(symbol.minVolume),
                step_volume=int(symbol.stepVolume), max_volume=int(symbol.maxVolume),
            )
        except (KeyError, TypeError, ValueError) as exc:
            self._finish({"status": "ERROR", "error": str(exc)})
            return

        side = str(self.request["side"]).upper()
        order = ProtoOANewOrderReq()
        order.ctidTraderAccountId = self.account_id
        order.symbolId = int(symbol.symbolId)
        order.orderType = ProtoOAOrderType.Value("MARKET")
        order.tradeSide = ProtoOATradeSide.Value(side)
        order.volume = volume
        order.clientOrderId = str(self.request["client_order_id"])
        order.comment = "HAFNOT"
        order.label = "HAFNOT"
        order.relativeStopLoss = order_math.relative_price_units(self.request["stop_loss_distance"])
        order.relativeTakeProfit = order_math.relative_price_units(self.request["take_profit_distance"])

        self._record_sent(str(self.request["client_order_id"]))
        print(f"[SEND] PLACE_ORDER {side} {self.request['volume_lots']} lots {self.request['symbol']} volume={volume}")
        self._send(order)

    def _on_execution(self, event) -> None:
        details = execution_details(event)
        kind = details["execution_type"]
        print(f"[EVENT] {kind}")
        if kind == "ORDER_ACCEPTED":
            self.accepted = details   # a market order's fill follows as ORDER_FILLED
            return
        if kind == "ORDER_FILLED":
            self._finish({"status": "OK", **details, "accepted": self.accepted})
            return
        if kind in TERMINAL_FAILURES:
            self._finish({"status": "REJECTED", **details})


def main() -> None:
    if len(sys.argv) != 2:
        _fail("Usage: native_order_execution.py <request_file.json>")
    request_file = Path(sys.argv[1]).resolve()
    if not request_file.exists():
        _fail(f"Request file not found: {request_file}")
    OrderWorker(json.loads(request_file.read_text(encoding="utf-8")), request_file).start()


if __name__ == "__main__":
    main()
