"""
Pure order arithmetic for the native cTrader worker: no network, no Twisted, so it
can be tested from any interpreter.

Units, per the broker's own symbol data (ProtoOASymbol; data/broker/symbol_specs.json):
  - lotSize, minVolume, stepVolume and maxVolume are in hundredths of a unit.
    EURUSD: lotSize 10,000,000 = 100,000 units x 100; minVolume 100,000 = 0.01 lot.
    XAUUSD: lotSize 10,000 = 100 oz x 100; minVolume 100 = 0.01 lot.
  - An order's volume is on the same scale, so raw volume = lots x lotSize.
    (The worker as first written multiplied by 100 again - 100 times the size - and
    read these fields from ProtoOALightSymbol, which does not carry them at all.)
  - Relative stop-loss and take-profit distances are in 1/100,000 of the price.
"""

from __future__ import annotations

PRICE_UNITS = 100_000


def raw_volume(lots: float, *, lot_size: int, min_volume: int, step_volume: int, max_volume: int) -> int:
    """Broker volume for `lots`, rounded DOWN to the step; refuses anything outside the broker's bounds."""

    if lots <= 0:
        raise ValueError("Volume must be positive.")
    if lot_size <= 0 or min_volume <= 0 or step_volume <= 0:
        raise ValueError("Symbol volume specification is missing; fetch the full symbol (ProtoOASymbolByIdReq).")
    raw = int(round(lots * lot_size))
    raw = (raw // step_volume) * step_volume
    if raw < min_volume:
        raise ValueError(f"{lots} lots is below the broker minimum of {min_volume / lot_size} lots.")
    if max_volume and raw > max_volume:
        raise ValueError(f"{lots} lots is above the broker maximum of {max_volume / lot_size} lots.")
    return raw


def relative_price_units(distance: float) -> int:
    """A price distance (e.g. 0.0050 for 50 EURUSD pips) in the 1/100,000 units relative stops use."""

    units = int(round(float(distance) * PRICE_UNITS))
    if units < 1:
        raise ValueError(f"Stop or target distance {distance} is not positive.")
    return units
