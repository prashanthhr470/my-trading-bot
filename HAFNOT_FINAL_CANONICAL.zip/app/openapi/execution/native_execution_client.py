"""
Async client for the native cTrader order-execution worker.

Runs under the MAIN project interpreter (Python 3.14 / .venv, asyncio-based).
It never talks to cTrader directly - it writes a request file, launches
native_order_execution.py as a short-lived subprocess under .ctrader_venv
(Python 3.12, required by ctrader_open_api/Twisted), waits for the result
file, and returns it as a plain dict.

STATUS: NOT VERIFIED against a live DEMO account - see the warning in
native_order_execution.py. Disabled by default (DEMO_ORDER_EXECUTION_ENABLED
must be explicitly set to "true" in .env, and the worker independently
refuses to run against a non-DEMO/isLive account regardless of this flag).
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[3]

CTRADER_PYTHON = ROOT / ".ctrader_venv" / "Scripts" / "python.exe"
WORKER_SCRIPT = Path(__file__).resolve().parent / "native_order_execution.py"

REQUEST_DIR = ROOT / "data" / "openapi" / "execution" / "requests"

SUBPROCESS_TIMEOUT_SECONDS = 45


def is_demo_order_execution_enabled() -> bool:
    return os.getenv("DEMO_ORDER_EXECUTION_ENABLED", "false").strip().lower() == "true"


def result_path_for(request_file: Path) -> Path:
    """Where the worker writes its result: the request file's full name plus ".result.json".

    The first version used request_file.with_suffix(".request.json.result.json"), which
    replaces only ".json" and looks for "x.request.request.json.result.json" - so no
    result was ever found (found 2026-09-14 by the read-only verification run)."""

    return request_file.with_name(request_file.name + ".result.json")


async def _run_worker(request: dict) -> dict:

    REQUEST_DIR.mkdir(parents=True, exist_ok=True)

    request_id = request.get("client_order_id") or f"{request['action']}-{uuid.uuid4().hex[:12]}"
    request_file = REQUEST_DIR / f"{request_id}.request.json"
    result_file = result_path_for(request_file)

    request_file.write_text(json.dumps(request, indent=2), encoding="utf-8")

    if not CTRADER_PYTHON.exists():
        return {"status": "ERROR", "error": f"cTrader interpreter missing: {CTRADER_PYTHON}"}

    if not WORKER_SCRIPT.exists():
        return {"status": "ERROR", "error": f"Worker script missing: {WORKER_SCRIPT}"}

    try:
        process = await asyncio.create_subprocess_exec(
            str(CTRADER_PYTHON),
            str(WORKER_SCRIPT),
            str(request_file),
            cwd=str(ROOT),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=SUBPROCESS_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            return {
                "status": "TIMEOUT",
                "error": f"Worker did not exit within {SUBPROCESS_TIMEOUT_SECONDS}s.",
            }

        if result_file.exists():
            try:
                return json.loads(result_file.read_text(encoding="utf-8"))
            except Exception as exc:
                return {"status": "ERROR", "error": f"Could not parse result file: {exc}"}

        return {
            "status": "ERROR",
            "error": "Worker exited without writing a result file.",
            "exit_code": process.returncode,
            "stdout_tail": stdout.decode("utf-8", "replace")[-2000:],
            "stderr_tail": stderr.decode("utf-8", "replace")[-2000:],
        }

    except Exception as exc:
        return {"status": "ERROR", "error": f"{type(exc).__name__}: {exc}"}


async def place_market_order(
    *,
    client_order_id: str,
    symbol: str,
    side: str,
    volume_lots: float,
    stop_loss_distance: float,
    take_profit_distance: float,
) -> dict:
    """
    Place a real DEMO market order with stop-loss and take-profit set as price
    DISTANCES from the fill (e.g. 0.0050 = 50 EURUSD pips). Returns a dict with at
    least a "status" key: "OK" (the order FILLED - see execution_price and
    position_id), "REJECTED" (inspect error_code/description), "TIMEOUT", or
    "ERROR". Never raises for broker-side outcomes.

    Does nothing (returns a clear ERROR result) unless
    DEMO_ORDER_EXECUTION_ENABLED=true and the authorized account is a
    genuine DEMO account - both are re-checked inside the worker
    subprocess, not just here.
    """

    if not is_demo_order_execution_enabled():
        return {
            "status": "DISABLED",
            "error": (
                "DEMO_ORDER_EXECUTION_ENABLED is not 'true'. Real order "
                "placement is intentionally off by default."
            ),
        }

    request = {
        "action": "PLACE_ORDER",
        "client_order_id": client_order_id,
        "symbol": symbol.upper(),
        "side": side.upper(),
        "volume_lots": float(volume_lots),
        "stop_loss_distance": float(stop_loss_distance),
        "take_profit_distance": float(take_profit_distance),
    }

    return await _run_worker(request)


async def close_position(*, position_id: int) -> dict:
    """Close an open DEMO position by its broker position_id."""

    if not is_demo_order_execution_enabled():
        return {"status": "DISABLED", "error": "DEMO_ORDER_EXECUTION_ENABLED is not 'true'."}

    return await _run_worker({
        "action": "CLOSE_POSITION",
        "position_id": int(position_id),
        "client_order_id": f"close-{position_id}-{int(time.time())}",
    })


async def reconcile() -> dict:
    """
    Fetch the broker's live open positions/orders for this account.
    Unlike place_market_order/close_position, this is read-only and does
    NOT require DEMO_ORDER_EXECUTION_ENABLED - it is safe to call any time
    to compare broker state against local paper/demo bookkeeping.
    """

    return await _run_worker({
        "action": "RECONCILE",
        "client_order_id": f"reconcile-{int(time.time())}",
    })
