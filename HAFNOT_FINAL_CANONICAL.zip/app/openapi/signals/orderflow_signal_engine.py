﻿"""
HAFNOT Order Flow Signal Engine.

Converts measured order-book conditions into an evidence-rich
signal. It does NOT execute trades.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class OrderFlowSignal:
    direction: str
    score: float
    confidence: float
    regime: str

    reasons: list[str]
    warnings: list[str]

    evidence: dict[str, Any]

    execution_allowed: bool = False

    def to_dict(self):
        return asdict(self)


class OrderFlowSignalEngine:

    def evaluate(
        self,
        orderbook,
        footprint=None,
        heatmap=None,
    ) -> OrderFlowSignal:

        pressure = float(
            orderbook.book_pressure
        )

        momentum = float(
            orderbook.short_term_book_momentum
        )

        stacking = float(
            orderbook.stacking_score
        )

        pulling = float(
            orderbook.pulling_score
        )

        migration = float(
            orderbook.liquidity_migration
        )

        absorption = float(
            orderbook.absorption_proxy
        )

        score = (
            0.40 * pressure +
            0.20 * momentum +
            0.15 * stacking +
            0.10 * pulling +
            0.10 * migration +
            0.05 * absorption
        )

        score = max(
            -1.0,
            min(1.0, score)
        )

        reasons = []
        warnings = []

        if pressure > 0.25:
            reasons.append(
                "Bid-side book pressure is dominant."
            )

        if pressure < -0.25:
            reasons.append(
                "Ask-side book pressure is dominant."
            )

        if stacking > 0.10:
            reasons.append(
                "Bid stacking exceeds ask stacking."
            )

        if stacking < -0.10:
            reasons.append(
                "Ask stacking exceeds bid stacking."
            )

        if pulling > 0.10:
            reasons.append(
                "Ask liquidity removal is stronger."
            )

        if pulling < -0.10:
            reasons.append(
                "Bid liquidity removal is stronger."
            )

        if abs(migration) > 0.15:
            reasons.append(
                "Liquidity is migrating between book sides."
            )

        if abs(absorption) > 0.25:
            warnings.append(
                "Absorption is only a resting-liquidity proxy."
            )

        if footprint is not None:
            warnings.append(
                "Footprint delta is depth-derived, not executed-trade delta."
            )

        if score >= 0.25:
            direction = "BULLISH"
        elif score <= -0.25:
            direction = "BEARISH"
        else:
            direction = "NEUTRAL"

        confidence = min(
            1.0,
            (
                0.55 * abs(score) +
                0.25 * float(orderbook.confidence) +
                0.20 * min(
                    1.0,
                    len(reasons) / 4.0
                )
            )
        )

        if confidence >= 0.70:
            regime = "STRONG"
        elif confidence >= 0.45:
            regime = "MODERATE"
        else:
            regime = "WEAK"

        return OrderFlowSignal(
            direction=direction,
            score=score,
            confidence=confidence,
            regime=regime,
            reasons=reasons,
            warnings=warnings,
            evidence={
                "book_pressure": pressure,
                "book_momentum": momentum,
                "stacking": stacking,
                "pulling": pulling,
                "liquidity_migration": migration,
                "absorption_proxy": absorption,
                "weighted_imbalance": orderbook.weighted_imbalance,
                "raw_imbalance": orderbook.raw_imbalance,
                "spread": orderbook.spread,
                "bid_depth": orderbook.bid_depth,
                "ask_depth": orderbook.ask_depth,
            },
            execution_allowed=False,
        )
