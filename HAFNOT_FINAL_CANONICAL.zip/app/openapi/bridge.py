from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .market.depth import DepthBook
from .orderflow.engine import OrderFlowEngine
from .orderflow.footprint import FootprintAggregator
from .orderflow.heatmap import LiquidityHeatmap


@dataclass
class OpenAPIMarketState:
    symbol: str

    bid: float | None = None
    ask: float | None = None

    depth_available: bool = False
    orderflow_available: bool = False
    footprint_available: bool = False
    heatmap_available: bool = False

    depth: dict[str, Any] | None = None
    orderflow: dict[str, Any] | None = None
    footprint: list[dict[str, Any]] | None = None
    heatmap: dict[str, Any] | None = None


class OpenAPIIntelligenceBridge:

    def __init__(self, symbol: str):
        self.symbol = symbol

        self.depth_book = DepthBook(
            symbol=symbol
        )

        self.orderflow = OrderFlowEngine(
            symbol=symbol
        )

        self.footprint = FootprintAggregator()

        self.heatmap = LiquidityHeatmap(
            symbol=symbol
        )

    def update_spot(
        self,
        *,
        bid: float | None,
        ask: float | None,
    ) -> None:

        self._bid = bid
        self._ask = ask

    def update_depth(
        self,
        *,
        new_quotes=None,
        deleted_quotes=None,
        digits=5,
    ) -> OpenAPIMarketState:

        self.depth_book.apply_event(
            new_quotes=new_quotes,
            deleted_quotes=deleted_quotes,
            digits=digits,
        )

        snapshot = (
            self.depth_book.snapshot()
        )

        self.orderflow.ingest_depth_snapshot(
            snapshot
        )

        self.footprint.ingest_snapshot(
            snapshot
        )

        self.heatmap.ingest(
            snapshot
        )

        return self.state()

    def state(self) -> OpenAPIMarketState:

        depth = self.depth_book.snapshot()

        return OpenAPIMarketState(
            symbol=self.symbol,
            bid=getattr(
                self,
                "_bid",
                None
            ),
            ask=getattr(
                self,
                "_ask",
                None
            ),
            depth_available=bool(
                depth["bids"]
                or depth["asks"]
            ),
            orderflow_available=bool(
                self.orderflow.events
            ),
            footprint_available=bool(
                self.footprint.rows
            ),
            heatmap_available=bool(
                self.heatmap.snapshots
            ),
            depth=depth,
            orderflow=self.orderflow.summary(),
            footprint=self.footprint.build(),
            heatmap=self.heatmap.build(),
        )
