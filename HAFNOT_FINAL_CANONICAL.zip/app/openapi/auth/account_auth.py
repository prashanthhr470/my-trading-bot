﻿from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from twisted.internet import reactor

from ctrader_open_api import Client, Protobuf, TcpProtocol
from ctrader_open_api.endpoints import EndPoints

from ctrader_open_api.messages.OpenApiMessages_pb2 import (
    ProtoOAAccountAuthReq,
    ProtoOAAccountAuthRes,
    ProtoOAApplicationAuthReq,
    ProtoOAApplicationAuthRes,
    ProtoOAGetAccountListByAccessTokenReq,
    ProtoOAGetAccountListByAccessTokenRes,
)


PROJECT_ROOT = Path(__file__).resolve().parents[3]
ENV_FILE = PROJECT_ROOT / ".env"
TOKEN_FILE = PROJECT_ROOT / "data" / "ctrader_oauth_tokens.json"
ACCOUNT_FILE = PROJECT_ROOT / "data" / "ctrader_authorized_account.json"


load_dotenv(ENV_FILE)


CLIENT_ID = os.getenv("CTRADER_CLIENT_ID", "").strip()
CLIENT_SECRET = os.getenv("CTRADER_CLIENT_SECRET", "").strip()

_preferred_id_raw = os.getenv("CTRADER_DEMO_ID", "").strip()
PREFERRED_ACCOUNT_ID = int(_preferred_id_raw) if _preferred_id_raw.isdigit() else None

HOST_TYPE = os.getenv("CTRADER_OPENAPI_HOST", "demo").strip().lower()

if HOST_TYPE not in ("demo", "live"):
    HOST_TYPE = "demo"


if HOST_TYPE == "live":
    HOST = EndPoints.PROTOBUF_LIVE_HOST
else:
    HOST = EndPoints.PROTOBUF_DEMO_HOST


PORT = EndPoints.PROTOBUF_PORT


def load_access_token() -> str:
    if not TOKEN_FILE.exists():
        raise RuntimeError(
            f"OAuth token file not found: {TOKEN_FILE}"
        )

    data = json.loads(
        TOKEN_FILE.read_text(encoding="utf-8")
    )

    access_token = str(
        data.get("accessToken", "")
    ).strip()

    if not access_token:
        raise RuntimeError(
            "No access token found in OAuth token file."
        )

    return access_token


def save_account(account, permission_scope):
    ACCOUNT_FILE.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    data = {
        "ctidTraderAccountId": int(
            account.ctidTraderAccountId
        ),
        "brokerTitle": getattr(
            account,
            "brokerTitle",
            "",
        ),
        "isLive": bool(
            getattr(
                account,
                "isLive",
                False,
            )
        ),
        "permissionScope": str(
            permission_scope
        ),
        "hostType": HOST_TYPE,
    }

    ACCOUNT_FILE.write_text(
        json.dumps(
            data,
            indent=2,
        ),
        encoding="utf-8",
    )


class AccountAuthenticator:

    def __init__(self):
        self.client = None
        self.access_token = None
        self.accounts = []
        self.application_authorized = False

    # --------------------------------------------------------
    # CONNECTION
    # --------------------------------------------------------

    def connected(self, client):
        print()
        print("[CONNECTED]")
        print("cTrader Open API TCP connection established.")
        print()

        request = ProtoOAApplicationAuthReq()
        request.clientId = CLIENT_ID
        request.clientSecret = CLIENT_SECRET

        print("[1] Sending application authentication...")
        client.send(request)

    # --------------------------------------------------------
    # DISCONNECTION
    # --------------------------------------------------------

    def disconnected(self, client, reason):
        print()
        print("[DISCONNECTED]")
        print(reason)
        print()

    # --------------------------------------------------------
    # ERROR
    # --------------------------------------------------------

    def error(self, failure):
        print()
        print("[ERROR]")
        print(failure)
        print()

        try:
            reactor.stop()
        except Exception:
            pass

    # --------------------------------------------------------
    # MESSAGE HANDLER
    # --------------------------------------------------------

    def message_received(self, client, message):

        try:

            # ------------------------------------------------
            # APPLICATION AUTH RESPONSE
            # ------------------------------------------------

            if (
                message.payloadType
                == ProtoOAApplicationAuthRes().payloadType
            ):

                self.application_authorized = True

                print()
                print("[PASS] APPLICATION AUTHENTICATED")
                print()
                print(
                    "[2] Requesting accounts associated "
                    "with OAuth token..."
                )

                request = (
                    ProtoOAGetAccountListByAccessTokenReq()
                )

                request.accessToken = self.access_token

                client.send(request)

                return

            # ------------------------------------------------
            # ACCOUNT LIST RESPONSE
            # ------------------------------------------------

            if (
                message.payloadType
                == ProtoOAGetAccountListByAccessTokenRes().payloadType
            ):

                response = Protobuf.extract(message)

                self.accounts = list(
                    response.ctidTraderAccount
                )

                print()
                print(
                    f"[PASS] ACCOUNT LIST RECEIVED: "
                    f"{len(self.accounts)} account(s)"
                )
                print()

                if not self.accounts:
                    print(
                        "No cTrader accounts were returned "
                        "for this OAuth token."
                    )

                    reactor.stop()
                    return

                print("Available accounts:")
                print()

                for index, account in enumerate(
                    self.accounts,
                    start=1,
                ):

                    account_id = int(
                        account.ctidTraderAccountId
                    )

                    broker_title = getattr(
                        account,
                        "brokerTitle",
                        "",
                    )

                    is_live = getattr(
                        account,
                        "isLive",
                        False,
                    )

                    environment = (
                        "LIVE"
                        if is_live
                        else "DEMO"
                    )

                    print(
                        f"  [{index}] "
                        f"Account ID: {account_id} | "
                        f"Broker: {broker_title or 'N/A'} | "
                        f"Environment: {environment}"
                    )

                # ------------------------------------------------
                # SELECT ACCOUNT
                #
                # Prefer CTRADER_DEMO_ID from .env if it matches one
                # of the returned accounts (and is not flagged LIVE).
                # Otherwise fall back to the first DEMO account found.
                # ------------------------------------------------

                selected = None

                if PREFERRED_ACCOUNT_ID is not None:
                    for account in self.accounts:
                        if int(account.ctidTraderAccountId) == PREFERRED_ACCOUNT_ID:
                            if getattr(account, "isLive", False):
                                print(
                                    f"[WARNING] CTRADER_DEMO_ID={PREFERRED_ACCOUNT_ID} "
                                    "is flagged LIVE, not DEMO. Ignoring it and "
                                    "falling back to the first DEMO account."
                                )
                            else:
                                selected = account
                                print(
                                    f"[INFO] Using CTRADER_DEMO_ID from .env: "
                                    f"{PREFERRED_ACCOUNT_ID}"
                                )
                            break
                    else:
                        print(
                            f"[WARNING] CTRADER_DEMO_ID={PREFERRED_ACCOUNT_ID} "
                            "was not found in the returned account list. "
                            "Falling back to the first DEMO account."
                        )

                if selected is None:
                    for account in self.accounts:
                        if not getattr(account, "isLive", False):
                            selected = account
                            break

                if selected is None:
                    print(
                        "[FATAL] No DEMO account is available on this "
                        "OAuth token. Refusing to select a LIVE account "
                        "automatically."
                    )
                    reactor.stop()
                    return

                selected_id = int(
                    selected.ctidTraderAccountId
                )

                print()
                print(
                    f"Selecting account: {selected_id}"
                )
                print()

                request = ProtoOAAccountAuthReq()

                request.ctidTraderAccountId = selected_id
                request.accessToken = self.access_token

                print(
                    "[3] Authenticating selected account..."
                )

                client.send(request)

                return

            # ------------------------------------------------
            # ACCOUNT AUTH RESPONSE
            # ------------------------------------------------

            if (
                message.payloadType
                == ProtoOAAccountAuthRes().payloadType
            ):

                response = Protobuf.extract(message)

                account_id = int(
                    response.ctidTraderAccountId
                )

                print()
                print(
                    "================================================"
                )
                print(
                    " ACCOUNT AUTHENTICATION: SUCCESS"
                )
                print(
                    "================================================"
                )
                print()

                print(
                    f"Authorized account ID: {account_id}"
                )

                print(
                    f"Open API environment: {HOST_TYPE.upper()}"
                )

                print()
                print(
                    "Account session is now authorized."
                )

                # Find selected account metadata.
                selected = None

                for account in self.accounts:
                    if (
                        int(account.ctidTraderAccountId)
                        == account_id
                    ):
                        selected = account
                        break

                if selected is not None:
                    permission_scope = getattr(
                        selected,
                        "permissionScope",
                        "",
                    )

                    save_account(
                        selected,
                        permission_scope,
                    )

                print()
                print(
                    "Account authorization file:"
                )
                print(
                    f"  {ACCOUNT_FILE}"
                )

                print()
                print(
                    "NEXT DATA LAYER:"
                )
                print(
                    "  Symbol discovery"
                )
                print(
                    "  Symbol IDs"
                )
                print(
                    "  Current quotes"
                )
                print(
                    "  Live trendbars"
                )
                print(
                    "  Market depth / Level II"
                )

                print()
                print(
                    "SAFETY:"
                )
                print(
                    "  Trading permission: NOT REQUESTED"
                )
                print(
                    "  New order request:  NOT SENT"
                )
                print(
                    "  Order count:        0"
                )
                print(
                    "  Live execution:     DISABLED"
                )

                print()

                reactor.callLater(
                    1,
                    reactor.stop,
                )

                return

            # ------------------------------------------------
            # UNEXPECTED MESSAGE
            # ------------------------------------------------

            try:
                extracted = Protobuf.extract(message)

                print()
                print(
                    "[INFO] Received message:"
                )
                print(
                    type(extracted).__name__
                )

            except Exception:
                pass

        except Exception as exc:

            print()
            print(
                "[MESSAGE HANDLER ERROR]"
            )
            print(
                repr(exc)
            )
            print()

            try:
                reactor.stop()
            except Exception:
                pass


def main():

    print(
        "=" * 60
    )
    print(
        "HAFNOT cTRADER OPEN API - ACCOUNT AUTHENTICATION"
    )
    print(
        "=" * 60
    )
    print()

    if not CLIENT_ID:
        raise RuntimeError(
            "CTRADER_CLIENT_ID missing from .env"
        )

    if not CLIENT_SECRET:
        raise RuntimeError(
            "CTRADER_CLIENT_SECRET missing from .env"
        )

    access_token = load_access_token()

    print(
        f"Environment: {HOST_TYPE.upper()}"
    )

    print(
        f"Endpoint: {HOST}"
    )

    print(
        f"Port: {PORT}"
    )

    print(
        "Client ID: CONFIGURED"
    )

    print(
        "Client Secret: CONFIGURED (hidden)"
    )

    print(
        "Access Token: CONFIGURED (hidden)"
    )

    print()

    authenticator = AccountAuthenticator()

    authenticator.access_token = access_token

    client = Client(
        HOST,
        PORT,
        TcpProtocol,
    )

    authenticator.client = client

    client.setConnectedCallback(
        authenticator.connected
    )

    client.setDisconnectedCallback(
        authenticator.disconnected
    )

    client.setMessageReceivedCallback(
        authenticator.message_received
    )

    print(
        "Connecting to cTrader Open API..."
    )

    print(
        "No order submission capability is being used."
    )

    print()

    client.startService()

    reactor.run()


if __name__ == "__main__":
    main()
