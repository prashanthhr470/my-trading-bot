﻿from __future__ import annotations

import argparse
import json
import os
import secrets
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import requests
from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parents[3]
ENV_FILE = PROJECT_ROOT / ".env"
TOKEN_FILE = PROJECT_ROOT / "data" / "ctrader_oauth_tokens.json"

AUTH_BASE = "https://id.ctrader.com"
TOKEN_URL = "https://openapi.ctrader.com/apps/token"


def load_config() -> tuple[str, str, str]:
    load_dotenv(ENV_FILE)

    client_id = os.getenv("CTRADER_CLIENT_ID", "").strip()
    client_secret = os.getenv("CTRADER_CLIENT_SECRET", "").strip()
    redirect_uri = os.getenv("CTRADER_REDIRECT_URI", "").strip()

    missing = []

    if not client_id:
        missing.append("CTRADER_CLIENT_ID")

    if not client_secret:
        missing.append("CTRADER_CLIENT_SECRET")

    if not redirect_uri:
        missing.append("CTRADER_REDIRECT_URI")

    if missing:
        raise RuntimeError(
            "Missing required .env variables: " + ", ".join(missing)
        )

    return client_id, client_secret, redirect_uri


def build_authorization_url(
    client_id: str,
    redirect_uri: str,
    scope: str = "accounts",
    state: str | None = None,
) -> tuple[str, str]:
    if state is None:
        state = secrets.token_urlsafe(32)

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": scope,
        "product": "web",
        "state": state,
    }

    url = (
        f"{AUTH_BASE}/my/settings/openapi/grantingaccess/"
        f"?{urlencode(params)}"
    )

    return url, state


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    result: dict = {}

    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)

        code = query.get("code", [None])[0]
        state = query.get("state", [None])[0]
        error = query.get("error", [None])[0]

        OAuthCallbackHandler.result = {
            "code": code,
            "state": state,
            "error": error,
            "description": query.get("description", [None])[0],
        }

        body = """
        <!doctype html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>HAFNOT cTrader OAuth</title>
        </head>
        <body style="font-family:Arial;text-align:center;padding:60px">
            <h1>HAFNOT cTrader OAuth</h1>
            <p>Authentication response received.</p>
            <p>You can close this browser window and return to PowerShell.</p>
        </body>
        </html>
        """

        encoded = body.encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def log_message(self, format, *args):
        return


def callback_server(redirect_uri: str):
    parsed = urlparse(redirect_uri)

    if parsed.scheme != "http":
        raise RuntimeError(
            "This local OAuth helper expects an HTTP redirect URI."
        )

    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or 80

    server = HTTPServer(
        (host, port),
        OAuthCallbackHandler,
    )

    return server


def exchange_code(
    client_id: str,
    client_secret: str,
    redirect_uri: str,
    code: str,
) -> dict:
    params = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
        "client_id": client_id,
        "client_secret": client_secret,
    }

    response = requests.get(
        TOKEN_URL,
        params=params,
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
        timeout=30,
    )

    response.raise_for_status()

    data = response.json()

    if data.get("errorCode"):
        raise RuntimeError(
            f"cTrader token error: {data.get('errorCode')} - "
            f"{data.get('description')}"
        )

    if not data.get("accessToken"):
        raise RuntimeError(
            "cTrader did not return an access token."
        )

    return data


def save_tokens(token_data: dict, scope: str = "accounts"):
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)

    payload = {
        "accessToken": token_data.get("accessToken"),
        "refreshToken": token_data.get("refreshToken"),
        "tokenType": token_data.get("tokenType"),
        "expiresIn": token_data.get("expiresIn"),
        # Recorded so tools can tell a read-only token from a trading one before using it.
        "scope": scope,
        "savedAt": int(time.time()),
    }

    TOKEN_FILE.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    try:
        os.chmod(TOKEN_FILE, 0o600)
    except Exception:
        pass


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Authorize HAFNOT with the cTrader Open API.")
    parser.add_argument(
        "--scope", choices=("accounts", "trading"), default="accounts",
        help="accounts = read-only (default). trading = the token may place orders on the accounts "
             "you approve in the cTrader consent page - approve only your DEMO account.",
    )
    return parser.parse_args(argv)


def scope_label(scope: str) -> str:
    return "READ-ONLY" if scope == "accounts" else "TRADING (HAFNOT sends orders only to the DEMO server)"


def main(argv=None):
    args = parse_args(argv)

    print("=" * 60)
    print("HAFNOT cTRADER OAUTH AUTHENTICATION")
    print("=" * 60)
    print()

    client_id, client_secret, redirect_uri = load_config()

    print("Client ID:       CONFIGURED")
    print("Client Secret:   CONFIGURED")
    print("Redirect URI:    ", redirect_uri)
    print()

    # cTrader supports "accounts" (read-only) and "trading" scopes. Read-only is the
    # default; trading must be asked for explicitly with --scope trading.
    scope = args.scope

    authorization_url, expected_state = build_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_uri,
        scope=scope,
    )

    print("OAuth scope:")
    print(f"  {scope} ({scope_label(scope)})")
    print()

    if scope == "trading":
        print("WARNING: this token will be able to place orders on EVERY account you approve")
        print("in the cTrader consent page. Approve ONLY your DEMO account.")
        print("HAFNOT's order worker connects only to the DEMO server and refuses live accounts;")
        print("live execution stays disabled.")
        print()

    server = callback_server(redirect_uri)

    print("OAuth callback server:")
    print(f"  http://{server.server_address[0]}:{server.server_address[1]}")
    print()

    print("Opening cTrader authorization page...")
    print()

    webbrowser.open(authorization_url)

    print("Waiting for OAuth callback...")
    print("Complete the cTrader authorization in your browser.")
    print()

    server.timeout = 1

    start = time.time()

    while time.time() - start < 180:
        server.handle_request()

        result = OAuthCallbackHandler.result

        if result:
            break

    server.server_close()

    if not OAuthCallbackHandler.result:
        raise RuntimeError(
            "OAuth callback timeout. No authorization response was received."
        )

    result = OAuthCallbackHandler.result

    if result.get("error"):
        raise RuntimeError(
            f"OAuth authorization failed: {result.get('error')} "
            f"{result.get('description') or ''}"
        )

    returned_state = result.get("state")

    if returned_state and returned_state != expected_state:
        raise RuntimeError(
            "OAuth state validation failed."
        )

    code = result.get("code")

    if not code:
        raise RuntimeError(
            "OAuth callback did not contain an authorization code."
        )

    print("Authorization code received.")
    print("Exchanging authorization code for access token...")

    token_data = exchange_code(
        client_id=client_id,
        client_secret=client_secret,
        redirect_uri=redirect_uri,
        code=code,
    )

    save_tokens(token_data, scope=scope)

    print()
    print("=" * 60)
    print("CTRADER OAUTH: SUCCESS")
    print("=" * 60)
    print()

    print("Access token:    RECEIVED")
    print("Refresh token:   RECEIVED")
    print("Token storage:   ", TOKEN_FILE)
    print()
    print(f"OAuth scope:     {scope} ({scope_label(scope)})")
    print()
    print("No trading operation was performed.")
    print("No order was submitted.")
    print("Live execution remains DISABLED.")
    print()


if __name__ == "__main__":
    main()
