﻿"""
HAFNOT Liquidity Heatmap Engine.

Maintains historical resting-depth intensity by price level.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from typing import Any
import time


@dataclass
class HeatmapCell:
    price: float
    current_size: float
    average_size: float
    max_size: float
    persistence: float
    intensity: float


@dataclass
class HeatmapSnapshot:
    timestamp: float
    symbol: str
    cells: list[dict[str, Any]]
    strongest_bid_liquidity: dict[str, Any] | None
    strongest_ask_liquidity: dict[str, Any] | None

    def to_dict(self):
        return asdict(self)


class HeatmapEngine:

    def __init__(
        self,
        symbol: str = "XAUUSD",
        max_samples: int = 300,
    ):
        self.symbol = symbol
        self.max_samples = max_samples

        self.samples: dict[
            float,
            deque[float]
        ] = defaultdict(
            lambda: deque(
                maxlen=max_samples
            )
        )

    def update(
        self,
        bids: list[dict[str, Any]],
        asks: list[dict[str, Any]],
        timestamp: float | None = None,
    ) -> HeatmapSnapshot:

        now = timestamp or time.time()

        current = {}

        for side, levels in (
            ("bid", bids),
            ("ask", asks),
        ):

            for level in levels:

                price = float(level["price"])
                size = float(level.get("size", 0.0))

                self.samples[price].append(size)

                current.setdefault(
                    price,
                    {
                        "price": price,
                        "side": side,
                        "current_size": 0.0,
                    },
                )

                current[price]["current_size"] += size

        cells = []

        for price, data in current.items():

            history = self.samples[price]

            average = (
                sum(history) / len(history)
                if history
                else 0.0
            )

            maximum = max(
                history,
                default=0.0
            )

            persistence = (
                sum(
                    1
                    for x in history
                    if x > 0
                ) / len(history)
                if history
                else 0.0
            )

            intensity = (
                data["current_size"] / average
                if average > 0
                else 1.0
            )

            cells.append(
                HeatmapCell(
                    price=price,
                    current_size=data["current_size"],
                    average_size=average,
                    max_size=maximum,
                    persistence=persistence,
                    intensity=intensity,
                ).__dict__
            )

        bid_cells = [
            x for x in cells
            if any(
                abs(float(b["price"]) - x["price"]) < 1e-9
                for b in bids
            )
        ]

        ask_cells = [
            x for x in cells
            if any(
                abs(float(a["price"]) - x["price"]) < 1e-9
                for a in asks
            )
        ]

        strongest_bid = max(
            bid_cells,
            key=lambda x: x["current_size"],
            default=None,
        )

        strongest_ask = max(
            ask_cells,
            key=lambda x: x["current_size"],
            default=None,
        )

        return HeatmapSnapshot(
            timestamp=now,
            symbol=self.symbol,
            cells=sorted(
                cells,
                key=lambda x: x["price"]
            ),
            strongest_bid_liquidity=strongest_bid,
            strongest_ask_liquidity=strongest_ask,
        )
