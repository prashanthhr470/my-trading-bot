"""
HAFNOT cTrader Open API integration.

This package contains:
- OAuth/account authorization
- authenticated Open API connection
- live quotes
- live trendbars
- Level-II depth
- order-flow aggregation
- footprint data
- heatmap data
- paper-only execution bridge

REAL BROKER EXECUTION REMAINS HARD DISABLED.
"""
