import asyncio

from app.storage.trading_store import TradingStore
from app.analytics.performance import calculate_performance
from app.backtest.engine import BacktestEngine
from app.trade_management.manager import (
    ManagedTrade,
    TradeLifecycle,
    TradeManager,
)
from app.monitoring.health import HealthMonitor
from app.monitoring.forward_test import ForwardTestEngine
from app.agent.autonomous_loop import AutonomousLoop


def test_storage(tmp_path):
    store = TradingStore(str(tmp_path / "test.db"))
    store.store_market_snapshot("XAUUSD", {"price": 4300})
    store.store_ai_decision(
        "XAUUSD",
        {"decision": "WAIT", "confidence": "low"},
    )
    store.audit("TEST", "OK")

    assert store.count("market_snapshots") == 1
    assert store.count("ai_decisions") == 1
    assert store.count("audit_events") == 1


def test_analytics():
    result = calculate_performance([1, -1, 2, -0.5])
    assert result["trades"] == 4
    assert result["wins"] == 2
    assert result["losses"] == 2
    assert result["net_r"] == 1.5
    assert result["win_rate"] == 50.0


def test_backtest():
    bars = [
        {"high": 101, "low": 99},
        {"high": 103, "low": 100},
        {"high": 106, "low": 102},
    ]

    def signal_provider(bars, index):
        if index == 0:
            return {
                "direction": "BUY",
                "entry": 100,
                "stop_loss": 99,
                "take_profit": 102,
            }
        return None

    result = BacktestEngine().run(
        bars,
        signal_provider,
        "XAUUSD",
    )

    assert len(result["trades"]) == 1
    assert result["r_multiples"][0] == 2.0


def test_trade_lifecycle():
    manager = TradeManager()

    trade = ManagedTrade(
        symbol="XAUUSD",
        direction="BUY",
        entry=4300,
        stop_loss=4290,
        take_profit=4320,
    )

    manager.register("T1", trade)

    manager.transition("T1", TradeLifecycle.READY)
    manager.transition("T1", TradeLifecycle.OPEN)
    manager.transition("T1", TradeLifecycle.PROTECTED)
    manager.transition("T1", TradeLifecycle.CLOSED)

    assert manager.get("T1").state == TradeLifecycle.CLOSED


def test_health():
    health = HealthMonitor()
    health.report("MCP", "READY")
    health.report("AI", "READY")

    assert health.overall_state() == "READY"

    health.report("MCP", "BLOCKED", "connection refused")
    assert health.overall_state() == "BLOCKED"


def test_forward_testing():
    engine = ForwardTestEngine(10000)
    engine.record_trade(100)
    engine.record_trade(-50)

    snapshot = engine.snapshot()

    assert snapshot["equity"] == 10050
    assert snapshot["paper_trading"] is True
    assert snapshot["live_execution"] is False


def test_autonomous_loop():
    calls = []

    async def cycle():
        calls.append(1)

    async def run():
        loop = AutonomousLoop(
            cycle_callback=cycle,
            interval_seconds=1,
            max_cycles=2,
        )
        return await loop.run()

    result = asyncio.run(run())

    assert result.cycles == 2
    assert len(calls) == 2
    assert result.errors == 0
