"""Deterministic multi-timeframe market regime classifier."""
from __future__ import annotations
from typing import Any, Dict


def _trend(summary: Any) -> str:
    if not isinstance(summary, dict):
        return "unknown"
    return str(summary.get("trend", summary.get("bias", "unknown"))).lower()


def _atr(summary: Any) -> float | None:
    if not isinstance(summary, dict):
        return None
    try:
        return float(summary.get("atr_14"))
    except (TypeError, ValueError):
        return None


def classify_market_regime(timeframe_summaries: Dict[str, Any]) -> Dict[str, Any]:
    trends = [_trend(v) for v in timeframe_summaries.values()]
    bullish = sum(t == "bullish" for t in trends)
    bearish = sum(t == "bearish" for t in trends)
    known = bullish + bearish

    if known == 0:
        regime = "UNKNOWN"
        direction = "neutral"
    elif bullish >= max(3, bearish + 2):
        regime = "TREND_BULL"
        direction = "bullish"
    elif bearish >= max(3, bullish + 2):
        regime = "TREND_BEAR"
        direction = "bearish"
    elif known >= 3 and abs(bullish - bearish) <= 1:
        regime = "MIXED"
        direction = "neutral"
    else:
        regime = "TRANSITION"
        direction = "bullish" if bullish > bearish else "bearish"

    atrs = [x for x in (_atr(v) for v in timeframe_summaries.values()) if x is not None]
    volatility = "normal"
    if atrs:
        median = sorted(atrs)[len(atrs) // 2]
        if median > 25:
            volatility = "high"
        elif median < 5:
            volatility = "low"

    confidence = "high" if known >= 4 and regime not in {"MIXED", "UNKNOWN"} else (
        "moderate" if known >= 2 else "low"
    )

    return {
        "available": known > 0,
        "regime": regime,
        "direction": direction,
        "confidence": confidence,
        "volatility": volatility,
        "bullish_timeframes": bullish,
        "bearish_timeframes": bearish,
        "known_timeframes": known,
        "timeframes": {
            str(k).upper(): _trend(v) for k, v in timeframe_summaries.items()
        },
    }
