import pandas as pd


def find_swing_points(df, left=3, right=3):
    df = df.copy()

    df["swing_high"] = False
    df["swing_low"] = False

    for i in range(left, len(df) - right):

        current_high = df.iloc[i]["high"]
        current_low = df.iloc[i]["low"]

        left_highs = df.iloc[i-left:i]["high"]
        right_highs = df.iloc[i+1:i+right+1]["high"]

        left_lows = df.iloc[i-left:i]["low"]
        right_lows = df.iloc[i+1:i+right+1]["low"]

        if (
            current_high > left_highs.max()
            and current_high > right_highs.max()
        ):
            df.loc[df.index[i], "swing_high"] = True

        if (
            current_low < left_lows.min()
            and current_low < right_lows.min()
        ):
            df.loc[df.index[i], "swing_low"] = True

    return df


def determine_structure(df):
    swing_highs = df[df["swing_high"]].copy()
    swing_lows = df[df["swing_low"]].copy()

    high_pattern = "unknown"
    low_pattern = "unknown"

    # ---------------------------------------------------------
    # RECENT STRUCTURE
    # ---------------------------------------------------------

    if len(swing_highs) >= 2:

        previous_high = swing_highs.iloc[-2]["high"]
        latest_high = swing_highs.iloc[-1]["high"]

        if latest_high > previous_high:
            high_pattern = "higher_high"

        elif latest_high < previous_high:
            high_pattern = "lower_high"

    if len(swing_lows) >= 2:

        previous_low = swing_lows.iloc[-2]["low"]
        latest_low = swing_lows.iloc[-1]["low"]

        if latest_low > previous_low:
            low_pattern = "higher_low"

        elif latest_low < previous_low:
            low_pattern = "lower_low"

    # ---------------------------------------------------------
    # RECENT STRUCTURE CLASSIFICATION
    # ---------------------------------------------------------

    if high_pattern == "higher_high" and low_pattern == "higher_low":
        recent_structure = "bullish"

    elif high_pattern == "lower_high" and low_pattern == "lower_low":
        recent_structure = "bearish"

    elif high_pattern == "unknown" or low_pattern == "unknown":
        recent_structure = "insufficient_data"

    else:
        recent_structure = "mixed"

    # ---------------------------------------------------------
    # DOMINANT STRUCTURE
    #
    # Look at several historical swings instead of only the
    # latest two. This prevents one short-term retracement from
    # completely changing the structural classification.
    # ---------------------------------------------------------

    dominant_structure = "insufficient_data"

    if len(swing_highs) >= 4 and len(swing_lows) >= 4:

        high_values = swing_highs["high"].tolist()
        low_values = swing_lows["low"].tolist()

        higher_highs = 0
        lower_highs = 0

        higher_lows = 0
        lower_lows = 0

        for i in range(1, len(high_values)):

            if high_values[i] > high_values[i - 1]:
                higher_highs += 1

            elif high_values[i] < high_values[i - 1]:
                lower_highs += 1

        for i in range(1, len(low_values)):

            if low_values[i] > low_values[i - 1]:
                higher_lows += 1

            elif low_values[i] < low_values[i - 1]:
                lower_lows += 1

        bullish_score = higher_highs + higher_lows
        bearish_score = lower_highs + lower_lows

        if bullish_score > bearish_score:
            dominant_structure = "bullish"

        elif bearish_score > bullish_score:
            dominant_structure = "bearish"

        else:
            dominant_structure = "mixed"

    # ---------------------------------------------------------
    # FINAL STRUCTURE
    #
    # Dominant structure has priority over a recent corrective
    # move.
    # ---------------------------------------------------------

    if dominant_structure in ("bullish", "bearish"):

        structure = dominant_structure

    else:

        structure = recent_structure

    # ---------------------------------------------------------
    # STRUCTURE CONTEXT
    #
    # This tells the AI whether recent movement is potentially
    # a retracement against the dominant structure.
    # ---------------------------------------------------------

    if (
        dominant_structure == "bearish"
        and recent_structure == "bullish"
    ):
        structure_context = "bullish_retracement"

    elif (
        dominant_structure == "bullish"
        and recent_structure == "bearish"
    ):
        structure_context = "bearish_retracement"

    elif (
        dominant_structure == recent_structure
        and dominant_structure in ("bullish", "bearish")
    ):
        structure_context = "trend_continuation"

    elif dominant_structure == "mixed":
        structure_context = "mixed_structure"

    else:
        structure_context = "insufficient_data"

    return {
        "structure": structure,
        "dominant_structure": dominant_structure,
        "recent_structure": recent_structure,
        "structure_context": structure_context,
        "high_pattern": high_pattern,
        "low_pattern": low_pattern,
        "swing_high_count": len(swing_highs),
        "swing_low_count": len(swing_lows),
    }