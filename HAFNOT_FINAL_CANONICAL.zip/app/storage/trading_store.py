from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Optional


class TradingStore:
    """Persistent SQLite storage for market, decisions, plans, trades and audit events."""

    def __init__(self, db_path: str = "data/hafnot_trading.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize(self):
        with self._connect() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS market_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                symbol TEXT NOT NULL,
                payload TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS ai_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                symbol TEXT NOT NULL,
                decision TEXT,
                confidence TEXT,
                payload TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS trade_plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                symbol TEXT NOT NULL,
                status TEXT,
                direction TEXT,
                entry REAL,
                stop_loss REAL,
                take_profit REAL,
                risk_percent REAL,
                reward_risk REAL,
                payload TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                symbol TEXT NOT NULL,
                event TEXT NOT NULL,
                payload TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                component TEXT NOT NULL,
                event TEXT NOT NULL,
                severity TEXT NOT NULL,
                payload TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_market_symbol
            ON market_snapshots(symbol, timestamp);

            CREATE INDEX IF NOT EXISTS idx_ai_symbol
            ON ai_decisions(symbol, timestamp);

            CREATE INDEX IF NOT EXISTS idx_audit_time
            ON audit_events(timestamp);
            """)

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _json(payload: Any):
        return json.dumps(payload, default=str, ensure_ascii=False)

    def store_market_snapshot(self, symbol: str, payload: dict):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO market_snapshots(timestamp,symbol,payload) VALUES(?,?,?)",
                (self._now(), symbol.upper(), self._json(payload)),
            )

    def store_ai_decision(self, symbol: str, decision: dict):
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO ai_decisions
                   (timestamp,symbol,decision,confidence,payload)
                   VALUES(?,?,?,?,?)""",
                (
                    self._now(),
                    symbol.upper(),
                    decision.get("decision"),
                    decision.get("confidence"),
                    self._json(decision),
                ),
            )

    def store_trade_plan(self, symbol: str, plan: dict):
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO trade_plans
                   (timestamp,symbol,status,direction,entry,stop_loss,
                    take_profit,risk_percent,reward_risk,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    self._now(),
                    symbol.upper(),
                    plan.get("status"),
                    plan.get("direction"),
                    plan.get("entry"),
                    plan.get("stop_loss"),
                    plan.get("take_profit"),
                    plan.get("risk_percent"),
                    plan.get("reward_risk"),
                    self._json(plan),
                ),
            )

    def store_trade_event(self, symbol: str, event: str, payload: dict):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO trades(timestamp,symbol,event,payload) VALUES(?,?,?,?)",
                (self._now(), symbol.upper(), event, self._json(payload)),
            )

    def audit(self, component: str, event: str,
              payload: Optional[dict] = None,
              severity: str = "INFO"):
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO audit_events
                   (timestamp,component,event,severity,payload)
                   VALUES(?,?,?,?,?)""",
                (
                    self._now(),
                    component,
                    event,
                    severity,
                    self._json(payload or {}),
                ),
            )

    def recent_audit(self, limit: int = 100):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM audit_events ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]

    def count(self, table: str):
        allowed = {
            "market_snapshots",
            "ai_decisions",
            "trade_plans",
            "trades",
            "audit_events",
        }
        if table not in allowed:
            raise ValueError("Invalid table")
        with self._connect() as conn:
            return conn.execute(
                f"SELECT COUNT(*) FROM {table}"
            ).fetchone()[0]
