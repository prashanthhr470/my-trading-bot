import numpy as np
import pandas as pd


def calculate_indicators(bars):
    """
    Convert OHLCV candle data into a DataFrame
    and calculate basic market indicators.
    """

    df = pd.DataFrame(bars)

    if df.empty:
        raise ValueError("No candle data received.")

    # Make sure numbers are numeric
    for column in ["open", "high", "low", "close", "volume"]:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    # Remove incomplete rows
    df = df.dropna().copy()

    # -------------------------
    # Moving averages
    # -------------------------

    df["sma_20"] = df["close"].rolling(20).mean()
    df["sma_50"] = df["close"].rolling(50).mean()

    # -------------------------
    # EMA
    # -------------------------

    df["ema_20"] = df["close"].ewm(
        span=20,
        adjust=False
    ).mean()

    df["ema_50"] = df["close"].ewm(
        span=50,
        adjust=False
    ).mean()

    # -------------------------
    # RSI
    # -------------------------

    change = df["close"].diff()

    gain = change.clip(lower=0)
    loss = -change.clip(upper=0)

    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()

    rs = avg_gain / avg_loss.replace(0, np.nan)

    df["rsi_14"] = 100 - (100 / (1 + rs))

    # -------------------------
    # ATR
    # -------------------------

    previous_close = df["close"].shift(1)

    tr1 = df["high"] - df["low"]
    tr2 = (df["high"] - previous_close).abs()
    tr3 = (df["low"] - previous_close).abs()

    true_range = pd.concat(
        [tr1, tr2, tr3],
        axis=1
    ).max(axis=1)

    df["atr_14"] = true_range.rolling(14).mean()

    # -------------------------
    # Volume average
    # -------------------------

    df["volume_sma_20"] = df["volume"].rolling(20).mean()

    # -------------------------
    # Returns
    # -------------------------

    df["return_1"] = df["close"].pct_change()

    # Remove rows where indicators
    # cannot yet be calculated
    df = df.dropna().reset_index(drop=True)

    return df


def create_market_summary(df):
    """
    Create a market summary using EMA direction and
    ATR-normalized EMA separation.
    """

    if df.empty:
        raise ValueError("No indicator data available.")

    latest = df.iloc[-1]

    ema_20 = float(latest["ema_20"])
    ema_50 = float(latest["ema_50"])
    atr_14 = float(latest["atr_14"])

    # -------------------------
    # EMA TREND
    # -------------------------

    ema_difference = ema_20 - ema_50

    # Normalize EMA separation by ATR
    if atr_14 > 0:
        ema_separation_atr = (
            abs(ema_difference) / atr_14
        )
    else:
        ema_separation_atr = 0.0

    # Minimum meaningful EMA separation
    trend_threshold = 0.05

    if ema_separation_atr < trend_threshold:
        trend = "neutral"

    elif ema_difference > 0:
        trend = "bullish"

    else:
        trend = "bearish"

    # -------------------------
    # RSI MOMENTUM
    # -------------------------

    rsi_14 = float(latest["rsi_14"])

    if rsi_14 >= 70:
        momentum = "overbought"

    elif rsi_14 <= 30:
        momentum = "oversold"

    else:
        momentum = "neutral"

    # -------------------------
    # VOLUME
    # -------------------------

    volume = float(latest["volume"])
    average_volume_20 = float(
        latest["volume_sma_20"]
    )

    if volume > average_volume_20:
        volume_condition = "above_average"

    else:
        volume_condition = "below_average"

    # -------------------------
    # SUMMARY
    # -------------------------

    return {
        "close": float(latest["close"]),

        "ema_20": ema_20,
        "ema_50": ema_50,

        "ema_difference": float(
            ema_difference
        ),

        "ema_separation_atr": float(
            ema_separation_atr
        ),

        "rsi_14": rsi_14,
        "atr_14": atr_14,

        "volume": volume,

        "average_volume_20": (
            average_volume_20
        ),

        "trend": trend,
        "momentum": momentum,
        "volume_condition": volume_condition,
    }