"""
HAFNOT AI TRADING AGENT
PAIR-LEVEL FUNDAMENTAL RISK ENGINE V5

Purpose
-------
Combines:

1. Currency/event data from:
       data/fundamental/fundamental_snapshot.json

2. Pair-level fundamental bias from:
       data/fundamental/pair_fundamental_snapshot.json

3. Upcoming-event timing and importance.

This module ONLY calculates fundamental risk.

It DOES NOT:
    - place orders
    - modify broker state
    - enable live trading
    - execute trades
    - override the final execution safety system
"""

from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ============================================================================
# PATHS
# ============================================================================

FUNDAMENTAL_SNAPSHOT_PATH = Path(
    "data/fundamental/fundamental_snapshot.json"
)

PAIR_FUNDAMENTAL_SNAPSHOT_PATH = Path(
    "data/fundamental/pair_fundamental_snapshot.json"
)

OUTPUT_PATH = Path(
    "data/fundamental/pair_fundamental_risk_snapshot.json"
)


# ============================================================================
# SUPPORTED PAIRS
# ============================================================================

SUPPORTED_PAIRS = {
    "USDJPY": ("USD", "JPY"),
    "GBPUSD": ("GBP", "USD"),
    "AUDUSD": ("AUD", "USD"),
    "GBPJPY": ("GBP", "JPY"),
    "AUDJPY": ("AUD", "JPY"),
    "GBPAUD": ("GBP", "AUD"),
}


# ============================================================================
# EVENT IMPACT
# ============================================================================

IMPACT_WEIGHTS = {
    "HIGH": 1.00,
    "MEDIUM": 0.65,
    "LOW": 0.25,
    "HOLIDAY": 0.10,
    "OTHER": 0.10,
    "UNKNOWN": 0.10,
}


# ============================================================================
# RISK WINDOWS
#
# These are deliberately conservative but do not treat every future
# high-impact event as an immediate trading block.
# ============================================================================

IMMEDIATE_HIGH_MINUTES = 60

NEAR_HIGH_MINUTES = 360

NEAR_MEDIUM_MINUTES = 180

WATCH_HIGH_MINUTES = 1440


# ============================================================================
# GENERAL HELPERS
# ============================================================================

def _safe_float(value: Any) -> float | None:
    """
    Safely convert a value to float.
    """

    if value is None:
        return None

    if isinstance(value, bool):
        return None

    try:
        number = float(value)

        if not math.isfinite(number):
            return None

        return number

    except (TypeError, ValueError):
        return None


def _parse_datetime(value: Any) -> datetime | None:
    """
    Parse:

        ISO-8601
        ISO-8601 with Z
        timezone-aware strings
        timezone-naive strings
        Unix seconds
        Unix milliseconds
    """

    if value is None:
        return None

    if isinstance(value, datetime):

        dt = value

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=timezone.utc
            )

        return dt.astimezone(
            timezone.utc
        )

    if isinstance(value, (int, float)):

        number = float(value)

        if not math.isfinite(number):
            return None

        if abs(number) > 100_000_000_000:
            number /= 1000.0

        try:
            return datetime.fromtimestamp(
                number,
                tz=timezone.utc,
            )
        except (
            OverflowError,
            OSError,
            ValueError,
        ):
            return None

    if not isinstance(value, str):
        return None

    text = value.strip()

    if not text:
        return None

    if text.endswith("Z"):
        text = (
            text[:-1]
            + "+00:00"
        )

    try:

        dt = datetime.fromisoformat(
            text
        )

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=timezone.utc
            )

        return dt.astimezone(
            timezone.utc
        )

    except ValueError:
        pass

    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
    ]

    for fmt in formats:

        try:

            dt = datetime.strptime(
                text,
                fmt,
            )

            return dt.replace(
                tzinfo=timezone.utc
            )

        except ValueError:
            continue

    return None


# ============================================================================
# EVENT FIELD EXTRACTION
# ============================================================================

def _get_currency(
    event: dict[str, Any],
) -> str:

    value = (
        event.get("currency")
        or event.get("country")
        or event.get("currency_code")
        or ""
    )

    return str(
        value
    ).upper().strip()


def _get_title(
    event: dict[str, Any],
) -> str:

    return str(
        event.get("title")
        or event.get("event")
        or event.get("name")
        or "Unknown Event"
    )


def _get_impact(
    event: dict[str, Any],
) -> str:

    value = (
        event.get("impact_normalized")
        or event.get("impact")
        or event.get("importance")
        or "UNKNOWN"
    )

    return str(
        value
    ).upper().strip()


def _get_event_type(
    event: dict[str, Any],
) -> str:

    return str(
        event.get("event_type")
        or event.get("category")
        or "other"
    ).lower().strip()


def _get_release_status(
    event: dict[str, Any],
) -> str:

    return str(
        event.get("release_status")
        or ""
    ).upper().strip()


def _get_event_datetime(
    event: dict[str, Any],
) -> datetime | None:
    """
    IMPORTANT:
    The current fundamental engine stores:

        datetime_utc

    This is the primary field.
    """

    fields = [
        "datetime_utc",
        "event_datetime",
        "timestamp",
        "datetime",
        "date",
        "time",
    ]

    for field in fields:

        if field not in event:
            continue

        dt = _parse_datetime(
            event.get(field)
        )

        if dt is not None:
            return dt

    return None


def _get_economic_importance(
    event: dict[str, Any],
) -> float:

    value = _safe_float(
        event.get(
            "economic_importance"
        )
    )

    if value is not None:

        return max(
            0.0,
            min(
                1.0,
                value,
            ),
        )

    category = str(
        event.get(
            "economic_importance_class"
        )
        or ""
    ).upper()

    if category in {
        "HIGH",
        "CENTRAL_BANK",
    }:
        return 1.0

    if category == "MEDIUM":
        return 0.70

    if category == "LOW":
        return 0.35

    return 0.15


# ============================================================================
# EVENT WEIGHTS
# ============================================================================

def _impact_weight(
    impact: str,
) -> float:

    return IMPACT_WEIGHTS.get(
        impact.upper(),
        IMPACT_WEIGHTS["UNKNOWN"],
    )


def _proximity_weight(
    minutes_until: float | None,
) -> float:
    """
    Time proximity weight.

    Closer = larger value.

    This is used for severity calculation only.
    It is NOT the final trading block rule.
    """

    if minutes_until is None:
        return 0.0

    if minutes_until < 0:
        return 0.0

    if minutes_until <= 60:
        return 1.0

    if minutes_until <= 180:
        return 0.75

    if minutes_until <= 360:
        return 0.55

    if minutes_until <= 720:
        return 0.30

    if minutes_until <= 1440:
        return 0.15

    return 0.05


# ============================================================================
# EVENT SEVERITY
# ============================================================================

def calculate_event_severity(
    event: dict[str, Any],
    now: datetime | None = None,
) -> dict[str, Any]:
    """
    Calculate event severity.

    Important distinction:

        impact
        +
        economic importance
        +
        time proximity

    are separate concepts.

    A HIGH event 45 hours away should not be treated the same
    as a HIGH event 30 minutes away.
    """

    if now is None:

        now = datetime.now(
            timezone.utc
        )

    if now.tzinfo is None:

        now = now.replace(
            tzinfo=timezone.utc
        )

    now = now.astimezone(
        timezone.utc
    )

    event_datetime = _get_event_datetime(
        event
    )

    minutes_until = None

    timing_status = (
        "TIME_UNKNOWN"
    )

    if event_datetime is not None:

        minutes_until = (
            event_datetime - now
        ).total_seconds() / 60.0

        if minutes_until >= 0:
            timing_status = "FUTURE"
        else:
            timing_status = "PAST"

    impact = _get_impact(
        event
    )

    impact_weight = _impact_weight(
        impact
    )

    economic_importance = (
        _get_economic_importance(
            event
        )
    )

    proximity = _proximity_weight(
        minutes_until
    )

    # Calendar impact is primary.
    #
    # Economic importance is allowed to increase the severity,
    # but only moderately.
    importance_factor = (
        0.70
        + (
            0.30
            * economic_importance
        )
    )

    severity = (
        impact_weight
        * proximity
        * importance_factor
    )

    if timing_status == "PAST":
        severity = 0.0

    return {
        "title": _get_title(event),
        "currency": _get_currency(event),
        "impact": impact,
        "event_type": _get_event_type(event),
        "economic_importance": round(
            economic_importance,
            4,
        ),
        "datetime_utc": (
            event_datetime.isoformat()
            if event_datetime
            else None
        ),
        "minutes_until": (
            round(
                minutes_until,
                2,
            )
            if minutes_until is not None
            else None
        ),
        "timing_status": timing_status,
        "impact_weight": round(
            impact_weight,
            4,
        ),
        "proximity_weight": round(
            proximity,
            4,
        ),
        "severity": round(
            max(
                0.0,
                min(
                    1.0,
                    severity,
                ),
            ),
            4,
        ),
    }


# ============================================================================
# LOAD FUNDAMENTAL EVENTS
# ============================================================================

def load_fundamental_snapshot() -> dict[str, Any]:

    if not FUNDAMENTAL_SNAPSHOT_PATH.exists():

        raise FileNotFoundError(
            "Fundamental snapshot not found: "
            f"{FUNDAMENTAL_SNAPSHOT_PATH}"
        )

    with FUNDAMENTAL_SNAPSHOT_PATH.open(
        "r",
        encoding="utf-8",
    ) as file:

        return json.load(
            file
        )


def extract_events(
    snapshot: dict[str, Any],
) -> list[dict[str, Any]]:

    events = snapshot.get(
        "events"
    )

    if not isinstance(
        events,
        list,
    ):
        return []

    return [
        event
        for event in events
        if isinstance(
            event,
            dict,
        )
    ]


# ============================================================================
# LOAD PAIR FUNDAMENTAL SNAPSHOT
# ============================================================================

def load_pair_fundamental_snapshot() -> dict[str, Any]:

    if not PAIR_FUNDAMENTAL_SNAPSHOT_PATH.exists():

        raise FileNotFoundError(
            "Pair fundamental snapshot not found: "
            f"{PAIR_FUNDAMENTAL_SNAPSHOT_PATH}"
        )

    with PAIR_FUNDAMENTAL_SNAPSHOT_PATH.open(
        "r",
        encoding="utf-8",
    ) as file:

        return json.load(
            file
        )


def _find_pair_container(
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    """
    Locate the pair results regardless of the exact top-level
    container used by the pair fundamental engine.
    """

    possible_keys = [
        "pairs",
        "pair_results",
        "results",
        "pair_fundamentals",
    ]

    for key in possible_keys:

        value = snapshot.get(
            key
        )

        if isinstance(
            value,
            dict,
        ):
            return value

    return {}


def extract_pair_fundamental(
    snapshot: dict[str, Any],
    pair: str,
) -> dict[str, Any]:
    """
    Read the actual pair-level fundamental result.

    Supports the existing pair snapshot and several compatible
    layouts.
    """

    pair = pair.upper().strip()

    container = _find_pair_container(
        snapshot
    )

    result = container.get(
        pair
    )

    if isinstance(
        result,
        dict,
    ):
        return result

    # Some possible nested structures.
    for key in [
        "pair",
        "analysis",
        "fundamental",
        "result",
    ]:

        nested = snapshot.get(
            key
        )

        if isinstance(
            nested,
            dict,
        ):

            result = nested.get(
                pair
            )

            if isinstance(
                result,
                dict,
            ):
                return result

    # Safe fallback.
    return {
        "pair": pair,
        "direction": "NEUTRAL",
        "pair_score": 0.0,
        "strength": 0.0,
        "confidence": "NONE",
        "conflict": True,
        "actionable": False,
        "bias": "NO_EDGE",
    }


# ============================================================================
# NORMALIZE PAIR FUNDAMENTAL RESULT
# ============================================================================

def normalize_pair_fundamental(
    pair: str,
    raw: dict[str, Any],
) -> dict[str, Any]:
    """
    Normalize pair fundamental fields.

    This handles naming differences such as:

        pair_score
        score

        strength
        fundamental_strength

        direction
        fundamental_direction
    """

    score = _safe_float(
        raw.get(
            "pair_score"
        )
    )

    if score is None:

        score = _safe_float(
            raw.get(
                "score"
            )
        )

    if score is None:

        score = _safe_float(
            raw.get(
                "fundamental_score"
            )
        )

    if score is None:
        score = 0.0

    strength = _safe_float(
        raw.get(
            "strength"
        )
    )

    if strength is None:

        strength = _safe_float(
            raw.get(
                "fundamental_strength"
            )
        )

    if strength is None:
        strength = abs(
            score
        )

    direction = str(
        raw.get(
            "direction"
        )
        or raw.get(
            "fundamental_direction"
        )
        or ""
    ).upper().strip()

    if direction not in {
        "BULLISH",
        "BEARISH",
        "NEUTRAL",
    }:

        if score > 0.05:
            direction = "BULLISH"

        elif score < -0.05:
            direction = "BEARISH"

        else:
            direction = "NEUTRAL"

    confidence = str(
        raw.get(
            "confidence"
        )
        or raw.get(
            "fundamental_confidence"
        )
        or "NONE"
    ).upper().strip()

    conflict = bool(
        raw.get(
            "conflict",
            raw.get(
                "fundamental_conflict",
                False,
            ),
        )
    )

    bias = str(
        raw.get(
            "bias"
        )
        or ""
    ).upper().strip()

    actionable = bool(
        raw.get(
            "actionable",
            False,
        )
    )

    return {
        "pair": pair,
        "direction": direction,
        "pair_score": round(
            max(
                -1.0,
                min(
                    1.0,
                    score,
                ),
            ),
            4,
        ),
        "strength": round(
            max(
                0.0,
                min(
                    1.0,
                    abs(strength),
                ),
            ),
            4,
        ),
        "confidence": confidence,
        "conflict": conflict,
        "bias": bias,
        "actionable": actionable,
        "raw": raw,
    }


# ============================================================================
# UPCOMING EVENTS FOR PAIR
# ============================================================================

def get_pair_upcoming_events(
    pair: str,
    events: list[dict[str, Any]],
    now: datetime | None = None,
) -> tuple[
    list[dict[str, Any]],
    dict[str, int],
]:

    pair = pair.upper().strip()

    if pair not in SUPPORTED_PAIRS:

        raise ValueError(
            f"Unsupported pair: {pair}"
        )

    base_currency, quote_currency = (
        SUPPORTED_PAIRS[pair]
    )

    if now is None:

        now = datetime.now(
            timezone.utc
        )

    if now.tzinfo is None:

        now = now.replace(
            tzinfo=timezone.utc
        )

    now = now.astimezone(
        timezone.utc
    )

    diagnostics = {
        "total_events": len(events),
        "upcoming_status": 0,
        "currency_matches": 0,
        "datetime_parsed": 0,
        "future_events": 0,
        "past_events": 0,
        "unknown_time_events": 0,
    }

    relevant = []

    for event in events:

        status = _get_release_status(
            event
        )

        if status != "UPCOMING":
            continue

        diagnostics[
            "upcoming_status"
        ] += 1

        currency = _get_currency(
            event
        )

        if currency not in {
            base_currency,
            quote_currency,
        }:
            continue

        diagnostics[
            "currency_matches"
        ] += 1

        event_datetime = (
            _get_event_datetime(
                event
            )
        )

        if event_datetime is not None:

            diagnostics[
                "datetime_parsed"
            ] += 1

            if event_datetime >= now:

                diagnostics[
                    "future_events"
                ] += 1

            else:

                diagnostics[
                    "past_events"
                ] += 1

        else:

            diagnostics[
                "unknown_time_events"
            ] += 1

        severity = calculate_event_severity(
            event,
            now,
        )

        if (
            severity["timing_status"]
            == "PAST"
        ):
            continue

        side = (
            "BASE"
            if currency == base_currency
            else "QUOTE"
        )

        relevant.append(
            {
                **severity,
                "side": side,
                "release_status": status,
            }
        )

    relevant.sort(
        key=lambda event: (
            -event["severity"],
            (
                event["minutes_until"]
                if event["minutes_until"]
                is not None
                else float("inf")
            ),
        )
    )

    return (
        relevant,
        diagnostics,
    )


# ============================================================================
# SEVERITY AGGREGATION
# ============================================================================

def _maximum_severity(
    events: list[dict[str, Any]],
) -> float:

    if not events:
        return 0.0

    return max(
        float(
            event.get(
                "severity",
                0.0,
            )
        )
        for event in events
    )


def _combined_severity(
    events: list[dict[str, Any]],
) -> float:
    """
    Combine multiple event risks:

        1 - product(1 - severity)

    This captures clustering without simply adding values.
    """

    if not events:
        return 0.0

    remaining = 1.0

    for event in events:

        severity = max(
            0.0,
            min(
                1.0,
                float(
                    event.get(
                        "severity",
                        0.0,
                    )
                ),
            ),
        )

        remaining *= (
            1.0 - severity
        )

    return 1.0 - remaining


# ============================================================================
# EVENT CLASSIFICATION
# ============================================================================

def classify_event_risk(
    event: dict[str, Any],
) -> str:
    """
    Classify individual event according to both impact and time.

    Returns:

        BLOCK
        HIGH_RISK
        CAUTION
        WATCH
        LOW
    """

    impact = event[
        "impact"
    ]

    minutes = event[
        "minutes_until"
    ]

    if minutes is None:

        if impact == "HIGH":
            return "CAUTION"

        if impact == "MEDIUM":
            return "CAUTION"

        return "LOW"

    if minutes < 0:
        return "LOW"

    # ---------------------------------------------------------------
    # HIGH
    # ---------------------------------------------------------------

    if impact == "HIGH":

        if (
            minutes
            <= IMMEDIATE_HIGH_MINUTES
        ):
            return "BLOCK"

        if (
            minutes
            <= NEAR_HIGH_MINUTES
        ):
            return "HIGH_RISK"

        if (
            minutes
            <= WATCH_HIGH_MINUTES
        ):
            return "WATCH"

        return "LOW"

    # ---------------------------------------------------------------
    # MEDIUM
    # ---------------------------------------------------------------

    if impact == "MEDIUM":

        if (
            minutes
            <= NEAR_MEDIUM_MINUTES
        ):
            return "CAUTION"

        if (
            minutes
            <= WATCH_HIGH_MINUTES
        ):
            return "WATCH"

        return "LOW"

    # ---------------------------------------------------------------
    # LOW / OTHER
    # ---------------------------------------------------------------

    if impact in {
        "LOW",
        "OTHER",
        "HOLIDAY",
        "UNKNOWN",
    }:

        if (
            minutes is not None
            and minutes <= 60
            and impact == "LOW"
        ):
            return "WATCH"

        return "LOW"

    return "LOW"


# ============================================================================
# PAIR RISK
# ============================================================================

def calculate_pair_risk(
    pair: str,
    pair_fundamental: dict[str, Any],
    events: list[dict[str, Any]],
    now: datetime | None = None,
) -> dict[str, Any]:

    pair = pair.upper().strip()

    if now is None:

        now = datetime.now(
            timezone.utc
        )

    if now.tzinfo is None:

        now = now.replace(
            tzinfo=timezone.utc
        )

    now = now.astimezone(
        timezone.utc
    )

    normalized_fundamental = (
        normalize_pair_fundamental(
            pair,
            pair_fundamental,
        )
    )

    upcoming, diagnostics = (
        get_pair_upcoming_events(
            pair,
            events,
            now,
        )
    )

    base_currency, quote_currency = (
        SUPPORTED_PAIRS[pair]
    )

    base_events = [
        event
        for event in upcoming
        if event["currency"]
        == base_currency
    ]

    quote_events = [
        event
        for event in upcoming
        if event["currency"]
        == quote_currency
    ]

    # Add risk class to every event.
    classified_events = []

    for event in upcoming:

        classified = {
            **event,
            "risk_class": classify_event_risk(
                event
            ),
        }

        classified_events.append(
            classified
        )

    upcoming = classified_events

    blocking_events = [
        event
        for event in upcoming
        if event["risk_class"]
        == "BLOCK"
    ]

    high_risk_events = [
        event
        for event in upcoming
        if event["risk_class"]
        == "HIGH_RISK"
    ]

    caution_events = [
        event
        for event in upcoming
        if event["risk_class"]
        == "CAUTION"
    ]

    watch_events = [
        event
        for event in upcoming
        if event["risk_class"]
        == "WATCH"
    ]

    unknown_time_events = [
        event
        for event in upcoming
        if event["timing_status"]
        == "TIME_UNKNOWN"
    ]

    maximum_severity = (
        _maximum_severity(
            upcoming
        )
    )

    combined_severity = (
        _combined_severity(
            upcoming
        )
    )

    direction = (
        normalized_fundamental[
            "direction"
        ]
    )

    score = (
        normalized_fundamental[
            "pair_score"
        ]
    )

    strength = (
        normalized_fundamental[
            "strength"
        ]
    )

    confidence = (
        normalized_fundamental[
            "confidence"
        ]
    )

    conflict = (
        normalized_fundamental[
            "conflict"
        ]
    )

    # ========================================================================
    # FINAL RISK DECISION
    # ========================================================================

    risk_level = "CLEAR"

    trade_allowed = True

    reason = (
        "No material upcoming fundamental "
        "event risk was identified."
    )

    # ------------------------------------------------------------------------
    # 1. Immediate high-impact event
    # ------------------------------------------------------------------------

    if blocking_events:

        risk_level = "BLOCKED"

        trade_allowed = False

        reason = (
            "A high-impact economic event is "
            "within the immediate risk window."
        )

    # ------------------------------------------------------------------------
    # 2. High-impact event in near window
    # ------------------------------------------------------------------------

    elif high_risk_events:

        risk_level = "HIGH_RISK"

        trade_allowed = False

        reason = (
            "A high-impact economic event is "
            "approaching within the near-risk window."
        )

    # ------------------------------------------------------------------------
    # 3. Unknown event time
    # ------------------------------------------------------------------------

    elif unknown_time_events:

        risk_level = "CAUTION"

        trade_allowed = False

        reason = (
            "A relevant upcoming event exists but "
            "its release time could not be verified."
        )

    # ------------------------------------------------------------------------
    # 4. Medium event approaching
    # ------------------------------------------------------------------------

    elif caution_events:

        risk_level = "CAUTION"

        trade_allowed = False

        reason = (
            "A medium-impact economic event is "
            "approaching."
        )

    # ------------------------------------------------------------------------
    # 5. Macro conflict
    # ------------------------------------------------------------------------

    elif conflict:

        risk_level = "CAUTION"

        trade_allowed = False

        reason = (
            "The pair has conflicting macroeconomic "
            "evidence."
        )

    # ------------------------------------------------------------------------
    # 6. No directional edge
    # ------------------------------------------------------------------------

    elif (
        direction == "NEUTRAL"
        or strength < 0.15
    ):

        risk_level = "NO_EDGE"

        trade_allowed = False

        reason = (
            "The pair does not currently have "
            "a meaningful fundamental directional edge."
        )

    # ------------------------------------------------------------------------
    # 7. No confidence
    # ------------------------------------------------------------------------

    elif confidence == "NONE":

        risk_level = (
            "INSUFFICIENT_DATA"
        )

        trade_allowed = False

        reason = (
            "Fundamental confidence is insufficient."
        )

    # ------------------------------------------------------------------------
    # 8. Otherwise
    # ------------------------------------------------------------------------

    else:

        risk_level = "CLEAR"

        trade_allowed = True

        reason = (
            "Fundamental direction is usable and "
            "there is no immediate material event risk."
        )

    return {
        "pair": pair,

        "base_currency": base_currency,
        "quote_currency": quote_currency,

        "fundamental_direction": direction,
        "fundamental_score": score,
        "fundamental_strength": strength,
        "fundamental_confidence": confidence,
        "fundamental_conflict": conflict,

        "fundamental_bias": normalized_fundamental[
            "bias"
        ],

        "fundamental_actionable": normalized_fundamental[
            "actionable"
        ],

        "risk_level": risk_level,
        "trade_allowed": trade_allowed,

        "upcoming_event_count": len(
            upcoming
        ),

        "base_event_count": len(
            base_events
        ),

        "quote_event_count": len(
            quote_events
        ),

        "blocking_event_count": len(
            blocking_events
        ),

        "high_risk_event_count": len(
            high_risk_events
        ),

        "caution_event_count": len(
            caution_events
        ),

        "watch_event_count": len(
            watch_events
        ),

        "unknown_time_event_count": len(
            unknown_time_events
        ),

        "maximum_severity": round(
            maximum_severity,
            4,
        ),

        "combined_severity": round(
            combined_severity,
            4,
        ),

        "reason": reason,

        "diagnostics": diagnostics,

        "events": upcoming,
    }


# ============================================================================
# BUILD COMPLETE SNAPSHOT
# ============================================================================

def build_pair_risk_snapshot(
    fundamental_snapshot: dict[str, Any],
    pair_fundamental_snapshot: dict[str, Any],
) -> dict[str, Any]:

    events = extract_events(
        fundamental_snapshot
    )

    generated_at = datetime.now(
        timezone.utc
    )

    pair_results = {}

    for pair in SUPPORTED_PAIRS:

        raw_pair_fundamental = (
            extract_pair_fundamental(
                pair_fundamental_snapshot,
                pair,
            )
        )

        pair_results[pair] = (
            calculate_pair_risk(
                pair=pair,
                pair_fundamental=(
                    raw_pair_fundamental
                ),
                events=events,
                now=generated_at,
            )
        )

    return {
        "generated_at": generated_at.isoformat(),

        "pairs": pair_results,

        "metadata": {
            "fundamental_event_count": len(
                events
            ),

            "supported_pairs": list(
                SUPPORTED_PAIRS.keys()
            ),

            "fundamental_source": str(
                FUNDAMENTAL_SNAPSHOT_PATH
            ),

            "pair_fundamental_source": str(
                PAIR_FUNDAMENTAL_SNAPSHOT_PATH
            ),

            "execution_enabled": False,

            "dry_run": True,

            "purpose": (
                "pair_level_fundamental_event_risk"
            ),
        },
    }


# ============================================================================
# SAVE
# ============================================================================

def save_snapshot(
    snapshot: dict[str, Any],
) -> None:

    OUTPUT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with OUTPUT_PATH.open(
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            snapshot,
            file,
            indent=2,
            ensure_ascii=False,
        )


# ============================================================================
# DISPLAY
# ============================================================================

def print_pair_result(
    pair: str,
    result: dict[str, Any],
) -> None:

    print()
    print(pair)

    print(
        f"  Fundamental direction: "
        f"{result['fundamental_direction']}"
    )

    print(
        f"  Fundamental score:     "
        f"{result['fundamental_score']:+.4f}"
    )

    print(
        f"  Fundamental strength:  "
        f"{result['fundamental_strength']:.4f}"
    )

    print(
        f"  Fundamental confidence: "
        f"{result['fundamental_confidence']}"
    )

    print(
        f"  Fundamental conflict:  "
        f"{result['fundamental_conflict']}"
    )

    print(
        f"  Risk level:            "
        f"{result['risk_level']}"
    )

    print(
        f"  Trade allowed:         "
        f"{result['trade_allowed']}"
    )

    print(
        f"  Upcoming events:       "
        f"{result['upcoming_event_count']}"
    )

    print(
        f"  Base events:           "
        f"{result['base_event_count']}"
    )

    print(
        f"  Quote events:          "
        f"{result['quote_event_count']}"
    )

    print(
        f"  Blocking events:       "
        f"{result['blocking_event_count']}"
    )

    print(
        f"  High-risk events:      "
        f"{result['high_risk_event_count']}"
    )

    print(
        f"  Caution events:        "
        f"{result['caution_event_count']}"
    )

    print(
        f"  Watch events:          "
        f"{result['watch_event_count']}"
    )

    print(
        f"  Unknown-time events:   "
        f"{result['unknown_time_event_count']}"
    )

    print(
        f"  Maximum severity:      "
        f"{result['maximum_severity']:.4f}"
    )

    print(
        f"  Combined severity:     "
        f"{result['combined_severity']:.4f}"
    )

    print(
        f"  Reason:                "
        f"{result['reason']}"
    )

    diagnostics = result[
        "diagnostics"
    ]

    print("  Diagnostics:")

    print(
        f"    Upcoming status:     "
        f"{diagnostics['upcoming_status']}"
    )

    print(
        f"    Currency matches:    "
        f"{diagnostics['currency_matches']}"
    )

    print(
        f"    Datetimes parsed:    "
        f"{diagnostics['datetime_parsed']}"
    )

    print(
        f"    Future events:       "
        f"{diagnostics['future_events']}"
    )

    print(
        f"    Past events:         "
        f"{diagnostics['past_events']}"
    )

    print(
        f"    Unknown-time events: "
        f"{diagnostics['unknown_time_events']}"
    )

    print("  Relevant events:")

    for event in result[
        "events"
    ][:10]:

        minutes = event[
            "minutes_until"
        ]

        if minutes is None:

            time_text = "TIME UNKNOWN"

        elif minutes < 60:

            time_text = (
                f"{minutes:.0f} min"
            )

        else:

            time_text = (
                f"{minutes / 60:.1f} h"
            )

        print(
            f"    - "
            f"{event['side']} | "
            f"{event['currency']} | "
            f"{event['impact']} | "
            f"{event['event_type']} | "
            f"{event['title']} | "
            f"{time_text} | "
            f"{event['risk_class']} | "
            f"severity={event['severity']:.4f}"
        )


# ============================================================================
# MAIN
# ============================================================================

def main() -> None:

    print(
        "Loading fundamental snapshot..."
    )

    fundamental_snapshot = (
        load_fundamental_snapshot()
    )

    print(
        "Loading pair fundamental snapshot..."
    )

    pair_fundamental_snapshot = (
        load_pair_fundamental_snapshot()
    )

    events = extract_events(
        fundamental_snapshot
    )

    upcoming_events = [
        event
        for event in events
        if _get_release_status(event)
        == "UPCOMING"
    ]

    currencies = sorted(
        {
            _get_currency(event)
            for event in events
            if _get_currency(event)
        }
    )

    print(
        f"Fundamental events loaded: "
        f"{len(events)}"
    )

    print(
        f"Upcoming events loaded: "
        f"{len(upcoming_events)}"
    )

    print(
        f"Currencies found: "
        f"{currencies}"
    )

    print()
    print("=" * 78)
    print(
        "HAFNOT AI TRADING AGENT"
    )
    print(
        "PAIR-LEVEL FUNDAMENTAL RISK ENGINE V5"
    )
    print("=" * 78)

    snapshot = (
        build_pair_risk_snapshot(
            fundamental_snapshot,
            pair_fundamental_snapshot,
        )
    )

    for pair in SUPPORTED_PAIRS:

        print_pair_result(
            pair,
            snapshot[
                "pairs"
            ][pair],
        )

    save_snapshot(
        snapshot
    )

    print()
    print("=" * 78)

    print()

    print(
        "Snapshot written to: "
        f"{OUTPUT_PATH}"
    )

    print()

    print(
        "PAIR FUNDAMENTAL RISK ENGINE TEST COMPLETE"
    )


if __name__ == "__main__":
    main()