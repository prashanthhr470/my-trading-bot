from __future__ import annotations

from math import sqrt
from statistics import mean, pstdev


def calculate_performance(r_multiples):
    values = [float(x) for x in r_multiples]

    if not values:
        return {
            "trades": 0,
            "wins": 0,
            "losses": 0,
            "win_rate": 0.0,
            "net_r": 0.0,
            "expectancy_r": 0.0,
            "profit_factor": 0.0,
            "max_drawdown_r": 0.0,
            "average_win_r": 0.0,
            "average_loss_r": 0.0,
            "sharpe_like": 0.0,
        }

    wins = [x for x in values if x > 0]
    losses = [x for x in values if x < 0]

    equity = 0.0
    peak = 0.0
    max_dd = 0.0

    for value in values:
        equity += value
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)

    gross_profit = sum(wins)
    gross_loss = abs(sum(losses))

    sharpe_like = 0.0
    if len(values) > 1:
        sd = pstdev(values)
        if sd:
            sharpe_like = mean(values) / sd * sqrt(len(values))

    return {
        "trades": len(values),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": len(wins) / len(values) * 100,
        "net_r": sum(values),
        "expectancy_r": mean(values),
        "profit_factor": (
            gross_profit / gross_loss if gross_loss else
            float("inf") if gross_profit else 0.0
        ),
        "max_drawdown_r": max_dd,
        "average_win_r": mean(wins) if wins else 0.0,
        "average_loss_r": mean(losses) if losses else 0.0,
        "sharpe_like": sharpe_like,
    }


def group_performance(records, key):
    groups = {}

    for record in records:
        group = record.get(key, "UNKNOWN")
        groups.setdefault(group, []).append(record["r"])

    return {
        group: calculate_performance(values)
        for group, values in groups.items()
    }
