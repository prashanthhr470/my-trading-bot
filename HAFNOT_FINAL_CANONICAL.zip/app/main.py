# ============================================================
# HAFNOT AI TRADING AGENT
# MAIN PIPELINE
# ============================================================
#
# Pipeline:
#
# cTrader
#    ↓
# Market Data
#    ↓
# Multi-Timeframe Analysis
#    ↓
# Market State
#    ↓
# Market Structure
#    ↓
# Support / Resistance
#    ↓
# Liquidity
#    ↓
# Fundamentals
#    ↓
# Evidence Engine
#    ↓
# Qwen3 AI
#    ↓
# AI Validator
#    ↓
# Decision Gate
#    ↓
# Setup Analyzer
#    ↓
# Risk Management
#    ↓
# Trade Plan
#    ↓
# Broker Validation
#    ↓
# Final Safety Gate
#
# IMPORTANT:
# DRY_RUN = True
# No live broker order is permitted.
#
# ============================================================

import asyncio
import json
import traceback
from pathlib import Path


# ============================================================
# cTRADER
# ============================================================

from app.ctrader.market_data import (
    get_market_snapshot,
)

from app.ctrader.symbol_info import (
    get_symbol_spec,
)

from app.ctrader.execution_adapter import (
    BrokerExecutionAdapter,
)


# ============================================================
# TECHNICAL ANALYSIS
# ============================================================

from app.analysis_engine import (
    calculate_indicators,
    create_market_summary,
)

from app.market_state import (
    determine_market_state,
)

from app.market_structure import (
    find_swing_points,
    determine_structure,
)

from app.support_resistance import (
    find_support_resistance,
    group_levels,
)

from app.liquidity_engine import (
    build_liquidity_evidence,
)


# ============================================================
# EVIDENCE
# ============================================================

from app.evidence_engine import (
    build_evidence,
)


# ============================================================
# SETUP
# ============================================================

from app.setup_analyzer import (
    analyze_setup,
)


# ============================================================
# AI
# ============================================================

from app.ai.provider import (
    SYSTEM_INSTRUCTION,
    analyze_with_ollama,
)

from app.ai.validator import (
    validate_ai_decision,
)

from app.ai.decision_gate import (
    apply_decision_gate,
)


# ============================================================
# RISK
# ============================================================

from app.risk_management import (
    calculate_risk,
)


from app.trade_plan import (
    build_trade_plan,
    trade_plan_to_dict,
)


# ============================================================
# EXECUTION SAFETY
# ============================================================

from app.execution_safety import (
    ExecutionSafetyGate,
)


# ============================================================
# CONFIGURATION
# ============================================================

SYMBOL = "XAUUSD"

ACCOUNT_BALANCE = 10000.0

RISK_PERCENT = 1.0


# ------------------------------------------------------------
# TEST DISTANCES
# ------------------------------------------------------------
#
# These are NOT the final trading strategy.
#
# They are deterministic distances used while the complete
# setup/risk/execution pipeline is being tested.
#
# ------------------------------------------------------------

STOP_DISTANCE = 10.0

TARGET_DISTANCE = 20.0


# ------------------------------------------------------------
# SAFETY
# ------------------------------------------------------------

DRY_RUN = True

MAX_SPREAD = 5.0

MAX_OPEN_POSITIONS = 1

MAX_DAILY_LOSS_PERCENT = 3.0


# ============================================================
# FUNDAMENTAL DATA PATHS
# ============================================================

FUNDAMENTAL_DIR = (
    Path("data")
    / "fundamental"
)

FUNDAMENTAL_SNAPSHOT_PATH = (
    FUNDAMENTAL_DIR
    / "fundamental_snapshot.json"
)

PAIR_FUNDAMENTAL_PATH = (
    FUNDAMENTAL_DIR
    / "pair_fundamental_snapshot.json"
)

PAIR_RISK_PATH = (
    FUNDAMENTAL_DIR
    / "pair_fundamental_risk.json"
)


# ============================================================
# PRINT HELPERS
# ============================================================

def section(title):

    print()

    print("=" * 70)

    print(title)

    print("=" * 70)


def print_json(title, data):

    print()

    print(
        f"========== {title} =========="
    )

    print(
        json.dumps(
            data,
            indent=2,
            ensure_ascii=False,
            default=str,
        )
    )


# ============================================================
# JSON LOADER
# ============================================================

def load_json_file(path):

    if not path.exists():

        return None

    try:

        with path.open(
            "r",
            encoding="utf-8",
        ) as file:

            return json.load(file)

    except Exception as error:

        print(
            f"[WARNING] Failed to load "
            f"{path}: {error}"
        )

        return None


# ============================================================
# GENERIC RECORD FINDER
# ============================================================

def find_record(
    data,
    symbol,
):

    if not isinstance(
        data,
        dict,
    ):

        return None

    # --------------------------------------------------------
    # Direct symbol key
    # --------------------------------------------------------

    direct = data.get(
        symbol
    )

    if isinstance(
        direct,
        dict,
    ):

        return direct

    # --------------------------------------------------------
    # Common container names
    # --------------------------------------------------------

    containers = [
        "pairs",
        "pair_scores",
        "pair_fundamentals",
        "pair_risk",
        "pair_risks",
        "results",
    ]

    for container_name in containers:

        container = data.get(
            container_name
        )

        if not isinstance(
            container,
            dict,
        ):

            continue

        direct = container.get(
            symbol
        )

        if isinstance(
            direct,
            dict,
        ):

            return direct

        # Sometimes a list is used.

        if isinstance(
            container,
            list,
        ):

            for item in container:

                if not isinstance(
                    item,
                    dict,
                ):

                    continue

                item_symbol = (
                    item.get("symbol")
                    or item.get("pair")
                    or item.get("instrument")
                )

                if str(
                    item_symbol
                ).upper() == symbol.upper():

                    return item

    # --------------------------------------------------------
    # Search top-level lists
    # --------------------------------------------------------

    for value in data.values():

        if not isinstance(
            value,
            list,
        ):

            continue

        for item in value:

            if not isinstance(
                item,
                dict,
            ):

                continue

            item_symbol = (
                item.get("symbol")
                or item.get("pair")
                or item.get("instrument")
            )

            if str(
                item_symbol
            ).upper() == symbol.upper():

                return item

    return None


# ============================================================
# FUNDAMENTAL EVIDENCE BUILDER
# ============================================================

def build_fundamental_evidence(
    symbol,
):
    """
    Load the already-generated fundamental intelligence
    and convert it into the compact structure expected by
    the Evidence Engine.

    No fundamental calculations are performed here.

    The fundamental subsystem has already calculated:

        - currency strength
        - pair differential
        - pair direction
        - confidence
        - conflict
        - monetary policy pressure
        - upcoming event risk
        - data quality
        - event information

    This function only connects those results to the
    evidence layer.
    """

    # ========================================================
    # LOAD FUNDAMENTAL SNAPSHOT
    # ========================================================

    fundamental_snapshot = (
        load_json_file(
            FUNDAMENTAL_SNAPSHOT_PATH
        )
    )

    pair_snapshot = (
        load_json_file(
            PAIR_FUNDAMENTAL_PATH
        )
    )

    pair_risk_snapshot = (
        load_json_file(
            PAIR_RISK_PATH
        )
    )

    # ========================================================
    # NO FUNDAMENTAL DATA
    # ========================================================

    if fundamental_snapshot is None:

        return {

            "available": False,

            "instrument": symbol,

            "mode": "UNAVAILABLE",

            "direction": "NEUTRAL",

            "strength": 0.0,

            "confidence": "NONE",

            "conflict": False,

            "bias": "NO_EDGE",

            "actionable": False,

            "base_currency": None,

            "quote_currency": None,

            "currency": {},

            "pair": None,

            "monetary_policy": {},

            "released_events": {},

            "upcoming_event_risk": {},

            "data_quality": {},

            "reason": (
                "Fundamental snapshot "
                "is unavailable."
            ),
        }

    # ========================================================
    # CURRENCY SCORES
    # ========================================================

    currency_scores = (
        fundamental_snapshot.get(
            "currency_scores",
            {},
        )
    )

    if not isinstance(
        currency_scores,
        dict,
    ):

        currency_scores = {}

    # ========================================================
    # GLOBAL EVENT RISK
    # ========================================================

    global_event_risk = (
        fundamental_snapshot.get(
            "event_risk",
            {},
        )
    )

    if not isinstance(
        global_event_risk,
        dict,
    ):

        global_event_risk = {}

    # ========================================================
    # EVENTS
    # ========================================================

    all_events = (
        fundamental_snapshot.get(
            "events",
            [],
        )
    )

    if not isinstance(
        all_events,
        list,
    ):

        all_events = []

    # ========================================================
    # DATA QUALITY
    # ========================================================

    data_quality = (
        fundamental_snapshot.get(
            "data_quality",
            {},
        )
    )

    if not isinstance(
        data_quality,
        dict,
    ):

        data_quality = {}

    # ========================================================
    # PAIR DATA
    # ========================================================

    pair_record = find_record(
        pair_snapshot,
        symbol,
    )

    pair_risk_record = find_record(
        pair_risk_snapshot,
        symbol,
    )

    # ========================================================
    # SUPPORTED FX PAIRS
    # ========================================================

    supported_pairs = {
        "USDJPY": ("USD", "JPY"),
        "GBPUSD": ("GBP", "USD"),
        "AUDUSD": ("AUD", "USD"),
        "GBPJPY": ("GBP", "JPY"),
        "AUDJPY": ("AUD", "JPY"),
        "GBPAUD": ("GBP", "AUD"),
    }

    # ========================================================
    # XAUUSD
    # ========================================================
    #
    # Gold is not a currency pair in the same way as FX.
    #
    # Therefore we use USD macro fundamentals as context.
    #
    # IMPORTANT:
    #
    # We deliberately DO NOT mark this as actionable
    # directional fundamental evidence.
    #
    # This prevents the system from pretending that
    # "USD bearish = automatically buy gold".
    #
    # The AI receives the information as context.
    #
    # ========================================================

    if symbol.upper() == "XAUUSD":

        usd_data = currency_scores.get(
            "USD",
            {},
        )

        if not isinstance(
            usd_data,
            dict,
        ):

            usd_data = {}

        usd_score = usd_data.get(
            "overall_direction_score",
            usd_data.get(
                "score",
                0.0,
            ),
        )

        try:

            usd_score = float(
                usd_score
            )

        except (
            TypeError,
            ValueError,
        ):

            usd_score = 0.0

        usd_strength = abs(
            usd_score
        )

        usd_state = str(
            usd_data.get(
                "state",
                "NEUTRAL",
            )
        ).upper()

        usd_confidence = str(
            usd_data.get(
                "confidence",
                "LOW",
            )
        ).upper()

        usd_conflict = bool(
            usd_data.get(
                "conflict",
                False,
            )
        )

        # ----------------------------------------------------
        # Relevant USD events
        # ----------------------------------------------------

        usd_events = []

        for event in all_events:

            if not isinstance(
                event,
                dict,
            ):

                continue

            currency = str(
                event.get(
                    "currency",
                    event.get(
                        "country",
                        "",
                    ),
                )
            ).upper()

            if currency == "USD":

                usd_events.append(
                    event
                )

        # ----------------------------------------------------
        # Monetary policy
        # ----------------------------------------------------

        monetary_policy = (
            usd_data.get(
                "monetary_policy",
                {},
            )
        )

        if not isinstance(
            monetary_policy,
            dict,
        ):

            monetary_policy = {}

        # ----------------------------------------------------
        # Fundamental direction
        #
        # Inverse USD context:
        #
        # USD negative pressure can be supportive for gold.
        #
        # But this remains CONTEXT_ONLY.
        # ----------------------------------------------------

        if usd_score < 0:

            gold_context_direction = (
                "BULLISH"
            )

        elif usd_score > 0:

            gold_context_direction = (
                "BEARISH"
            )

        else:

            gold_context_direction = (
                "NEUTRAL"
            )

        return {

            "available": True,

            "instrument": symbol,

            "mode": (
                "INVERSE_USD_CONTEXT"
            ),

            "direction": (
                gold_context_direction
            ),

            "strength": (
                round(
                    usd_strength,
                    4,
                )
            ),

            "confidence": (
                usd_confidence
            ),

            "conflict": (
                usd_conflict
            ),

            "bias": (
                "CONTEXT_ONLY"
            ),

            "actionable": False,

            "base_currency": "XAU",

            "quote_currency": "USD",

            "currency": {

                "USD": {

                    "score": (
                        round(
                            usd_score,
                            4,
                        )
                    ),

                    "strength": (
                        round(
                            usd_strength,
                            4,
                        )
                    ),

                    "state": (
                        usd_state
                    ),

                    "confidence": (
                        usd_confidence
                    ),

                    "conflict": (
                        usd_conflict
                    ),
                }
            },

            "pair": None,

            "monetary_policy": (
                monetary_policy
            ),

            "released_events": {

                "USD": usd_events,
            },

            "upcoming_event_risk": (
                global_event_risk
            ),

            "data_quality": (
                data_quality
            ),

            "reason": (
                "USD macroeconomic conditions are "
                "provided as contextual information "
                "for XAUUSD. The relationship is "
                "not treated as an automatically "
                "actionable gold signal."
            ),
        }

    # ========================================================
    # FX PAIR
    # ========================================================

    pair_info = (
        supported_pairs.get(
            symbol.upper()
        )
    )

    if pair_info is None:

        return {

            "available": True,

            "instrument": symbol,

            "mode": "UNSUPPORTED_PAIR",

            "direction": "NEUTRAL",

            "strength": 0.0,

            "confidence": "LOW",

            "conflict": True,

            "bias": "NO_EDGE",

            "actionable": False,

            "base_currency": None,

            "quote_currency": None,

            "currency": {},

            "pair": None,

            "monetary_policy": {},

            "released_events": {},

            "upcoming_event_risk": {},

            "data_quality": (
                data_quality
            ),

            "reason": (
                "Fundamental pair mapping is "
                "not configured for this symbol."
            ),
        }

    base_currency, quote_currency = (
        pair_info
    )

    # ========================================================
    # PAIR FUNDAMENTAL RECORD
    # ========================================================

    if pair_record is None:

        return {

            "available": True,

            "instrument": symbol,

            "mode": "FX_PAIR",

            "direction": "NEUTRAL",

            "strength": 0.0,

            "confidence": "LOW",

            "conflict": True,

            "bias": "NO_EDGE",

            "actionable": False,

            "base_currency": (
                base_currency
            ),

            "quote_currency": (
                quote_currency
            ),

            "currency": {

                base_currency: (
                    currency_scores.get(
                        base_currency,
                        {},
                    )
                ),

                quote_currency: (
                    currency_scores.get(
                        quote_currency,
                        {},
                    )
                ),
            },

            "pair": None,

            "monetary_policy": {},

            "released_events": {},

            "upcoming_event_risk": (
                pair_risk_record
                if pair_risk_record
                else global_event_risk
            ),

            "data_quality": (
                data_quality
            ),

            "reason": (
                "Pair fundamental record was "
                "not found."
            ),
        }

    # ========================================================
    # EXTRACT PAIR VALUES
    # ========================================================

    direction = str(
        pair_record.get(
            "direction",
            "NEUTRAL",
        )
    ).upper()

    strength = pair_record.get(
        "strength",
        pair_record.get(
            "fundamental_strength",
            0.0,
        ),
    )

    try:

        strength = float(
            strength
        )

    except (
        TypeError,
        ValueError,
    ):

        strength = 0.0

    strength = max(
        0.0,
        min(
            1.0,
            strength,
        ),
    )

    confidence = str(
        pair_record.get(
            "confidence",
            pair_record.get(
                "fundamental_confidence",
                "LOW",
            ),
        )
    ).upper()

    conflict = bool(
        pair_record.get(
            "conflict",
            pair_record.get(
                "fundamental_conflict",
                True,
            ),
        )
    )

    bias = str(
        pair_record.get(
            "bias",
            "NO_EDGE",
        )
    ).upper()

    # --------------------------------------------------------
    # Actionability
    # --------------------------------------------------------
    #
    # Conservative requirement:
    #
    #   direction exists
    #   AND
    #   no conflict
    #   AND
    #   sufficient confidence
    #   AND
    #   meaningful strength
    #
    # --------------------------------------------------------

    actionable = bool(
        pair_record.get(
            "actionable",
            False,
        )
    )

    if confidence not in {
        "HIGH",
        "MEDIUM",
        "MODERATE",
    }:

        actionable = False

    if conflict:

        actionable = False

    if strength <= 0.0:

        actionable = False

    # --------------------------------------------------------
    # Relevant events
    # --------------------------------------------------------

    base_events = []

    quote_events = []

    for event in all_events:

        if not isinstance(
            event,
            dict,
        ):

            continue

        currency = str(
            event.get(
                "currency",
                event.get(
                    "country",
                    "",
                ),
            )
        ).upper()

        if currency == base_currency:

            base_events.append(
                event
            )

        elif currency == quote_currency:

            quote_events.append(
                event
            )

    # --------------------------------------------------------
    # Monetary policy
    # --------------------------------------------------------

    base_currency_data = (
        currency_scores.get(
            base_currency,
            {},
        )
    )

    quote_currency_data = (
        currency_scores.get(
            quote_currency,
            {},
        )
    )

    if not isinstance(
        base_currency_data,
        dict,
    ):

        base_currency_data = {}

    if not isinstance(
        quote_currency_data,
        dict,
    ):

        quote_currency_data = {}

    base_policy = (
        base_currency_data.get(
            "monetary_policy",
            {},
        )
    )

    quote_policy = (
        quote_currency_data.get(
            "monetary_policy",
            {},
        )
    )

    monetary_policy = {

        base_currency: (
            base_policy
            if isinstance(
                base_policy,
                dict,
            )
            else {}
        ),

        quote_currency: (
            quote_policy
            if isinstance(
                quote_policy,
                dict,
            )
            else {}
        ),
    }

    # ========================================================
    # FINAL FX FUNDAMENTAL EVIDENCE
    # ========================================================

    return {

        "available": True,

        "instrument": symbol,

        "mode": "FX_PAIR",

        "direction": direction,

        "strength": round(
            strength,
            4,
        ),

        "confidence": confidence,

        "conflict": conflict,

        "bias": bias,

        "actionable": actionable,

        "base_currency": (
            base_currency
        ),

        "quote_currency": (
            quote_currency
        ),

        "currency": {

            base_currency: (
                base_currency_data
            ),

            quote_currency: (
                quote_currency_data
            ),
        },

        "pair": pair_record,

        "monetary_policy": (
            monetary_policy
        ),

        "released_events": {

            base_currency: (
                base_events
            ),

            quote_currency: (
                quote_events
            ),
        },

        "upcoming_event_risk": (
            pair_risk_record
            if pair_risk_record
            else global_event_risk
        ),

        "data_quality": (
            data_quality
        ),

        "reason": (
            pair_record.get(
                "reason",
                "Fundamental pair analysis "
                "loaded successfully.",
            )
        ),
    }


# ============================================================
# SPOT NORMALIZATION
# ============================================================

def extract_spot(snapshot):

    spot_data = snapshot.get(
        "spot",
        [],
    )

    if not spot_data:

        raise RuntimeError(
            "No spot price returned."
        )

    for item in spot_data:

        if not isinstance(
            item,
            dict,
        ):

            continue

        # ----------------------------------------------------
        # Direct response
        # ----------------------------------------------------

        if (
            "bid" in item
            and "ask" in item
        ):

            return item

        # ----------------------------------------------------
        # Nested response
        # ----------------------------------------------------

        nested = item.get(
            "result"
        )

        if isinstance(
            nested,
            dict,
        ):

            if (
                "bid" in nested
                and "ask" in nested
            ):

                return nested

    raise RuntimeError(
        "Unable to normalize live XAUUSD spot."
    )


# ============================================================
# MAIN PIPELINE
# ============================================================

async def main():

    section(
        "HAFNOT AI TRADING AGENT"
    )

    print(
        "Starting AI Trading Agent..."
    )

    print(
        f"Symbol: {SYMBOL}"
    )

    print(
        f"Account balance: "
        f"{ACCOUNT_BALANCE}"
    )

    print(
        f"Risk: {RISK_PERCENT}%"
    )

    print(
        f"DRY RUN: {DRY_RUN}"
    )

    print()

    print(
        "IMPORTANT: "
        "No live broker order will be placed."
    )

    # ========================================================
    # 1. LIVE MARKET SNAPSHOT
    # ========================================================

    section(
        "1. LIVE MARKET DATA"
    )

    print(
        f"Requesting {SYMBOL} "
        "market snapshot..."
    )

    snapshot = await get_market_snapshot(
        SYMBOL
    )

    print(
        f"Symbol: "
        f"{snapshot.get('symbol')}"
    )

    print(
        f"Request time: "
        f"{snapshot.get('request_time')}"
    )

    # ========================================================
    # 2. LIVE SPOT
    # ========================================================

    section(
        "2. LIVE SPOT"
    )

    spot = extract_spot(
        snapshot
    )

    bid = float(
        spot["bid"]
    )

    ask = float(
        spot["ask"]
    )

    spread = ask - bid

    print_json(
        "LIVE SPOT",
        {
            "symbol": SYMBOL,
            "bid": bid,
            "ask": ask,
            "spread": spread,
        },
    )

    # ========================================================
    # 3. MULTI-TIMEFRAME ANALYSIS
    # ========================================================

    section(
        "3. MULTI-TIMEFRAME ANALYSIS"
    )

    timeframe_summaries = {}

    for (
        timeframe,
        data,
    ) in snapshot.get(
        "timeframes",
        {},
    ).items():

        bars = data.get(
            "bars",
            [],
        )

        print(
            f"Processing "
            f"{timeframe.upper()} "
            f"({len(bars)} bars)..."
        )

        if not bars:

            print(
                f"[WARNING] "
                f"No {timeframe} bars."
            )

            continue

        try:

            df = calculate_indicators(
                bars
            )

            summary = create_market_summary(
                df
            )

            timeframe_summaries[
                timeframe
            ] = summary

            print(
                f"{timeframe.upper()}: "
                f"trend={summary['trend']} "
                f"momentum={summary['momentum']} "
                f"RSI={summary['rsi_14']:.2f}"
            )

        except Exception as error:

            print(
                f"[WARNING] "
                f"{timeframe} analysis failed: "
                f"{error}"
            )

    if not timeframe_summaries:

        raise RuntimeError(
            "No timeframe analysis was produced."
        )

    print_json(
        "TIMEFRAME SUMMARIES",
        timeframe_summaries,
    )

    # ========================================================
    # 4. MARKET STATE
    # ========================================================

    section(
        "4. MARKET STATE"
    )

    market_state = determine_market_state(
        timeframe_summaries
    )

    print_json(
        "MARKET STATE",
        market_state,
    )

    # ========================================================
    # 5. MARKET STRUCTURE
    # ========================================================

    section(
        "5. MARKET STRUCTURE"
    )

    structure_bars = (
        snapshot
        .get(
            "timeframes",
            {},
        )
        .get(
            "m5",
            {},
        )
        .get(
            "bars",
            [],
        )
    )

    if not structure_bars:

        raise RuntimeError(
            "No M5 bars available for structure."
        )

    structure_df = calculate_indicators(
        structure_bars
    )

    structure_df = find_swing_points(
        structure_df
    )

    structure = determine_structure(
        structure_df
    )

    print_json(
        "STRUCTURE",
        structure,
    )

    # ========================================================
    # 6. SUPPORT / RESISTANCE
    # ========================================================

    section(
        "6. SUPPORT / RESISTANCE"
    )

    raw_levels = find_support_resistance(
        structure_df
    )

    zones = group_levels(
        raw_levels
    )

    support_levels = [

        zone

        for zone in zones

        if zone.get(
            "type"
        ) == "support"
    ]

    resistance_levels = [

        zone

        for zone in zones

        if zone.get(
            "type"
        ) == "resistance"
    ]

    print(
        f"Raw levels: "
        f"{len(raw_levels)}"
    )

    print(
        f"Zones: "
        f"{len(zones)}"
    )

    print_json(
        "SUPPORT ZONES",
        support_levels,
    )

    print_json(
        "RESISTANCE ZONES",
        resistance_levels,
    )

    # ========================================================
    # 7. LIQUIDITY
    # ========================================================

    section(
        "7. LIQUIDITY ENGINE"
    )

    m5_bars = (
        snapshot
        .get(
            "timeframes",
            {},
        )
        .get(
            "m5",
            {},
        )
        .get(
            "bars",
            [],
        )
    )

    d1_bars = (
        snapshot
        .get(
            "timeframes",
            {},
        )
        .get(
            "d1",
            {},
        )
        .get(
            "bars",
            [],
        )
    )

    liquidity_evidence = (
        build_liquidity_evidence(
            m5_bars=m5_bars,
            daily_bars=d1_bars,
            current_price=ask,
        )
    )

    print_json(
        "LIQUIDITY EVIDENCE",
        liquidity_evidence,
    )

    # ========================================================
    # 8. FUNDAMENTAL INTELLIGENCE
    # ========================================================

    section(
        "8. FUNDAMENTAL INTELLIGENCE"
    )

    print(
        "Loading fundamental intelligence..."
    )

    fundamental_evidence = (
        build_fundamental_evidence(
            SYMBOL
        )
    )

    print_json(
        "FUNDAMENTAL EVIDENCE",
        fundamental_evidence,
    )

    # ========================================================
    # 9. EVIDENCE ENGINE
    # ========================================================

    section(
        "9. EVIDENCE ENGINE"
    )

    evidence = build_evidence(
        market_state=market_state,
        timeframe_summaries=timeframe_summaries,
        structure=structure,
        support_levels=support_levels,
        resistance_levels=resistance_levels,
        news_analysis=None,
        liquidity_evidence=liquidity_evidence,
        fundamental_evidence=fundamental_evidence,
    )

    print_json(
        "FINAL EVIDENCE",
        evidence,
    )

    # ========================================================
    # 10. SETUP ANALYZER
    # ========================================================

    section(
        "10. SETUP ANALYZER"
    )

    setup_result = analyze_setup(
        evidence
    )

    print_json(
        "SETUP RESULT",
        setup_result,
    )

    # ========================================================
    # 11. AI REASONING
    # ========================================================

    section(
        "11. QWEN3 AI REASONING"
    )

    print(
        "Sending complete evidence "
        "to Ollama..."
    )

    ai_decision = analyze_with_ollama(
        SYSTEM_INSTRUCTION,
        evidence,
    )

    print_json(
        "AI DECISION",
        ai_decision,
    )

    # ========================================================
    # 12. AI VALIDATOR
    # ========================================================

    section(
        "12. AI VALIDATOR"
    )

    validator_result = (
        validate_ai_decision(
            ai_decision,
            evidence,
        )
    )

    print_json(
        "VALIDATOR RESULT",
        validator_result,
    )

    # ========================================================
    # 13. DECISION GATE
    # ========================================================

    section(
        "13. DECISION GATE"
    )

    gate_result = apply_decision_gate(
        ai_decision,
        evidence,
    )

    print_json(
        "GATE RESULT",
        gate_result,
    )

    # ========================================================
    # 14. RISK MANAGEMENT
    # ========================================================

    section(
        "14. RISK MANAGEMENT"
    )

    risk_result = None

    gated_decision = gate_result.get(
        "decision",
        "WAIT",
    )

    gate_passed = (
        gate_result.get(
            "gate_status"
        )
        == "PASSED"
    )

    setup_found = setup_result.get(
        "setup_found",
        False,
    )

    if (
        gate_passed
        and setup_found
        and gated_decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }
    ):

        direction = (
            "BUY"
            if gated_decision
            == "BUY_CANDIDATE"
            else "SELL"
        )

        # ----------------------------------------------------
        # TEST ENTRY / SL / TP
        # ----------------------------------------------------

        if direction == "BUY":

            entry_price = ask

            stop_loss = (
                entry_price
                - STOP_DISTANCE
            )

            take_profit = (
                entry_price
                + TARGET_DISTANCE
            )

        else:

            entry_price = bid

            stop_loss = (
                entry_price
                + STOP_DISTANCE
            )

            take_profit = (
                entry_price
                - TARGET_DISTANCE
            )

        print(
            f"Direction: "
            f"{direction}"
        )

        print(
            f"Entry: "
            f"{entry_price}"
        )

        print(
            f"Stop: "
            f"{stop_loss}"
        )

        print(
            f"Target: "
            f"{take_profit}"
        )

        # ----------------------------------------------------
        # BROKER SYMBOL SPEC
        # ----------------------------------------------------

        print(
            "Requesting live broker "
            "symbol specification..."
        )

        symbol_spec = await get_symbol_spec(
            SYMBOL
        )

        print_json(
            "BROKER SYMBOL SPEC",
            {
                "symbol": symbol_spec.symbol,
                "digits": symbol_spec.digits,
                "pip_size": symbol_spec.pip_size,
                "lot_size": symbol_spec.lot_size,
                "min_volume": symbol_spec.min_volume,
                "max_volume": symbol_spec.max_volume,
                "volume_step": symbol_spec.volume_step,
            },
        )

        # ----------------------------------------------------
        # CALCULATE RISK
        # ----------------------------------------------------

        risk_result = calculate_risk(
            account_balance=ACCOUNT_BALANCE,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            risk_percent=RISK_PERCENT,
            symbol_spec=symbol_spec,
        )

        print_json(
            "RISK RESULT",
            risk_result.__dict__,
        )

    else:

        print(
            "Risk calculation skipped."
        )

        print(
            "The upstream pipeline did not "
            "produce an executable candidate."
        )

    # ========================================================
    # 15. TRADE PLAN
    # ========================================================

    section(
        "15. TRADE PLAN"
    )

    trade_plan = build_trade_plan(
        ai_decision=ai_decision,
        validator_result=validator_result,
        gate_result=gate_result,
        setup_result=setup_result,
        risk_result=risk_result,
        symbol=SYMBOL,
    )

    trade_plan_dict = (
        trade_plan_to_dict(
            trade_plan
        )
    )

    print_json(
        "TRADE PLAN",
        trade_plan_dict,
    )

    # ========================================================
    # 16. BROKER VALIDATION
    # ========================================================

    section(
        "16. BROKER EXECUTION ADAPTER"
    )

    adapter = BrokerExecutionAdapter(
        dry_run=DRY_RUN,
        max_spread=MAX_SPREAD,
    )

    broker_result = await adapter.execute(
        trade_plan
    )

    print_json(
        "BROKER RESULT",
        broker_result.__dict__,
    )

    # ========================================================
    # 17. FINAL EXECUTION SAFETY GATE
    # ========================================================

    section(
        "17. FINAL EXECUTION SAFETY GATE"
    )

    safety_gate = ExecutionSafetyGate(
        max_spread=MAX_SPREAD,
        max_open_positions=MAX_OPEN_POSITIONS,
        max_daily_loss_percent=(
            MAX_DAILY_LOSS_PERCENT
        ),
        require_dry_run=True,
    )

    safety_result = safety_gate.check(
        trade_plan,
        broker_result,
        open_positions=0,
        daily_loss_percent=0.0,
        kill_switch=False,
        duplicate_position=False,
        dry_run=DRY_RUN,
    )

    print_json(
        "FINAL SAFETY RESULT",
        safety_result.__dict__,
    )

    # ========================================================
    # 18. FINAL SUMMARY
    # ========================================================

    section(
        "FINAL PIPELINE SUMMARY"
    )

    print(
        f"Symbol:             {SYMBOL}"
    )

    print(
        f"Fundamental Available: "
        f"{fundamental_evidence.get('available')}"
    )

    print(
        f"Fundamental Direction: "
        f"{fundamental_evidence.get('direction')}"
    )

    print(
        f"Fundamental Strength: "
        f"{fundamental_evidence.get('strength')}"
    )

    print(
        f"Fundamental Confidence: "
        f"{fundamental_evidence.get('confidence')}"
    )

    print(
        f"Fundamental Conflict: "
        f"{fundamental_evidence.get('conflict')}"
    )

    print(
        f"Fundamental Actionable: "
        f"{fundamental_evidence.get('actionable')}"
    )

    print(
        f"Evidence Bias:      "
        f"{evidence.get('evidence_bias')}"
    )

    print(
        f"Evidence Confidence: "
        f"{evidence.get('confidence_state')}"
    )

    print(
        f"AI Decision:        "
        f"{ai_decision.get('decision')}"
    )

    print(
        f"AI Bias:            "
        f"{ai_decision.get('bias')}"
    )

    print(
        f"AI Confidence:      "
        f"{ai_decision.get('confidence')}"
    )

    print(
        f"Validator:          "
        f"{validator_result.get('valid')}"
    )

    print(
        f"Decision Gate:      "
        f"{gate_result.get('gate_status')}"
    )

    print(
        f"Gate Decision:      "
        f"{gate_result.get('decision')}"
    )

    print(
        f"Setup Found:        "
        f"{setup_result.get('setup_found')}"
    )

    print(
        f"Risk Allowed:       "
        f"{getattr(risk_result, 'allowed', False)}"
    )

    print(
        f"Trade Plan:         "
        f"{trade_plan.status}"
    )

    print(
        f"Broker Allowed:     "
        f"{broker_result.allowed}"
    )

    print(
        f"Broker Executed:    "
        f"{broker_result.executed}"
    )

    print(
        f"Final Safety:       "
        f"{safety_result.allowed}"
    )

    print(
        f"DRY RUN:            "
        f"{DRY_RUN}"
    )

    print()

    # ========================================================
    # HARD SAFETY CHECK
    # ========================================================

    if broker_result.executed:

        print(
            "[CRITICAL ERROR] "
            "An order appears to have been executed."
        )

    else:

        print(
            "[PASS] "
            "No broker order was executed."
        )
    if DRY_RUN:
        print(
            "[PASS] "
            "DRY-RUN mode is enabled."
        )

    else:
        print(
            "[CRITICAL ERROR] "
            "DRY-RUN mode is disabled."
        )
    if safety_result.allowed:
        print(
            "[INFO] "
            "Final safety gate passed."
        )
        print(
            "[INFO] "
            "Because DRY-RUN is enabled, "
            "no real order is placed."
        )
    else:
        print(
            "[INFO] "
            "Final safety gate rejected "
            "the trade."
        )
    print()
    print("=" * 70)
    print(
        "AI TRADING AGENT RUN COMPLETE"
    )
    print("=" * 70)

# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    try:
        asyncio.run(
            main()
        )
    except KeyboardInterrupt:
        print(
            "\nAI Trading Agent stopped."
        )
    except Exception as error:
        print(
            "\nCRITICAL PIPELINE ERROR:"
        )
        print(
            str(error)
        )
        traceback.print_exc()