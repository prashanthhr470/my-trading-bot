"""
CFTC Commitments of Traders - Traders in Financial Futures (TFF): leveraged funds' positions
in CME currency futures. Outside, non-price information approved by the user on 2026-09-15.
Yearly files are fetched into memory from cftc.gov on every run and fingerprinted; nothing
is stored.

Series per currency: leveraged-funds net position as a fraction of open interest,
(long - short) / open interest, from the weekly report (positions as of Tuesday, normally
published the following Friday at 15:30 US Eastern). Contracts are matched by CFTC contract
market code - names changed over the years (e.g. "BRITISH POUND STERLING" became "BRITISH
POUND") - and dates by their value, since the date column's header changed in 2013.

As-of rule (app.quant.external_daily.DailyAsOf): a report dated D counts as known from
calendar day D + lag_days (6: the following Monday); a date uses the latest known report; one
older than max_age_days is unavailable. Publication delays during US government shutdowns
(for example December 2018 to January 2019) are NOT modelled.
"""

from __future__ import annotations

import csv
import io
import urllib.request
import zipfile
from datetime import date, datetime
from typing import Callable, Iterable

from app.quant.external_rates import fingerprint

CFTC_TFF_URL = "https://www.cftc.gov/files/dea/history/fut_fin_txt_{year}.zip"
# Single-year files exist only from 2010 (whose file starts in July 2010); 2006-2016 are also published as one archive.
CFTC_TFF_COMBINED_URL = "https://www.cftc.gov/files/dea/history/fin_fut_txt_2006_2016.zip"
FIRST_SINGLE_YEAR = 2010
CONTRACT_CODES = {"EUR": "099741", "GBP": "096742", "JPY": "097741", "CHF": "092741", "CAD": "090741",
                  "AUD": "232741", "NZD": "112741"}

AS_OF_RULE = (
    "A report dated D (positions as of that Tuesday) is known from calendar day D + lag_days; a date uses the latest "
    "known report; one older than max_age_days is unavailable. Delayed publication during US government shutdowns is "
    "not modelled."
)

__all__ = ["CFTC_TFF_URL", "CFTC_TFF_COMBINED_URL", "CONTRACT_CODES", "AS_OF_RULE", "parse_tff", "fetch_cot",
           "fingerprint"]


def _download_bytes(url: str, timeout: int = 120) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "HAFNOT-research"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _report_date(raw: str) -> date:
    """ISO dates, or US dates optionally followed by a time ("1/10/2012 12:00:00 AM" in the 2006-2016 archive)."""

    raw = raw.strip().split(" ")[0]
    return date.fromisoformat(raw) if "-" in raw else datetime.strptime(raw, "%m/%d/%Y").date()


def parse_tff(text: str) -> dict[str, dict[str, float]]:
    """{currency: {report date: leveraged-funds net fraction of open interest}} for the tracked contract codes."""

    rows = list(csv.reader(io.StringIO(text)))
    header = [h.strip() for h in rows[0]]
    date_column = next(h for h in header if h.startswith("Report_Date_as"))
    di, ci = header.index(date_column), header.index("CFTC_Contract_Market_Code")
    oi, li, si = (header.index("Open_Interest_All"), header.index("Lev_Money_Positions_Long_All"),
                  header.index("Lev_Money_Positions_Short_All"))
    currency_by_code = {code: currency for currency, code in CONTRACT_CODES.items()}
    out: dict[str, dict[str, float]] = {}
    for row in rows[1:]:
        if len(row) <= max(di, ci, oi, li, si):
            continue
        currency = currency_by_code.get(row[ci].strip())
        if currency is None:
            continue
        open_interest = float(row[oi])
        if open_interest <= 0:
            continue
        net = (float(row[li]) - float(row[si])) / open_interest
        out.setdefault(currency, {})[_report_date(row[di]).isoformat()] = net
    return out


def fetch_cot(years: Iterable[int], download: Callable[[str], bytes] = _download_bytes) -> dict[str, list[list]]:
    """{currency: [["YYYY-MM-DD", net fraction], ...]} merged over the files; refuses a missing currency.

    Years before 2010 come from the 2006-2016 archive; single-year files are read after it, so where both hold a
    report the single-year file's value is used."""

    years = sorted(set(years))
    urls = ([CFTC_TFF_COMBINED_URL] if any(year < FIRST_SINGLE_YEAR for year in years) else []) + \
           [CFTC_TFF_URL.format(year=year) for year in years if year >= FIRST_SINGLE_YEAR]
    merged: dict[str, dict[str, float]] = {}
    for url in urls:
        archive = zipfile.ZipFile(io.BytesIO(download(url)))
        text = archive.read(archive.namelist()[0]).decode("latin-1")
        for currency, values in parse_tff(text).items():
            merged.setdefault(currency, {}).update(values)
    missing = sorted(set(CONTRACT_CODES) - set(merged))
    if missing:
        raise ValueError(f"CFTC files had no reports for {missing}.")
    return {currency: [[d, round(v, 10)] for d, v in sorted(values.items())] for currency, values in merged.items()}
