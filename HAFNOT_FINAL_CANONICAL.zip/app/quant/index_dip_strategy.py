"""
Index dip in an uptrend - buy a short-term low while the long-term trend is up.

HYPOTHESIS: in US equity indices, short-term selling in a long-term uptrend is usually
temporary (liquidity-driven overshoots, dip buying by trend followers and dealers), so a
new multi-day closing low while price is above its 200-day average rebounds over the next
days often enough to pay for spread, slippage and overnight financing. Short-term reversal
in equity indices is one of the most documented patterns in trading literature; it is
tested here, not assumed. Long only.

Rules (closed daily OHLC bars):
  Uptrend = the close is above the mean of the last `trend_days` closes (including today).
  Dip     = the close is below every close of the previous `dip_days` days.
  BUY     = uptrend and dip.
  Stop    = stop_atr x ATR(atr_period) below the close; target_r x that risk is a distant cap.
  Exit    = at the close `hold_bars` bars after entry, unless stopped.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "index-dip-in-uptrend"

DEFAULTS = {
    "dip_days": 3,
    "hold_bars": 5,
    "trend_days": 200,
    "stop_atr": 3.0,
    "atr_period": 20,
    "target_r": 10.0,
}


def evaluate(bars, *, dip_days: int, hold_bars: int, trend_days: int, stop_atr: float, atr_period: int,
             target_r: float) -> Optional[dict]:
    if len(bars) < max(trend_days, dip_days, atr_period) + 1:
        return None
    close = float(bars[-1]["close"])
    closes = [float(b["close"]) for b in bars[-trend_days:]]
    if close <= sum(closes) / trend_days:
        return None
    if close >= min(float(b["close"]) for b in bars[-(dip_days + 1):-1]):
        return None
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    stop, target = fixed_r_levels("BUY", close, stop_atr * atr, target_r)
    return {
        "direction": "BUY",
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if min(settings["dip_days"], settings["hold_bars"], settings["trend_days"], settings["atr_period"]) < 1:
        raise ValueError(f"{STRATEGY_ID}: dip_days, hold_bars, trend_days and atr_period must be >= 1")
    if settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: stop_atr and target_r must be positive")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
