"""
Real walk-forward validation.

Rolling windows: choose parameters using ONLY the in-sample window, then score
exactly those parameters on the untouched out-of-sample window that follows,
slide forward, and repeat. A strategy whose out-of-sample results collapse
relative to in-sample is showing the overfitting signature this exists to catch.

Works for any strategy: pass `signal_provider_factory` (params dict ->
signal_provider). The default is the EMA trend strategy, for backward
compatibility. `select_params` replaces the default "highest in-sample
expectancy" rule - for example with a rule that prefers robust neighbourhoods
of parameters over a single peak.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from itertools import product
from typing import Callable, Optional, Sequence

from app.forex_v2.metrics import summarize_trades
from app.quant.costed_backtest import run_costed_backtest

ScoredCombination = tuple[dict, Optional[float], int]


@dataclass
class WindowResult:
    window_index: int
    in_sample_size: int
    out_of_sample_size: int
    chosen_params: dict
    in_sample_expectancy_r: Optional[float]
    out_of_sample_expectancy_r: Optional[float]
    out_of_sample_trade_count: int
    out_of_sample_net_pnl_usd: float


@dataclass
class WalkForwardResult:
    symbol: str
    windows: list = field(default_factory=list)

    @property
    def out_of_sample_expectancies(self) -> list:
        return [
            w.out_of_sample_expectancy_r
            for w in self.windows
            if w.out_of_sample_expectancy_r is not None
        ]

    @property
    def mean_out_of_sample_expectancy_r(self) -> Optional[float]:
        values = self.out_of_sample_expectancies
        return sum(values) / len(values) if values else None

    @property
    def positive_window_fraction(self) -> Optional[float]:
        if not self.windows:
            return None
        positive = sum(
            1 for w in self.windows
            if w.out_of_sample_expectancy_r is not None and w.out_of_sample_expectancy_r > 0
        )
        return positive / len(self.windows)


def _default_ema_signal_provider_factory(params: dict):
    from app.forex_v2.strategy import StrategyConfig
    from app.quant.strategy_adapter import make_signal_provider

    return make_signal_provider(StrategyConfig(**params))


def parameter_combinations(param_grid: Optional[dict]) -> list[dict]:
    if not param_grid:
        return [{}]
    keys = list(param_grid)
    return [dict(zip(keys, values)) for values in product(*(param_grid[key] for key in keys))]


def score_parameters(
    bars: Sequence[dict],
    symbol: str,
    factory: Callable[[dict], Callable],
    params: dict,
    *,
    max_open_positions: Optional[int] = 1,
) -> Optional[tuple[Optional[float], int, float]]:
    """(expectancy_r, trade_count, net_pnl_usd), or None for an invalid combination."""

    try:
        provider = factory(params)
    except ValueError:
        return None

    result = run_costed_backtest(
        bars=list(bars),
        signal_provider=provider,
        symbol=symbol,
        max_open_positions=max_open_positions,
    )

    if not result.trades:
        return None, 0, 0.0

    summary = summarize_trades(
        [{"pnl_usd": t.net_pnl_usd, "result_r": t.result_r} for t in result.trades],
        initial_equity=result.starting_equity_usd,
    )

    return summary.expectancy_r, len(result.trades), sum(t.net_pnl_usd for t in result.trades)


def highest_expectancy(scored: list[ScoredCombination]) -> Optional[dict]:
    candidates = [(params, expectancy) for params, expectancy, _ in scored if expectancy is not None]
    if not candidates:
        return None
    return max(candidates, key=lambda item: item[1])[0]


def run_walk_forward(
    bars: list,
    symbol: str,
    *,
    param_grid: Optional[dict] = None,
    in_sample_bars: int = 300,
    out_of_sample_bars: int = 100,
    step_bars: Optional[int] = None,
    signal_provider_factory: Optional[Callable[[dict], Callable]] = None,
    select_params: Optional[Callable[[list[ScoredCombination]], Optional[dict]]] = None,
    max_open_positions: Optional[int] = 1,
) -> WalkForwardResult:
    """
    param_grid example: {"fast_ema_period": [5, 8, 13], "slow_ema_period": [21, 34]}.
    Invalid combinations (the factory raises ValueError) are skipped. If no
    combination trades in-sample, the first valid combination is scored, so the
    window is still recorded rather than silently dropped.
    """

    factory = signal_provider_factory or _default_ema_signal_provider_factory
    selector = select_params or highest_expectancy
    step = step_bars or out_of_sample_bars
    combinations = parameter_combinations(param_grid)

    bars = list(bars)
    windows: list[WindowResult] = []

    window_index = 0
    start = 0

    while start + in_sample_bars + out_of_sample_bars <= len(bars):

        in_sample = bars[start: start + in_sample_bars]
        out_of_sample = bars[start + in_sample_bars: start + in_sample_bars + out_of_sample_bars]

        scored: list[ScoredCombination] = []
        for params in combinations:
            outcome = score_parameters(in_sample, symbol, factory, params, max_open_positions=max_open_positions)
            if outcome is None:
                continue
            expectancy, trade_count, _ = outcome
            scored.append((params, expectancy, trade_count))

        if scored:
            chosen = selector(scored) or scored[0][0]
            chosen_expectancy = next((e for p, e, _ in scored if p == chosen), None)

            oos = score_parameters(out_of_sample, symbol, factory, chosen, max_open_positions=max_open_positions)
            oos_expectancy, oos_trade_count, oos_net_pnl = oos if oos is not None else (None, 0, 0.0)

            windows.append(
                WindowResult(
                    window_index=window_index,
                    in_sample_size=len(in_sample),
                    out_of_sample_size=len(out_of_sample),
                    chosen_params=dict(chosen),
                    in_sample_expectancy_r=chosen_expectancy,
                    out_of_sample_expectancy_r=oos_expectancy,
                    out_of_sample_trade_count=oos_trade_count,
                    out_of_sample_net_pnl_usd=oos_net_pnl,
                )
            )

        window_index += 1
        start += step

    return WalkForwardResult(symbol=symbol, windows=windows)
