"""
Time-series momentum - the sign of the past return.

HYPOTHESIS: a market that has risen over the last `lookback` days tends to keep
rising, and one that has fallen tends to keep falling, often enough across many
currencies and years to pay for the trade after costs. This is the
"time-series momentum" effect documented across futures and currencies; it is
modest, slow, and has had long flat or losing stretches.

Rules (OHLC only, closed bars only):
  Signal = BUY when the close is above the close `lookback` bars earlier, SELL when
           below, nothing when equal. With one position at a time, a new trade is
           taken on the first bar after the previous one exits.
  Stop   = stop_atr x ATR(atr_period) beyond the entry.
  Target = target_r x that risk beyond the entry (the live safety gate requires one).
  Trail  = when trail_atr > 0, the stop starts trail_atr x ATR away and trails the best
           price since entry at that distance; target_r is then only a distant cap.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "time-series-momentum"

DEFAULTS = {
    "lookback": 126,
    "stop_atr": 2.0,
    "atr_period": 20,
    "target_r": 3.0,
    "trail_atr": 0.0,
}


def evaluate(
    bars: list[dict], *,
    lookback: int, stop_atr: float, atr_period: int, target_r: float, trail_atr: float = 0.0,
) -> Optional[dict]:

    if len(bars) < max(lookback, atr_period) + 1:
        return None

    close = float(bars[-1]["close"])
    past = float(bars[-(lookback + 1)]["close"])

    if close > past:
        direction = "BUY"
    elif close < past:
        direction = "SELL"
    else:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    risk = (trail_atr if trail_atr > 0 else stop_atr) * atr
    stop, target = fixed_r_levels(direction, close, risk, target_r)
    signal = {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "lookback_return": close / past - 1.0 if past else None,
        "data_sources_used": ["ohlc_bars"],
    }
    if trail_atr > 0:
        signal["trailing_stop_distance"] = risk
    return signal


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["lookback"] < 1 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: lookback and atr_period must be >= 1")
    if settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: stop_atr and target_r must be positive")
    if settings["trail_atr"] < 0:
        raise ValueError(f"{STRATEGY_ID}: trail_atr must be >= 0")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
