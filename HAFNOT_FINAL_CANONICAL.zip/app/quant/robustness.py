"""
Parameter robustness / sensitivity testing.

Nothing like this existed anywhere in the project before (confirmed by
repo-wide search in the research/validation audit). A strategy that is
only profitable at one exact parameter combination, with performance
collapsing at small neighboring values, is a classic overfitting signature
even if that one combination back-tests beautifully.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Callable, Optional

from app.forex_v2.metrics import summarize_trades
from app.quant.costed_backtest import run_costed_backtest


@dataclass
class ParameterResult:
    params: dict
    trade_count: int
    expectancy_r: Optional[float]
    profit_factor: Optional[float]
    net_pnl_usd: float


@dataclass
class RobustnessResult:
    symbol: str
    results: list

    @property
    def profitable_fraction(self) -> float:
        """Fraction of the sweep grid that came out net-positive."""

        scored = [r for r in self.results if r.trade_count > 0]
        if not scored:
            return 0.0
        profitable = sum(1 for r in scored if r.net_pnl_usd > 0)
        return profitable / len(scored)

    @property
    def best(self) -> Optional[ParameterResult]:
        scored = [r for r in self.results if r.expectancy_r is not None]
        if not scored:
            return None
        return max(scored, key=lambda r: r.expectancy_r)


def _default_ema_signal_provider_factory(params: dict):
    """Backward-compatible default: app.forex_v2.strategy's EMA trend strategy."""

    from app.forex_v2.strategy import StrategyConfig
    from app.quant.strategy_adapter import make_signal_provider as ema_make_signal_provider

    config = StrategyConfig(**params)  # raises ValueError on an invalid combo
    return ema_make_signal_provider(config)


def run_robustness_sweep(
    bars: list,
    symbol: str,
    *,
    param_grid: dict,
    starting_equity_usd: float = 10_000.0,
    signal_provider_factory: Optional[Callable[[dict], Callable]] = None,
) -> RobustnessResult:
    """
    param_grid: {"fast_ema_period": [5, 8, 13], "slow_ema_period": [21, 34, 55], ...}
    Runs a costed backtest for every combination in the grid's Cartesian
    product and reports how performance varies across neighboring
    parameter choices, not just at one cherry-picked point.

    signal_provider_factory: params dict -> signal_provider(visible_bars, index).
    Defaults to the EMA trend strategy (app.forex_v2.strategy.StrategyConfig)
    for backward compatibility. Any other strategy family's make_signal_provider
    can be swept the same way - e.g.
    ``lambda p: app.quant.asian_range_breakout_strategy.make_signal_provider(**p)``
    - this sweep engine is not specific to one strategy.
    """

    factory = signal_provider_factory or _default_ema_signal_provider_factory

    keys = list(param_grid.keys())
    value_lists = [param_grid[k] for k in keys]

    results: list[ParameterResult] = []

    for combo in product(*value_lists):
        params = dict(zip(keys, combo))

        try:
            provider = factory(params)
        except ValueError:
            # Invalid combination (e.g. fast_ema_period >= slow_ema_period)
            # - skip rather than crash the whole sweep.
            continue

        result = run_costed_backtest(
            bars=list(bars),
            signal_provider=provider,
            symbol=symbol,
            starting_equity_usd=starting_equity_usd,
        )

        if not result.trades:
            results.append(
                ParameterResult(
                    params=params,
                    trade_count=0,
                    expectancy_r=None,
                    profit_factor=None,
                    net_pnl_usd=0.0,
                )
            )
            continue

        summary = summarize_trades(
            [{"pnl_usd": t.net_pnl_usd, "result_r": t.result_r} for t in result.trades],
            initial_equity=starting_equity_usd,
        )

        results.append(
            ParameterResult(
                params=params,
                trade_count=len(result.trades),
                expectancy_r=summary.expectancy_r,
                profit_factor=summary.profit_factor,
                net_pnl_usd=sum(t.net_pnl_usd for t in result.trades),
            )
        )

    return RobustnessResult(symbol=symbol, results=results)
