"""
Index VIX spike - buy US equity indices after a jump in implied volatility.

HYPOTHESIS: a sharp rise in the VIX, the market's implied volatility, marks fear-driven
selling and forced de-risking that usually overshoots; equity indices tend to recover
over the following days to weeks as that fear premium decays, enough to pay spread,
slippage and overnight financing. It uses information the price chart does not contain
(option-implied volatility, from FRED). Long only.

Rules (daily bars carrying the as-of VIX history, app.quant.bar_features "fred_daily"):
  Spike = the latest known VIX close is at least spike_pct above the mean of the `lookback`
          closes before it. With a one-day lag, a decision at a daily close uses the VIX
          close of an earlier day.
  BUY   = on a spike.
  Stop  = stop_atr x ATR(atr_period) below the close; target_r x that risk is a distant cap.
  Exit  = at the close `hold_bars` bars after entry, unless stopped.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "index-vix-spike"

DEFAULTS = {
    "spike_pct": 0.35,
    "hold_bars": 10,
    "lookback": 20,
    "stop_atr": 3.0,
    "atr_period": 20,
    "target_r": 10.0,
}


def evaluate(bars, *, spike_pct: float, hold_bars: int, lookback: int, stop_atr: float, atr_period: int,
             target_r: float) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    history = ((bars[-1].get("daily") or {}).get("VIX")) or []
    if len(history) < lookback + 1:
        return None
    latest = float(history[-1])
    base = sum(float(v) for v in history[-(lookback + 1):-1]) / lookback
    if base <= 0 or latest < base * (1 + spike_pct):
        return None
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bars[-1]["close"])
    stop, target = fixed_r_levels("BUY", close, stop_atr * atr, target_r)
    return {
        "direction": "BUY",
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "vix_latest": latest,
        "vix_base": base,
        "data_sources_used": ["ohlc_bars", "fred_vixcls"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["hold_bars"] < 1 or settings["atr_period"] < 1 or not 2 <= settings["lookback"] <= 59:
        raise ValueError(f"{STRATEGY_ID}: hold_bars and atr_period >= 1, lookback 2-59 required")
    if settings["spike_pct"] <= 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: spike_pct, stop_atr and target_r must be positive")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
