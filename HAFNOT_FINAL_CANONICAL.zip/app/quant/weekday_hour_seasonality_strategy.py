"""
Weekday-and-hour seasonality on H4 bars.

HYPOTHESIS: recurring flows at the same time of the week - fixings, session opens,
week-end position squaring, index rebalancing - make the average return of a given
weekday-and-time slot persist from week to week, strongly enough to trade the next
bar in that direction after costs. Same-time-of-day return persistence has been
documented in equity and FX markets; it is tested here, not assumed.

Rules (closed OHLC bars; slots in New York time, DST-aware):
  Slot     = (weekday, hour) of a bar's OPEN in New York time.
  History  = log(close / open) over each `hold_bars`-bar window, from the first bar's open to the last
             bar's close, kept per slot of the window's first bar: the last `lookback_weeks`. With
             hold_bars = 1 that is each bar's own return. A window's return is recorded only once
             its last bar has closed.
  Decision = at the close of bar t, the next bar is expected to open at t's open +
             `bar_minutes`. With at least half of `lookback_weeks` samples in that slot,
             t-stat = mean / (sd / sqrt(n)).
  BUY      = t-stat >= min_t;  SELL = t-stat <= -min_t.
  Stop     = stop_atr x ATR(atr_period) from the close; target_r x that risk is a distant cap.
  Exit     = at the close of `hold_bars` bars after entry (the engine's exit_after_bars),
             unless the stop or cap is hit first.
"""

from __future__ import annotations

import math
from collections import defaultdict, deque
from datetime import timedelta
from statistics import mean, stdev
from typing import Optional
from zoneinfo import ZoneInfo

from app.core.zones import parse_ts
from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "weekday-hour-seasonality"
NEW_YORK = ZoneInfo("America/New_York")

DEFAULTS = {
    "lookback_weeks": 52,
    "min_t": 1.5,
    "stop_atr": 1.0,
    "atr_period": 14,
    "target_r": 10.0,
    "hold_bars": 1,
    "bar_minutes": 240,
}


def slot_of(moment) -> tuple[int, int]:
    local = moment.astimezone(NEW_YORK)
    return local.weekday(), local.hour


class SlotHistory:
    """Per-slot returns of closed `window_bars`-bar windows, updated once per bar; a lower index (a new replay) starts over."""

    def __init__(self, lookback_weeks: int, window_bars: int = 1):
        self.lookback = int(lookback_weeks)
        self.window = int(window_bars)
        if self.window < 1:
            raise ValueError("window_bars must be at least 1")
        self.reset()

    def reset(self) -> None:
        self.returns = defaultdict(lambda: deque(maxlen=self.lookback))
        self.next_index = 0

    def update(self, bars: list, last_closed_index: int) -> None:
        if last_closed_index < self.next_index - 1:
            self.reset()
        for i in range(self.next_index, last_closed_index + 1):
            start = i - self.window + 1
            if start < 0:
                continue
            first = bars[start]
            opened = parse_ts(first.get("timestamp"))
            o, c = float(first["open"]), float(bars[i]["close"])
            if opened is not None and o > 0 and c > 0:
                self.returns[slot_of(opened)].append(math.log(c / o))
        self.next_index = max(self.next_index, last_closed_index + 1)


def evaluate(bars: list[dict], history: SlotHistory, *, lookback_weeks: int, min_t: float, stop_atr: float,
             atr_period: int, target_r: float, hold_bars: int, bar_minutes: int) -> Optional[dict]:
    n = len(bars)
    if n < atr_period + 2:
        return None
    history.update(bars, n - 1)
    opened = parse_ts(bars[-1].get("timestamp"))
    if opened is None:
        return None
    samples = history.returns.get(slot_of(opened + timedelta(minutes=bar_minutes)))
    if not samples or len(samples) < max(2, lookback_weeks // 2):
        return None

    average, spread = mean(samples), stdev(samples)
    if spread == 0:
        if average == 0:
            return None
        t_stat = math.copysign(math.inf, average)
    else:
        t_stat = average / (spread / math.sqrt(len(samples)))
    if t_stat >= min_t:
        direction = "BUY"
    elif t_stat <= -min_t:
        direction = "SELL"
    else:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bars[-1]["close"])
    stop, target = fixed_r_levels(direction, close, stop_atr * atr, target_r)
    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "slot_t_statistic": t_stat,
        "slot_samples": len(samples),
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["lookback_weeks"] < 4 or settings["atr_period"] < 1 or settings["hold_bars"] < 1 or settings["bar_minutes"] < 1:
        raise ValueError(f"{STRATEGY_ID}: lookback_weeks >= 4, atr_period, hold_bars and bar_minutes >= 1 required")
    if settings["min_t"] <= 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: min_t, stop_atr and target_r must be positive")
    history = SlotHistory(int(settings["lookback_weeks"]), window_bars=int(settings["hold_bars"]))

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, history, **settings)

    return signal_provider
