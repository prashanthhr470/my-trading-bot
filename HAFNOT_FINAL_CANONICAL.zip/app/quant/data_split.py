"""
In-sample / out-of-sample splitting.

Nothing in this project did this before (confirmed by repo-wide search -
see the research/validation audit). A strategy must only be tuned on the
in-sample slice and scored exactly once on the untouched out-of-sample
slice; mixing the two, or re-tuning after seeing OOS results, defeats the
entire point and silently reintroduces the overfitting this is meant to
catch.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Split:
    in_sample: list
    out_of_sample: list
    split_index: int


def chronological_split(bars: list, in_sample_fraction: float = 0.7) -> Split:
    """
    Split bars into an earlier in-sample slice and a later out-of-sample
    slice, in chronological (list) order - never randomly, since a random
    split would let out-of-sample bars leak into in-sample indicator
    warm-up windows and vice versa.
    """

    if not 0.0 < in_sample_fraction < 1.0:
        raise ValueError("in_sample_fraction must be between 0 and 1, exclusive")

    bars = list(bars)
    split_index = int(round(len(bars) * in_sample_fraction))
    split_index = max(1, min(split_index, len(bars) - 1)) if len(bars) > 1 else len(bars)

    return Split(
        in_sample=bars[:split_index],
        out_of_sample=bars[split_index:],
        split_index=split_index,
    )


@dataclass
class ThreeWaySplit:
    train: list
    validation: list
    locked_out_of_sample: list
    train_end_index: int
    validation_end_index: int


def three_way_chronological_split(
    bars: list, *,
    train_fraction: float = 0.5,
    validation_fraction: float = 0.25,
) -> ThreeWaySplit:
    """
    TRAIN -> VALIDATION -> LOCKED_OUT_OF_SAMPLE, in chronological order.

    TRAIN is for developing/selecting a strategy (trying strategy families,
    picking an entry rule). VALIDATION is for parameter tuning and
    walk-forward runs - it can be looked at repeatedly while iterating.
    LOCKED_OUT_OF_SAMPLE is scored AT MOST ONCE per strategy candidate -
    see app.quant.locked_oos_guard.LockedOutOfSampleGuard, which enforces
    this instead of leaving it as a convention a re-run could silently
    violate.
    """

    if not 0.0 < train_fraction < 1.0:
        raise ValueError("train_fraction must be between 0 and 1, exclusive")
    if not 0.0 < validation_fraction < 1.0:
        raise ValueError("validation_fraction must be between 0 and 1, exclusive")
    if train_fraction + validation_fraction >= 1.0:
        raise ValueError("train_fraction + validation_fraction must leave room for a locked out-of-sample slice")

    bars = list(bars)
    n = len(bars)

    train_end = int(round(n * train_fraction))
    validation_end = int(round(n * (train_fraction + validation_fraction)))

    train_end = max(1, min(train_end, n - 2)) if n > 2 else n
    validation_end = max(train_end + 1, min(validation_end, n - 1)) if n > 2 else n

    return ThreeWaySplit(
        train=bars[:train_end],
        validation=bars[train_end:validation_end],
        locked_out_of_sample=bars[validation_end:],
        train_end_index=train_end,
        validation_end_index=validation_end,
    )
