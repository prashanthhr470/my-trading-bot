"""
Strategy Scorecard.

Summarises every recorded result for a strategy (app.quant.strategy_registry)
into one standardised report. Two hard rules:

  1. A strategy is never promoted or judged on one metric alone.
  2. A metric that has not actually been measured is reported as
     NOT_YET_MEASURED, never silently omitted or estimated.

RESULTS ARE GROUPED BY EXPERIMENT DESIGN AND NEVER SUMMED ACROSS DESIGNS.
An earlier version added every record together. That was wrong, not merely
imprecise: the registry holds a 2-year and a 5-year test of the same symbol
(overlapping in time), corrected re-runs next to the results they replace,
and single-symbol rows next to the 8-symbol total that already contains
them. Summing those produced numbers such as "382 out-of-sample trades" for
a test that had 348.

A design is the test type with its in-sample/out-of-sample token and any
_NNPCT split suffix removed, so IN_SAMPLE_8_SYMBOLS_70PCT pairs with
OUT_OF_SAMPLE_8_SYMBOLS_30PCT. Within a design and side, a record is
excluded from the totals (but still listed) when:
  - a later record has the same test type and symbol (an earlier run),
  - another record declares it superseded (scorecard["supersedes"] begins
    with its test type, for the same symbol), or
  - an "ALL" row exists on that side, making a single-symbol row a subset.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional

from app.quant.overfitting_defense import flag_is_oos_divergence, flag_small_sample
from app.quant.strategy_registry import get_results, load_strategy

NOT_YET_MEASURED = "NOT_YET_MEASURED"

IN_SAMPLE = "IN_SAMPLE"
OUT_OF_SAMPLE = "OUT_OF_SAMPLE"
SINGLE = "SINGLE"


@dataclass
class SideTotals:
    trades: int = 0
    net_pnl_usd: float = 0.0
    has_trade_data: bool = False
    per_symbol: dict[str, dict[str, Any]] = field(default_factory=dict)
    excluded: list[str] = field(default_factory=list)


@dataclass
class DesignSummary:
    design: str
    sides: dict[str, SideTotals] = field(default_factory=dict)

    @property
    def has_in_and_out_of_sample(self) -> bool:
        return (
            self.sides.get(IN_SAMPLE, SideTotals()).has_trade_data
            and self.sides.get(OUT_OF_SAMPLE, SideTotals()).has_trade_data
        )


@dataclass
class Scorecard:
    strategy_id: str
    version: str
    family: str
    total_test_records: int
    designs: list[DesignSummary] = field(default_factory=list)
    overfitting_flags: list[str] = field(default_factory=list)

    sharpe_ratio: Any = NOT_YET_MEASURED
    sortino_ratio: Any = NOT_YET_MEASURED
    max_drawdown: Any = NOT_YET_MEASURED
    parameter_sensitivity: Any = NOT_YET_MEASURED
    monte_carlo_robustness: Any = NOT_YET_MEASURED
    transaction_cost_sensitivity: Any = NOT_YET_MEASURED
    performance_by_regime: Any = NOT_YET_MEASURED

    verdict: str = ""

    def design(self, name: str) -> Optional[DesignSummary]:
        return next((d for d in self.designs if d.design == name), None)


def side_of(test_type: str) -> str:
    upper = test_type.upper()
    if OUT_OF_SAMPLE in upper:
        return OUT_OF_SAMPLE
    if IN_SAMPLE in upper:
        return IN_SAMPLE
    return SINGLE


def design_key(test_type: str) -> str:
    stripped = test_type.upper().replace(OUT_OF_SAMPLE, "").replace(IN_SAMPLE, "")
    stripped = re.sub(r"_?\d+PCT$", "", stripped).strip("_")
    return stripped or "BASE"


def _trade_data(scorecard: dict[str, Any]) -> tuple[Optional[int], Optional[float]]:
    trades = scorecard.get("trade_count", scorecard.get("total_trades"))
    net = scorecard.get("net_pnl_usd", scorecard.get("total_net_pnl_usd"))
    if trades is None and net is None:
        return None, None
    return int(trades or 0), float(net or 0.0)


def _included_records(results: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[int, str]]:
    """Returns (included records, {record index: exclusion reason})."""

    exclusions: dict[int, str] = {}

    latest_index: dict[tuple[str, str], int] = {}
    for index, record in enumerate(results):
        latest_index[(record.get("test_type", ""), record.get("symbol", ""))] = index
    for index, record in enumerate(results):
        key = (record.get("test_type", ""), record.get("symbol", ""))
        if latest_index[key] != index:
            exclusions[index] = f"{key[1]}: earlier run of {key[0]}"

    superseded_by: dict[tuple[str, str], str] = {}
    for record in results:
        text = (record.get("scorecard") or {}).get("supersedes")
        match = re.match(r"\s*([A-Z0-9_]+)", text) if isinstance(text, str) else None
        if match:
            superseded_by[(match.group(1), record.get("symbol", ""))] = record.get("test_type", "")
    for index, record in enumerate(results):
        key = (record.get("test_type", ""), record.get("symbol", ""))
        if index not in exclusions and key in superseded_by:
            exclusions[index] = f"{key[1]}: superseded by {superseded_by[key]}"

    # An ALL row marks its design/side as an aggregate even once superseded:
    # a single-symbol row was part of that aggregate either way.
    has_all_row = {
        (design_key(r.get("test_type", "")), side_of(r.get("test_type", "")))
        for r in results
        if r.get("symbol") == "ALL"
    }
    for index, record in enumerate(results):
        group = (design_key(record.get("test_type", "")), side_of(record.get("test_type", "")))
        if index not in exclusions and record.get("symbol") != "ALL" and group in has_all_row:
            exclusions[index] = f"{record.get('symbol')}: subset of the ALL row"

    included = [r for i, r in enumerate(results) if i not in exclusions]
    return included, exclusions


def build_scorecard(strategy_id: str, version: str) -> Scorecard:

    spec = load_strategy(strategy_id, version)
    results = get_results(strategy_id, version)
    included, exclusions = _included_records(results)

    designs: dict[str, DesignSummary] = {}

    for index, record in enumerate(results):
        test_type = record.get("test_type", "UNKNOWN")
        summary = designs.setdefault(design_key(test_type), DesignSummary(design=design_key(test_type)))
        side = summary.sides.setdefault(side_of(test_type), SideTotals())

        if index in exclusions:
            side.excluded.append(exclusions[index])
            continue

        trades, net = _trade_data(record.get("scorecard") or {})
        if trades is None:
            continue

        symbol = record.get("symbol", "UNKNOWN")
        side.has_trade_data = True
        side.trades += trades
        side.net_pnl_usd += net
        bucket = side.per_symbol.setdefault(symbol, {"trades": 0, "net_pnl_usd": 0.0})
        bucket["trades"] += trades
        bucket["net_pnl_usd"] += net

    for summary in designs.values():
        for side in summary.sides.values():
            side.net_pnl_usd = round(side.net_pnl_usd, 2)
            for bucket in side.per_symbol.values():
                bucket["net_pnl_usd"] = round(bucket["net_pnl_usd"], 2)

    measured: dict[str, Any] = {}
    for record in included:
        scorecard_data = record.get("scorecard") or {}
        for name in ("sharpe_ratio", "sortino_ratio", "max_drawdown_percent"):
            if scorecard_data.get(name) is not None and name not in measured:
                measured[name] = scorecard_data[name]

    overfitting_flags: list[str] = []

    for summary in designs.values():
        if not summary.has_in_and_out_of_sample:
            continue
        is_side, oos_side = summary.sides[IN_SAMPLE], summary.sides[OUT_OF_SAMPLE]
        for flag in flag_is_oos_divergence(
            in_sample_trades=is_side.trades, in_sample_net_pnl_usd=is_side.net_pnl_usd,
            out_of_sample_trades=oos_side.trades, out_of_sample_net_pnl_usd=oos_side.net_pnl_usd,
        ):
            overfitting_flags.append(f"[{summary.design}] {flag}")

    overfitting_flags.extend(flag_small_sample(included))

    for record in included:
        test_type = record.get("test_type", "").upper()
        if "WINDOW" not in test_type and "ROLLING" not in test_type:
            continue
        scorecard_data = record.get("scorecard") or {}
        windows, profitable = scorecard_data.get("windows"), scorecard_data.get("profitable_windows")
        if windows and profitable is not None and profitable / windows < 0.6:
            overfitting_flags.append(
                f"Rolling-window consistency check: only {profitable}/{windows} "
                f"windows profitable ({profitable / windows:.0%}) - not a consistent, repeatable edge."
            )

    any_trades = any(
        side.has_trade_data and side.trades > 0
        for summary in designs.values()
        for side in summary.sides.values()
    )
    positive_design = any(
        summary.has_in_and_out_of_sample
        and summary.sides[IN_SAMPLE].trades > 0 and summary.sides[OUT_OF_SAMPLE].trades > 0
        and summary.sides[IN_SAMPLE].net_pnl_usd > 0 and summary.sides[OUT_OF_SAMPLE].net_pnl_usd > 0
        for summary in designs.values()
    )

    if not any_trades:
        verdict = "NO TRADES RECORDED - cannot assess."
    elif overfitting_flags:
        verdict = "NOT VALIDATED - overfitting/consistency concerns flagged below. Do not treat as proven."
    elif positive_design:
        verdict = (
            "PROMISING BUT UNPROVEN - positive in both in-sample and out-of-sample within one design; "
            "needs walk-forward, Monte Carlo and more symbols before any promotion."
        )
    else:
        verdict = "NOT PROFITABLE based on recorded evidence."

    return Scorecard(
        strategy_id=strategy_id,
        version=version,
        family=spec.family,
        total_test_records=len(results),
        designs=list(designs.values()),
        overfitting_flags=overfitting_flags,
        verdict=verdict,
        sharpe_ratio=measured.get("sharpe_ratio", NOT_YET_MEASURED),
        sortino_ratio=measured.get("sortino_ratio", NOT_YET_MEASURED),
        max_drawdown=measured.get("max_drawdown_percent", NOT_YET_MEASURED),
    )


def print_scorecard(card: Scorecard) -> None:
    print()
    print("=" * 78)
    print(f" SCORECARD: {card.strategy_id} v{card.version}  ({card.family})")
    print("=" * 78)
    print(f"Test records: {card.total_test_records}")
    print("Results by experiment design - never summed across designs (they overlap in time):")

    for summary in card.designs:
        print()
        print(f"  [{summary.design}]")
        for side_name in (IN_SAMPLE, OUT_OF_SAMPLE, SINGLE):
            side = summary.sides.get(side_name)
            if side is None:
                continue
            label = "result" if side_name == SINGLE else side_name
            if side.has_trade_data:
                symbols = ", ".join(
                    f"{s} {v['trades']}/${v['net_pnl_usd']:,.2f}" for s, v in sorted(side.per_symbol.items())
                )
                print(f"    {label:<14} trades={side.trades:>5}  net=${side.net_pnl_usd:>11,.2f}   {symbols}")
            else:
                print(f"    {label:<14} (no trade totals in this record type)")
            for reason in side.excluded:
                print(f"    {'':<14} excluded from totals - {reason}")

    print()
    print("RISK-ADJUSTED METRICS (NOT_YET_MEASURED = real gap, not hidden as zero):")
    print(f"  Sharpe ratio                : {card.sharpe_ratio}")
    print(f"  Sortino ratio               : {card.sortino_ratio}")
    print(f"  Max drawdown                : {card.max_drawdown}")
    print(f"  Parameter sensitivity       : {card.parameter_sensitivity}")
    print(f"  Monte Carlo robustness      : {card.monte_carlo_robustness}")
    print(f"  Transaction-cost sensitivity: {card.transaction_cost_sensitivity}")
    print(f"  Performance by regime       : {card.performance_by_regime}")
    print()
    if card.overfitting_flags:
        print("FLAGS:")
        for flag in card.overfitting_flags:
            print(f"  - {flag}")
        print()
    print(f"VERDICT: {card.verdict}")
    print("=" * 78)
