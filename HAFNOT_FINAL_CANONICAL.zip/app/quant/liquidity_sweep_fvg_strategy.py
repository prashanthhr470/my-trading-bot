"""
Liquidity Sweep + Fair Value Gap (FVG) strategy.

A mechanical implementation of a discretionary institutional-style ("Smart
Money Concepts") setup: mark higher-timeframe liquidity (previous day
high/low, equal highs/lows, Asian session high/low) -> wait for a sweep
(a wick through that level with a strong rejection back inside) -> confirm
a Market Structure Shift (an impulsive break of the most recent opposing
swing point, on a LATER bar than the sweep - not the same bar) -> require
a Fair Value Gap formed during that displacement leg that overlaps the
50%-61.8% Fibonacci retracement of the sweep-to-shift move -> enter only
when price actually retraces back into that zone (a limit-order concept,
not an immediate market entry).

HONEST LIMITATIONS - this is a real, working implementation, but it is a
MECHANICAL approximation of what is normally a discretionary, visually-
judged setup. Specific things this does NOT do:

  - No partial take-profit + move-to-breakeven at TP1. The backtest engine
    (app.backtest.engine) supports exactly one stop-loss and one
    take-profit per trade. TP1 (the nearer target) is computed and
    attached for reference, but the backtest is scored against TP2 only -
    a full partial-exit model would require extending PaperPosition/the
    backtest engine itself, which has not been done.
  - No historical news-event blackout (CPI/NFP avoidance) - no historical
    economic calendar dataset has been downloaded. The live paper-trading
    system's news firewall (app/ai/decision_gate.py) is separate and does
    apply in live/paper trading, just not in this specific backtest.
  - "Equal highs/lows" uses a fixed tolerance (0.05% of price) - real
    equal-highs judgment is often more visually nuanced than a fixed
    percentage.
  - Zones are computed from the same single-timeframe bar series passed
    in (typically M5), by aggregating a trailing window into daily/session
    buckets, rather than from separately-fetched H1/H4/D1 series. This
    keeps the implementation self-contained and anti-lookahead-safe
    without touching the existing (tested) backtest engine, at the cost
    of needing enough M5 history in the trailing window to see a full
    prior day and Asian session.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

LOOKBACK_BARS = 600
SWING_CONFIRM_BARS = 3
EQUAL_LEVEL_TOLERANCE_PCT = 0.0005
MIN_REJECTION_WICK_FRACTION = 0.5

# How many bars after a sweep the Market Structure Shift is allowed to take
# to confirm, and then how many further bars price has to retrace back into
# the entry zone. Bounds the backward scan so this stays anti-lookahead-safe
# and fast; a real setup that takes longer than this to develop is treated
# as invalidated (consistent with "no retest, no trade").
MAX_BARS_TO_MSS = 60
MAX_BARS_TO_RETRACEMENT = 40

LONDON_WINDOW_UTC = (7, 10)
NY_WINDOW_UTC = (13, 16)
ASIAN_SESSION_WINDOW_UTC = (0, 8)

MIN_REWARD_TO_RISK_TP2 = 1.5


def _parse_ts(raw) -> Optional[datetime]:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
    try:
        text = str(raw).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _in_session_window(ts: datetime, window: tuple[int, int]) -> bool:
    start_hour, end_hour = window
    return start_hour <= ts.hour < end_hour


@dataclass
class SwingPoint:
    index: int
    price: float
    kind: str  # "high" or "low"


def _find_confirmed_swings(bars: list[dict]) -> list[SwingPoint]:
    """Fractal swing points, confirmed within the given slice only."""

    swings: list[SwingPoint] = []
    n = len(bars)

    for i in range(SWING_CONFIRM_BARS, n - SWING_CONFIRM_BARS):
        w = bars[i - SWING_CONFIRM_BARS: i + SWING_CONFIRM_BARS + 1]
        high_i = bars[i]["high"]
        low_i = bars[i]["low"]

        if high_i == max(b["high"] for b in w):
            swings.append(SwingPoint(index=i, price=high_i, kind="high"))
        if low_i == min(b["low"] for b in w):
            swings.append(SwingPoint(index=i, price=low_i, kind="low"))

    return swings


def _daily_and_session_zones(bars: list[dict]) -> dict:
    dated_bars = []
    for b in bars:
        ts = _parse_ts(b.get("timestamp"))
        if ts is not None:
            dated_bars.append((ts, b))

    if not dated_bars:
        return {}

    latest_ts = dated_bars[-1][0]
    today = latest_ts.date()
    yesterday = today - timedelta(days=1)

    pdh = pdl = None
    for ts, b in dated_bars:
        if ts.date() == yesterday:
            pdh = b["high"] if pdh is None else max(pdh, b["high"])
            pdl = b["low"] if pdl is None else min(pdl, b["low"])

    asian_high = asian_low = None
    for ts, b in dated_bars:
        if ts.date() == today and _in_session_window(ts, ASIAN_SESSION_WINDOW_UTC):
            asian_high = b["high"] if asian_high is None else max(asian_high, b["high"])
            asian_low = b["low"] if asian_low is None else min(asian_low, b["low"])

    return {"pdh": pdh, "pdl": pdl, "asian_high": asian_high, "asian_low": asian_low}


def _equal_level_cluster(swings: list[SwingPoint], kind: str) -> Optional[float]:
    points = [s for s in swings if s.kind == kind]
    for i in range(len(points) - 1, 0, -1):
        a, b = points[i], points[i - 1]
        tolerance = abs(a.price) * EQUAL_LEVEL_TOLERANCE_PCT
        if abs(a.price - b.price) <= tolerance:
            return (a.price + b.price) / 2.0
    return None


def _find_fvg_overlapping_zone(
    bars: list[dict], start_index: int, end_index: int,
    zone_low: float, zone_high: float, direction: str,
) -> Optional[tuple[float, float]]:
    """Scan bars[start_index:end_index+1] for a 3-candle FVG overlapping the zone."""

    for i in range(end_index, start_index + 1, -1):
        if i - 2 < 0:
            continue
        c1, c3 = bars[i - 2], bars[i]

        if direction == "BUY":
            if c1["high"] < c3["low"]:
                fvg_low, fvg_high = c1["high"], c3["low"]
                if fvg_high >= zone_low and fvg_low <= zone_high:
                    return fvg_low, fvg_high
        else:
            if c1["low"] > c3["high"]:
                fvg_low, fvg_high = c3["high"], c1["low"]
                if fvg_high >= zone_low and fvg_low <= zone_high:
                    return fvg_low, fvg_high

    return None


def _bar_overlaps_zone(bar: dict, zone_low: float, zone_high: float) -> bool:
    return bar["low"] <= zone_high and bar["high"] >= zone_low


def _try_direction(window: list[dict], swings: list[SwingPoint], direction: str, candidate_sweep_levels: list[float]) -> Optional[dict]:

    n = len(window)
    is_buy = direction == "BUY"

    # ------------------------------------------------------------
    # 1. FIND THE MOST RECENT SWEEP (scan backward so we prefer the
    #    freshest setup; leave room after it for MSS + retracement).
    # ------------------------------------------------------------

    earliest_sweep_search = max(SWING_CONFIRM_BARS, n - MAX_BARS_TO_MSS - MAX_BARS_TO_RETRACEMENT - 5)

    sweep_idx = None
    swept_level = None

    for i in range(n - MAX_BARS_TO_RETRACEMENT - 1, earliest_sweep_search - 1, -1):
        if i < 0:
            break
        bar = window[i]
        bar_range = max(bar["high"] - bar["low"], 1e-9)

        for level in candidate_sweep_levels:
            if is_buy:
                if bar["low"] < level <= bar["close"]:
                    wick = bar["close"] - bar["low"]
                    if wick / bar_range >= MIN_REJECTION_WICK_FRACTION:
                        sweep_idx, swept_level = i, level
                        break
            else:
                if bar["high"] > level >= bar["close"]:
                    wick = bar["high"] - bar["close"]
                    if wick / bar_range >= MIN_REJECTION_WICK_FRACTION:
                        sweep_idx, swept_level = i, level
                        break
        if sweep_idx is not None:
            break

    if sweep_idx is None:
        return None

    # ------------------------------------------------------------
    # 2. MARKET STRUCTURE SHIFT: a LATER bar closes beyond the most
    #    recent opposing swing point confirmed BEFORE the sweep.
    # ------------------------------------------------------------

    opposing_kind = "high" if is_buy else "low"
    prior_swings = [s for s in swings if s.index < sweep_idx and s.kind == opposing_kind]
    if not prior_swings:
        return None

    target_swing = prior_swings[-1]

    mss_idx = None
    mss_search_end = min(n - 1, sweep_idx + MAX_BARS_TO_MSS)
    for i in range(sweep_idx + 1, mss_search_end + 1):
        if is_buy and window[i]["close"] > target_swing.price:
            mss_idx = i
            break
        if not is_buy and window[i]["close"] < target_swing.price:
            mss_idx = i
            break

    if mss_idx is None:
        return None

    # ------------------------------------------------------------
    # 3. FIBONACCI GOLDEN ZONE + FVG within the displacement leg.
    # ------------------------------------------------------------

    if is_buy:
        swing_low_price = window[sweep_idx]["low"]
        swing_high_price = max(window[i]["high"] for i in range(sweep_idx, mss_idx + 1))
        fib_range = swing_high_price - swing_low_price
        if fib_range <= 0:
            return None
        golden_low = swing_high_price - 0.618 * fib_range
        golden_high = swing_high_price - 0.5 * fib_range
    else:
        swing_high_price = window[sweep_idx]["high"]
        swing_low_price = min(window[i]["low"] for i in range(sweep_idx, mss_idx + 1))
        fib_range = swing_high_price - swing_low_price
        if fib_range <= 0:
            return None
        golden_low = swing_low_price + 0.5 * fib_range
        golden_high = swing_low_price + 0.618 * fib_range

    fvg = _find_fvg_overlapping_zone(window, sweep_idx, mss_idx, golden_low, golden_high, direction)
    if fvg is None:
        return None

    fvg_low, fvg_high = fvg
    entry = (fvg_low + fvg_high) / 2.0

    # ------------------------------------------------------------
    # 4. RETRACEMENT ENTRY: price must have come back into the zone,
    #    and this must be the FIRST bar (after MSS) to do so - "no
    #    retest, no trade" also means we don't keep re-signaling every
    #    bar price happens to sit inside an already-touched zone.
    # ------------------------------------------------------------

    latest_idx = n - 1
    if latest_idx <= mss_idx:
        return None

    if not _bar_overlaps_zone(window[latest_idx], fvg_low, fvg_high):
        return None

    for i in range(mss_idx + 1, latest_idx):
        if _bar_overlaps_zone(window[i], fvg_low, fvg_high):
            # Already touched the zone on an earlier bar - this is a
            # re-visit, not the first retracement; skip (matches "if
            # price moves directly toward target without pulling back,
            # cancel" - the inverse also holds: don't chase a zone
            # that's already been tagged once).
            return None

    # ------------------------------------------------------------
    # 5. STOP-LOSS / TAKE-PROFITS
    # ------------------------------------------------------------

    buffer = fib_range * 0.05

    if is_buy:
        stop_loss = swing_low_price - buffer
        opposing_levels = [lv for lv in candidate_sweep_levels if lv > entry]
    else:
        stop_loss = swing_high_price + buffer
        opposing_levels = [lv for lv in candidate_sweep_levels if lv < entry]

    tp1 = min(opposing_levels, key=lambda v: abs(v - entry)) if opposing_levels else None
    tp2 = (max(opposing_levels) if is_buy else min(opposing_levels)) if opposing_levels else None

    if tp2 is None:
        risk = (entry - stop_loss) if is_buy else (stop_loss - entry)
        if risk <= 0:
            return None
        tp2 = entry + risk * 2.0 if is_buy else entry - risk * 2.0

    if is_buy:
        risk = entry - stop_loss
        reward = tp2 - entry
        valid_structure = stop_loss < entry < tp2
    else:
        risk = stop_loss - entry
        reward = entry - tp2
        valid_structure = tp2 < entry < stop_loss

    if not valid_structure or risk <= 0 or reward / risk < MIN_REWARD_TO_RISK_TP2:
        return None

    return {
        "direction": direction,
        "entry": entry,
        "stop_loss": stop_loss,
        "take_profit": tp2,
        "take_profit_1": tp1,
    }


def evaluate(bars: list[dict]) -> Optional[dict]:
    """
    Evaluate the most recent bar in `bars` for a liquidity-sweep+FVG setup.
    `bars` must be oldest-to-newest; only the trailing LOOKBACK_BARS are
    used. Returns None or a dict with direction/entry/stop_loss/
    take_profit/take_profit_1.
    """

    if len(bars) < SWING_CONFIRM_BARS * 2 + MAX_BARS_TO_MSS + MAX_BARS_TO_RETRACEMENT:
        return None

    window = bars[-LOOKBACK_BARS:]
    n = len(window)

    latest_ts = _parse_ts(window[-1].get("timestamp"))
    if latest_ts is None:
        return None

    if not (_in_session_window(latest_ts, LONDON_WINDOW_UTC) or _in_session_window(latest_ts, NY_WINDOW_UTC)):
        return None

    zones = _daily_and_session_zones(window)
    swings = _find_confirmed_swings(window)

    eq_high = _equal_level_cluster(swings, "high")
    eq_low = _equal_level_cluster(swings, "low")

    high_levels = [v for v in (zones.get("pdh"), zones.get("asian_high"), eq_high) if v is not None]
    low_levels = [v for v in (zones.get("pdl"), zones.get("asian_low"), eq_low) if v is not None]

    signal = _try_direction(window, swings, "BUY", low_levels)
    if signal:
        return signal

    return _try_direction(window, swings, "SELL", high_levels)


def make_signal_provider():
    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars)

    return signal_provider
