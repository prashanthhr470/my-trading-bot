"""
Shock-day continuation - the price footprint of news.

HYPOTHESIS: a day whose range is far larger than normal, closing near its extreme,
usually reflects new information (a data release, a central-bank surprise, a geopolitical
event). Markets absorb such news over several days, so the move continues often and far
enough, with a stop at the far end of the shock day, to pay for costs. The broker offers
no historical news calendar, so the shock is identified from price alone.

Rules (closed daily OHLC bars):
  ATR     = ATR(atr_period) of the bars BEFORE the decision bar.
  Shock   = the decision bar's true range >= shock_atr x that ATR.
  BUY     = it closes in the top `close_zone` of its range; SELL = in the bottom `close_zone`.
  Stop    = the shock bar's low (BUY) or high (SELL).
  Target  = target_r x the risk from the close.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "shock-day-continuation"

DEFAULTS = {
    "shock_atr": 2.0,
    "close_zone": 0.25,
    "atr_period": 20,
    "target_r": 2.0,
}


def evaluate(bars: list[dict], *, shock_atr: float, close_zone: float, atr_period: int, target_r: float) -> Optional[dict]:
    if len(bars) < atr_period + 2:
        return None
    atr = average_true_range(bars[-(atr_period + 2):-1], atr_period)
    if not atr:
        return None

    bar = bars[-1]
    h, l, c = float(bar["high"]), float(bar["low"]), float(bar["close"])
    previous_close = float(bars[-2]["close"])
    true_range = max(h - l, abs(h - previous_close), abs(l - previous_close))
    span = h - l
    if true_range < shock_atr * atr or span <= 0:
        return None
    if c >= h - close_zone * span:
        direction, stop = "BUY", l
    elif c <= l + close_zone * span:
        direction, stop = "SELL", h
    else:
        return None

    risk = abs(c - stop)
    if risk <= 0:
        return None
    stop_loss, take_profit = fixed_r_levels(direction, c, risk, target_r)
    return {
        "direction": direction,
        "entry": c,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "reward_to_risk": target_r,
        "shock_true_range_atr": true_range / atr,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["atr_period"] < 1 or settings["shock_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: atr_period >= 1, shock_atr and target_r positive required")
    if not 0 < settings["close_zone"] < 0.5:
        raise ValueError(f"{STRATEGY_ID}: close_zone must be between 0 and 0.5")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
