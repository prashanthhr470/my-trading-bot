"""
Realistic-cost backtest wrapper.

app.backtest.engine.BacktestEngine is a correct anti-lookahead OHLC replay
loop, but its raw R-multiples are pure price-distance ratios: no spread, no
slippage, no commission, no realistic position sizing. This module runs the
engine, then re-prices every raw trade through app.forex_v2.risk's
proven, tested cost model (spread cap, adverse-slippage fills, round-turn
commission, equity-percent position sizing) to produce trade-by-trade $
P&L and cost-adjusted R-multiples, compounding equity chronologically the
same way a real account would.

The engine records a trade for every signal, even while an earlier trade on
the same symbol is still open, so it can hold overlapping positions that the
live risk model (one position per symbol) would never allow.
`max_open_positions` enforces that limit here; a trade only occupies a slot
if the risk model actually accepted it.

Only symbols in app.forex_v2.risk.FX_USD_MAJOR_SPECS, or USD-quoted research
instruments registered from broker data (app.forex_v2.instrument_specs), can be
costed this way (see the risk module's docstring for why cross pairs are excluded).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from app.backtest.engine import BacktestEngine
from app.forex_v2.risk import (
    AccountState,
    FxQuote,
    PaperPosition,
    RiskConfig,
    RiskDecision,
    TradeRequest,
    close_paper_position,
    evaluate_paper_trade,
    resolve_spec,
)

MAX_OPEN_POSITIONS_REASON = "MAX_OPEN_POSITIONS"


@dataclass
class CostedTrade:
    entry_index: int
    exit_index: int
    symbol: str
    side: str
    lots: float
    entry_fill_price: float
    exit_fill_price: float
    risk_amount_usd: float
    gross_pnl_usd: float
    net_pnl_usd: float
    result_r: float
    equity_after_usd: float
    exit_reason: str = ""   # the engine's STOP / TAKE_PROFIT / TIME / END_OF_DATA


@dataclass
class CostedBacktestResult:
    symbol: str
    supported: bool
    starting_equity_usd: float
    ending_equity_usd: float
    raw_signal_count: int
    accepted_trade_count: int
    rejected_trade_count: int
    rejection_reasons: dict[str, int]
    trades: list[CostedTrade] = field(default_factory=list)


def is_costable_symbol(symbol: str) -> bool:
    return resolve_spec(str(symbol).upper()) is not None


def run_costed_backtest(
    bars: list[dict],
    signal_provider: Callable[[list, int], Any],
    symbol: str,
    *,
    starting_equity_usd: float = 10_000.0,
    risk_config: Optional[RiskConfig] = None,
    assumed_spread_pips: float = 1.2,
    max_open_positions: Optional[int] = 1,
    bid_bars: bool = False,
    close_open_at_end: bool = False,
) -> CostedBacktestResult:
    """
    Run the anti-lookahead OHLC replay, then cost every raw trade through
    the real risk/execution model, compounding equity chronologically.

    assumed_spread_pips: OHLC bars carry no historical bid/ask, so a fixed
    assumed spread is used to synthesize a quote around each raw entry
    price. This is a known approximation - real spread varies by session
    and volatility. 1.2 pips is a reasonable default for a liquid major;
    override it for less liquid symbols or wider-typical-spread instruments.

    max_open_positions: defaults to 1, matching the live one-position-per-
    symbol rule. A signal that would exceed the limit is rejected as
    MAX_OPEN_POSITIONS; a position opened at bar i and exited during bar e
    frees its slot for a new decision at bar e or later. None restores the
    engine's historical behaviour (overlapping positions allowed), which every
    result recorded before 2026-09-12 used.

    bid_bars: False (the default, used by every result recorded so far) centres
    a synthetic quote on the bar price, charging HALF of assumed_spread_pips at
    entry. cTrader trendbars are BID prices (verified 2026-09-14 against raw
    broker quotes), so a real round trip pays the WHOLE spread once: a BUY on
    entry at the ask, a SELL on exit when it buys back at the ask. True models
    exactly that, with assumed_spread_pips as the full spread - so it should be
    a measured per-symbol value, not the uniform 1.2-pip default.

    close_open_at_end: passed to the engine - a trade still open after the last bar
    is closed at that bar's close instead of being dropped.
    """

    symbol = symbol.upper()
    config = risk_config or RiskConfig()

    if max_open_positions is not None and max_open_positions < 1:
        raise ValueError("max_open_positions must be None or at least 1")

    if not is_costable_symbol(symbol):
        return CostedBacktestResult(
            symbol=symbol,
            supported=False,
            starting_equity_usd=starting_equity_usd,
            ending_equity_usd=starting_equity_usd,
            raw_signal_count=0,
            accepted_trade_count=0,
            rejected_trade_count=0,
            rejection_reasons={"UNSUPPORTED_SYMBOL": 1},
        )

    spec = resolve_spec(symbol)

    raw = BacktestEngine(
        initial_equity=starting_equity_usd,
    ).run(bars, signal_provider, symbol, close_open_at_end=close_open_at_end)

    raw_trades = sorted(raw["trades"], key=lambda t: t["entry_index"])

    equity = float(starting_equity_usd)
    costed_trades: list[CostedTrade] = []
    rejection_reasons: dict[str, int] = {}
    open_exit_indices: list[int] = []

    half_spread = spec.pip_size * assumed_spread_pips / 2.0
    full_spread = spec.pip_size * assumed_spread_pips

    for raw_trade in raw_trades:

        if max_open_positions is not None:
            open_exit_indices = [e for e in open_exit_indices if e > raw_trade["entry_index"]]
            if len(open_exit_indices) >= max_open_positions:
                rejection_reasons[MAX_OPEN_POSITIONS_REASON] = rejection_reasons.get(MAX_OPEN_POSITIONS_REASON, 0) + 1
                continue

        side = raw_trade["direction"]
        entry = float(raw_trade["entry"])
        stop = float(raw_trade["stop_loss"])
        target = float(raw_trade["take_profit"])
        raw_result_r = float(raw_trade["result_r"])

        if bid_bars:
            # The bar price is the bid. A SELL's stop and target are hit on bid
            # bars but filled buying back at the ask, one spread higher.
            quote = FxQuote(symbol=symbol, bid=entry, ask=entry + full_spread)
            level_shift = full_spread if side == "SELL" else 0.0
        else:
            quote = FxQuote(
                symbol=symbol,
                bid=entry - half_spread,
                ask=entry + half_spread,
            )
            level_shift = 0.0

        request = TradeRequest(
            symbol=symbol,
            side=side,
            stop_loss=stop + level_shift,
            take_profit=target + level_shift,
        )

        account = AccountState(
            equity_usd=equity,
            day_start_equity_usd=equity,
        )

        decision: RiskDecision = evaluate_paper_trade(
            request=request,
            quote=quote,
            account=account,
            config=config,
        )

        if not decision.accepted or decision.position is None:
            rejection_reasons[decision.reason] = rejection_reasons.get(decision.reason, 0) + 1
            continue

        position: PaperPosition = decision.position

        # The raw engine already determined, from real forward bars, which
        # level was actually touched first (its conservative same-bar
        # ambiguity rule: stop wins ties). Reuse that outcome rather than
        # re-deriving it, and apply the costed model's own exit slippage on
        # top of whichever uncosted trigger price was actually hit.
        # The engine records where the trade actually left: stop or target for fixed
        # exits, anywhere for trailing or end-of-data exits.
        raw_exit = raw_trade.get("exit_price")
        exit_trigger_price = (float(raw_exit) if raw_exit is not None else (stop if raw_result_r <= 0 else target)) + level_shift

        close = close_paper_position(
            position=position,
            exit_price=exit_trigger_price,
            config=config,
        )

        if not close.accepted:
            rejection_reasons[close.reason] = rejection_reasons.get(close.reason, 0) + 1
            continue

        equity += close.net_pnl_usd

        if max_open_positions is not None:
            open_exit_indices.append(raw_trade["exit_index"])

        costed_trades.append(
            CostedTrade(
                entry_index=raw_trade["entry_index"],
                exit_index=raw_trade["exit_index"],
                symbol=symbol,
                side=side,
                lots=position.lots,
                entry_fill_price=position.entry_fill_price,
                exit_fill_price=close.exit_fill_price,
                risk_amount_usd=position.risk_amount_usd,
                gross_pnl_usd=close.gross_pnl_usd,
                net_pnl_usd=close.net_pnl_usd,
                result_r=close.result_r if close.result_r is not None else 0.0,
                equity_after_usd=equity,
                exit_reason=str(raw_trade.get("exit_reason") or ""),
            )
        )

    return CostedBacktestResult(
        symbol=symbol,
        supported=True,
        starting_equity_usd=starting_equity_usd,
        ending_equity_usd=equity,
        raw_signal_count=len(raw_trades),
        accepted_trade_count=len(costed_trades),
        rejected_trade_count=sum(rejection_reasons.values()),
        rejection_reasons=rejection_reasons,
        trades=costed_trades,
    )
