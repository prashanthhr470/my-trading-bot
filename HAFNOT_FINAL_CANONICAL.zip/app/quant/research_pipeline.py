"""
Pre-registered research pipeline.

Runs one strategy family on one symbol through a fixed sequence, with every
pass criterion written to disk BEFORE any result of the series exists:

  PREREGISTER   hypothesis, parameter grid, data split, selection rule and every
                gate -> data/research/preregistrations/<experiment_id>.json
  TRAIN         first 50% of the data. Sweep the grid and choose parameters by
                the best NEIGHBOURHOOD: the median expectancy of a combination
                and its one-step neighbours. One lucky combination surrounded by
                losers cannot win this way.
  VALIDATION    next 25%. The chosen parameters must pass the out-of-sample gate.
  WALK-FORWARD  rolling re-selection across train + validation.
  LOCKED OOS    final 25%, scored once per candidate (enforced by
                app.quant.locked_oos_guard), and only after every earlier gate passed.

A failure stops the run, so the locked data stays untouched by strategies that
have not earned a look at it. Every run, accepted or rejected, is recorded in both
registries, and the same experiment cannot be run twice.

The gates are not new: app.quant.promotion.STAGE_GATES["OUT_OF_SAMPLE"] and the
walk-forward criteria beside it existed before this pipeline or these strategy
families. All backtests enforce one open position per symbol, as live trading does.
"""

from __future__ import annotations

import importlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any, Callable, Optional

from app.core.data_quality import load_bar_file
from app.forex_v2.metrics import PromotionGate, evaluate_promotion, summarize_trades
from app.quant import experiment_registry, locked_oos_guard, signal_filters, strategy_registry
from app.quant.costed_backtest import run_costed_backtest
from app.quant.data_split import three_way_chronological_split
from app.quant.overfitting_defense import assess_parameter_sensitivity, assess_trade_concentration
from app.quant.promotion import (
    STAGE_GATES, WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION, WALK_FORWARD_MIN_WINDOWS,
)
from app.quant.walk_forward import parameter_combinations, run_walk_forward

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PREREGISTRATION_DIR = PROJECT_ROOT / "data" / "research" / "preregistrations"
HISTORICAL_BARS_DIR = PROJECT_ROOT / "data" / "historical" / "bars"

STARTING_EQUITY_USD = 10_000.0

TRAIN, VALIDATION, WALK_FORWARD, LOCKED = "TRAIN", "VALIDATION", "WALK_FORWARD", "LOCKED_OUT_OF_SAMPLE"


@dataclass(frozen=True)
class PipelineConfig:
    series: str = "pipeline-v1"
    timeframe: str = "H1"
    train_fraction: float = 0.5
    validation_fraction: float = 0.25
    warmup_bars: int = 300
    max_open_positions: int = 1
    min_train_trades: int = 30
    required_sensitivity_verdict: str = "PLATEAU"
    walk_forward_in_sample_bars: int = 6000
    walk_forward_out_of_sample_bars: int = 1500

    @property
    def out_of_sample_gate(self) -> PromotionGate:
        return STAGE_GATES["OUT_OF_SAMPLE"]

    @property
    def test_type_suffix(self) -> str:
        return self.series.upper().replace("-", "_")


@dataclass(frozen=True)
class FamilyDefinition:
    strategy_id: str
    version: str
    family: str
    hypothesis: str
    entry_rules: str
    exit_rules: str
    stop_loss_logic: str
    take_profit_logic: str
    session_conditions: str
    regime_conditions: str
    module: str
    param_grid: dict
    fixed_params: dict
    # A fixed, pre-declared app.quant.signal_filters spec, or None. A filter can only
    # remove signals, so a filtered family isolates the filter's own contribution.
    signal_filter: Optional[dict] = None

    def factory(self, timeframe_minutes: int = 60) -> Callable[[dict], Callable]:
        overlap = set(self.param_grid) & set(self.fixed_params)
        if overlap:
            raise ValueError(f"{self.strategy_id}: parameters both tuned and fixed: {sorted(overlap)}")
        signal_filters.validate_filter(self.signal_filter)
        module = importlib.import_module(self.module)
        fixed = dict(self.fixed_params)
        spec = self.signal_filter
        return lambda params: signal_filters.apply_filter(
            module.make_signal_provider(**{**fixed, **params}), spec, timeframe_minutes=timeframe_minutes,
        )


@dataclass
class StageResult:
    stage: str
    passed: bool
    reasons: list[str]
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExperimentOutcome:
    experiment_id: str
    strategy_id: str
    version: str
    symbol: str
    decision: str
    stage_reached: str
    chosen_params: Optional[dict]
    stages: list[StageResult] = field(default_factory=list)


def experiment_id_for(definition: FamilyDefinition, symbol: str, config: PipelineConfig) -> str:
    return f"{config.series}-{definition.strategy_id}-{symbol.lower()}"


def candidate_id_for(definition: FamilyDefinition, symbol: str, config: PipelineConfig) -> str:
    return f"{definition.strategy_id}__{definition.version}__{symbol.upper()}__{config.series}"


# ---------------------------------------------------------------- selection

def neighbourhood_scores(param_grid: dict, scored: list, *, min_trades: int) -> dict:
    """{param tuple: median expectancy of it and its one-step neighbours}, for qualifying centres."""

    keys = list(param_grid)
    by_key = {tuple(params[k] for k in keys): (expectancy, trades) for params, expectancy, trades in scored}

    def qualifies(combination):
        entry = by_key.get(combination)
        return entry is not None and entry[0] is not None and entry[1] >= min_trades

    scores: dict = {}
    for combination in by_key:
        if not qualifies(combination):
            continue
        neighbourhood = [combination]
        for position, key in enumerate(keys):
            values = list(param_grid[key])
            index = values.index(combination[position])
            for step in (-1, 1):
                if 0 <= index + step < len(values):
                    neighbour = list(combination)
                    neighbour[position] = values[index + step]
                    neighbourhood.append(tuple(neighbour))
        scores[combination] = median(by_key[c][0] for c in neighbourhood if qualifies(c))
    return scores


def neighbourhood_select(param_grid: dict, scored: list, *, min_trades: int) -> Optional[dict]:
    scores = neighbourhood_scores(param_grid, scored, min_trades=min_trades)
    if not scores:
        return None
    keys = list(param_grid)
    best = max(scores, key=lambda combination: scores[combination])
    return dict(zip(keys, best))


# ---------------------------------------------------------------- backtesting

def run_trades(warmup: list, evaluation: list, symbol: str, factory: Callable, params: dict,
               config: PipelineConfig) -> list[dict]:
    """
    Backtest `evaluation` with `warmup` bars prepended so indicators are ready at
    its first bar; trades entered during the warmup are discarded.
    """

    bars = list(warmup) + list(evaluation)
    result = run_costed_backtest(
        bars=bars, signal_provider=factory(params), symbol=symbol,
        starting_equity_usd=STARTING_EQUITY_USD, max_open_positions=config.max_open_positions,
    )
    offset = len(warmup)
    return [
        {"pnl_usd": t.net_pnl_usd, "result_r": t.result_r, "entry_index": t.entry_index - offset}
        for t in result.trades if t.entry_index >= offset
    ]


def _summary_fields(trades: list[dict]) -> dict[str, Any]:
    summary = summarize_trades(trades, initial_equity=STARTING_EQUITY_USD)
    return {
        "trade_count": summary.trade_count,
        "win_rate": summary.win_rate,
        "net_pnl_usd": round(summary.net_pnl_usd, 2),
        "profit_factor": summary.profit_factor,
        "expectancy_r": summary.expectancy_r,
        "max_drawdown_percent": round(summary.max_drawdown_percent, 3),
    }


# ---------------------------------------------------------------- preregistration

def _preregistration_body(definition: FamilyDefinition, symbol: str, config: PipelineConfig) -> dict[str, Any]:
    gate = config.out_of_sample_gate
    body = {
        "experiment_id": experiment_id_for(definition, symbol, config),
        "series": config.series,
        "strategy_id": definition.strategy_id,
        "strategy_version": definition.version,
        "family": definition.family,
        "hypothesis": definition.hypothesis,
        "rules": {
            "entry": definition.entry_rules, "exit": definition.exit_rules,
            "stop_loss": definition.stop_loss_logic, "take_profit": definition.take_profit_logic,
            "session": definition.session_conditions, "regime": definition.regime_conditions,
        },
        "module": definition.module,
        "param_grid": definition.param_grid,
        "fixed_params": definition.fixed_params,
        "symbol": symbol.upper(),
        "timeframe": config.timeframe,
        "data": f"data/historical/bars/{symbol.lower()}_{config.timeframe.lower()}.json via load_bar_file(strict=True); provenance in data/historical/manifest.json",
        "split": {"train": config.train_fraction, "validation": config.validation_fraction,
                  "locked_out_of_sample": round(1 - config.train_fraction - config.validation_fraction, 6)},
        "costs": "app.forex_v2.risk default RiskConfig; 1.2-pip assumed spread; adverse slippage; $7/lot round turn; 0.5% equity risk per trade",
        "execution": f"at most {config.max_open_positions} open position per symbol; conservative same-bar rule (stop before target)",
        "selection_rule": f"median expectancy_r over each combination and its one-step grid neighbours; combinations with fewer than {config.min_train_trades} training trades excluded",
        "gates": {
            TRAIN: {
                "minimum_trades_for_selection": config.min_train_trades,
                "parameter_sensitivity_verdict": config.required_sensitivity_verdict,
                "chosen_expectancy_r": "> 0",
            },
            VALIDATION: asdict(gate),
            WALK_FORWARD: {
                "in_sample_bars": config.walk_forward_in_sample_bars,
                "out_of_sample_bars": config.walk_forward_out_of_sample_bars,
                "minimum_windows": WALK_FORWARD_MIN_WINDOWS,
                "minimum_positive_window_fraction": WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION,
                "mean_out_of_sample_expectancy_r": "> 0",
            },
            LOCKED: asdict(gate),
        },
        "known_limitations": [
            f"Validation and locked slices get {config.warmup_bars} warm-up bars; walk-forward windows start cold and lose each strategy's lookback.",
            "At most one trade per slice boundary may differ from a continuous run because of the position limit.",
            "Trades still open at the end of a slice are not counted.",
        ],
    }
    if definition.signal_filter is not None:
        # Added only for filtered families, so earlier series' preregistrations stay byte-identical.
        body["signal_filter"] = definition.signal_filter
        body["signal_filter_rule"] = signal_filters.describe(definition.signal_filter)
    return body


def preregister(definition: FamilyDefinition, symbol: str, config: PipelineConfig) -> Path:
    """
    Write the preregistration. An identical existing one is kept with its original
    timestamp (so an interrupted series can resume); a different one is refused,
    because changing criteria after a series has started is exactly what this prevents.
    """

    PREREGISTRATION_DIR.mkdir(parents=True, exist_ok=True)
    body = _preregistration_body(definition, symbol, config)
    path = PREREGISTRATION_DIR / f"{body['experiment_id']}.json"

    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        existing.pop("preregistered_at", None)
        if existing != json.loads(json.dumps(body)):
            raise ValueError(
                f"Preregistration {path.name} already exists with different content. "
                "Criteria cannot change once a series is registered; start a new series instead."
            )
        return path

    path.write_text(
        json.dumps({"preregistered_at": datetime.now(timezone.utc).isoformat(), **body}, indent=2),
        encoding="utf-8",
    )
    return path


# ---------------------------------------------------------------- the run

def _register_spec(definition: FamilyDefinition, config: PipelineConfig, symbols: list[str]) -> None:
    module, factory_name, kwargs = definition.module, "make_signal_provider", dict(definition.fixed_params)
    parameters = {"param_grid": definition.param_grid, "fixed_params": definition.fixed_params}
    if definition.signal_filter is not None:
        # Registered through the filter's own factory, so the strategy can never be rebuilt without its filter.
        module, factory_name = "app.quant.signal_filters", "make_filtered_signal_provider"
        kwargs = {"base_module": definition.module, "signal_filter": definition.signal_filter,
                  "timeframe_minutes": signal_filters.TIMEFRAME_MINUTES[config.timeframe], **definition.fixed_params}
        parameters["signal_filter"] = definition.signal_filter
    spec = strategy_registry.StrategySpec(
        strategy_id=definition.strategy_id, version=definition.version, family=definition.family,
        entry_rules=definition.entry_rules, exit_rules=definition.exit_rules,
        stop_loss_logic=definition.stop_loss_logic, take_profit_logic=definition.take_profit_logic,
        timeframe=config.timeframe, symbols=list(symbols),
        session_conditions=definition.session_conditions, regime_conditions=definition.regime_conditions,
        parameters=parameters,
        transaction_cost_assumptions="app.forex_v2.risk default RiskConfig; 1.2-pip assumed spread; one position per symbol",
        risk_model="app.forex_v2.risk.size_position, 0.5% equity risk per trade",
        signal_provider_module=module, signal_provider_factory=factory_name,
        signal_provider_kwargs=kwargs, notes=definition.hypothesis,
    )
    try:
        strategy_registry.register_strategy(spec)
    except ValueError:
        pass


def run_experiment(
    definition: FamilyDefinition,
    symbol: str,
    config: PipelineConfig = PipelineConfig(),
    *,
    bars: Optional[list] = None,
    trade_runner: Callable = run_trades,
    walk_forward_runner: Callable = run_walk_forward,
    all_symbols: Optional[list[str]] = None,
) -> ExperimentOutcome:

    symbol = symbol.upper()
    experiment_id = experiment_id_for(definition, symbol, config)
    candidate_id = candidate_id_for(definition, symbol, config)
    suffix = config.test_type_suffix

    if not (PREREGISTRATION_DIR / f"{experiment_id}.json").exists():
        raise RuntimeError(f"{experiment_id} has no preregistration; call preregister() before running.")
    if any(e.get("experiment_id") == experiment_id for e in experiment_registry.list_experiments()):
        raise RuntimeError(f"{experiment_id} has already been run; re-running would inflate the experiment count.")

    if bars is None:
        path = HISTORICAL_BARS_DIR / f"{symbol.lower()}_{config.timeframe.lower()}.json"
        bars = load_bar_file(path, strict=True).bars

    split = three_way_chronological_split(bars, train_fraction=config.train_fraction,
                                          validation_fraction=config.validation_fraction)
    factory = definition.factory(timeframe_minutes=signal_filters.TIMEFRAME_MINUTES[config.timeframe])
    _register_spec(definition, config, all_symbols or [symbol])

    outcome = ExperimentOutcome(experiment_id=experiment_id, strategy_id=definition.strategy_id,
                                version=definition.version, symbol=symbol, decision="REJECTED",
                                stage_reached=TRAIN, chosen_params=None)

    def record(test_type: str, scorecard: dict, period: list) -> None:
        strategy_registry.record_result(
            definition.strategy_id, definition.version, test_type=f"{test_type}_{suffix}", symbol=symbol,
            period_start=period[0].get("timestamp") if period else None,
            period_end=period[-1].get("timestamp") if period else None,
            scorecard=scorecard,
        )

    def finish() -> ExperimentOutcome:
        experiment_registry.record_experiment(
            experiment_id=experiment_id, hypothesis=definition.hypothesis,
            strategy_id=definition.strategy_id, strategy_version=definition.version,
            symbols=[symbol], timeframe=config.timeframe,
            parameters={"param_grid": definition.param_grid, "fixed_params": definition.fixed_params,
                        "chosen_params": outcome.chosen_params, "signal_filter": definition.signal_filter},
            result={"stage_reached": outcome.stage_reached,
                    "stages": [{"stage": s.stage, "passed": s.passed, "reasons": s.reasons} for s in outcome.stages],
                    "metrics": {s.stage: s.metrics for s in outcome.stages}},
            decision=outcome.decision,
            period_start=bars[0].get("timestamp") if bars else None,
            period_end=bars[-1].get("timestamp") if bars else None,
            notes=f"Preregistered in data/research/preregistrations/{experiment_id}.json",
        )
        return outcome

    # ---- TRAIN
    combos, scored = [], []
    for params in parameter_combinations(definition.param_grid):
        try:
            trades = trade_runner([], split.train, symbol, factory, params, config)
        except ValueError:
            continue
        fields = _summary_fields(trades)
        combos.append({"params": params, **fields})
        scored.append((params, fields["expectancy_r"], fields["trade_count"]))

    traded = [c for c in combos if c["trade_count"] > 0]
    profitable_fraction = (sum(1 for c in traded if c["net_pnl_usd"] > 0) / len(traded)) if traded else None
    sensitivity = assess_parameter_sensitivity(
        profitable_fraction=profitable_fraction, combos_tried=len(combos),
        tuned_parameter_count=len(definition.param_grid),
    )
    chosen = neighbourhood_select(definition.param_grid, scored, min_trades=config.min_train_trades)
    chosen_row = next((c for c in combos if c["params"] == chosen), None)

    reasons = list(sensitivity.flags)
    if chosen is None:
        reasons.append(f"No parameter combination produced at least {config.min_train_trades} training trades.")
    elif chosen_row["expectancy_r"] is None or chosen_row["expectancy_r"] <= 0:
        reasons.append("The neighbourhood-selected parameters do not have positive training expectancy.")
    if sensitivity.verdict != config.required_sensitivity_verdict:
        reasons.append(f"Parameter sensitivity is {sensitivity.verdict}; {config.required_sensitivity_verdict} is required.")

    passed = (chosen is not None and chosen_row["expectancy_r"] is not None and chosen_row["expectancy_r"] > 0
              and sensitivity.verdict == config.required_sensitivity_verdict)
    outcome.chosen_params = chosen
    metrics = {"combos": combos, "profitable_fraction": profitable_fraction,
               "sensitivity_verdict": sensitivity.verdict, "chosen_params": chosen}
    outcome.stages.append(StageResult(TRAIN, passed, reasons, metrics))

    train_scorecard = {"combos_tried": len(combos), "profitable_fraction": profitable_fraction,
                       "sensitivity_verdict": sensitivity.verdict, "chosen_params": chosen, "stage_passed": passed}
    if chosen_row:
        train_scorecard.update({k: chosen_row[k] for k in ("trade_count", "win_rate", "net_pnl_usd",
                                                           "profit_factor", "expectancy_r", "max_drawdown_percent")})
    record("IN_SAMPLE", train_scorecard, split.train)

    if not passed:
        return finish()

    # ---- VALIDATION
    outcome.stage_reached = VALIDATION
    trades = trade_runner(split.train[-config.warmup_bars:], split.validation, symbol, factory, chosen, config)
    fields = _summary_fields(trades)
    decision = evaluate_promotion(summarize_trades(trades, initial_equity=STARTING_EQUITY_USD), config.out_of_sample_gate)
    concentration = assess_trade_concentration([{"net_pnl_usd": t["pnl_usd"]} for t in trades])
    outcome.stages.append(StageResult(VALIDATION, decision.passed, list(decision.reasons),
                                      {**fields, "trade_concentration": concentration.verdict}))
    record("OUT_OF_SAMPLE", {**fields, "stage_passed": decision.passed, "gate_reasons": list(decision.reasons),
                             "trade_concentration": concentration.verdict}, split.validation)

    if not decision.passed:
        return finish()

    # ---- WALK-FORWARD
    outcome.stage_reached = WALK_FORWARD
    history = list(split.train) + list(split.validation)
    walk = walk_forward_runner(
        history, symbol, param_grid=definition.param_grid,
        in_sample_bars=config.walk_forward_in_sample_bars,
        out_of_sample_bars=config.walk_forward_out_of_sample_bars,
        signal_provider_factory=factory,
        select_params=lambda scored_windows: neighbourhood_select(
            definition.param_grid, scored_windows, min_trades=config.min_train_trades),
        max_open_positions=config.max_open_positions,
    )
    windows = list(walk.windows)
    positive_fraction = walk.positive_window_fraction
    mean_expectancy = walk.mean_out_of_sample_expectancy_r

    reasons = []
    if len(windows) < WALK_FORWARD_MIN_WINDOWS:
        reasons.append(f"Only {len(windows)} walk-forward windows; at least {WALK_FORWARD_MIN_WINDOWS} required.")
    if positive_fraction is None or positive_fraction < WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION:
        reasons.append(f"Positive-window fraction {positive_fraction} is below {WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION}.")
    if mean_expectancy is None or mean_expectancy <= 0:
        reasons.append(f"Mean out-of-sample expectancy {mean_expectancy} is not positive.")
    passed = not reasons

    window_detail = [{"window": w.window_index, "chosen_params": w.chosen_params,
                      "in_sample_expectancy_r": w.in_sample_expectancy_r,
                      "out_of_sample_expectancy_r": w.out_of_sample_expectancy_r,
                      "out_of_sample_trades": w.out_of_sample_trade_count,
                      "out_of_sample_net_pnl_usd": round(w.out_of_sample_net_pnl_usd, 2)} for w in windows]
    wf_metrics = {"windows": len(windows),
                  "profitable_windows": sum(1 for w in windows if (w.out_of_sample_expectancy_r or 0) > 0),
                  "positive_window_fraction": positive_fraction,
                  "mean_out_of_sample_expectancy_r": mean_expectancy, "window_detail": window_detail}
    outcome.stages.append(StageResult(WALK_FORWARD, passed, reasons, wf_metrics))
    record("WALK_FORWARD", {**wf_metrics, "stage_passed": passed}, history)

    if not passed:
        return finish()

    # ---- LOCKED OUT-OF-SAMPLE (one look)
    outcome.stage_reached = LOCKED
    if locked_oos_guard.has_been_consumed(candidate_id):
        raise locked_oos_guard.LockedOutOfSampleAlreadyConsumed(
            f"{candidate_id} already used its locked out-of-sample look.")

    trades = trade_runner(history[-config.warmup_bars:], split.locked_out_of_sample, symbol, factory, chosen, config)
    fields = _summary_fields(trades)
    decision = evaluate_promotion(summarize_trades(trades, initial_equity=STARTING_EQUITY_USD), config.out_of_sample_gate)
    locked_oos_guard.consume_locked_out_of_sample(
        candidate_id, split.locked_out_of_sample,
        evidence={**fields, "passed": decision.passed, "reasons": list(decision.reasons), "chosen_params": chosen},
    )
    outcome.stages.append(StageResult(LOCKED, decision.passed, list(decision.reasons), fields))
    record("LOCKED_OUT_OF_SAMPLE", {**fields, "stage_passed": decision.passed,
                                    "gate_reasons": list(decision.reasons), "validated": decision.passed},
           split.locked_out_of_sample)

    if decision.passed:
        outcome.decision = "ACCEPTED"
    return finish()
