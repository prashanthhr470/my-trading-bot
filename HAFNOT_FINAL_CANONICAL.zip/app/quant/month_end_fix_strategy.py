"""
Month-end fix flows - trade the currency hedge rebalancing into the London 4pm fix.

HYPOTHESIS: international investors hedge the currency risk of their foreign equity
holdings and reset those hedges at month-end, largely at the WM/Reuters London 4pm fix.
When US equities have outperformed foreign equities over the month, foreign holders of US
stocks must sell more US dollars forward to stay hedged (and US holders of foreign stocks
buy fewer), so the dollar tends to weaken in the hours before the fix on the month's last
trading day; the reverse when US equities underperformed. Documented in academic work on
the London fix. Uses only broker data: FX hourly bars and equity index daily closes.

Rules (hourly bars carrying month-to-date index returns, app.quant.bar_features
"month_end_equity"; London time, DST-aware):
  Day       = the last weekday of the calendar month (London date); holidays not modelled.
              With mid_month_placebo = 1, the last weekday on or before the 15th instead: a
              control on a day with no month-end rebalancing.
  Decision  = at the close of the hourly bar ending `hours_before_fix` hours before `fix_hour`.
  Signal    = US500 month-to-date return minus the pair's foreign index month-to-date return,
              in percentage points (EUR: EUSTX50, GBP: UK100, AUD: AUS200, JPY: JPN225), from
              daily closes completed before the decision bar opened.
  Trade     = above +threshold_pct: the dollar is expected to weaken (BUY XXXUSD, SELL USDXXX);
              below -threshold_pct: the reverse.
  Exit      = at the close of the bar ending at the fix (exit_after_bars = hours_before_fix),
              unless the stop_atr x ATR(atr_period) stop is hit first; target_r is a distant cap.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Optional
from zoneinfo import ZoneInfo

from app.core.zones import parse_ts
from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "month-end-fix-flow"
LONDON = ZoneInfo("Europe/London")
US_INDEX = "US500"
CURRENCY_INDEX = {"EUR": "EUSTX50", "GBP": "UK100", "AUD": "AUS200", "JPY": "JPN225"}
# pair -> (foreign currency, +1 when the pair rises as the dollar weakens)
PAIRS = {"EURUSD": ("EUR", 1), "GBPUSD": ("GBP", 1), "AUDUSD": ("AUD", 1), "USDJPY": ("JPY", -1)}

DEFAULTS = {
    "threshold_pct": 1.0,
    "hours_before_fix": 4,
    "fix_hour": 16,
    "stop_atr": 3.0,
    "atr_period": 24,
    "target_r": 10.0,
    "bar_minutes": 60,
    "mid_month_placebo": 0,
}


def last_weekday_of_month(day: date) -> date:
    following = date(day.year + (day.month == 12), day.month % 12 + 1, 1)
    cursor = following - timedelta(days=1)
    while cursor.weekday() >= 5:
        cursor -= timedelta(days=1)
    return cursor


def mid_month_weekday(day: date) -> date:
    cursor = date(day.year, day.month, 15)
    while cursor.weekday() >= 5:
        cursor -= timedelta(days=1)
    return cursor


def evaluate(bars, *, threshold_pct: float, hours_before_fix: int, fix_hour: int, stop_atr: float, atr_period: int,
             target_r: float, bar_minutes: int, mid_month_placebo: int) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    bar = bars[-1]
    opened = parse_ts(bar.get("timestamp"))
    if opened is None:
        return None
    closes_local = (opened + timedelta(minutes=bar_minutes)).astimezone(LONDON)
    if closes_local.minute != 0 or closes_local.hour != fix_hour - hours_before_fix:
        return None
    day = closes_local.date()
    if day != (mid_month_weekday(day) if mid_month_placebo else last_weekday_of_month(day)):
        return None

    pair = PAIRS.get(str(bar.get("symbol", "")).upper())
    mtd = bar.get("equity_mtd") or {}
    if pair is None:
        return None
    us, foreign = mtd.get(US_INDEX), mtd.get(CURRENCY_INDEX[pair[0]])
    if us is None or foreign is None:
        return None
    relative = (us - foreign) * 100
    if relative > threshold_pct:
        dollar_weakens = True
    elif relative < -threshold_pct:
        dollar_weakens = False
    else:
        return None
    direction = "BUY" if dollar_weakens == (pair[1] > 0) else "SELL"

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bar["close"])
    stop, target = fixed_r_levels(direction, close, stop_atr * atr, target_r)
    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hours_before_fix,
        "us_minus_foreign_mtd_pct": relative,
        "data_sources_used": ["ohlc_bars", "equity_index_daily_closes"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if not 1 <= settings["hours_before_fix"] <= settings["fix_hour"] or not 0 <= settings["fix_hour"] <= 23:
        raise ValueError(f"{STRATEGY_ID}: 1 <= hours_before_fix <= fix_hour <= 23 required")
    if settings["threshold_pct"] < 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: threshold_pct >= 0, stop_atr and target_r > 0 required")
    if settings["atr_period"] < 1 or settings["bar_minutes"] < 1 or settings["mid_month_placebo"] not in (0, 1):
        raise ValueError(f"{STRATEGY_ID}: atr_period and bar_minutes >= 1, mid_month_placebo 0 or 1 required")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
