"""
COT positioning momentum - follow a large change in hedge-fund positioning.

HYPOTHESIS: leveraged funds trade on information and conviction; when they add an unusually
large net position in a currency over recent weeks, the currency tends to keep moving the
same way while that capital keeps arriving, enough to pay for spread, commission and
overnight swaps. Uses CFTC positioning, which the chart does not show. It is the opposite
bet to cot-crowding-reversal, preregistered and counted separately.

Rules (daily bars carrying as-of CFTC history, app.quant.bar_features "cot_positioning"):
  Change = latest known net position minus the one `change_weeks` reports earlier.
  Scale  = standard deviation of the same `change_weeks` change over the previous
           `lookback_weeks` reports (the latest change excluded).
  Long   = change / scale >= z_min: funds adding to the currency -> buy it against USD.
  Short  = change / scale <= -z_min -> sell it against USD.
  Stop   = stop_atr x ATR(atr_period) from the close; target_r x that risk is a distant cap.
  Exit   = at the close `hold_bars` bars after entry, unless stopped.
"""

from __future__ import annotations

from statistics import pstdev
from typing import Optional

from app.quant.currency_strength_strategy import LEGS
from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "cot-positioning-momentum"

DEFAULTS = {
    "change_weeks": 4,
    "hold_bars": 10,
    "lookback_weeks": 104,
    "z_min": 1.0,
    "stop_atr": 3.0,
    "atr_period": 20,
    "target_r": 10.0,
}


def evaluate(bars, *, change_weeks: int, hold_bars: int, lookback_weeks: int, z_min: float, stop_atr: float,
             atr_period: int, target_r: float) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    bar = bars[-1]
    leg = LEGS.get(str(bar.get("symbol", "")).upper())
    if leg is None:
        return None
    currency, sign = leg
    history = ((bar.get("cot") or {}).get(currency)) or []
    if len(history) < lookback_weeks + change_weeks + 1:
        return None
    changes = [history[i] - history[i - change_weeks] for i in range(len(history) - lookback_weeks - 1, len(history))]
    latest, previous = changes[-1], changes[:-1]
    scale = pstdev(previous)
    if scale <= 0:
        return None
    z = latest / scale
    if z >= z_min:
        long_currency = True
    elif z <= -z_min:
        long_currency = False
    else:
        return None
    direction = "BUY" if long_currency == (sign > 0) else "SELL"

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bar["close"])
    stop, target = fixed_r_levels(direction, close, stop_atr * atr, target_r)
    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "positioning_change_z": z,
        "data_sources_used": ["ohlc_bars", "cftc_tff_leveraged_funds"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["change_weeks"] < 1 or settings["hold_bars"] < 1 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: change_weeks, hold_bars and atr_period must be >= 1")
    if settings["lookback_weeks"] + settings["change_weeks"] + 1 > 160 or settings["lookback_weeks"] < 10:
        raise ValueError(f"{STRATEGY_ID}: 10 <= lookback_weeks and lookback_weeks + change_weeks + 1 <= 160 required")
    if settings["z_min"] <= 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: z_min, stop_atr and target_r must be positive")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
