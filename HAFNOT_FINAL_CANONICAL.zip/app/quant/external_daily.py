"""
Daily series from FRED for research signals - non-price information from an outside source,
approved by the user on 2026-09-15. Fetched into memory on every run and fingerprinted;
nothing is stored.

  VIX  = VIXCLS, the CBOE Volatility Index close (the market's implied 30-day volatility of the S&P 500).

As-of rule (no look-ahead, nothing invented):
  - an observation dated D counts as known from calendar day D + lag_days;
  - at a date, the latest known observation is used;
  - if it is more than max_age_days calendar days old, the value is unavailable, so weekends
    and holidays are bridged only that far.
"""

from __future__ import annotations

import csv
import io
from bisect import bisect_right
from datetime import date, timedelta
from typing import Callable, Optional

from app.quant.external_rates import FRED_CSV, _download, fingerprint

DAILY_SERIES = {"VIX": "VIXCLS"}

AS_OF_RULE = (
    "An observation dated D is known from calendar day D + lag_days; a date uses the latest known observation; one "
    "more than max_age_days calendar days old is unavailable; missing days are not filled."
)

__all__ = ["DAILY_SERIES", "AS_OF_RULE", "DailyAsOf", "fetch_fred_daily", "fingerprint"]


def fetch_fred_daily(series_by_name: dict = DAILY_SERIES, download: Callable[[str], str] = _download) -> dict[str, list[list]]:
    """{name: [["YYYY-MM-DD", value], ...]} in date order; refuses a series with no values."""

    out = {}
    for name, series_id in series_by_name.items():
        rows = list(csv.reader(io.StringIO(download(FRED_CSV.format(series_id)))))
        values = [[row[0][:10], float(row[1])] for row in rows[1:] if len(row) >= 2 and row[1] not in ("", ".")]
        if not values:
            raise ValueError(f"FRED series {series_id} ({name}) returned no values.")
        out[name] = sorted(values)
    return out


class DailyAsOf:
    def __init__(self, values: list, lag_days: int = 1, max_age_days: int = 5):
        if lag_days < 0 or max_age_days < lag_days:
            raise ValueError("Need 0 <= lag_days <= max_age_days.")
        self.lag, self.max_age = int(lag_days), int(max_age_days)
        self._dates = [date.fromisoformat(d) for d, _ in values]
        self._values = [float(v) for _, v in values]

    def _latest(self, day: date) -> int:
        position = bisect_right(self._dates, day - timedelta(days=self.lag)) - 1
        if position < 0 or (day - self._dates[position]).days > self.max_age:
            return -1
        return position

    def value(self, day: date) -> Optional[float]:
        position = self._latest(day)
        return None if position < 0 else self._values[position]

    def history(self, day: date, count: int) -> list[float]:
        """Up to `count` known observations as of `day`, oldest first; empty if the latest is too old."""

        position = self._latest(day)
        return [] if position < 0 else self._values[max(0, position - count + 1): position + 1]
