"""
Liquidity sweep reversal - the stop hunt at yesterday's or last week's extreme.

HYPOTHESIS: many traders rest stops just beyond the previous day's and previous week's
high and low. When price first runs those stops and closes straight back inside the
level, the stop orders have been absorbed and the move fails; trading back in the
direction of the higher-timeframe bias, with a stop just beyond the sweep, pays for
costs. This is the smart-money / ICT "liquidity grab" at daily and weekly liquidity.

Rules (closed intraday OHLC bars; levels from app.quant.liquidity_levels):
  Bias   = the last completed daily close against the mean of the last `bias_days`
           completed daily closes: above = up, below = down.
  BUY    = bias up. For the previous day's low or previous week's low L: the prior bar
           closed above L, today's price had not traded below L before this bar, this
           bar trades below L and closes back above it.
  SELL   = the mirror at the previous day's or week's high with bias down.
  Stop   = stop_buffer_atr x ATR(atr_period) beyond the sweep bar's extreme.
  Target = target_r x the risk from the close.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params
from app.quant.liquidity_levels import LiquidityLevels

STRATEGY_ID = "liquidity-sweep-reversal"

DEFAULTS = {
    "bias_days": 20,
    "target_r": 2.0,
    "stop_buffer_atr": 0.1,
    "atr_period": 14,
}


def evaluate(bars, levels: LiquidityLevels, *, bias_days: int, target_r: float, stop_buffer_atr: float,
             atr_period: int) -> Optional[dict]:
    n = len(bars)
    if n < atr_period + 2:
        return None
    levels.update(bars, n - 1)
    bias = levels.bias(bias_days)
    if bias == 0:
        return None

    bar = bars[-1]
    h, l, c = float(bar["high"]), float(bar["low"]), float(bar["close"])
    previous_close = float(bars[-2]["close"])
    signal = None
    if bias > 0:
        for name, level in (("previous_day_low", levels.prev_day_low), ("previous_week_low", levels.prev_week_low)):
            if level is None or (levels.before_low is not None and levels.before_low < level):
                continue
            if previous_close > level and l < level and c > level:
                signal = ("BUY", name, level, l)
                break
    else:
        for name, level in (("previous_day_high", levels.prev_day_high), ("previous_week_high", levels.prev_week_high)):
            if level is None or (levels.before_high is not None and levels.before_high > level):
                continue
            if previous_close < level and h > level and c < level:
                signal = ("SELL", name, level, h)
                break
    if signal is None:
        return None

    # ATR only once a sweep is found: most bars have none, and 15-minute histories are long.
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    direction, name, level, extreme = signal
    stop = extreme - stop_buffer_atr * atr if direction == "BUY" else extreme + stop_buffer_atr * atr
    risk = abs(c - stop)
    if risk <= 0:
        return None
    stop_loss, take_profit = fixed_r_levels(direction, c, risk, target_r)
    return {
        "direction": direction,
        "entry": c,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "reward_to_risk": target_r,
        "liquidity_level": name,
        "level_price": level,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["bias_days"] < 2 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: bias_days >= 2 and atr_period >= 1 required")
    if settings["target_r"] <= 0 or settings["stop_buffer_atr"] < 0:
        raise ValueError(f"{STRATEGY_ID}: target_r must be positive and stop_buffer_atr non-negative")
    levels = LiquidityLevels(max_daily_closes=max(60, int(settings["bias_days"])))

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, levels, **settings)

    return signal_provider
