"""
COT crowding reversal - fade extreme hedge-fund positioning in a currency.

HYPOTHESIS: when leveraged funds (hedge funds, CTAs) hold an extreme net position in a
currency relative to its own recent history, the trade is crowded: few new buyers (or
sellers) remain, and as funds exit the currency tends to move against them. Selling the
currency when funds are at an extreme long, and buying it at an extreme short, pays for
spread, commission and overnight swaps. Uses CFTC positioning, which the chart does not show.

Rules (daily bars carrying as-of CFTC history, app.quant.bar_features "cot_positioning"):
  Rank   = the share of the last `lookback_weeks` known reports (including the latest) with a
           net position at or below the latest one.
  Short  = rank >= 1 - extreme: funds crowded long the currency -> sell it against USD.
  Long   = rank <= extreme: funds crowded short -> buy it against USD.
  Stop   = stop_atr x ATR(atr_period) from the close; target_r x that risk is a distant cap.
  Exit   = at the close `hold_bars` bars after entry, unless stopped.
"""

from __future__ import annotations

from typing import Optional

from app.quant.currency_strength_strategy import LEGS
from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "cot-crowding-reversal"

DEFAULTS = {
    "extreme": 0.10,
    "hold_bars": 10,
    "lookback_weeks": 156,
    "stop_atr": 3.0,
    "atr_period": 20,
    "target_r": 10.0,
}


def evaluate(bars, *, extreme: float, hold_bars: int, lookback_weeks: int, stop_atr: float, atr_period: int,
             target_r: float) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    bar = bars[-1]
    leg = LEGS.get(str(bar.get("symbol", "")).upper())
    if leg is None:
        return None
    currency, sign = leg
    history = ((bar.get("cot") or {}).get(currency)) or []
    if len(history) < lookback_weeks:
        return None
    window = history[-lookback_weeks:]
    latest = window[-1]
    rank = sum(1 for value in window if value <= latest) / len(window)
    if rank >= 1 - extreme:
        long_currency = False
    elif rank <= extreme:
        long_currency = True
    else:
        return None
    direction = "BUY" if long_currency == (sign > 0) else "SELL"

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bar["close"])
    stop, target = fixed_r_levels(direction, close, stop_atr * atr, target_r)
    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "positioning_rank": rank,
        "data_sources_used": ["ohlc_bars", "cftc_tff_leveraged_funds"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if not 0 < settings["extreme"] < 0.5 or settings["hold_bars"] < 1 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: 0 < extreme < 0.5, hold_bars and atr_period >= 1 required")
    if not 10 <= settings["lookback_weeks"] <= 160 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: lookback_weeks 10-160, stop_atr and target_r > 0 required")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
