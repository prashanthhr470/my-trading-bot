"""
Adapts app.forex_v2.strategy.ForexIntradayStrategy (a clean, broker-
independent, already-tested research strategy) into the
BacktestEngine(bars, signal_provider, symbol) callable shape.
"""

from __future__ import annotations

from typing import Any, Optional

from app.forex_v2.strategy import StrategyConfig, generate_signal


# EMA/ATR converge to within a fraction of a percent of their true value
# using roughly 5x the slow period of trailing bars; 400 comfortably covers
# every slow_ema_period used anywhere in this project (max 55) with a large
# safety margin. Capping the window here is what makes the adapter usable
# against multi-year hourly data - without it, generate_signal recomputes
# indicators over the ENTIRE growing history on every single bar, which is
# O(n^2) and becomes impractically slow past a few thousand bars (confirmed
# directly: it did not finish in 5 minutes on 12,440 H1 bars before this fix).
_MAX_LOOKBACK_BARS = 200


def make_signal_provider(config: Optional[StrategyConfig] = None):
    """
    Returns a signal_provider(visible_bars, index) usable by
    BacktestEngine.run() and app.quant.costed_backtest.run_costed_backtest.
    """

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        # Bound the window passed to generate_signal - see
        # _MAX_LOOKBACK_BARS above for why this is necessary, not optional.
        windowed_bars = visible_bars[-_MAX_LOOKBACK_BARS:]

        try:
            signal = generate_signal(windowed_bars, config)
        except ValueError:
            # Not enough history yet, or malformed bar - no setup.
            return None

        if signal.direction == "FLAT":
            return None

        return {
            "direction": signal.direction,
            "entry": signal.entry,
            "stop_loss": signal.stop_loss,
            "take_profit": signal.take_profit,
        }

    return signal_provider
