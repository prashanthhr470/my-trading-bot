"""
Daily trend following - Donchian channel breakout.

HYPOTHESIS: a daily close beyond the highest high or lowest low of the previous
`channel_bars` days marks a trend that, across many currencies and years, runs far
enough and often enough to pay for the trade after costs. Trend following is one of
the longest-documented return sources in futures and FX; its returns are modest and
it has had multi-year drawdowns, so it is tested here, not assumed.

Rules (OHLC only, closed bars only):
  Channel = highest high / lowest low of the `channel_bars` bars BEFORE the current
            bar. The current bar never helps define the channel it breaks.
  Entry   = BUY on a close above the channel high, SELL on a close below the low.
  Stop    = stop_atr x ATR(atr_period) beyond the entry.
  Target  = target_r x that risk beyond the entry. The live safety gate requires a
            target with reward:risk >= 1.5.
  Trail   = when trail_atr > 0, the stop starts trail_atr x ATR from the entry and
            then trails the best price since entry at that distance (the engine's
            trailing_stop_distance), so a trend can run until it reverses; target_r
            is then only a distant cap. trail_atr = 0 keeps the fixed exit above.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, highest_high, lowest_low, validate_params

STRATEGY_ID = "donchian-trend"

DEFAULTS = {
    "channel_bars": 55,
    "stop_atr": 2.0,
    "atr_period": 20,
    "target_r": 3.0,
    "trail_atr": 0.0,
}


def evaluate(
    bars: list[dict], *,
    channel_bars: int, stop_atr: float, atr_period: int, target_r: float, trail_atr: float = 0.0,
) -> Optional[dict]:

    if len(bars) < max(channel_bars, atr_period) + 1:
        return None

    channel = bars[-(channel_bars + 1):-1]
    high, low = highest_high(channel), lowest_low(channel)
    close = float(bars[-1]["close"])

    if close > high:
        direction = "BUY"
    elif close < low:
        direction = "SELL"
    else:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    risk = (trail_atr if trail_atr > 0 else stop_atr) * atr
    stop, target = fixed_r_levels(direction, close, risk, target_r)
    signal = {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "channel_high": high,
        "channel_low": low,
        "data_sources_used": ["ohlc_bars"],
    }
    if trail_atr > 0:
        signal["trailing_stop_distance"] = risk
    return signal


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["channel_bars"] < 2 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: channel_bars must be >= 2 and atr_period >= 1")
    if settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: stop_atr and target_r must be positive")
    if settings["trail_atr"] < 0:
        raise ValueError(f"{STRATEGY_ID}: trail_atr must be >= 0")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
