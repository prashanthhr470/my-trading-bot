"""
Market-structure pullback - buy the higher low, sell the lower high.

HYPOTHESIS: the discretionary "trade with the structure" setup. When price makes higher
highs and higher lows, a pullback that reaches the latest higher low and is rejected
there (a bullish candle closing back above the zone) resumes the trend often enough,
with a stop just beyond that low, to pay for costs. Lower highs and lower lows mirror it.

Rules (closed OHLC bars only; swings from app.quant.market_structure, confirmed
`swing_bars` bars later, using only bars BEFORE the decision bar):
  Structure = the last two confirmed swing highs (H1, H2) and lows (L1, L2).
              Up: H2 > H1 and L2 > L1.  Down: H2 < H1 and L2 < L1.
  BUY       = up structure; the decision bar's low is in [L2, L2 + zone_atr x ATR];
              it closes above its open, above that zone and below H2.
  SELL      = mirror: down structure, high in [H2 - zone, H2], bearish close below the
              zone and above L2.
  Stop      = stop_atr x ATR beyond L2 (BUY) or H2 (SELL).
  Target    = target_r x the risk from the close.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params
from app.quant.market_structure import SwingTracker

STRATEGY_ID = "market-structure-pullback"

DEFAULTS = {
    "swing_bars": 3,
    "zone_atr": 0.5,
    "stop_atr": 0.5,
    "atr_period": 14,
    "target_r": 2.0,
}


def evaluate(bars: list[dict], tracker: SwingTracker, *,
             zone_atr: float, stop_atr: float, atr_period: int, target_r: float) -> Optional[dict]:
    n = len(bars)
    if n < atr_period + 2:
        return None
    tracker.update(bars, n - 2)
    if len(tracker.highs) < 2 or len(tracker.lows) < 2:
        return None
    (_, h1), (_, h2) = tracker.highs[-2:]
    (_, l1), (_, l2) = tracker.lows[-2:]
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    bar = bars[-1]
    o, h, l, c = (float(bar[key]) for key in ("open", "high", "low", "close"))
    zone = zone_atr * atr
    if h2 > h1 and l2 > l1 and l2 <= l <= l2 + zone and c > o and c > l2 + zone and c < h2:
        direction, level, stop = "BUY", l2, l2 - stop_atr * atr
    elif h2 < h1 and l2 < l1 and h2 - zone <= h <= h2 and c < o and c < h2 - zone and c > l2:
        direction, level, stop = "SELL", h2, h2 + stop_atr * atr
    else:
        return None

    risk = abs(c - stop)
    if risk <= 0:
        return None
    stop_loss, take_profit = fixed_r_levels(direction, c, risk, target_r)
    return {
        "direction": direction,
        "entry": c,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "reward_to_risk": target_r,
        "structure_level": level,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["swing_bars"] < 1 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: swing_bars and atr_period must be >= 1")
    if settings["zone_atr"] <= 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: zone_atr, stop_atr and target_r must be positive")
    tracker = SwingTracker(int(settings["swing_bars"]))
    rules = {key: settings[key] for key in ("zone_atr", "stop_atr", "atr_period", "target_r")}

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, tracker, **rules)

    return signal_provider
