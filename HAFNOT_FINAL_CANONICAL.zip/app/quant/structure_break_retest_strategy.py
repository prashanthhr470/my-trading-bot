"""
Structure break and retest - old resistance becomes support.

HYPOTHESIS: the discretionary "break and retest" setup. When price closes beyond the
latest swing high, holds above it, and then returns to test that level and is rejected
(a bullish candle closing back above it), the broken level acts as support often enough,
with a stop just below it, to pay for costs. A break below the latest swing low mirrors it.

Rules (closed OHLC bars only; swings from app.quant.market_structure, confirmed
`swing_bars` bars later, using only bars BEFORE the decision bar):
  Level   = the latest confirmed swing high (for BUY) or swing low (for SELL).
  Break   = the first close beyond the level after the swing, before the decision bar,
            no more than `retest_bars` bars ago; every close since stayed beyond it.
  BUY     = the decision bar's low reaches level + zone_atr x ATR or lower; it closes
            above its open and above the level.
  SELL    = mirror: high reaches level - zone or higher; bearish close below the level.
  Stop    = stop_atr x ATR beyond the level.
  Target  = target_r x the risk from the close.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params
from app.quant.market_structure import SwingTracker

STRATEGY_ID = "structure-break-retest"

DEFAULTS = {
    "swing_bars": 3,
    "retest_bars": 20,
    "zone_atr": 0.5,
    "stop_atr": 0.5,
    "atr_period": 14,
    "target_r": 2.0,
}


def _held_break(bars: list[dict], swing_index: int, level: float, beyond, retest_bars: int) -> bool:
    last_closed = len(bars) - 2
    broke_at = next((j for j in range(swing_index + 1, last_closed + 1) if beyond(float(bars[j]["close"]), level)), None)
    if broke_at is None or last_closed + 1 - broke_at > retest_bars:
        return False
    return all(beyond(float(bars[j]["close"]), level) for j in range(broke_at, last_closed + 1))


def evaluate(bars: list[dict], tracker: SwingTracker, *,
             retest_bars: int, zone_atr: float, stop_atr: float, atr_period: int, target_r: float) -> Optional[dict]:
    n = len(bars)
    if n < atr_period + 2:
        return None
    tracker.update(bars, n - 2)
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    bar = bars[-1]
    o, h, l, c = (float(bar[key]) for key in ("open", "high", "low", "close"))
    zone = zone_atr * atr
    signal = None
    if tracker.highs:
        index, level = tracker.highs[-1]
        if (_held_break(bars, index, level, lambda close, lvl: close > lvl, retest_bars)
                and l <= level + zone and c > level and c > o):
            signal = ("BUY", level, level - stop_atr * atr)
    if signal is None and tracker.lows:
        index, level = tracker.lows[-1]
        if (_held_break(bars, index, level, lambda close, lvl: close < lvl, retest_bars)
                and h >= level - zone and c < level and c < o):
            signal = ("SELL", level, level + stop_atr * atr)
    if signal is None:
        return None

    direction, level, stop = signal
    risk = abs(c - stop)
    if risk <= 0:
        return None
    stop_loss, take_profit = fixed_r_levels(direction, c, risk, target_r)
    return {
        "direction": direction,
        "entry": c,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "reward_to_risk": target_r,
        "structure_level": level,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["swing_bars"] < 1 or settings["atr_period"] < 1 or settings["retest_bars"] < 1:
        raise ValueError(f"{STRATEGY_ID}: swing_bars, retest_bars and atr_period must be >= 1")
    if settings["zone_atr"] <= 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: zone_atr, stop_atr and target_r must be positive")
    tracker = SwingTracker(int(settings["swing_bars"]))
    rules = {key: settings[key] for key in ("retest_bars", "zone_atr", "stop_atr", "atr_period", "target_r")}

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, tracker, **rules)

    return signal_provider
