"""
Historically-testable market regime classifier - Phase 10.

app.market_regime.classify_market_regime already exists but is built for
the LIVE pipeline: it expects five simultaneous timeframe summaries
(M15/H1/H4/D1/W1) and needs at least 3 of them agreeing to call a trend.
Backtests in this project typically have one or two OHLC series loaded
per symbol (not all five), so feeding that function a single series would
silently degrade to "UNKNOWN" on almost every bar - technically not
fabrication, but not a real regime signal either, and not honest to
present as "the regime engine is wired in" when it would do nothing.

This module is a SEPARATE, single-series regime classifier purpose-built
for backtesting: trend (via EMA20/EMA50 slope, the same logic already
used for the H4 confluence filter in app.quant.mtf_confluence_strategy)
and volatility (via ATR percentile against its own trailing history).
It is deliberately simpler than the live classifier and is documented as
such - the two are not meant to produce identical labels, and nothing
here claims otherwise.

Anti-lookahead: RegimeLookup.regime_at(ts) only ever uses the most recent
bar that had already CLOSED strictly before ts, same pattern as
app.quant.mtf_confluence_strategy.H4TrendLookup.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from app.core.zones import parse_ts

TREND_FAST_EMA = 20
TREND_SLOW_EMA = 50

# A trend is only called BULL/BEAR when the fast/slow EMA gap exceeds this
# fraction of the slow EMA's value - keeps the label scale-independent
# across symbols with very different price magnitudes (e.g. XAUUSD ~2000
# vs EURUSD ~1.08). Below this gap, price is chopping around both EMAs
# with no clear direction, which the RANGE label better reflects than
# forcing every bar into BULL or BEAR.
TREND_FLAT_THRESHOLD_FRACTION = 0.0015

ATR_PERIOD = 14
# Volatility percentile window: how far back to look when deciding
# whether "now" is high/normal/low volatility relative to its own recent
# history, rather than an arbitrary fixed number.
ATR_HISTORY_WINDOW = 200
HIGH_VOL_MULTIPLE = 1.5
LOW_VOL_MULTIPLE = 0.67


def _ema_series(values: list[float], period: int) -> list[Optional[float]]:
    if len(values) < period:
        return [None] * len(values)

    multiplier = 2.0 / (period + 1)
    result: list[Optional[float]] = [None] * (period - 1)

    seed = sum(values[:period]) / period
    result.append(seed)

    prev = seed
    for value in values[period:]:
        current = (value - prev) * multiplier + prev
        result.append(current)
        prev = current

    return result


def _atr_series(bars: list[dict], period: int) -> list[Optional[float]]:
    result: list[Optional[float]] = [None] * len(bars)
    if len(bars) <= period:
        return result

    true_ranges: list[float] = [0.0] * len(bars)
    for i in range(1, len(bars)):
        high = bars[i]["high"]
        low = bars[i]["low"]
        prev_close = bars[i - 1]["close"]
        true_ranges[i] = max(high - low, abs(high - prev_close), abs(low - prev_close))

    running_sum = sum(true_ranges[1:period + 1])
    result[period] = running_sum / period
    for i in range(period + 1, len(bars)):
        running_sum += true_ranges[i] - true_ranges[i - period]
        result[i] = running_sum / period

    return result


def _median(values: list[float]) -> float:
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2 == 0:
        return (ordered[mid - 1] + ordered[mid]) / 2.0
    return ordered[mid]


class RegimeLookup:
    """
    Precomputes a trend label ("TREND_BULL" / "TREND_BEAR" / "RANGE") and
    a volatility label ("HIGH" / "NORMAL" / "LOW") for every bar close in
    a single OHLC series, then answers "what was the regime at time T" by
    finding the most recent bar that had already closed strictly before T.

    Callers choose which series to pass in - a higher timeframe (H4/D1)
    gives a slower-moving, less noisy regime read; the same timeframe as
    the strategy being tested gives a faster-reacting one. Either is
    valid; which one was used should be recorded alongside any result
    that used this filter (see the "regime" field this module attaches
    to signals), consistent with Phase 11/12's per-regime reporting.
    """

    def __init__(self, bars: list[dict]):
        self._ts: list[datetime] = []
        self._trend: list[str] = []
        self._volatility: list[str] = []

        closes = [b["close"] for b in bars]
        fast = _ema_series(closes, TREND_FAST_EMA)
        slow = _ema_series(closes, TREND_SLOW_EMA)
        atr = _atr_series(bars, ATR_PERIOD)

        atr_history: list[float] = []

        for i, bar in enumerate(bars):
            ts = parse_ts(bar.get("timestamp"))
            if ts is None:
                continue

            if fast[i] is None or slow[i] is None or slow[i] == 0:
                trend = "UNKNOWN"
            else:
                gap_fraction = (fast[i] - slow[i]) / abs(slow[i])
                if gap_fraction > TREND_FLAT_THRESHOLD_FRACTION:
                    trend = "TREND_BULL"
                elif gap_fraction < -TREND_FLAT_THRESHOLD_FRACTION:
                    trend = "TREND_BEAR"
                else:
                    trend = "RANGE"

            if atr[i] is None:
                volatility = "UNKNOWN"
            else:
                # Only compare against ATR values already seen up to this
                # bar - the trailing history itself must be anti-lookahead
                # safe, not just the "current" ATR value.
                if len(atr_history) >= 5:
                    window = atr_history[-ATR_HISTORY_WINDOW:]
                    baseline = _median(window)
                    if baseline <= 0:
                        volatility = "NORMAL"
                    elif atr[i] >= baseline * HIGH_VOL_MULTIPLE:
                        volatility = "HIGH"
                    elif atr[i] <= baseline * LOW_VOL_MULTIPLE:
                        volatility = "LOW"
                    else:
                        volatility = "NORMAL"
                else:
                    volatility = "UNKNOWN"
                atr_history.append(atr[i])

            self._ts.append(ts)
            self._trend.append(trend)
            self._volatility.append(volatility)

    def regime_at(self, ts: datetime) -> dict:
        """Most recent regime confirmed strictly before `ts`."""

        for i in range(len(self._ts) - 1, -1, -1):
            if self._ts[i] <= ts:
                return {
                    "available": True,
                    "trend": self._trend[i],
                    "volatility": self._volatility[i],
                    "as_of_bar_ts": self._ts[i].isoformat(),
                }

        return {"available": False, "trend": "UNKNOWN", "volatility": "UNKNOWN", "as_of_bar_ts": None}
