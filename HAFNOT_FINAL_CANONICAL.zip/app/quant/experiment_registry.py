"""
Experiment registry - the defense against selection and multiple-testing bias.

app.quant.strategy_registry records STRATEGIES and their results. That is
not sufficient to judge whether a good-looking result is real, because it
does not record the DENOMINATOR: how many ideas were tried in order to
arrive at the one being praised. If fifty strategies are tested and the
best one looks profitable, that is a very different claim from testing one
strategy and finding it profitable - even with identical numbers.

This module records every experiment attempted, whatever its outcome, and
provides the arithmetic to state plainly how much of an apparently good
result could be explained by having looked many times.

The point is not to compute a publication-grade p-value. OHLC backtest
results are serially correlated and non-normal, so a clean significance
test is not available here. The point is to keep the count honest and
make the inflation explicit, so nobody (including a future session of
this project) mistakes "best of many" for "validated".
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
EXPERIMENTS_FILE = PROJECT_ROOT / "data" / "research" / "experiments.jsonl"

DECISIONS = ("ACCEPTED", "REJECTED", "INCONCLUSIVE")


def _code_version() -> str:
    """Best-effort code fingerprint. Not all checkouts are git repos."""

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(PROJECT_ROOT),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except Exception:
        pass

    return "unversioned"


@dataclass
class Experiment:
    experiment_id: str
    hypothesis: str
    strategy_id: str
    strategy_version: str
    symbols: list[str]
    timeframe: str
    period_start: Optional[str]
    period_end: Optional[str]
    parameters: dict[str, Any]
    result: dict[str, Any]
    decision: str
    notes: str = ""
    code_version: str = field(default_factory=_code_version)
    recorded_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


def record_experiment(
    *,
    experiment_id: str,
    hypothesis: str,
    strategy_id: str,
    strategy_version: str,
    symbols: list[str],
    timeframe: str,
    parameters: dict[str, Any],
    result: dict[str, Any],
    decision: str,
    period_start: Optional[str] = None,
    period_end: Optional[str] = None,
    notes: str = "",
) -> Experiment:
    """
    Append one experiment. Every experiment must be recorded, including
    (especially) the rejected and inconclusive ones - a registry holding
    only successes is exactly the bias this module exists to prevent.
    """

    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}, got {decision!r}")

    experiment = Experiment(
        experiment_id=experiment_id,
        hypothesis=hypothesis,
        strategy_id=strategy_id,
        strategy_version=strategy_version,
        symbols=list(symbols),
        timeframe=timeframe,
        period_start=period_start,
        period_end=period_end,
        parameters=dict(parameters),
        result=dict(result),
        decision=decision,
        notes=notes,
    )

    EXPERIMENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with EXPERIMENTS_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(asdict(experiment), default=str) + "\n")

    return experiment


def list_experiments() -> list[dict[str, Any]]:
    if not EXPERIMENTS_FILE.exists():
        return []

    out: list[dict[str, Any]] = []
    with EXPERIMENTS_FILE.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
    return out


@dataclass
class SelectionBiasReport:
    experiment_count: int
    accepted_count: int
    rejected_count: int
    inconclusive_count: int
    alpha: float
    family_wise_error_probability: Optional[float]
    bonferroni_alpha: Optional[float]
    expected_false_positives: Optional[float]
    interpretation: str


def selection_bias_report(alpha: float = 0.05) -> SelectionBiasReport:
    """
    Quantify how much "best of many" inflation the recorded experiment
    count implies.

    family_wise_error_probability = 1 - (1 - alpha) ** N
        the chance of at least one apparently-significant result if every
        strategy tested truly had zero edge.

    bonferroni_alpha = alpha / N
        the per-experiment threshold needed to keep the family-wise error
        at alpha. Deliberately conservative; it is a sanity anchor, not a
        claim that these results satisfy its assumptions.

    expected_false_positives = N * alpha
        how many zero-edge strategies would be expected to look good.
    """

    experiments = list_experiments()
    n = len(experiments)

    accepted = sum(1 for e in experiments if e.get("decision") == "ACCEPTED")
    rejected = sum(1 for e in experiments if e.get("decision") == "REJECTED")
    inconclusive = sum(1 for e in experiments if e.get("decision") == "INCONCLUSIVE")

    if n == 0:
        return SelectionBiasReport(
            experiment_count=0, accepted_count=0, rejected_count=0, inconclusive_count=0,
            alpha=alpha,
            family_wise_error_probability=None, bonferroni_alpha=None,
            expected_false_positives=None,
            interpretation=(
                "No experiments recorded. Nothing can be said about selection bias - "
                "and note that an empty registry does NOT mean no experiments were run, "
                "only that none were recorded."
            ),
        )

    fwer = 1.0 - (1.0 - alpha) ** n
    expected_fp = n * alpha

    if accepted == 0:
        interpretation = (
            f"{n} experiment(s) recorded, none accepted. No selection-bias problem "
            "arises from choosing a winner, because no winner was chosen."
        )
    elif accepted <= expected_fp:
        interpretation = (
            f"{accepted} accepted out of {n} experiments, but roughly {expected_fp:.1f} "
            f"would be expected to look good by chance alone at alpha={alpha}. The "
            "accepted result(s) are NOT distinguishable from noise on this evidence and "
            "must be confirmed on untouched data before being believed."
        )
    else:
        interpretation = (
            f"{accepted} accepted out of {n} experiments vs roughly {expected_fp:.1f} "
            f"expected by chance at alpha={alpha}. That is more survivors than chance "
            "alone predicts, which is encouraging but not conclusive - confirm on "
            "untouched out-of-sample data, and treat the per-experiment threshold as "
            f"{alpha / n:.5f} rather than {alpha}."
        )

    return SelectionBiasReport(
        experiment_count=n,
        accepted_count=accepted,
        rejected_count=rejected,
        inconclusive_count=inconclusive,
        alpha=alpha,
        family_wise_error_probability=fwer,
        bonferroni_alpha=alpha / n,
        expected_false_positives=expected_fp,
        interpretation=interpretation,
    )


def print_selection_bias_report(report: SelectionBiasReport) -> None:
    print()
    print("=" * 78)
    print(" SELECTION / MULTIPLE-TESTING BIAS REPORT")
    print("=" * 78)
    print(f"Experiments recorded      : {report.experiment_count}")
    print(f"  accepted                : {report.accepted_count}")
    print(f"  rejected                : {report.rejected_count}")
    print(f"  inconclusive            : {report.inconclusive_count}")
    print(f"alpha                     : {report.alpha}")
    if report.family_wise_error_probability is not None:
        print(f"Family-wise error prob.   : {report.family_wise_error_probability:.4f}")
        print(f"Bonferroni per-experiment : {report.bonferroni_alpha:.5f}")
        print(f"Expected false positives  : {report.expected_false_positives:.2f}")
    print()
    print(report.interpretation)
    print("=" * 78)
