"""
Asian session range breakout strategy.

A genuinely different archetype from everything tried so far (which were
all reversal/mean-reversion style - liquidity sweep, trend-following).
This is a BREAKOUT/continuation strategy: the Asian session (00:00-08:00
UTC) typically trades a tighter range; when London opens (07:00-10:00
UTC) and price breaks out of that range with conviction, the breakout is
traded in the breakout direction, targeting a measured move.

OHLC-only, historically testable - reuses app.core.zones for the Asian
session high/low (the same zone-marking code the reversal strategies use,
just a different rule applied to it).

Entry: first bar during the London window whose close breaks beyond the
Asian session high (long) or low (short) by at least a minimum fraction
of the Asian range itself (filters out marginal/noise breaks).
Stop: just back inside the broken level (NOT the far side of the range -
an earlier version used the opposite side of the range as the stop, which
made the risk distance mathematically always exceed the measured-move
reward, guaranteeing every signal failed the reward:risk gate regardless
of market conditions; caught via a zero-signals-across-8-symbols result
that should have been impossible by chance, traced to this exact
construction error, and fixed here).
Target: measured move - the Asian range's size, projected from the
breakout point (a standard, simple breakout target, not curve-fit to any
particular symbol).
"""

from __future__ import annotations

from typing import Optional

from app.core.zones import compute_asian_session_zone, parse_ts, in_session_window

LONDON_WINDOW_UTC = (7, 10)

MIN_BREAKOUT_FRACTION_OF_RANGE = 0.10  # breakout must clear the range by >=10% of its own size
MIN_REWARD_TO_RISK = 1.5
ASIAN_WINDOW_BARS = 400  # enough to always contain "today's" 00:00-08:00 bars


def evaluate(
    bars: list[dict], *,
    min_breakout_fraction_of_range: float = MIN_BREAKOUT_FRACTION_OF_RANGE,
    min_reward_to_risk: float = MIN_REWARD_TO_RISK,
    stop_buffer_fraction: float = 0.15,
) -> Optional[dict]:
    """
    min_breakout_fraction_of_range / min_reward_to_risk / stop_buffer_fraction
    default to this module's constants (the values actually tested and
    recorded in the strategy registry) - callers doing parameter-sensitivity
    sweeps (see app.quant.robustness) override them per combination without
    needing a second copy of this function.
    """

    if len(bars) < 20:
        return None

    latest = bars[-1]
    latest_ts = parse_ts(latest.get("timestamp"))
    if latest_ts is None:
        return None

    if not in_session_window(latest_ts, LONDON_WINDOW_UTC):
        return None

    asian_high, asian_low = compute_asian_session_zone(bars[-ASIAN_WINDOW_BARS:])
    if asian_high is None or asian_low is None:
        return None

    asian_range = asian_high - asian_low
    if asian_range <= 0:
        return None

    min_breakout_distance = asian_range * min_breakout_fraction_of_range

    close = latest["close"]

    # Stop buffer: a small fraction of the range back inside the broken
    # level - tight enough to keep risk proportional to the breakout
    # itself, not the whole prior range.
    stop_buffer = asian_range * stop_buffer_fraction

    if close > asian_high + min_breakout_distance:
        entry = close
        stop_loss = asian_high - stop_buffer
        risk = entry - stop_loss
        if risk <= 0:
            return None
        take_profit = entry + asian_range  # measured move
        reward = take_profit - entry
        if reward / risk < min_reward_to_risk:
            return None
        return {
            "direction": "BUY", "entry": entry, "stop_loss": stop_loss,
            "take_profit": take_profit,
            "asian_high": asian_high, "asian_low": asian_low,
        }

    if close < asian_low - min_breakout_distance:
        entry = close
        stop_loss = asian_low + stop_buffer
        risk = stop_loss - entry
        if risk <= 0:
            return None
        take_profit = entry - asian_range
        reward = entry - take_profit
        if reward / risk < min_reward_to_risk:
            return None
        return {
            "direction": "SELL", "entry": entry, "stop_loss": stop_loss,
            "take_profit": take_profit,
            "asian_high": asian_high, "asian_low": asian_low,
        }

    return None


def make_signal_provider(
    *,
    min_breakout_fraction_of_range: float = MIN_BREAKOUT_FRACTION_OF_RANGE,
    min_reward_to_risk: float = MIN_REWARD_TO_RISK,
    stop_buffer_fraction: float = 0.15,
):
    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(
            visible_bars,
            min_breakout_fraction_of_range=min_breakout_fraction_of_range,
            min_reward_to_risk=min_reward_to_risk,
            stop_buffer_fraction=stop_buffer_fraction,
        )
    return signal_provider
