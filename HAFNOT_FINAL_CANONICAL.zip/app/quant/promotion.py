"""
Strategy promotion pipeline.

Nothing like this existed anywhere in the project before (confirmed by
repo-wide search: no stage-tracking code, no persisted candidate state).
This tracks one strategy candidate through the stages the project owner
asked for:

    RESEARCH -> BACKTEST -> OUT_OF_SAMPLE -> WALK_FORWARD
             -> PAPER_FORWARD -> DEMO_FORWARD -> VALIDATED

A candidate that fails a stage's gate is marked REJECTED and stays
rejected - nothing here silently promotes a failing candidate, and nothing
here re-promotes a rejected one without a brand new candidate_id (i.e. a
human deciding to try again, not an automatic retry).

State is persisted as one JSON file per candidate under
data/promotion/<candidate_id>.json so a stage's outcome survives process
restarts and is auditable after the fact.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from app.forex_v2.metrics import PerformanceSummary, PromotionGate, evaluate_promotion, summarize_trades

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROMOTION_DIR = PROJECT_ROOT / "data" / "promotion"

STAGES = (
    "RESEARCH",
    "BACKTEST",
    "OUT_OF_SAMPLE",
    "WALK_FORWARD",
    "PAPER_FORWARD",
    "DEMO_FORWARD",
    "VALIDATED",
)

REJECTED = "REJECTED"

# States outside the linear STAGES sequence. A VALIDATED candidate enters
# CONTINUOUS_MONITORING (Phase L) to track forward paper/DEMO performance
# against what validation promised. If that forward performance degrades,
# the candidate moves to REVIEW_REQUIRED - a terminal state for this
# candidate_id, same policy as REJECTED: no automatic reactivation, no
# automatic parameter change. A human reviews and, if warranted, starts a
# brand new candidate_id back at RESEARCH. new_trades_allowed() below is
# the actual enforceable check an execution layer calls, not just a label.
CONTINUOUS_MONITORING = "CONTINUOUS_MONITORING"
REVIEW_REQUIRED = "REVIEW_REQUIRED"

# Stages a candidate may be degraded FROM into REVIEW_REQUIRED. Paper/demo
# forward stages are included (not just CONTINUOUS_MONITORING) because
# performance can visibly degrade before a candidate ever reaches full
# VALIDATED status, and the spec's own example ("DEMO PERFORMANCE
# DEGRADES") is exactly that case.
DEGRADABLE_STAGES = ("PAPER_FORWARD", "DEMO_FORWARD", CONTINUOUS_MONITORING)

TERMINAL_STAGES = (REJECTED, REVIEW_REQUIRED)

# Later stages require more evidence and tighter risk before promotion.
# BACKTEST/OOS use the library default (100 trades). Paper/demo forward
# stages intentionally require fewer closed trades to reach a checkpoint
# (waiting for 100 real paper trades before even looking at the data would
# take too long to be useful) but hold profit factor and drawdown to the
# same bar.
STAGE_GATES: dict[str, PromotionGate] = {
    "BACKTEST": PromotionGate(minimum_closed_trades=100, minimum_profit_factor=1.15, minimum_expectancy_r=0.05, maximum_drawdown_percent=12.0),
    "OUT_OF_SAMPLE": PromotionGate(minimum_closed_trades=30, minimum_profit_factor=1.10, minimum_expectancy_r=0.03, maximum_drawdown_percent=15.0),
    "PAPER_FORWARD": PromotionGate(minimum_closed_trades=30, minimum_profit_factor=1.10, minimum_expectancy_r=0.03, maximum_drawdown_percent=15.0),
    "DEMO_FORWARD": PromotionGate(minimum_closed_trades=30, minimum_profit_factor=1.10, minimum_expectancy_r=0.03, maximum_drawdown_percent=15.0),
}

# Walk-forward has its own criterion (see _evaluate_walk_forward) since it
# is judged on out-of-sample consistency across windows, not one summary.
WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION = 0.55
WALK_FORWARD_MIN_WINDOWS = 3


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class StageRecord:
    stage: str
    passed: bool
    reasons: tuple
    timestamp: str
    evidence: dict


@dataclass
class StrategyCandidate:
    candidate_id: str
    symbol: str
    params: dict
    current_stage: str
    created_at: str
    history: list = field(default_factory=list)

    def to_json(self) -> dict:
        data = asdict(self)
        return data

    @staticmethod
    def from_json(data: dict) -> "StrategyCandidate":
        candidate = StrategyCandidate(
            candidate_id=data["candidate_id"],
            symbol=data["symbol"],
            params=data["params"],
            current_stage=data["current_stage"],
            created_at=data["created_at"],
        )
        candidate.history = data.get("history", [])
        return candidate


def _path(candidate_id: str) -> Path:
    return PROMOTION_DIR / f"{candidate_id}.json"


def create_candidate(candidate_id: str, symbol: str, params: dict) -> StrategyCandidate:

    if _path(candidate_id).exists():
        raise ValueError(f"Candidate {candidate_id!r} already exists.")

    candidate = StrategyCandidate(
        candidate_id=candidate_id,
        symbol=symbol.upper(),
        params=dict(params),
        current_stage="RESEARCH",
        created_at=_now(),
    )
    _save(candidate)
    return candidate


def load_candidate(candidate_id: str) -> StrategyCandidate:
    path = _path(candidate_id)
    if not path.exists():
        raise FileNotFoundError(f"No candidate found: {candidate_id!r}")
    return StrategyCandidate.from_json(json.loads(path.read_text(encoding="utf-8")))


def _save(candidate: StrategyCandidate) -> None:
    PROMOTION_DIR.mkdir(parents=True, exist_ok=True)
    _path(candidate.candidate_id).write_text(
        json.dumps(candidate.to_json(), indent=2, default=str),
        encoding="utf-8",
    )


def _next_stage(current: str) -> str:
    index = STAGES.index(current)
    if index + 1 >= len(STAGES):
        return current
    return STAGES[index + 1]


def _record_stage_result(
    candidate: StrategyCandidate,
    stage: str,
    passed: bool,
    reasons: tuple,
    evidence: dict,
) -> StrategyCandidate:

    if candidate.current_stage in (REJECTED, "VALIDATED"):
        raise ValueError(
            f"Candidate {candidate.candidate_id!r} is already in terminal "
            f"state {candidate.current_stage!r}; create a new candidate to try again."
        )

    if candidate.current_stage != stage:
        raise ValueError(
            f"Candidate {candidate.candidate_id!r} is at stage "
            f"{candidate.current_stage!r}, not {stage!r}. Stages must be "
            f"completed in order: {' -> '.join(STAGES)}."
        )

    record = StageRecord(
        stage=stage,
        passed=passed,
        reasons=tuple(reasons),
        timestamp=_now(),
        evidence=evidence,
    )
    candidate.history.append(asdict(record))
    candidate.current_stage = _next_stage(stage) if passed else REJECTED

    _save(candidate)
    return candidate


def _summary_evidence(summary: PerformanceSummary) -> dict:
    return summary.as_dict()


def submit_stage_result(
    candidate: StrategyCandidate,
    stage: str,
    trades: list[dict],
    *,
    initial_equity: float,
) -> StrategyCandidate:
    """
    Score a stage's closed trades (each needs pnl_usd, optionally result_r)
    against that stage's PromotionGate and advance or reject the candidate.
    Use for BACKTEST, OUT_OF_SAMPLE, PAPER_FORWARD, DEMO_FORWARD. For
    WALK_FORWARD, use submit_walk_forward_result instead.
    """

    gate = STAGE_GATES.get(stage)
    if gate is None:
        raise ValueError(f"{stage!r} does not use submit_stage_result (use a dedicated function).")

    summary = summarize_trades(trades, initial_equity=initial_equity)
    decision = evaluate_promotion(summary, gate)

    return _record_stage_result(
        candidate,
        stage,
        decision.passed,
        decision.reasons,
        _summary_evidence(summary),
    )


def new_trades_allowed(candidate: StrategyCandidate) -> bool:
    """
    The actual enforceable check an execution layer should call before
    opening a new position for this candidate - not just documentation.
    False for any terminal state (REJECTED, REVIEW_REQUIRED); true
    otherwise, including mid-pipeline stages and CONTINUOUS_MONITORING.
    """

    return candidate.current_stage not in TERMINAL_STAGES


def enter_continuous_monitoring(candidate: StrategyCandidate) -> StrategyCandidate:
    """VALIDATED -> CONTINUOUS_MONITORING (Phase L: track forward performance)."""

    if candidate.current_stage != "VALIDATED":
        raise ValueError(
            f"Candidate {candidate.candidate_id!r} is at stage {candidate.current_stage!r}, "
            "not 'VALIDATED'; only a validated candidate enters continuous monitoring."
        )

    record = StageRecord(
        stage=CONTINUOUS_MONITORING, passed=True, reasons=("Entered continuous forward-performance monitoring.",),
        timestamp=_now(), evidence={},
    )
    candidate.history.append(asdict(record))
    candidate.current_stage = CONTINUOUS_MONITORING
    _save(candidate)
    return candidate


def flag_performance_degradation(
    candidate: StrategyCandidate, *, reasons: list[str], evidence: dict,
) -> StrategyCandidate:
    """
    Move a candidate whose forward (paper/DEMO/monitored) performance has
    degraded below what validation promised into REVIEW_REQUIRED. This is
    terminal for this candidate_id, same as REJECTED: no automatic
    reactivation and no automatic parameter change (per the spec - "Any
    strategy modification must return to the research and validation
    lifecycle" as a brand new candidate). Call new_trades_allowed() after
    this to see the practical effect: it now returns False.
    """

    if candidate.current_stage in TERMINAL_STAGES:
        raise ValueError(
            f"Candidate {candidate.candidate_id!r} is already in terminal state "
            f"{candidate.current_stage!r}."
        )
    if candidate.current_stage not in DEGRADABLE_STAGES:
        raise ValueError(
            f"Candidate {candidate.candidate_id!r} is at stage {candidate.current_stage!r}; "
            f"degradation can only be flagged from {DEGRADABLE_STAGES}."
        )

    record = StageRecord(
        stage=REVIEW_REQUIRED, passed=False, reasons=tuple(reasons),
        timestamp=_now(), evidence=evidence,
    )
    candidate.history.append(asdict(record))
    candidate.current_stage = REVIEW_REQUIRED
    _save(candidate)
    return candidate


def submit_walk_forward_result(candidate: StrategyCandidate, walk_forward_result: Any) -> StrategyCandidate:
    """walk_forward_result: an app.quant.walk_forward.WalkForwardResult."""

    windows = walk_forward_result.windows
    positive_fraction = walk_forward_result.positive_window_fraction
    mean_expectancy = walk_forward_result.mean_out_of_sample_expectancy_r

    reasons = []
    passed = True

    if len(windows) < WALK_FORWARD_MIN_WINDOWS:
        passed = False
        reasons.append(
            f"Only {len(windows)} walk-forward windows produced; need at "
            f"least {WALK_FORWARD_MIN_WINDOWS} for a meaningful result."
        )

    if positive_fraction is None or positive_fraction < WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION:
        passed = False
        reasons.append(
            f"Out-of-sample positive-window fraction "
            f"{positive_fraction if positive_fraction is not None else 'N/A'} "
            f"is below the required {WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION}."
        )

    if mean_expectancy is None or mean_expectancy <= 0:
        passed = False
        reasons.append(
            f"Mean out-of-sample expectancy_r {mean_expectancy!r} is not positive."
        )

    if not reasons:
        reasons.append("Walk-forward out-of-sample results met all thresholds.")

    return _record_stage_result(
        candidate,
        "WALK_FORWARD",
        passed,
        tuple(reasons),
        {
            "window_count": len(windows),
            "positive_window_fraction": positive_fraction,
            "mean_out_of_sample_expectancy_r": mean_expectancy,
        },
    )
