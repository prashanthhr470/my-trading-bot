"""
Overfitting-defense system.

A dedicated place for the checks that decide whether a backtest result is
trustworthy evidence of a real edge, or a strategy that has been
curve-fit to its own history. Nothing here re-runs a backtest - every
function takes already-computed results (a parameter sweep, walk-forward
windows, a trade list, an in-sample/out-of-sample pair) and returns an
explicit verdict plus the reasons, so a brittle strategy is FLAGGED, never
silently passed through.

Two of the checks below (`flag_is_oos_divergence`, `flag_small_sample`)
were originally written inline in app.quant.strategy_scorecard and are
now defined once here and imported there, rather than existing as two
copies of the same logic in two files.

What this module does NOT cover yet, and says so explicitly rather than
pretending: sensitivity to the backtest's start date (would require
re-running the same strategy from several different start dates - a real
test, not yet automated) and a running count of how many times a given
strategy_id/version has been re-tuned and re-tested (the "excessive
optimization attempts" check the spec asks for - this needs the strategy
registry to track sweep attempts over time, which it does not do yet).
Both are listed in every OverfittingReport's `not_yet_automated` field
instead of being skipped without comment.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# --- shared thresholds -----------------------------------------------

# Below this fraction of a parameter grid being net-profitable, a single
# winning combination looks like an isolated lucky peak rather than a
# robust region - the classic "works great at exactly these settings,
# falls apart one tick either side" overfitting signature.
PLATEAU_MIN_PROFITABLE_FRACTION = 0.5
ISOLATED_PEAK_MAX_PROFITABLE_FRACTION = 0.15

# More independently tuned parameters means more ways to accidentally fit
# noise in a finite historical sample. Not a hard rule, just a rising
# risk flag past this count.
HIGH_PARAMETER_COUNT_THRESHOLD = 4

# A metric is considered "large IS/OOS divergence" if the in-sample and
# out-of-sample net P&L per trade differ by more than this many dollars -
# a coarse, easy-to-explain threshold, not a statistically tuned one.
DIVERGENCE_FLAG_THRESHOLD_USD_PER_TRADE = 20.0

SMALL_SAMPLE_TRADE_THRESHOLD = 3

# Walk-forward: fraction of windows required to be net-positive for the
# result to be called "consistent" rather than "trend-dependent".
WALK_FORWARD_MIN_POSITIVE_FRACTION = 0.55
WALK_FORWARD_MIN_WINDOWS = 3
# Coefficient of variation (stdev/mean) of trade count across windows
# above which the strategy is producing wildly different numbers of
# trades window to window - a sign the setup is regime/period-dependent
# rather than a stable, repeatable pattern.
UNSTABLE_TRADE_COUNT_CV_THRESHOLD = 0.75

# A strategy whose top 1 or top 3 trades account for more than this
# fraction of total net profit is not demonstrating a repeatable edge so
# much as a couple of lucky outsized trades - removing them should be
# checked before trusting the aggregate number.
TOP_TRADE_CONCENTRATION_FRACTION = 0.5


# --- IS/OOS divergence + small-sample flags (shared with the scorecard) ---

def flag_is_oos_divergence(
    *, in_sample_trades: int, in_sample_net_pnl_usd: float,
    out_of_sample_trades: int, out_of_sample_net_pnl_usd: float,
) -> list[str]:
    flags: list[str] = []

    if in_sample_trades <= 0 or out_of_sample_trades <= 0:
        return flags

    is_per_trade = in_sample_net_pnl_usd / in_sample_trades
    oos_per_trade = out_of_sample_net_pnl_usd / out_of_sample_trades
    divergence = abs(is_per_trade - oos_per_trade)

    if divergence >= DIVERGENCE_FLAG_THRESHOLD_USD_PER_TRADE:
        flags.append(
            f"Large IS/OOS divergence: ${is_per_trade:.2f}/trade in-sample vs. "
            f"${oos_per_trade:.2f}/trade out-of-sample (${divergence:.2f} gap). "
            "Strategy may be curve-fit to the in-sample period."
        )

    if (in_sample_net_pnl_usd > 0) != (out_of_sample_net_pnl_usd > 0):
        flags.append(
            "Sign flip between in-sample and out-of-sample net P&L "
            "(one period profitable, the other not) - inconsistent, not robust."
        )

    return flags


def flag_small_sample(results: list[dict[str, Any]]) -> list[str]:
    small = [
        r for r in results
        if isinstance(r.get("scorecard", {}).get("trade_count"), int)
        and 0 < r["scorecard"]["trade_count"] <= SMALL_SAMPLE_TRADE_THRESHOLD
    ]
    if not small:
        return []
    return [
        f"{len(small)} result(s) have {SMALL_SAMPLE_TRADE_THRESHOLD} or fewer trades - too "
        "small to be statistically meaningful on their own; any striking win rate in "
        "these should be treated as noise until confirmed by more data."
    ]


# --- parameter sensitivity ---------------------------------------------

@dataclass
class ParameterSensitivityAssessment:
    verdict: str  # "PLATEAU", "ISOLATED_PEAK", "NO_EDGE", "INSUFFICIENT_DATA"
    flags: list[str] = field(default_factory=list)


def assess_parameter_sensitivity(
    *, profitable_fraction: Optional[float] = None,
    combos_tried: Optional[int] = None,
    tuned_parameter_count: Optional[int] = None,
) -> ParameterSensitivityAssessment:
    """
    profitable_fraction: fraction of a parameter grid sweep that came out
    net-positive (see app.quant.robustness.RobustnessResult.profitable_fraction).
    combos_tried: grid size, for context in the flag text.
    tuned_parameter_count: how many independent parameters were varied.
    """

    flags: list[str] = []

    if profitable_fraction is None:
        verdict = "INSUFFICIENT_DATA"
        flags.append("No parameter sweep result was supplied - parameter sensitivity is unassessed, not passing.")
    elif profitable_fraction <= 0.0:
        verdict = "NO_EDGE"
        flags.append(
            f"0% of {combos_tried or 'the'} parameter combinations tested were net-profitable - "
            "no edge to be sensitive about; the strategy simply does not work across this grid."
        )
    elif profitable_fraction < ISOLATED_PEAK_MAX_PROFITABLE_FRACTION:
        verdict = "ISOLATED_PEAK"
        flags.append(
            f"Only {profitable_fraction:.0%} of {combos_tried or 'the'} combinations were profitable - "
            "looks like an isolated lucky peak, not a robust parameter region. Do not promote on the "
            "strength of the single best combination alone."
        )
    elif profitable_fraction < PLATEAU_MIN_PROFITABLE_FRACTION:
        verdict = "ISOLATED_PEAK"
        flags.append(
            f"{profitable_fraction:.0%} of {combos_tried or 'the'} combinations were profitable - "
            "a minority, not a plateau. Neighboring parameter choices mostly fail, which is a "
            "curve-fitting warning sign even though at least one setting worked."
        )
    else:
        verdict = "PLATEAU"

    if tuned_parameter_count is not None and tuned_parameter_count > HIGH_PARAMETER_COUNT_THRESHOLD:
        flags.append(
            f"{tuned_parameter_count} parameters were independently tuned (> {HIGH_PARAMETER_COUNT_THRESHOLD}) - "
            "more degrees of freedom raises the risk that any single winning combination is fitting "
            "noise in the historical sample rather than a real pattern."
        )

    return ParameterSensitivityAssessment(verdict=verdict, flags=flags)


# --- walk-forward stability --------------------------------------------

@dataclass
class WalkForwardStabilityAssessment:
    verdict: str  # "STABLE", "UNSTABLE", "INSUFFICIENT_DATA"
    flags: list[str] = field(default_factory=list)
    positive_window_fraction: Optional[float] = None
    trade_count_cv: Optional[float] = None


def assess_walk_forward_windows(windows: list[dict[str, Any]]) -> WalkForwardStabilityAssessment:
    """
    windows: list of dicts with at least out_of_sample_expectancy_r and
    out_of_sample_trade_count (matches app.quant.walk_forward.WindowResult
    field names - pass [vars(w) for w in result.windows] or equivalent).
    """

    flags: list[str] = []

    if len(windows) < WALK_FORWARD_MIN_WINDOWS:
        return WalkForwardStabilityAssessment(
            verdict="INSUFFICIENT_DATA",
            flags=[f"Only {len(windows)} walk-forward window(s) - need at least {WALK_FORWARD_MIN_WINDOWS} to assess stability."],
        )

    expectancies = [w.get("out_of_sample_expectancy_r") for w in windows]
    scored = [e for e in expectancies if e is not None]
    positive_fraction = (sum(1 for e in scored if e > 0) / len(scored)) if scored else None

    trade_counts = [w.get("out_of_sample_trade_count") for w in windows if w.get("out_of_sample_trade_count") is not None]
    trade_count_cv = None
    if trade_counts and len(trade_counts) > 1:
        mean_tc = sum(trade_counts) / len(trade_counts)
        if mean_tc > 0:
            variance = sum((tc - mean_tc) ** 2 for tc in trade_counts) / len(trade_counts)
            trade_count_cv = (variance ** 0.5) / mean_tc

    unstable = False

    if positive_fraction is None or positive_fraction < WALK_FORWARD_MIN_POSITIVE_FRACTION:
        unstable = True
        flags.append(
            f"Out-of-sample positive-window fraction "
            f"{'N/A' if positive_fraction is None else f'{positive_fraction:.0%}'} is below the "
            f"{WALK_FORWARD_MIN_POSITIVE_FRACTION:.0%} required for a consistent, repeatable edge."
        )

    if trade_count_cv is not None and trade_count_cv > UNSTABLE_TRADE_COUNT_CV_THRESHOLD:
        unstable = True
        flags.append(
            f"Trade count varies sharply window to window (coefficient of variation {trade_count_cv:.2f}) - "
            "the setup fires inconsistently across periods rather than at a stable rate."
        )

    # First-half vs second-half degradation: a crude proxy for
    # date/period sensitivity using data already on hand (a real
    # multi-start-date sweep is listed under not_yet_automated).
    if len(scored) >= WALK_FORWARD_MIN_WINDOWS:
        mid = len(scored) // 2
        first_half = scored[:mid]
        second_half = scored[mid:]
        if first_half and second_half:
            first_mean = sum(first_half) / len(first_half)
            second_mean = sum(second_half) / len(second_half)
            if (first_mean > 0) != (second_mean > 0):
                unstable = True
                flags.append(
                    f"Out-of-sample expectancy flips sign between the earlier windows "
                    f"(mean {first_mean:.3f}R) and later windows (mean {second_mean:.3f}R) - "
                    "performance is not consistent across the full period tested."
                )

    verdict = "UNSTABLE" if unstable else "STABLE"

    return WalkForwardStabilityAssessment(
        verdict=verdict, flags=flags,
        positive_window_fraction=positive_fraction, trade_count_cv=trade_count_cv,
    )


# --- trade concentration ------------------------------------------------

@dataclass
class TradeConcentrationAssessment:
    verdict: str  # "DISTRIBUTED", "CONCENTRATED", "INSUFFICIENT_DATA"
    flags: list[str] = field(default_factory=list)
    top_1_fraction_of_profit: Optional[float] = None
    top_3_fraction_of_profit: Optional[float] = None


def assess_trade_concentration(trades: list[dict[str, Any]]) -> TradeConcentrationAssessment:
    """trades: list of dicts with at least net_pnl_usd."""

    if len(trades) < 5:
        return TradeConcentrationAssessment(
            verdict="INSUFFICIENT_DATA",
            flags=[f"Only {len(trades)} trade(s) - too few to assess concentration risk."],
        )

    pnls = [float(t["net_pnl_usd"]) for t in trades]
    total_profit = sum(p for p in pnls if p > 0)

    if total_profit <= 0:
        return TradeConcentrationAssessment(
            verdict="DISTRIBUTED",
            flags=["No positive trades to concentrate - the strategy has no winners to be reliant on."],
            top_1_fraction_of_profit=0.0, top_3_fraction_of_profit=0.0,
        )

    winners_sorted = sorted((p for p in pnls if p > 0), reverse=True)
    top_1_fraction = winners_sorted[0] / total_profit
    top_3_fraction = sum(winners_sorted[:3]) / total_profit

    net_total = sum(pnls)
    would_flip_without_best_trade = net_total > 0 and (net_total - winners_sorted[0]) <= 0

    flags: list[str] = []
    if top_3_fraction >= TOP_TRADE_CONCENTRATION_FRACTION:
        flags.append(
            f"Top 3 winning trades account for {top_3_fraction:.0%} of total gross profit - "
            "the result leans heavily on a small number of exceptional trades rather than a "
            "broadly repeatable edge."
        )
    if would_flip_without_best_trade:
        flags.append(
            "Removing the single best trade flips total net P&L from positive to negative - "
            "the strategy's profitability depends entirely on one outlier."
        )

    verdict = "CONCENTRATED" if flags else "DISTRIBUTED"

    return TradeConcentrationAssessment(
        verdict=verdict, flags=flags,
        top_1_fraction_of_profit=top_1_fraction, top_3_fraction_of_profit=top_3_fraction,
    )


# --- consolidated report -------------------------------------------------

NOT_YET_AUTOMATED = (
    "Start-date sensitivity (re-running the same strategy from several different "
    "backtest start dates) - not yet automated, would require a dedicated multi-start sweep.",
    "Excessive-optimization-attempt tracking (how many times a strategy_id/version has "
    "been re-tuned and re-tested against the same data) - the strategy registry does not "
    "yet log sweep/tuning attempts over time, only final results.",
)


@dataclass
class OverfittingReport:
    verdict: str  # "ROBUST", "BRITTLE", "INSUFFICIENT_EVIDENCE"
    flags: list[str] = field(default_factory=list)
    parameter_sensitivity: Optional[ParameterSensitivityAssessment] = None
    walk_forward_stability: Optional[WalkForwardStabilityAssessment] = None
    trade_concentration: Optional[TradeConcentrationAssessment] = None
    is_oos_flags: list[str] = field(default_factory=list)
    not_yet_automated: tuple = NOT_YET_AUTOMATED


def build_overfitting_report(
    *,
    profitable_fraction: Optional[float] = None,
    combos_tried: Optional[int] = None,
    tuned_parameter_count: Optional[int] = None,
    walk_forward_windows: Optional[list[dict[str, Any]]] = None,
    trades: Optional[list[dict[str, Any]]] = None,
    in_sample_trades: Optional[int] = None,
    in_sample_net_pnl_usd: Optional[float] = None,
    out_of_sample_trades: Optional[int] = None,
    out_of_sample_net_pnl_usd: Optional[float] = None,
) -> OverfittingReport:
    """
    Combine whichever checks the caller has evidence for into one report.
    Every argument is optional - a strategy with only a parameter sweep
    and no walk-forward run yet still gets a report, just with that
    section marked INSUFFICIENT_DATA rather than skipped silently.
    """

    all_flags: list[str] = []
    any_brittle = False
    any_evidence = False

    param_assessment = None
    if profitable_fraction is not None or tuned_parameter_count is not None:
        any_evidence = True
        param_assessment = assess_parameter_sensitivity(
            profitable_fraction=profitable_fraction, combos_tried=combos_tried,
            tuned_parameter_count=tuned_parameter_count,
        )
        all_flags.extend(param_assessment.flags)
        if param_assessment.verdict in ("ISOLATED_PEAK", "NO_EDGE"):
            any_brittle = True

    wf_assessment = None
    if walk_forward_windows is not None:
        any_evidence = True
        wf_assessment = assess_walk_forward_windows(walk_forward_windows)
        all_flags.extend(wf_assessment.flags)
        if wf_assessment.verdict == "UNSTABLE":
            any_brittle = True

    concentration_assessment = None
    if trades is not None:
        any_evidence = True
        concentration_assessment = assess_trade_concentration(trades)
        all_flags.extend(concentration_assessment.flags)
        if concentration_assessment.verdict == "CONCENTRATED":
            any_brittle = True

    is_oos_flags: list[str] = []
    if None not in (in_sample_trades, in_sample_net_pnl_usd, out_of_sample_trades, out_of_sample_net_pnl_usd):
        any_evidence = True
        is_oos_flags = flag_is_oos_divergence(
            in_sample_trades=in_sample_trades, in_sample_net_pnl_usd=in_sample_net_pnl_usd,
            out_of_sample_trades=out_of_sample_trades, out_of_sample_net_pnl_usd=out_of_sample_net_pnl_usd,
        )
        all_flags.extend(is_oos_flags)
        if is_oos_flags:
            any_brittle = True

    if not any_evidence:
        verdict = "INSUFFICIENT_EVIDENCE"
    elif any_brittle:
        verdict = "BRITTLE"
    else:
        verdict = "ROBUST"

    return OverfittingReport(
        verdict=verdict,
        flags=all_flags,
        parameter_sensitivity=param_assessment,
        walk_forward_stability=wf_assessment,
        trade_concentration=concentration_assessment,
        is_oos_flags=is_oos_flags,
    )
