"""
CORE STRATEGY - the single decision logic shared by the historical
backtester AND the live/paper/DEMO pipeline.

Uses ONLY data that is genuinely available historically:
  - OHLC price bars (and derived: sessions, volatility, market regime)
  - market structure (swing highs/lows, BOS, CHoCH) - app.core.structure
  - liquidity zones inferred from price behavior (previous day/week
    high/low, Asian session high/low, equal highs/lows) - app.core.zones
  - liquidity sweeps + Fair Value Gap confluence, inferred from price
    action alone
  - momentum
  - deterministic risk management (position sizing, reward:risk floor)

Deliberately does NOT use, and NEVER will inside this module:
  - order flow / footprint / DOM / bid-ask volume-at-price
  - news or economic-calendar events
  - sentiment
  - live execution conditions (current real-time spread, broker state)

Those live-only signals belong in app.live.confirmation_layer, which
wraps this module's output and is only ever invoked when running against
live/paper/DEMO data - never during a historical backtest. This keeps the
boundary between "honestly backtestable" and "live-only" structurally
enforced by which module gets imported, not just documented in prose.

Every result this module returns carries a "data_sources" field stating
exactly what was and was not used, so nothing downstream can accidentally
present a historical result as if it included live-only confirmation.
"""

from __future__ import annotations

from typing import Optional

from app.core.structure import find_structure_events
from app.core.zones import (
    SwingPoint, LiquidityZones, find_confirmed_swings, compute_zones,
    compute_daily_weekly_zones, compute_asian_session_zone, equal_level_cluster,
    parse_ts, in_session_window,
)

# Window sizes: zones need enough history to see a full previous week;
# swing/structure/FVG detection only needs a much shorter recent window.
# Kept separate so performance stays reasonable - recomputing zones over
# a huge window is cheap (simple aggregation), but recomputing swings is
# the O(window) per-bar cost that determines backtest speed.
ZONE_LOOKBACK_BARS = 4000  # ~2+ weeks of M15, ~14 days of M5-at-5min-granularity varies by symbol/period
STRUCTURE_LOOKBACK_BARS = 300

MIN_REJECTION_WICK_FRACTION = 0.5
MAX_BARS_TO_MSS = 60
MAX_BARS_TO_RETRACEMENT = 40
MIN_REWARD_TO_RISK = 1.5

ATR_PERIOD = 14
# Stop-loss buffer beyond the swept level, in multiples of ATR. Based on
# credible technical guidance (stops placed 2-3x ATR beyond a swept level
# to survive the "spike" of a stop hunt without being caught by it) rather
# than an arbitrary fixed fraction of the setup's own price range, which
# the previous version used and which does not scale with actual recent
# volatility. See git history for the earlier fib_range*0.05 version.
STOP_BUFFER_ATR_MULTIPLE = 2.5


def _average_true_range(bars: list[dict], period: int = ATR_PERIOD) -> Optional[float]:
    if len(bars) < period + 1:
        return None

    true_ranges = []
    for i in range(len(bars) - period, len(bars)):
        high = bars[i]["high"]
        low = bars[i]["low"]
        prev_close = bars[i - 1]["close"]
        true_range = max(high - low, abs(high - prev_close), abs(low - prev_close))
        true_ranges.append(true_range)

    return sum(true_ranges) / len(true_ranges) if true_ranges else None

# Session filter (execution windows), matches the project's documented
# London/New York open strategy.
LONDON_WINDOW_UTC = (7, 10)
NY_WINDOW_UTC = (13, 16)

DATA_SOURCES_USED = (
    "ohlc_bars", "sessions", "market_structure", "liquidity_zones",
    "swing_points", "bos_choch", "fair_value_gap", "deterministic_risk",
)
DATA_SOURCES_NOT_USED_HISTORICALLY = (
    "order_flow", "footprint", "dom_bid_ask_volume", "news_calendar",
    "sentiment", "live_execution_conditions",
)


def _find_fvg_overlapping_zone(
    bars: list[dict], start_index: int, end_index: int,
    zone_low: float, zone_high: float, direction: str,
) -> Optional[tuple[float, float]]:
    for i in range(end_index, start_index + 1, -1):
        if i - 2 < 0:
            continue
        c1, c3 = bars[i - 2], bars[i]
        if direction == "BUY":
            if c1["high"] < c3["low"]:
                fvg_low, fvg_high = c1["high"], c3["low"]
                if fvg_high >= zone_low and fvg_low <= zone_high:
                    return fvg_low, fvg_high
        else:
            if c1["low"] > c3["high"]:
                fvg_low, fvg_high = c3["high"], c1["low"]
                if fvg_high >= zone_low and fvg_low <= zone_high:
                    return fvg_low, fvg_high
    return None


def _bar_overlaps_zone(bar: dict, zone_low: float, zone_high: float) -> bool:
    return bar["low"] <= zone_high and bar["high"] >= zone_low


def _try_direction(
    window: list[dict], swings: list[SwingPoint], direction: str,
    candidate_sweep_levels: list[float],
) -> Optional[dict]:

    n = len(window)
    is_buy = direction == "BUY"

    earliest_sweep_search = max(3, n - MAX_BARS_TO_MSS - MAX_BARS_TO_RETRACEMENT - 5)
    sweep_idx = None
    swept_level = None

    for i in range(n - MAX_BARS_TO_RETRACEMENT - 1, earliest_sweep_search - 1, -1):
        if i < 0:
            break
        bar = window[i]
        bar_range = max(bar["high"] - bar["low"], 1e-9)
        for level in candidate_sweep_levels:
            if is_buy:
                if bar["low"] < level <= bar["close"]:
                    wick = bar["close"] - bar["low"]
                    if wick / bar_range >= MIN_REJECTION_WICK_FRACTION:
                        sweep_idx, swept_level = i, level
                        break
            else:
                if bar["high"] > level >= bar["close"]:
                    wick = bar["high"] - bar["close"]
                    if wick / bar_range >= MIN_REJECTION_WICK_FRACTION:
                        sweep_idx, swept_level = i, level
                        break
        if sweep_idx is not None:
            break

    if sweep_idx is None:
        return None

    opposing_kind = "high" if is_buy else "low"
    prior_swings = [s for s in swings if s.index < sweep_idx and s.kind == opposing_kind]
    if not prior_swings:
        return None

    target_swing = prior_swings[-1]

    mss_idx = None
    mss_search_end = min(n - 1, sweep_idx + MAX_BARS_TO_MSS)
    for i in range(sweep_idx + 1, mss_search_end + 1):
        if is_buy and window[i]["close"] > target_swing.price:
            mss_idx = i
            break
        if not is_buy and window[i]["close"] < target_swing.price:
            mss_idx = i
            break

    if mss_idx is None:
        return None

    if is_buy:
        swing_low_price = window[sweep_idx]["low"]
        swing_high_price = max(window[i]["high"] for i in range(sweep_idx, mss_idx + 1))
        fib_range = swing_high_price - swing_low_price
        if fib_range <= 0:
            return None
        golden_low = swing_high_price - 0.618 * fib_range
        golden_high = swing_high_price - 0.5 * fib_range
    else:
        swing_high_price = window[sweep_idx]["high"]
        swing_low_price = min(window[i]["low"] for i in range(sweep_idx, mss_idx + 1))
        fib_range = swing_high_price - swing_low_price
        if fib_range <= 0:
            return None
        golden_low = swing_low_price + 0.5 * fib_range
        golden_high = swing_low_price + 0.618 * fib_range

    fvg = _find_fvg_overlapping_zone(window, sweep_idx, mss_idx, golden_low, golden_high, direction)
    if fvg is None:
        return None

    fvg_low, fvg_high = fvg
    entry = (fvg_low + fvg_high) / 2.0

    latest_idx = n - 1
    if latest_idx <= mss_idx or not _bar_overlaps_zone(window[latest_idx], fvg_low, fvg_high):
        return None

    for i in range(mss_idx + 1, latest_idx):
        if _bar_overlaps_zone(window[i], fvg_low, fvg_high):
            return None

    atr = _average_true_range(window)
    # Fall back to the old fib-range-fraction buffer only if there isn't
    # enough history for a real ATR yet (should be rare given
    # STRUCTURE_LOOKBACK_BARS is far larger than ATR_PERIOD).
    buffer = (atr * STOP_BUFFER_ATR_MULTIPLE) if atr is not None else (fib_range * 0.05)
    if is_buy:
        stop_loss = swing_low_price - buffer
        opposing_levels = [lv for lv in candidate_sweep_levels if lv > entry]
    else:
        stop_loss = swing_high_price + buffer
        opposing_levels = [lv for lv in candidate_sweep_levels if lv < entry]

    take_profit_1 = min(opposing_levels, key=lambda v: abs(v - entry)) if opposing_levels else None
    take_profit_2 = (max(opposing_levels) if is_buy else min(opposing_levels)) if opposing_levels else None

    if take_profit_2 is None:
        risk = (entry - stop_loss) if is_buy else (stop_loss - entry)
        if risk <= 0:
            return None
        take_profit_2 = entry + risk * 2.0 if is_buy else entry - risk * 2.0

    if is_buy:
        risk = entry - stop_loss
        reward = take_profit_2 - entry
        valid_structure = stop_loss < entry < take_profit_2
    else:
        risk = stop_loss - entry
        reward = entry - take_profit_2
        valid_structure = take_profit_2 < entry < stop_loss

    if not valid_structure or risk <= 0 or reward / risk < MIN_REWARD_TO_RISK:
        return None

    return {
        "direction": direction,
        "entry": entry,
        "stop_loss": stop_loss,
        "take_profit": take_profit_2,
        "take_profit_1": take_profit_1,
        "sweep_level": swept_level,
        "sweep_index": sweep_idx,
        "mss_index": mss_idx,
    }


def evaluate(
    bars: list[dict], *, require_session_window: bool = True,
    trend_filter: Optional[str] = None, zones=None,
    regime_lookup=None, require_regime: Optional[set[str]] = None,
) -> Optional[dict]:
    """
    Evaluate the most recent bar in `bars` for a liquidity-sweep + BOS/CHoCH
    + FVG setup, using ONLY historically-available OHLC-derived evidence.

    trend_filter: pass "H4" or similar semantics by supplying a pre-decided
    higher-timeframe trend label ("BULLISH"/"BEARISH"/"RANGING") to require
    agreement - callers wanting multi-timeframe confluence compute that
    label themselves (e.g. via app.quant.mtf_confluence_strategy) and pass
    it in here rather than this module reaching out to another series.

    regime_lookup: an optional app.quant.regime_lookup.RegimeLookup. When
    given, every produced signal is tagged with the regime ("trend"/
    "volatility") in effect at that bar - purely informational unless
    require_regime is also given. This is a genuine historical filter
    (computed from OHLC alone, anti-lookahead-safe), distinct from
    app.market_regime.classify_market_regime which is live-pipeline-only
    (needs 5 simultaneous timeframes this project doesn't always have
    loaded for backtests) - see app.quant.regime_lookup's module docstring.

    require_regime: an optional set of allowed trend labels (e.g.
    {"TREND_BULL", "TREND_BEAR"} to exclude RANGE). A signal produced
    while the regime is outside this set is discarded (returns None for
    that bar) rather than returned with a note - callers who only want to
    tag-and-report (Phase 11/12) rather than filter should pass
    regime_lookup without require_regime.

    zones: an optional pre-computed app.core.zones.LiquidityZones. Zone
    levels (previous day/week high/low, Asian session high/low) only
    change once a day or once a week, so recomputing them from a large
    trailing window on every single bar call (the naive approach) is
    needlessly expensive over a long intraday backtest - callers that
    call evaluate() many times in sequence (see make_signal_provider
    below) should compute zones once per calendar day and pass them in
    here. When omitted, this function computes them itself (correct but
    slower - fine for one-off/standalone calls and tests).

    Returns None (no setup) or a dict including "data_sources_used" /
    "data_sources_not_used" for downstream honesty checks.
    """

    min_bars_needed = 3 * 2 + MAX_BARS_TO_MSS + MAX_BARS_TO_RETRACEMENT
    if len(bars) < min_bars_needed:
        return None

    structure_window = bars[-STRUCTURE_LOOKBACK_BARS:]

    latest_ts = parse_ts(structure_window[-1].get("timestamp"))
    if latest_ts is None:
        return None

    if require_session_window:
        if not (in_session_window(latest_ts, LONDON_WINDOW_UTC) or in_session_window(latest_ts, NY_WINDOW_UTC)):
            return None

    swings = find_confirmed_swings(structure_window)

    if zones is None:
        zone_window = bars[-ZONE_LOOKBACK_BARS:]
        zones = compute_zones(zone_window, swings=find_confirmed_swings(zone_window))

    high_levels = zones.high_levels()
    low_levels = zones.low_levels()

    candidates = []
    if trend_filter in (None, "BULLISH"):
        candidates.append(("BUY", low_levels))
    if trend_filter in (None, "BEARISH"):
        candidates.append(("SELL", high_levels))

    for direction, levels in candidates:
        signal = _try_direction(structure_window, swings, direction, levels)
        if signal is not None:
            if regime_lookup is not None:
                regime = regime_lookup.regime_at(latest_ts)
                if require_regime is not None and regime.get("trend") not in require_regime:
                    continue
                signal["regime"] = regime

            events = find_structure_events(structure_window, swings=swings)
            recent_event = events[-1] if events else None

            signal["data_sources_used"] = list(DATA_SOURCES_USED)
            signal["data_sources_not_used"] = list(DATA_SOURCES_NOT_USED_HISTORICALLY)
            signal["structure_event"] = (
                {"kind": recent_event.kind, "direction": recent_event.direction}
                if recent_event else None
            )
            signal["zones"] = {
                "previous_day_high": zones.previous_day_high,
                "previous_day_low": zones.previous_day_low,
                "previous_week_high": zones.previous_week_high,
                "previous_week_low": zones.previous_week_low,
                "asian_session_high": zones.asian_session_high,
                "asian_session_low": zones.asian_session_low,
            }
            return signal

    return None


def make_signal_provider(
    *, trend_lookup=None, require_session_window: bool = True,
    regime_lookup=None, require_regime: Optional[set[str]] = None,
):
    """
    signal_provider(visible_bars, index) for app.backtest.engine /
    app.quant.costed_backtest. `trend_lookup`, if given, must be an object
    with a `.trend_at(datetime) -> str` method (e.g.
    app.quant.mtf_confluence_strategy.H4TrendLookup) supplying a required
    higher-timeframe trend filter.

    `regime_lookup`, if given, must be an
    app.quant.regime_lookup.RegimeLookup - see evaluate()'s docstring for
    what it does and how it differs from the live-only regime classifier.
    `require_regime` optionally hard-gates on it; passing regime_lookup
    alone just tags every signal with its regime for later reporting.

    Caches ONLY the daily/weekly zone computation (PDH/PDL/PWH/PWL) per
    calendar date - these are the expensive-to-recompute (large trailing
    window) but genuinely date-stable values (see
    app.core.zones.compute_daily_weekly_zones's docstring). Asian-session
    high/low and equal-highs/lows are recomputed fresh on every call from
    a small recent window: caching those too would be a real correctness
    bug, not just an optimization - the Asian session for "today" is
    still forming at the point London-open evaluation happens (07:00 UTC,
    before the 08:00 UTC Asian close), so freezing it for the rest of the
    day would silently use an incomplete range. This split was added
    after that exact bug was caught by comparing backtest results before
    and after introducing caching (results must never change, only
    speed) - see git history / FINAL_ACCEPTANCE_REPORT.md if present.
    """

    daily_weekly_cache: dict[object, object] = {}

    # Small trailing window for Asian-session recomputation: only needs
    # to cover "today" plus a little slack, never the full multi-week
    # ZONE_LOOKBACK_BARS window.
    asian_window_bars = 400

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        trend_filter = None
        if trend_lookup is not None:
            ts = parse_ts(visible_bars[-1].get("timestamp"))
            if ts is not None:
                trend_filter = trend_lookup.trend_at(ts)
                if trend_filter == "NEUTRAL":
                    trend_filter = "__NONE_MATCHES__"  # no direction satisfies this

        latest_ts = parse_ts(visible_bars[-1].get("timestamp"))
        zones = None
        if latest_ts is not None:
            cache_key = latest_ts.date()
            daily_weekly = daily_weekly_cache.get(cache_key)
            if daily_weekly is None:
                zone_window = visible_bars[-ZONE_LOOKBACK_BARS:]
                daily_weekly = compute_daily_weekly_zones(zone_window)
                daily_weekly_cache[cache_key] = daily_weekly

            asian_high, asian_low = compute_asian_session_zone(visible_bars[-asian_window_bars:])

            structure_window = visible_bars[-STRUCTURE_LOOKBACK_BARS:]
            recent_swings = find_confirmed_swings(structure_window)

            zones = LiquidityZones(
                previous_day_high=daily_weekly.previous_day_high,
                previous_day_low=daily_weekly.previous_day_low,
                previous_week_high=daily_weekly.previous_week_high,
                previous_week_low=daily_weekly.previous_week_low,
                asian_session_high=asian_high,
                asian_session_low=asian_low,
                equal_highs=equal_level_cluster(recent_swings, "high"),
                equal_lows=equal_level_cluster(recent_swings, "low"),
            )

        return evaluate(
            visible_bars, require_session_window=require_session_window,
            trend_filter=trend_filter, zones=zones,
            regime_lookup=regime_lookup, require_regime=require_regime,
        )

    return signal_provider
