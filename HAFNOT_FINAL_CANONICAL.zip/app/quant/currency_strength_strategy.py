"""
Currency strength - cross-sectional currency momentum.

HYPOTHESIS: currencies that have strengthened most against the others over recent months
keep outperforming, and the weakest keep underperforming (cross-sectional currency
momentum, documented in academic FX research). Buying the strongest currencies against
the US dollar and selling the weakest, with a trailing stop, pays for costs. It differs
from time-series momentum: a currency is ranked against the others, not against its own past.

Rules (daily bars; bars carry the seven USD majors' same-day closes, app.quant.bar_features):
  Strength = log return over `lookback` bars of each currency against USD (EUR, GBP, AUD,
             NZD from XXXUSD; JPY, CHF, CAD from USDXXX, sign flipped); USD's strength is
             minus the mean of the seven.
  Rank     = the eight currencies from strongest to weakest.
  Long     = this pair's non-USD currency is in the top `top_k` and stronger than USD:
             BUY XXXUSD or SELL USDXXX.
  Short    = it is in the bottom `top_k` and weaker than USD: the opposite trade.
  Stop     = trail_atr x ATR(atr_period), trailing the best price since entry;
             target_r x that risk is only a distant cap.
"""

from __future__ import annotations

import math
from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "currency-strength-momentum"

# pair -> (non-USD currency, +1 when the pair rises as that currency strengthens)
LEGS = {
    "EURUSD": ("EUR", 1), "GBPUSD": ("GBP", 1), "AUDUSD": ("AUD", 1), "NZDUSD": ("NZD", 1),
    "USDJPY": ("JPY", -1), "USDCHF": ("CHF", -1), "USDCAD": ("CAD", -1),
}

DEFAULTS = {
    "lookback": 63,
    "top_k": 2,
    "atr_period": 20,
    "trail_atr": 3.0,
    "target_r": 10.0,
}


def strengths(now: dict, then: dict) -> Optional[dict]:
    if any(not (now.get(p) or 0) > 0 or not (then.get(p) or 0) > 0 for p in LEGS):
        return None
    values = {currency: sign * math.log(now[pair] / then[pair]) for pair, (currency, sign) in LEGS.items()}
    values["USD"] = -sum(values.values()) / len(LEGS)
    return values


def evaluate(bars: list[dict], *, lookback: int, top_k: int, atr_period: int, trail_atr: float,
             target_r: float) -> Optional[dict]:
    if len(bars) < max(lookback, atr_period) + 1:
        return None
    bar = bars[-1]
    symbol = str(bar.get("symbol", "")).upper()
    if symbol not in LEGS:
        return None
    strength = strengths(bar.get("fx_closes") or {}, bars[-(lookback + 1)].get("fx_closes") or {})
    if strength is None:
        return None

    ranked = sorted(strength, key=lambda currency: strength[currency], reverse=True)
    currency, sign = LEGS[symbol]
    rank = ranked.index(currency)
    if rank < top_k and strength[currency] > strength["USD"]:
        long_currency = True
    elif rank >= len(ranked) - top_k and strength[currency] < strength["USD"]:
        long_currency = False
    else:
        return None
    direction = "BUY" if long_currency == (sign > 0) else "SELL"

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bar["close"])
    risk = trail_atr * atr
    stop, target = fixed_r_levels(direction, close, risk, target_r)
    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "trailing_stop_distance": risk,
        "currency": currency,
        "currency_rank": rank + 1,
        "data_sources_used": ["ohlc_bars", "fx_major_closes"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["lookback"] < 1 or settings["atr_period"] < 1 or not 1 <= settings["top_k"] <= 3:
        raise ValueError(f"{STRATEGY_ID}: lookback and atr_period must be >= 1 and top_k 1-3")
    if settings["trail_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: trail_atr and target_r must be positive")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
