"""
Mean reversion - statistical deviation from a rolling mean.

HYPOTHESIS: when a close sits an unusually large number of standard deviations
from its recent mean, price moves back toward that mean often enough to pay for
the trade after costs.

Rules (OHLC only, closed bars only):
  z      = (close - mean) / stdev over the last `lookback` closes, current bar
           included - it has closed at decision time.
  Entry  = BUY when z <= -entry_z, SELL when z >= +entry_z, at the close.
  Stop   = stop_atr x ATR(atr_period) beyond the entry.
  Target = the rolling mean at decision time.
  Skip   = unless reward:risk >= min_reward_to_risk. The live execution safety
           gate rejects anything below 1.5, so a backtest of trades that could
           never be taken live would measure nothing useful.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import (
    average_true_range, closes, mean, reward_to_risk, stdev, validate_params,
)

STRATEGY_ID = "mean-reversion-zscore"

DEFAULTS = {
    "lookback": 50,
    "entry_z": 2.0,
    "stop_atr": 1.5,
    "atr_period": 14,
    "min_reward_to_risk": 1.5,
}


def evaluate(
    bars: list[dict], *,
    lookback: int, entry_z: float, stop_atr: float,
    atr_period: int, min_reward_to_risk: float,
) -> Optional[dict]:

    if len(bars) < max(lookback, atr_period + 1):
        return None

    window = closes(bars[-lookback:])
    centre = mean(window)
    dispersion = stdev(window)
    if centre is None or not dispersion:
        return None

    close = window[-1]
    zscore = (close - centre) / dispersion

    if zscore <= -entry_z:
        direction = "BUY"
    elif zscore >= entry_z:
        direction = "SELL"
    else:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    stop = close - stop_atr * atr if direction == "BUY" else close + stop_atr * atr
    ratio = reward_to_risk(direction, close, stop, centre)
    if ratio is None or ratio < min_reward_to_risk:
        return None

    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": centre,
        "reward_to_risk": ratio,
        "zscore": zscore,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["lookback"] < 3 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: lookback must be >= 3 and atr_period >= 1")
    if settings["entry_z"] <= 0 or settings["stop_atr"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: entry_z and stop_atr must be positive")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
