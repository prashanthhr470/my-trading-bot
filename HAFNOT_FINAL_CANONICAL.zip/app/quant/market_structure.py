"""
Market structure from closed OHLC bars: confirmed swing highs and lows.

A swing high is a bar whose high is above the highs of the `swing_bars` bars before it
and at least as high as the `swing_bars` bars after it; a swing low mirrors that. A
swing is CONFIRMED only once all `swing_bars` bars after it have closed, so no
decision ever uses a swing that could not yet have been known.

SwingTracker keeps the most recent confirmed swings incrementally - each bar is
checked once - because the backtest engine calls a strategy on every bar of long
intraday histories. Indices are absolute positions in the bar list the engine
replays; calls with a lower index (a new replay) start over.
"""

from __future__ import annotations


class SwingTracker:
    def __init__(self, swing_bars: int, keep: int = 4):
        if int(swing_bars) < 1:
            raise ValueError("swing_bars must be at least 1")
        self.k = int(swing_bars)
        self.keep = keep
        self.reset()

    def reset(self) -> None:
        self.highs: list[tuple[int, float]] = []   # (index, price), oldest first
        self.lows: list[tuple[int, float]] = []
        self.next_candidate = 0
        self.last_closed = -1

    def update(self, bars: list, last_closed_index: int) -> None:
        """Confirm every swing whose right-hand bars have all closed by bars[last_closed_index]."""

        if last_closed_index < self.last_closed:
            self.reset()
        self.last_closed = last_closed_index
        k = self.k
        for i in range(max(self.next_candidate, k), last_closed_index - k + 1):
            high, low = float(bars[i]["high"]), float(bars[i]["low"])
            left, right = bars[i - k:i], bars[i + 1:i + k + 1]
            if all(high > float(b["high"]) for b in left) and all(high >= float(b["high"]) for b in right):
                self.highs.append((i, high))
                del self.highs[:-self.keep]
            if all(low < float(b["low"]) for b in left) and all(low <= float(b["low"]) for b in right):
                self.lows.append((i, low))
                del self.lows[:-self.keep]
        self.next_candidate = max(self.next_candidate, last_closed_index - k + 1)
