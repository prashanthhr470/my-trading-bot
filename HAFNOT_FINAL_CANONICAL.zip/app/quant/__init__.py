"""
Research/validation framework.

Prior to this package, the project's "walk-forward" and "Monte Carlo"
checks (in the now-archived FINAL_NON_OPENAPI_COMPLETION.py) ran against
fabricated synthetic data and never touched a real strategy or real
prices - they proved the mechanism could run, not that any strategy is
robust. This package replaces that with validation that operates on real
backtest trade output and real price bars.

Scope limitation carried over from app.forex_v2.risk: only symbols in
FX_USD_MAJOR_SPECS (the USD-major FX pairs plus XAUUSD) can be
cost-modeled and promoted through this pipeline, because the underlying
risk model does not implement cross-currency conversion. GBPJPY, AUDJPY,
and GBPAUD - part of the project's actual trading universe - are NOT
supported here yet (see app.forex_v2.risk.UNSUPPORTED_CROSS_PAIRS).
"""
