"""
Cross-market bar features, attached to COPIES of each symbol's bars before a portfolio
experiment runs, so a strategy for one symbol can use other markets.

A feature on a bar may only use information available when that bar closes.
`currency_strength` attaches to every bar the closes of the seven USD FX majors for the
same daily bar (the same open timestamp - they all close at the same moment) and the
bar's own symbol, so a strategy can rank currencies without seeing any later bar. The
fetched bars, and the fingerprints pinned in the preregistration, are never changed.
"""

from __future__ import annotations

from bisect import bisect_right
from datetime import timedelta

from app.core.zones import parse_ts
from app.quant.liquidity_levels import trading_day

MTD_MAX_STALENESS = timedelta(days=5)


def _month_to_date_table(daily_bars: list) -> tuple[list, list, list]:
    """(close times, closes, previous month's last close) per daily bar; a daily bar counts as closed 24 h after it opens."""

    times, closes, bases = [], [], []
    current_month, previous_month_close, last_close = None, None, None
    for bar in daily_bars:
        opened = parse_ts(bar.get("timestamp"))
        if opened is None:
            continue
        day = trading_day(opened)
        month = (day.year, day.month)
        if month != current_month:
            previous_month_close, current_month = last_close, month
        close = float(bar["close"])
        times.append(opened + timedelta(days=1))
        closes.append(close)
        bases.append(previous_month_close)
        last_close = close
    return times, closes, bases


def month_to_date_return(table: tuple, moment) -> "float | None":
    """Month-to-date return from the latest daily close completed by `moment`; None if unknown or stale."""

    times, closes, bases = table
    position = bisect_right(times, moment) - 1
    if position < 0 or not bases[position] or moment - times[position] > MTD_MAX_STALENESS:
        return None
    return closes[position] / bases[position] - 1


def month_end_equity(bars_by_symbol: dict, external=None) -> dict:
    """Each bar carries its symbol and every feature index's month-to-date return, from daily closes completed before
    the bar OPENED (app.quant.month_end_fix_strategy)."""

    if not external:
        raise ValueError("month_end_equity needs feature index bars: set PortfolioConfig.feature_symbols.")
    tables = {name: _month_to_date_table(bars) for name, bars in external.items()}
    out = {}
    for symbol, bars in bars_by_symbol.items():
        copied = []
        for bar in bars:
            opened = parse_ts(bar.get("timestamp"))
            mtd = {name: month_to_date_return(table, opened) for name, table in tables.items()} if opened else {}
            copied.append({**bar, "symbol": symbol, "equity_mtd": mtd})
        out[symbol] = copied
    return out

FX_MAJORS = ("EURUSD", "GBPUSD", "AUDUSD", "NZDUSD", "USDJPY", "USDCHF", "USDCAD")


def interest_rates(bars_by_symbol: dict, external=None) -> dict:
    """Each bar carries its symbol and the as-of rates (app.quant.external_rates.RatesAsOf) on its trading date."""

    if external is None:
        raise ValueError("interest_rates needs as-of rates: set PortfolioConfig.external_rates.")
    by_day: dict = {}
    out = {}
    for symbol, bars in bars_by_symbol.items():
        copied = []
        for bar in bars:
            opened = parse_ts(bar.get("timestamp"))
            day = trading_day(opened) if opened is not None else None
            if day not in by_day:
                by_day[day] = external.rates(day) if day is not None else {}
            copied.append({**bar, "symbol": symbol, "rates": by_day[day]})
        out[symbol] = copied
    return out


DAILY_HISTORY_WINDOW = 60
COT_HISTORY_WINDOW = 160


def cot_positioning(bars_by_symbol: dict, external=None) -> dict:
    """Each bar carries its symbol and, per currency, the last COT_HISTORY_WINDOW CFTC leveraged-funds net positions
    known on its trading date (app.quant.external_cot) - a window, never the series itself."""

    if not external:
        raise ValueError("cot_positioning needs as-of CFTC series: set PortfolioConfig.external_cot.")
    by_day: dict = {}
    out = {}
    for symbol, bars in bars_by_symbol.items():
        copied = []
        for bar in bars:
            opened = parse_ts(bar.get("timestamp"))
            day = trading_day(opened) if opened is not None else None
            if day not in by_day:
                by_day[day] = ({currency: series.history(day, COT_HISTORY_WINDOW) for currency, series in external.items()}
                               if day is not None else {})
            copied.append({**bar, "symbol": symbol, "cot": by_day[day]})
        out[symbol] = copied
    return out


def fred_daily(bars_by_symbol: dict, external=None) -> dict:
    """Each bar carries its symbol and, per outside daily series, its last DAILY_HISTORY_WINDOW known values as of the
    bar's trading date (app.quant.external_daily.DailyAsOf) - a window, never the series itself."""

    if not external:
        raise ValueError("fred_daily needs as-of daily series: set PortfolioConfig.external_daily.")
    by_day: dict = {}
    out = {}
    for symbol, bars in bars_by_symbol.items():
        copied = []
        for bar in bars:
            opened = parse_ts(bar.get("timestamp"))
            day = trading_day(opened) if opened is not None else None
            if day not in by_day:
                by_day[day] = ({name: series.history(day, DAILY_HISTORY_WINDOW) for name, series in external.items()}
                               if day is not None else {})
            copied.append({**bar, "symbol": symbol, "daily": by_day[day]})
        out[symbol] = copied
    return out


def currency_strength(bars_by_symbol: dict, external=None) -> dict:
    missing = [pair for pair in FX_MAJORS if pair not in bars_by_symbol]
    if missing:
        raise ValueError(f"currency_strength needs all seven USD FX majors; missing {missing}.")
    closes: dict[str, dict] = {}
    for pair in FX_MAJORS:
        for bar in bars_by_symbol[pair]:
            closes.setdefault(str(bar["timestamp"]), {})[pair] = float(bar["close"])
    return {
        symbol: [{**bar, "symbol": symbol, "fx_closes": closes.get(str(bar["timestamp"]), {})} for bar in bars]
        for symbol, bars in bars_by_symbol.items()
    }


REGISTRY = {"currency_strength": currency_strength, "interest_rates": interest_rates, "fred_daily": fred_daily,
            "month_end_equity": month_end_equity, "cot_positioning": cot_positioning}

DESCRIPTIONS = {
    "currency_strength": (
        "Every bar carries its symbol and the closes of the seven USD FX majors for the same daily bar (same open "
        "timestamp); a pair missing on a date is absent. Attached to copies after the preregistration check."
    ),
    "interest_rates": (
        "Every bar carries its symbol and each currency's as-of 3-month rate on the bar's New York trading date "
        "(external_data as-of rule; None when unavailable). Attached to copies after the preregistration check."
    ),
    "cot_positioning": (
        "Every bar carries its symbol and, per currency, the last 160 CFTC leveraged-funds net positions (fraction of "
        "open interest) known on the bar's New York trading date (cot_data as-of rule). Attached to copies after the "
        "preregistration check."
    ),
    "month_end_equity": (
        "Every bar carries its symbol and each feature index's month-to-date return: its latest daily close completed "
        "(24 h after the daily bar opened) before the bar opened, over the previous month's last close; None if no "
        "close in the last 5 days. Feature indices are fetched from cTrader but not traded."
    ),
    "fred_daily": (
        "Every bar carries its symbol and, for each outside daily series, its last 60 values known on the bar's New York "
        "trading date (external_daily_data as-of rule). Attached to copies after the preregistration check."
    ),
}


def enrich(name: str, bars_by_symbol: dict, external=None) -> dict:
    if name not in REGISTRY:
        raise ValueError(f"Unknown bar feature {name!r}; known: {sorted(REGISTRY)}.")
    return REGISTRY[name](bars_by_symbol, external)


def describe(name: str) -> str:
    if name not in DESCRIPTIONS:
        raise ValueError(f"Unknown bar feature {name!r}.")
    return DESCRIPTIONS[name]
