"""
Fixed, pre-declared signal filters for incremental-feature experiments.

A filter wraps a strategy's signal provider and can only REMOVE signals, so the
difference between a filtered and an unfiltered run of the same strategy,
parameters and data is attributable to the filter alone. Filters are never
tuned: their settings are part of each experiment's preregistration.

Anti-lookahead:
  - Historical bar timestamps are bar OPEN times (cTrader utcTimestampInMinutes).
    A decision is made when the bar closes, so the session is judged at
    open + timeframe. Session membership is calendar arithmetic, known in advance.
  - The volatility label at bar i uses only bars 0..i: ATR(14) at i against the
    median of the ATRs before it (trailing 200) - app.quant.regime_lookup's own
    definition, reproduced incrementally and tested label-for-label against it.
"""

from __future__ import annotations

import importlib
from bisect import bisect_left, insort
from collections import deque
from datetime import datetime, timedelta
from functools import lru_cache
from typing import Any, Callable, Optional

from app.core.sessions import get_session_state
from app.core.zones import parse_ts
from app.quant import regime_lookup

TIMEFRAME_MINUTES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}

SESSION_NAMES = frozenset({"TOKYO", "LONDON", "NEW_YORK", "OFF_HOURS"})
VOLATILITY_LABELS = frozenset({"HIGH", "NORMAL", "LOW", "UNKNOWN"})


# ---------------------------------------------------------------- session

@lru_cache(maxsize=200_000)
def sessions_at(moment: datetime) -> frozenset:
    """Sessions open at `moment`; OFF_HOURS when none is."""

    state = get_session_state(moment)
    return frozenset(state.active_sessions) or frozenset({"OFF_HOURS"})


def decision_time(bar: dict, timeframe_minutes: int) -> Optional[datetime]:
    opened = parse_ts(bar.get("timestamp"))
    return None if opened is None else opened + timedelta(minutes=timeframe_minutes)


def with_session_filter(provider: Callable, *, allowed_sessions, timeframe_minutes: int) -> Callable:
    allowed = frozenset(allowed_sessions)

    def filtered(visible_bars: list, index: int):
        moment = decision_time(visible_bars[-1], timeframe_minutes)
        if moment is None or not (sessions_at(moment) & allowed):
            return None
        return provider(visible_bars, index)

    return filtered


# ---------------------------------------------------------------- volatility regime

class VolatilityRegimeTracker:
    """
    regime_lookup.RegimeLookup's volatility labels, computed incrementally for a
    bar list that grows one bar per call - as the backtest engine supplies it -
    instead of recomputing the whole history on every bar.
    """

    def __init__(self) -> None:
        self._reset()

    def _reset(self) -> None:
        self._timestamps: list = []
        self._true_ranges: list[float] = []
        self._atr_sum = 0.0
        self._labels: list[str] = []
        self._window: deque = deque()
        self._sorted_window: list[float] = []
        self._history_count = 0

    def label_at_end(self, bars: list[dict]) -> str:
        if not bars:
            return "UNKNOWN"
        seen = len(self._timestamps)
        # A different or shorter series than the cached one starts over.
        if seen > len(bars) or (seen and (self._timestamps[0] != bars[0].get("timestamp")
                                          or self._timestamps[seen - 1] != bars[seen - 1].get("timestamp"))):
            self._reset()
            seen = 0
        for i in range(seen, len(bars)):
            self._append(bars, i)
        return self._labels[len(bars) - 1]

    def _append(self, bars: list[dict], i: int) -> None:
        period = regime_lookup.ATR_PERIOD
        bar = bars[i]
        self._timestamps.append(bar.get("timestamp"))

        if i == 0:
            true_range = 0.0
        else:
            previous_close = bars[i - 1]["close"]
            true_range = max(bar["high"] - bar["low"], abs(bar["high"] - previous_close), abs(bar["low"] - previous_close))
        self._true_ranges.append(true_range)

        atr = None
        if 1 <= i <= period:
            self._atr_sum += true_range
            if i == period:
                atr = self._atr_sum / period
        elif i > period:
            self._atr_sum += true_range - self._true_ranges[i - period]
            atr = self._atr_sum / period

        if atr is None:
            self._labels.append("UNKNOWN")
            return

        if self._history_count >= 5:
            baseline = self._median()
            if baseline <= 0:
                label = "NORMAL"
            elif atr >= baseline * regime_lookup.HIGH_VOL_MULTIPLE:
                label = "HIGH"
            elif atr <= baseline * regime_lookup.LOW_VOL_MULTIPLE:
                label = "LOW"
            else:
                label = "NORMAL"
        else:
            label = "UNKNOWN"
        self._labels.append(label)

        # The current ATR joins the baseline only after it has been judged against it.
        self._history_count += 1
        self._window.append(atr)
        insort(self._sorted_window, atr)
        if len(self._window) > regime_lookup.ATR_HISTORY_WINDOW:
            oldest = self._window.popleft()
            del self._sorted_window[bisect_left(self._sorted_window, oldest)]

    def _median(self) -> float:
        ordered = self._sorted_window
        mid = len(ordered) // 2
        return (ordered[mid - 1] + ordered[mid]) / 2.0 if len(ordered) % 2 == 0 else ordered[mid]


def with_volatility_filter(provider: Callable, *, blocked_labels) -> Callable:
    blocked = frozenset(blocked_labels)
    tracker = VolatilityRegimeTracker()

    def filtered(visible_bars: list, index: int):
        if tracker.label_at_end(visible_bars) in blocked:
            return None
        return provider(visible_bars, index)

    return filtered


# ---------------------------------------------------------------- specs

def validate_filter(spec: Optional[dict]) -> None:
    if spec is None:
        return
    kind = spec.get("type")
    if kind == "session":
        allowed = spec.get("allowed_sessions")
        if set(spec) != {"type", "allowed_sessions"} or not allowed or not set(allowed) <= SESSION_NAMES:
            raise ValueError(f"Invalid session filter {spec!r}; allowed_sessions must be a non-empty subset of {sorted(SESSION_NAMES)}.")
    elif kind == "volatility_regime":
        blocked = spec.get("blocked_labels")
        if set(spec) != {"type", "blocked_labels"} or not blocked or not set(blocked) <= VOLATILITY_LABELS:
            raise ValueError(f"Invalid volatility filter {spec!r}; blocked_labels must be a non-empty subset of {sorted(VOLATILITY_LABELS)}.")
    elif kind == "exclude_new_york_hours":
        hours = spec.get("hours")
        if (set(spec) != {"type", "hours"} or not hours
                or not all(isinstance(h, int) and 0 <= h <= 23 for h in hours)):
            raise ValueError(f"Invalid New York hour filter {spec!r}; hours must be a non-empty list of integers 0-23.")
    else:
        raise ValueError(f"Unknown signal filter type in {spec!r}.")


def describe(spec: dict) -> str:
    validate_filter(spec)
    if spec["type"] == "session":
        return ("Signals are kept only when the decision bar CLOSES (bar open timestamp + timeframe) while one of "
                f"{sorted(spec['allowed_sessions'])} is open, per app.core.sessions (IANA time zones, DST-aware).")
    if spec["type"] == "exclude_new_york_hours":
        return (f"Signals are dropped when the decision bar CLOSES (bar open timestamp + timeframe) in New York hour(s) "
                f"{sorted(spec['hours'])} (America/New_York, DST-aware) - the broker's daily rollover, when spreads "
                "widen and index, metal and energy markets pause.")
    return (f"Signals are dropped when the volatility regime at the decision bar is one of {sorted(spec['blocked_labels'])}: "
            "ATR(14) against the median of the preceding 200 ATRs, >= 1.5x HIGH, <= 0.67x LOW, per app.quant.regime_lookup; "
            "UNKNOWN until enough history exists.")


def apply_filter(provider: Callable, spec: Optional[dict], *, timeframe_minutes: int) -> Callable:
    validate_filter(spec)
    if spec is None:
        return provider
    if spec["type"] == "session":
        return with_session_filter(provider, allowed_sessions=spec["allowed_sessions"], timeframe_minutes=timeframe_minutes)
    if spec["type"] == "exclude_new_york_hours":
        return with_new_york_hour_exclusion(provider, hours=spec["hours"], timeframe_minutes=timeframe_minutes)
    return with_volatility_filter(provider, blocked_labels=spec["blocked_labels"])


def with_new_york_hour_exclusion(provider: Callable, *, hours, timeframe_minutes: int) -> Callable:
    from zoneinfo import ZoneInfo

    new_york = ZoneInfo("America/New_York")
    excluded = frozenset(int(h) for h in hours)

    def filtered(visible_bars: list, index: int):
        # The provider still sees every bar (stateful strategies track structure bar by bar); only its signal is dropped.
        signal = provider(visible_bars, index)
        moment = decision_time(visible_bars[-1], timeframe_minutes)
        if moment is None or moment.astimezone(new_york).hour in excluded:
            return None
        return signal

    return filtered


def make_filtered_signal_provider(*, base_module: str, signal_filter: dict, timeframe_minutes: int, **params: Any) -> Callable:
    """
    Registry-loadable factory: the base strategy's provider with the filter applied.
    A filtered strategy registered this way can never be rebuilt without its filter.
    """

    base = importlib.import_module(base_module).make_signal_provider(**params)
    return apply_filter(base, signal_filter, timeframe_minutes=timeframe_minutes)
