"""
Strategy Registry - Phase 2 of the research framework.

Every strategy candidate is registered here with a complete, reproducible
specification BEFORE its results are trusted or compared. This exists so
strategies can be compared objectively (same metadata shape for all of
them) rather than as loose scripts with implicit, undocumented rules.

A StrategySpec is NOT the code itself - it's a structured, versioned
RECORD of what the code does (entry/exit/stop/target rules in plain
language, timeframe, symbols, session/regime conditions, parameters, cost
assumptions, risk model) plus a pointer to the actual callable
(module path + factory function name) so the spec can be re-instantiated
and re-run later, e.g. during walk-forward or robustness testing, without
the registry needing to embed executable code.

Test results are recorded separately (record_result), append-only, per
strategy_id+version - so a strategy's full history (every backtest, every
walk-forward run, every failure) stays visible rather than being
overwritten by the latest run. This is what "do not hide losing periods"
(Phase 7) and honest scorecards (Phase 16) are built on top of.
"""

from __future__ import annotations

import importlib
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
REGISTRY_DIR = PROJECT_ROOT / "data" / "strategy_registry"
SPECS_DIR = REGISTRY_DIR / "specs"
RESULTS_DIR = REGISTRY_DIR / "results"


class StrategyFamily(str, Enum):
    TREND_MOMENTUM = "TREND_MOMENTUM"
    BREAKOUT = "BREAKOUT"
    PULLBACK_CONTINUATION = "PULLBACK_CONTINUATION"
    MEAN_REVERSION = "MEAN_REVERSION"
    RANGE = "RANGE"
    LIQUIDITY_SWEEP_CONFIRMATION = "LIQUIDITY_SWEEP_CONFIRMATION"
    SESSION_BASED = "SESSION_BASED"
    REGIME_SPECIFIC = "REGIME_SPECIFIC"
    FAILED_BREAKOUT = "FAILED_BREAKOUT"
    VOLATILITY_EXPANSION = "VOLATILITY_EXPANSION"


@dataclass
class StrategySpec:
    strategy_id: str
    version: str
    family: str  # StrategyFamily value

    entry_rules: str
    exit_rules: str
    stop_loss_logic: str
    take_profit_logic: str

    timeframe: str
    symbols: list[str]
    session_conditions: str
    regime_conditions: str

    parameters: dict[str, Any]
    transaction_cost_assumptions: str
    risk_model: str

    # Pointer to the actual callable, not the callable itself - keeps the
    # registry JSON-serializable and human-readable.
    signal_provider_module: str
    signal_provider_factory: str
    signal_provider_kwargs: dict[str, Any] = field(default_factory=dict)

    registered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    notes: str = ""

    def build_signal_provider(self) -> Callable:
        """Re-instantiate the actual signal_provider callable from the spec."""

        module = importlib.import_module(self.signal_provider_module)
        factory = getattr(module, self.signal_provider_factory)
        return factory(**self.signal_provider_kwargs)


def _spec_path(strategy_id: str, version: str) -> Path:
    return SPECS_DIR / f"{strategy_id}__{version}.json"


def _results_path(strategy_id: str, version: str) -> Path:
    return RESULTS_DIR / f"{strategy_id}__{version}.jsonl"


def register_strategy(spec: StrategySpec, *, overwrite: bool = False) -> None:
    SPECS_DIR.mkdir(parents=True, exist_ok=True)
    path = _spec_path(spec.strategy_id, spec.version)

    if path.exists() and not overwrite:
        raise ValueError(
            f"Strategy {spec.strategy_id!r} version {spec.version!r} is already "
            "registered. Pass overwrite=True to replace it, or bump the version."
        )

    path.write_text(json.dumps(asdict(spec), indent=2, default=str), encoding="utf-8")


def load_strategy(strategy_id: str, version: str) -> StrategySpec:
    path = _spec_path(strategy_id, version)
    if not path.exists():
        raise FileNotFoundError(f"No registered strategy {strategy_id!r} version {version!r}")

    data = json.loads(path.read_text(encoding="utf-8"))
    return StrategySpec(**data)


def list_strategies() -> list[StrategySpec]:
    if not SPECS_DIR.exists():
        return []

    specs = []
    for path in sorted(SPECS_DIR.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            specs.append(StrategySpec(**data))
        except Exception:
            continue

    return specs


def record_result(
    strategy_id: str,
    version: str,
    *,
    test_type: str,
    symbol: str,
    period_start: Optional[str] = None,
    period_end: Optional[str] = None,
    scorecard: dict[str, Any],
) -> None:
    """
    Append one test result record. test_type is a free-form label
    ("IN_SAMPLE", "OUT_OF_SAMPLE", "WALK_FORWARD_WINDOW_1", "ROBUSTNESS_SWEEP",
    "MONTE_CARLO", etc.) - deliberately not an enum, since Phase 7-9 tests
    produce many differently-shaped result types and forcing them into one
    fixed set of labels would lose information. Every call appends, never
    overwrites - the full history stays visible (Phase 7's "do not hide
    losing periods").
    """

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = _results_path(strategy_id, version)

    record = {
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "test_type": test_type,
        "symbol": symbol,
        "period_start": period_start,
        "period_end": period_end,
        "scorecard": scorecard,
    }

    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, default=str) + "\n")


def get_results(strategy_id: str, version: str) -> list[dict[str, Any]]:
    path = _results_path(strategy_id, version)
    if not path.exists():
        return []

    results = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                results.append(json.loads(line))
            except Exception:
                continue

    return results
