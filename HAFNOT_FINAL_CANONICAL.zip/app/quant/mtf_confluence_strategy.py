"""
Multi-timeframe confluence strategy.

Extends app.quant.liquidity_sweep_fvg_strategy with a higher-timeframe
(H4) trend filter: a lower-timeframe (M5/M15) liquidity-sweep+FVG setup is
only taken when it agrees with the prevailing H4 trend direction. This is
the real "multiple things confirming together" upgrade over a single-
timeframe rule - a BUY setup on M15 during an H4 DOWNTREND is rejected
even if the M15-only pattern looks valid, and vice versa.

H4 trend is computed with the same EMA-slope logic used elsewhere in this
project (app.forex_v2.strategy's fast/slow EMA approach), applied to the
H4 series independently.

Anti-lookahead: only H4 bars whose CLOSE time is at or before the current
lower-timeframe bar's timestamp are ever used - the strategy never sees an
H4 candle that has not actually finished forming yet at that point in
simulated time.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from app.quant.liquidity_sweep_fvg_strategy import evaluate as evaluate_sweep_fvg

H4_TREND_FAST_EMA = 8
H4_TREND_SLOW_EMA = 21


def _parse_ts(raw) -> Optional[datetime]:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
    try:
        text = str(raw).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _ema_series(values: list[float], period: int) -> list[Optional[float]]:
    if len(values) < period:
        return [None] * len(values)

    multiplier = 2.0 / (period + 1)
    result: list[Optional[float]] = [None] * (period - 1)

    seed = sum(values[:period]) / period
    result.append(seed)

    prev = seed
    for value in values[period:]:
        current = (value - prev) * multiplier + prev
        result.append(current)
        prev = current

    return result


class H4TrendLookup:
    """
    Precomputes an EMA-based trend label ("BULLISH"/"BEARISH"/"NEUTRAL")
    for every H4 bar close, then answers "what was the H4 trend at time T"
    by finding the most recent H4 bar that had already CLOSED by T.
    """

    def __init__(self, h4_bars: list[dict]):
        self._closes_ts: list[datetime] = []
        self._trend: list[str] = []

        closes = [b["close"] for b in h4_bars]
        fast = _ema_series(closes, H4_TREND_FAST_EMA)
        slow = _ema_series(closes, H4_TREND_SLOW_EMA)

        for i, bar in enumerate(h4_bars):
            ts = _parse_ts(bar.get("timestamp"))
            if ts is None:
                continue

            if fast[i] is None or slow[i] is None:
                trend = "NEUTRAL"
            elif fast[i] > slow[i]:
                trend = "BULLISH"
            elif fast[i] < slow[i]:
                trend = "BEARISH"
            else:
                trend = "NEUTRAL"

            self._closes_ts.append(ts)
            self._trend.append(trend)

    def trend_at(self, ts: datetime) -> str:
        """Most recent H4 trend confirmed strictly before `ts`."""

        # Bars are chronological, so a simple backward linear scan from
        # the end is fine for the trailing-window sizes used here; a
        # binary search would be the next optimization if this ever
        # needs to run against much longer H4 series.
        for i in range(len(self._closes_ts) - 1, -1, -1):
            if self._closes_ts[i] <= ts:
                return self._trend[i]

        return "NEUTRAL"


def make_signal_provider(h4_bars: list[dict]):
    """
    signal_provider(visible_bars, index) for the lower timeframe (M5/M15),
    gated by H4 trend agreement. h4_bars must already be the FULL H4
    series for the same symbol/period as the lower-timeframe bars being
    backtested (loaded once, outside the backtest loop).
    """

    lookup = H4TrendLookup(h4_bars)

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:

        signal = evaluate_sweep_fvg(visible_bars)
        if signal is None:
            return None

        latest_ts = _parse_ts(visible_bars[-1].get("timestamp"))
        if latest_ts is None:
            return None

        h4_trend = lookup.trend_at(latest_ts)

        if signal["direction"] == "BUY" and h4_trend != "BULLISH":
            return None
        if signal["direction"] == "SELL" and h4_trend != "BEARISH":
            return None

        signal["h4_trend"] = h4_trend
        return signal

    return signal_provider
