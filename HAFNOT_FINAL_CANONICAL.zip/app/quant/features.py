"""
Small, pure price features shared by the strategy families.

Every function looks only at the bars or values it is given. A strategy that
passes the bars visible at decision time cannot leak future data through these
helpers, and none of them keeps state between calls.
"""

from __future__ import annotations

from math import sqrt
from typing import Optional, Sequence


def closes(bars: Sequence[dict]) -> list[float]:
    return [float(bar["close"]) for bar in bars]


def mean(values: Sequence[float]) -> Optional[float]:
    return sum(values) / len(values) if values else None


def stdev(values: Sequence[float]) -> Optional[float]:
    """Sample standard deviation; None for fewer than two values."""

    count = len(values)
    if count < 2:
        return None
    centre = sum(values) / count
    return sqrt(sum((value - centre) ** 2 for value in values) / (count - 1))


def average_true_range(bars: Sequence[dict], period: int) -> Optional[float]:
    """Simple average of the last `period` true ranges; needs period + 1 bars."""

    if period < 1 or len(bars) < period + 1:
        return None

    total = 0.0
    for index in range(len(bars) - period, len(bars)):
        high = float(bars[index]["high"])
        low = float(bars[index]["low"])
        previous_close = float(bars[index - 1]["close"])
        total += max(high - low, abs(high - previous_close), abs(low - previous_close))

    return total / period


def highest_high(bars: Sequence[dict]) -> float:
    return max(float(bar["high"]) for bar in bars)


def lowest_low(bars: Sequence[dict]) -> float:
    return min(float(bar["low"]) for bar in bars)


def efficiency_ratio(values: Sequence[float]) -> Optional[float]:
    """
    Kaufman efficiency ratio: net move divided by total path length.
    Near 0 means choppy, back-and-forth price; 1 means a straight line.
    """

    if len(values) < 2:
        return None
    path = sum(abs(later - earlier) for earlier, later in zip(values, values[1:]))
    if path == 0:
        return 0.0
    return abs(values[-1] - values[0]) / path


def reward_to_risk(direction: str, entry: float, stop: float, target: float) -> Optional[float]:
    """Reward:risk for a structurally valid trade; None when the structure is invalid."""

    if direction == "BUY":
        risk, reward = entry - stop, target - entry
    elif direction == "SELL":
        risk, reward = stop - entry, entry - target
    else:
        return None

    if risk <= 0 or reward <= 0:
        return None
    return reward / risk


def fixed_r_levels(direction: str, entry: float, risk: float, target_r: float) -> tuple[float, float]:
    """(stop, target): the stop `risk` away from entry, the target `target_r` x risk beyond it."""

    if direction == "BUY":
        return entry - risk, entry + target_r * risk
    return entry + risk, entry - target_r * risk


def validate_params(params: dict, defaults: dict, strategy_id: str) -> dict:
    """Merge params over defaults, refusing unknown names (a typo must not silently use a default)."""

    unknown = set(params) - set(defaults)
    if unknown:
        raise ValueError(f"{strategy_id}: unknown parameter(s) {sorted(unknown)}")
    return {**defaults, **params}
