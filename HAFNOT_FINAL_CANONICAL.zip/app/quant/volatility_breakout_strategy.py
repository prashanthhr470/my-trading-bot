"""
Volatility compression breakout - contraction followed by expansion.

HYPOTHESIS: an unusually narrow range relative to recent volatility tends to be
followed by a directional expansion, so a close outside that narrow range
captures a move large enough to pay for the trade after costs.

Rules (OHLC only, closed bars only):
  Box         = high/low of the `box_bars` bars BEFORE the current bar. The
                current bar never helps define the box it is breaking.
  Compression = box range / ATR <= max_box_atr_ratio, with ATR measured over
                the `atr_lookback` bars that precede the box - so the box is
                graded against earlier volatility, not against itself.
  Entry       = BUY on a close above the box high, SELL on a close below the
                box low, at the close.
  Stop        = the box midpoint.
  Target      = entry +/- target_r x risk.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import (
    average_true_range, highest_high, lowest_low, reward_to_risk, validate_params,
)

STRATEGY_ID = "volatility-compression-breakout"

DEFAULTS = {
    "box_bars": 12,
    "atr_lookback": 100,
    "max_box_atr_ratio": 4.0,
    "target_r": 2.0,
}


def evaluate(
    bars: list[dict], *,
    box_bars: int, atr_lookback: int, max_box_atr_ratio: float, target_r: float,
) -> Optional[dict]:

    needed = box_bars + atr_lookback + 2
    if len(bars) < needed:
        return None

    prior = bars[-needed:-1]
    box = prior[-box_bars:]
    reference = prior[:-box_bars]

    high = highest_high(box)
    low = lowest_low(box)
    box_range = high - low
    if box_range <= 0:
        return None

    base_atr = average_true_range(reference, atr_lookback)
    if not base_atr or box_range / base_atr > max_box_atr_ratio:
        return None

    close = float(bars[-1]["close"])
    midpoint = (high + low) / 2.0

    if close > high:
        direction = "BUY"
        target = close + target_r * (close - midpoint)
    elif close < low:
        direction = "SELL"
        target = close - target_r * (midpoint - close)
    else:
        return None

    ratio = reward_to_risk(direction, close, midpoint, target)
    if ratio is None:
        return None

    return {
        "direction": direction,
        "entry": close,
        "stop_loss": midpoint,
        "take_profit": target,
        "reward_to_risk": ratio,
        "box_high": high,
        "box_low": low,
        "box_atr_ratio": box_range / base_atr,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["box_bars"] < 2 or settings["atr_lookback"] < 2:
        raise ValueError(f"{STRATEGY_ID}: box_bars and atr_lookback must be >= 2")
    if settings["max_box_atr_ratio"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: max_box_atr_ratio and target_r must be positive")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
