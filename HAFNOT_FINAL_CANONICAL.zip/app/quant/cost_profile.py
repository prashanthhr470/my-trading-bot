"""
Measured per-symbol spreads for backtests.

Every backtest so far assumed one 1.2-pip spread for every symbol, gold included,
and charged half of it. Raw broker quotes show that is too expensive for the FX
majors and too cheap for gold (report section 7i). hafnot_measure_costs.py builds a
dated profile from those quotes; this module reads it for a research series, which
pins the file's SHA-256 so costs cannot change under an experiment afterwards.

Only the spread is measured. Commission and slippage stay the RiskConfig
assumptions until real DEMO fills can measure them.
"""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import median, quantiles
from typing import Iterable, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROFILE_DIR = PROJECT_ROOT / "data" / "broker"

MIN_SAMPLES_PER_HOUR = 50
# Rollover and the Asian session have the widest spreads; a profile that has not
# seen (nearly) every weekday hour cannot be trusted to include them.
MIN_HOURS_FOR_FULL_DAY = 22

RULE = (
    "backtest_spread_pips = the highest hourly 90th-percentile spread across weekday UTC hours with at least "
    f"{MIN_SAMPLES_PER_HOUR} sampled quotes, charged as ONE full spread per round trip on bid bars "
    "(run_costed_backtest bid_bars=True). Conservative by construction: most quotes are tighter."
)


def hourly_spread_stats(quotes: Iterable[tuple[datetime, float]]) -> dict[int, dict]:
    """{UTC hour: samples, median, p90} over weekday (spread-in-pips) quotes."""

    hours: dict[int, list[float]] = defaultdict(list)
    for moment, spread in quotes:
        if moment.weekday() < 5:
            hours[moment.hour].append(spread)
    return {
        hour: {
            "samples": len(values),
            "median": round(median(values), 3),
            "p90": round(quantiles(values, n=10)[-1], 3) if len(values) >= 10 else None,
        }
        for hour, values in sorted(hours.items())
    }


def _qualifying(stats: dict) -> list[dict]:
    return [s for s in stats.values() if s["samples"] >= MIN_SAMPLES_PER_HOUR and s["p90"] is not None]


def backtest_spread_pips(stats: dict) -> Optional[float]:
    qualifying = _qualifying(stats)
    return max(s["p90"] for s in qualifying) if qualifying else None


def hours_observed(stats: dict) -> int:
    return len(_qualifying(stats))


# ---------------------------------------------------------------- broker tick data

def hourly_windows(now: datetime, weekdays: int, minutes: int,
                   hours: Optional[Iterable[int]] = None) -> list[tuple[datetime, datetime]]:
    """A `minutes`-long window at the top of each UTC hour (all, or only `hours`) of the last `weekdays` weekdays."""

    day = now.astimezone(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    days = []
    while len(days) < weekdays:
        day -= timedelta(days=1)
        if day.weekday() < 5:
            days.append(day)
    wanted = sorted(set(hours)) if hours else range(24)
    return [(d + timedelta(hours=h), d + timedelta(hours=h, minutes=minutes)) for d in sorted(days) for h in wanted]


def decode_tick_data(entries: Iterable[tuple[int, int]], divisor: float = 100000.0, *, delta_sign: int = 1) -> list[tuple[int, float]]:
    """
    cTrader ProtoOAGetTickDataRes: the first entry holds an absolute timestamp (ms) and
    price (1/divisor units); every later entry holds the change from the previous one.
    `delta_sign` selects how a change is applied, because the direction is not stated in
    the protocol file - the caller checks which reading lands inside the requested window.
    Returns (timestamp_ms, price) in response order.
    """

    decoded, timestamp, price = [], 0, 0
    for index, (t, p) in enumerate(entries):
        if index == 0:
            timestamp, price = t, p
        else:
            timestamp, price = timestamp + delta_sign * t, price + delta_sign * p
        decoded.append((timestamp, price / divisor))
    return decoded


def sample_spreads(bid_ticks: list[tuple[int, float]], ask_ticks: list[tuple[int, float]],
                   start_ms: int, end_ms: int, *, step_ms: int = 1000) -> list[tuple[int, float]]:
    """
    The spread once every `step_ms`, from the latest bid and ask at or before each moment.
    Ticks only arrive when a side changes, so an unchanged quote is still the quote. No
    sample exists until both sides have ticked inside the window, so a closed market
    (no ticks) contributes nothing.
    """

    bids, asks = sorted(bid_ticks), sorted(ask_ticks)
    samples, i, j, bid, ask = [], 0, 0, None, None
    moment = start_ms
    while moment < end_ms:
        while i < len(bids) and bids[i][0] <= moment:
            bid = bids[i][1]
            i += 1
        while j < len(asks) and asks[j][0] <= moment:
            ask = asks[j][1]
            j += 1
        if bid is not None and ask is not None and ask >= bid:
            samples.append((moment, ask - bid))
        moment += step_ms
    return samples


def latest_profile_path(directory: Path = PROFILE_DIR) -> Optional[Path]:
    profiles = sorted(directory.glob("measured_costs_*.json"))
    return profiles[-1] if profiles else None


@dataclass(frozen=True)
class CostProfile:
    path: str
    sha256: str
    spreads_pips: dict
    hours_observed: dict
    measured_from: Optional[str]
    measured_to: Optional[str]
    execution_hours: Optional[tuple] = None


def load_cost_profile(path: Path, *, symbols: Iterable[str], require_full_day: bool = True,
                      hours: Optional[Iterable[int]] = None) -> CostProfile:
    """
    `hours`: UTC hours a strategy actually executes in. The spread charged is then the worst
    90th percentile of those hours rather than of the whole day - a daily strategy that waits
    out the rollover should not be charged the rollover spread, and one that cannot wait
    should say so by not passing hours.
    """

    raw = Path(path).read_bytes()
    data = json.loads(raw)
    execution_hours = tuple(hours) if hours else None
    spreads, observed = {}, {}
    for symbol in (s.upper() for s in symbols):
        entry = (data.get("symbols") or {}).get(symbol)
        if not entry or entry.get("backtest_spread_pips") is None:
            raise ValueError(f"{symbol}: no measured spread in {path}.")
        observed_hours = int(entry.get("hours_observed") or 0)
        # With explicit execution hours only those hours are charged, so only they must be measured.
        if require_full_day and not execution_hours and observed_hours < MIN_HOURS_FOR_FULL_DAY:
            raise ValueError(
                f"{symbol}: spreads observed in only {observed_hours} of 24 weekday hours in {path}; at least "
                f"{MIN_HOURS_FOR_FULL_DAY} are required so rollover and Asian-session spreads are included."
            )
        if execution_hours:
            stats = [(entry.get("hours") or {}).get(str(h)) for h in execution_hours]
            if any(s is None or s["samples"] < MIN_SAMPLES_PER_HOUR or s["p90"] is None for s in stats):
                raise ValueError(f"{symbol}: execution hours {list(execution_hours)} are not all measured with at least "
                                 f"{MIN_SAMPLES_PER_HOUR} samples in {path}.")
            spreads[symbol] = float(max(s["p90"] for s in stats))
        else:
            spreads[symbol] = float(entry["backtest_spread_pips"])
        observed[symbol] = observed_hours
    return CostProfile(str(path), hashlib.sha256(raw).hexdigest(), spreads, observed,
                       data.get("measured_from"), data.get("measured_to"), execution_hours)
