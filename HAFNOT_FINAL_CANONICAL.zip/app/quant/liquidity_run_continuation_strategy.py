"""
Liquidity run continuation - break of yesterday's or last week's extreme, retest, continue.

HYPOTHESIS: when price closes through the previous day's or previous week's high in the
direction of the higher-timeframe bias, the stops resting there have fuelled a genuine
move. A pullback that retests the broken level and is rejected shows the level has
turned to support, and the trend continues often enough, with a stop just below the
level, to pay for costs. This is the "take liquidity, retest, continue" setup.

Rules (closed intraday OHLC bars; levels from app.quant.liquidity_levels):
  Bias    = the last completed daily close against the mean of the last `bias_days`
            completed daily closes: above = up, below = down.
  Break   = within the last `retest_bars` bars and today, a close above level H (the
            previous day's or week's high) after a close at or below it, and every close
            since has stayed above H.
  BUY     = bias up; this bar's low reaches H + zone_atr x ATR or lower, and it closes
            above H and above its open.
  SELL    = the mirror at the previous day's or week's low with bias down.
  Stop    = stop_atr x ATR(atr_period) beyond the level.
  Target  = target_r x the risk from the close.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params
from app.quant.liquidity_levels import LiquidityLevels

STRATEGY_ID = "liquidity-run-continuation"

DEFAULTS = {
    "bias_days": 20,
    "target_r": 2.0,
    "retest_bars": 16,
    "zone_atr": 0.25,
    "stop_atr": 0.5,
    "atr_period": 14,
}


def _fresh_hold(bars, n: int, level: float, beyond, lowest_index: int) -> bool:
    """A fresh break of `level` in [lowest_index, n - 2] with every close since beyond it."""

    k, first = n - 2, None
    while k >= lowest_index and beyond(float(bars[k]["close"]), level):
        first, k = k, k - 1
    if first is None or first < 1:
        return False
    return not beyond(float(bars[first - 1]["close"]), level)


def evaluate(bars, levels: LiquidityLevels, *, bias_days: int, target_r: float, retest_bars: int, zone_atr: float,
             stop_atr: float, atr_period: int) -> Optional[dict]:
    n = len(bars)
    if n < atr_period + 2:
        return None
    levels.update(bars, n - 1)
    bias = levels.bias(bias_days)
    if bias == 0 or levels.day_start_index is None:
        return None

    bar = bars[-1]
    o, h, l, c = (float(bar[key]) for key in ("open", "high", "low", "close"))
    lowest = max(n - 1 - retest_bars, levels.day_start_index)
    atr = None   # computed only for a bar that already closed beyond a level after a held break
    signal = None
    if bias > 0:
        for name, level in (("previous_day_high", levels.prev_day_high), ("previous_week_high", levels.prev_week_high)):
            if level is None or not (c > level and c > o):
                continue
            if not _fresh_hold(bars, n, level, lambda close, lvl: close > lvl, lowest):
                continue
            atr = atr or average_true_range(bars[-(atr_period + 1):], atr_period)
            if atr and l <= level + zone_atr * atr:
                signal = ("BUY", name, level, level - stop_atr * atr)
                break
    else:
        for name, level in (("previous_day_low", levels.prev_day_low), ("previous_week_low", levels.prev_week_low)):
            if level is None or not (c < level and c < o):
                continue
            if not _fresh_hold(bars, n, level, lambda close, lvl: close < lvl, lowest):
                continue
            atr = atr or average_true_range(bars[-(atr_period + 1):], atr_period)
            if atr and h >= level - zone_atr * atr:
                signal = ("SELL", name, level, level + stop_atr * atr)
                break
    if signal is None:
        return None

    direction, name, level, stop = signal
    risk = abs(c - stop)
    if risk <= 0:
        return None
    stop_loss, take_profit = fixed_r_levels(direction, c, risk, target_r)
    return {
        "direction": direction,
        "entry": c,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "reward_to_risk": target_r,
        "liquidity_level": name,
        "level_price": level,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["bias_days"] < 2 or settings["atr_period"] < 1 or settings["retest_bars"] < 1:
        raise ValueError(f"{STRATEGY_ID}: bias_days >= 2, retest_bars and atr_period >= 1 required")
    if settings["target_r"] <= 0 or settings["zone_atr"] <= 0 or settings["stop_atr"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: target_r, zone_atr and stop_atr must be positive")
    levels = LiquidityLevels(max_daily_closes=max(60, int(settings["bias_days"])))

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, levels, **settings)

    return signal_provider
