"""
Locked out-of-sample enforcement - Phase E.

app.quant.data_split.three_way_chronological_split produces a
locked_out_of_sample slice that is meant to be scored AT MOST ONCE per
strategy candidate. Saying that in a docstring is not enforcement - a
tired or rushed re-run could easily score it twice, tweak parameters
based on what it saw, and the resulting "locked OOS" number would no
longer mean anything (this is exactly the failure mode the project
owner's spec calls out: "must not be repeatedly optimized against").

This module makes that a real constraint: the first time a candidate_id
consumes its locked-OOS look, the result is persisted to disk
(data/locked_oos/<candidate_id>.json) and any later attempt to consume it
again raises LockedOutOfSampleAlreadyConsumed instead of silently
running. A genuinely new attempt requires a new candidate_id (a human
decision to start over), matching how app.quant.promotion already
requires a new candidate_id after REJECTED rather than allowing a retry
in place.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
LOCKED_OOS_DIR = PROJECT_ROOT / "data" / "locked_oos"


class LockedOutOfSampleAlreadyConsumed(RuntimeError):
    pass


@dataclass
class LockedOosConsumption:
    candidate_id: str
    slice_fingerprint: str
    consumed_at: str
    evidence: dict[str, Any]


def _fingerprint(bars: list[dict]) -> str:
    """
    A stable fingerprint of the exact locked slice used (first/last
    timestamp + bar count), so a genuinely different slice (e.g. new data
    downloaded later, extending history) is distinguishable from a replay
    of the same one - not that a replay would be allowed either way once
    consumed, but the fingerprint is recorded as part of the audit trail.
    """

    if not bars:
        raw = "empty"
    else:
        raw = f"{bars[0].get('timestamp')}|{bars[-1].get('timestamp')}|{len(bars)}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _path(candidate_id: str) -> Path:
    return LOCKED_OOS_DIR / f"{candidate_id}.json"


def has_been_consumed(candidate_id: str) -> bool:
    return _path(candidate_id).exists()


def load_consumption(candidate_id: str) -> Optional[LockedOosConsumption]:
    path = _path(candidate_id)
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    return LockedOosConsumption(**data)


def consume_locked_out_of_sample(
    candidate_id: str, locked_bars: list[dict], *, evidence: dict[str, Any],
) -> LockedOosConsumption:
    """
    Record that `candidate_id` has now looked at its locked out-of-sample
    slice, with `evidence` (e.g. a PerformanceSummary.as_dict() or
    equivalent) for the audit trail. Raises
    LockedOutOfSampleAlreadyConsumed if this candidate_id has already
    consumed it - callers must create a new candidate_id to try again,
    the same discipline app.quant.promotion already enforces for a
    REJECTED candidate.
    """

    if has_been_consumed(candidate_id):
        previous = load_consumption(candidate_id)
        raise LockedOutOfSampleAlreadyConsumed(
            f"Candidate {candidate_id!r} already consumed its locked out-of-sample "
            f"slice at {previous.consumed_at if previous else 'an earlier time'}. "
            "Re-scoring it would let this run be tuned against the result, defeating "
            "the point of a locked slice. Create a new candidate_id to try again."
        )

    record = LockedOosConsumption(
        candidate_id=candidate_id,
        slice_fingerprint=_fingerprint(locked_bars),
        consumed_at=datetime.now(timezone.utc).isoformat(),
        evidence=evidence,
    )

    LOCKED_OOS_DIR.mkdir(parents=True, exist_ok=True)
    _path(candidate_id).write_text(json.dumps(asdict(record), indent=2, default=str), encoding="utf-8")

    return record
