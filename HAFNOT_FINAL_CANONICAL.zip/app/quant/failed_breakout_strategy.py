"""
Failed breakout reversal.

HYPOTHESIS: when a bar closes outside a well-defined range and the next bar
closes back inside it, the breakout has failed; traders who bought or sold the
break are trapped, and price tends to travel back toward the middle of the range.

Rules (OHLC only, closed bars only):
  Range   = high/low of the `range_bars` bars BEFORE the breakout bar.
  Upside  = breakout bar closes above the range high, current bar closes back
            below it -> SELL at the current close.
  Downside= breakout bar closes below the range low, current bar closes back
            above it -> BUY at the current close.
  Stop    = beyond the more extreme of the breakout and current bar, plus
            stop_buffer_atr x ATR(atr_period).
  Target  = the range midpoint.
  Skip    = unless reward:risk >= min_reward_to_risk (the live safety gate's floor).
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import (
    average_true_range, highest_high, lowest_low, reward_to_risk, validate_params,
)

STRATEGY_ID = "failed-breakout-reversal"

DEFAULTS = {
    "range_bars": 24,
    "atr_period": 14,
    "stop_buffer_atr": 0.25,
    "min_reward_to_risk": 1.5,
}


def evaluate(
    bars: list[dict], *,
    range_bars: int, atr_period: int, stop_buffer_atr: float, min_reward_to_risk: float,
) -> Optional[dict]:

    if len(bars) < max(range_bars + 2, atr_period + 1):
        return None

    current = bars[-1]
    breakout = bars[-2]
    reference = bars[-(range_bars + 2):-2]

    high = highest_high(reference)
    low = lowest_low(reference)
    if high <= low:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    close = float(current["close"])
    breakout_close = float(breakout["close"])
    midpoint = (high + low) / 2.0

    if breakout_close > high and close < high:
        direction = "SELL"
        stop = max(float(breakout["high"]), float(current["high"])) + stop_buffer_atr * atr
    elif breakout_close < low and close > low:
        direction = "BUY"
        stop = min(float(breakout["low"]), float(current["low"])) - stop_buffer_atr * atr
    else:
        return None

    ratio = reward_to_risk(direction, close, stop, midpoint)
    if ratio is None or ratio < min_reward_to_risk:
        return None

    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": midpoint,
        "reward_to_risk": ratio,
        "range_high": high,
        "range_low": low,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["range_bars"] < 2 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: range_bars must be >= 2 and atr_period >= 1")
    if settings["stop_buffer_atr"] < 0:
        raise ValueError(f"{STRATEGY_ID}: stop_buffer_atr must not be negative")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
