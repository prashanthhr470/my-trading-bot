"""
Routes backtested trade candidates through the SAME app.execution_safety.
ExecutionSafetyGate class that live/paper/DEMO trading uses - not a
parallel reimplementation of its checks. This is the concrete mechanism
satisfying "the same deterministic TradePlan/DecisionGate/RiskManagement/
ExecutionSafetyGate should be used across backtesting, paper trading, and
DEMO execution wherever technically possible."

What is and isn't shared, honestly:
  - ExecutionSafetyGate: the actual class, imported and run unmodified.
  - TradePlan: the actual dataclass, populated from backtest-computed
    values (not fabricated AI/decision-gate output - see
    build_trade_plan_from_candidate's docstring for what's approximated).
  - app.ai.decision_gate.apply_decision_gate is NOT run here: it expects
    an AI decision and evidence shaped fields (market_state, news, etc.)
    that a historical OHLC-only backtest does not have. Applying it would
    mean fabricating those fields, which this project has been explicitly
    told not to do. The backtest's OWN deterministic checks (reward:risk,
    structure validity - see app.quant.core_strategy) are its equivalent
    of a decision gate, built from data that genuinely exists historically.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.execution_safety import ExecutionSafetyGate, ExecutionSafetyResult
from app.trade_plan import TradePlan


@dataclass
class _BacktestBrokerResult:
    """
    Minimal stand-in for the live pipeline's broker validation result.
    ExecutionSafetyGate.check() only reads .allowed and .spread from it.
    `allowed=True` here means "the trade plan is structurally valid" -
    it does NOT mean a real broker was contacted (there is none in a
    backtest); this is honestly a lighter-weight object than the live
    BrokerExecutionAdapter result, not a claim of live validation.
    """

    allowed: bool
    spread: float


def build_trade_plan_from_costed_trade(
    *,
    symbol: str,
    direction: str,
    entry_price: float,
    stop_loss: float,
    take_profit: float,
    lots: float,
    risk_amount_usd: float,
) -> TradePlan:
    """
    Construct a real app.trade_plan.TradePlan directly from backtest-
    computed values (app.quant.core_strategy's candidate + app.forex_v2.
    risk's costed position sizing) - bypassing app.trade_plan.
    build_trade_plan's AI/validator/decision-gate orchestration, which a
    historical backtest has no equivalent inputs for.

    position_size and position_lots are both set to `lots` (this
    backtest's cost model works in lots directly, not broker unit
    counts - see app.forex_v2.risk.FxPairSpec.contract_size for the
    lots-to-units conversion if a caller needs raw units).
    """

    if direction == "BUY":
        risk = entry_price - stop_loss
        reward = take_profit - entry_price
    else:
        risk = stop_loss - entry_price
        reward = entry_price - take_profit

    reward_risk = (reward / risk) if risk > 0 else None

    return TradePlan(
        symbol=symbol,
        status="READY",
        decision=f"{direction}_CANDIDATE",
        direction=direction,
        entry_price=entry_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        risk_percent=None,
        risk_amount=risk_amount_usd,
        position_size=lots,
        position_lots=lots,
        reward_risk=reward_risk,
        broker_valid=True,
        execution_allowed=False,
        reason=(
            "Backtest trade plan built directly from app.quant.core_strategy "
            "+ app.forex_v2.risk costed sizing (historical mode - no AI/"
            "decision-gate/live-broker validation involved)."
        ),
    )


def check_against_execution_safety_gate(
    trade_plan: TradePlan,
    *,
    assumed_spread_pips: float,
    max_spread_pips: float = 5.0,
    max_open_positions: int = 1,
    max_daily_loss_percent: float = 3.0,
    open_positions: int = 0,
    daily_loss_percent: float = 0.0,
    kill_switch: bool = False,
    duplicate_position: bool = False,
) -> ExecutionSafetyResult:
    """
    Run `trade_plan` through the REAL ExecutionSafetyGate used by
    app.paper.multi_symbol_paper / batch7_final_integration.py. A
    backtested trade that fails this (e.g. reward:risk below 1.5, invalid
    price structure) is rejected the same way a live candidate would be -
    this is the architectural-parity mechanism, not a separate check that
    happens to use similar numbers.

    The account-state arguments default to an empty account, which is what
    a backtest (enforcing its own one-position rule) has. A paper or live
    caller MUST pass its real state: until 2026-09-12 the paper path did
    not, so the gate's open-position, daily-loss, kill-switch and
    duplicate-position checks could never block a paper trade.
    """

    gate = ExecutionSafetyGate(
        max_spread=max_spread_pips,
        max_open_positions=max_open_positions,
        max_daily_loss_percent=max_daily_loss_percent,
        require_dry_run=True,
    )

    broker_result = _BacktestBrokerResult(allowed=True, spread=assumed_spread_pips)

    return gate.check(
        trade_plan,
        broker_result,
        open_positions=open_positions,
        daily_loss_percent=daily_loss_percent,
        kill_switch=kill_switch,
        duplicate_position=duplicate_position,
        dry_run=True,
    )
