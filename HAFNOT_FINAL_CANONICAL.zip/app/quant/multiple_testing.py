"""
Multiple-testing guard for the locked out-of-sample look.

Every recorded experiment is another chance for a rule with no edge to look good by
luck - at a 5% significance level, one in twenty. Testing until something passes
therefore guarantees a false winner. This guard raises the bar with the number of
experiments recorded: the locked slice's per-trade R must be significantly above zero
at alpha / N (Bonferroni), N counting every experiment in the registry including the
one being judged. It is applied in addition to the ordinary out-of-sample gate.

Test: one-sided test that mean R > 0, t = mean / (sd / sqrt(n)), with the normal
approximation to its p-value (at least MIN_TRADES trades). Trades from different
symbols can overlap in time and are treated as independent, which overstates the
evidence; the guard is a floor, not a proof. Passing still earns only a paper-forward
trial, never live trading.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import mean, stdev
from typing import Iterable, Mapping, Optional

FAMILY_ALPHA = 0.05
MIN_TRADES = 30

RULE = (
    f"Locked out-of-sample per-trade R must be significantly above zero at {FAMILY_ALPHA} / N (Bonferroni), N = every "
    "experiment in the registry including this one at the time of the look; one-sided t = mean / (sd / sqrt(n)), normal "
    f"approximation, at least {MIN_TRADES} trades. Applied in addition to the out-of-sample gate."
)


@dataclass(frozen=True)
class SignificanceResult:
    passed: bool
    trade_count: int
    mean_r: Optional[float]
    t_statistic: Optional[float]
    p_value: Optional[float]
    experiments_counted: int
    required_p_value: float
    required_mean_r: Optional[float]   # the mean R this sample's size and spread would have needed
    reasons: tuple

    def as_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__ if k != "reasons"} | {"reasons": list(self.reasons)}


def one_sided_p_value(t: float) -> float:
    return 0.5 * math.erfc(t / math.sqrt(2.0))


def critical_z(p: float) -> float:
    """The z whose one-sided upper-tail probability is p."""

    if not 0.0 < p < 1.0:
        raise ValueError("p must be between 0 and 1.")
    lo, hi = -40.0, 40.0
    for _ in range(200):
        mid = (lo + hi) / 2.0
        if one_sided_p_value(mid) > p:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


def check(trades: Iterable[Mapping], experiments_counted: int, family_alpha: float = FAMILY_ALPHA) -> SignificanceResult:
    if experiments_counted < 1:
        raise ValueError("experiments_counted must include the experiment being judged.")
    values = [float(t["result_r"]) for t in trades if t.get("result_r") is not None]
    required_p = family_alpha / experiments_counted
    n = len(values)
    if n < MIN_TRADES:
        return SignificanceResult(False, n, mean(values) if values else None, None, None, experiments_counted,
                                  required_p, None, (f"Only {n} trades; the significance test needs at least {MIN_TRADES}.",))

    average, spread = mean(values), stdev(values)
    if spread == 0.0:
        t = math.inf if average > 0 else (-math.inf if average < 0 else 0.0)
        standard_error = 0.0
    else:
        standard_error = spread / math.sqrt(n)
        t = average / standard_error
    p = one_sided_p_value(t) if math.isfinite(t) else (0.0 if t > 0 else 1.0)
    required_mean = critical_z(required_p) * standard_error
    passed = p <= required_p
    reasons = (
        f"Mean {average:+.3f}R over {n} trades: p = {p:.2g} against the required {required_p:.2g} "
        f"({family_alpha} / {experiments_counted} experiments); this sample needed a mean of at least "
        f"{required_mean:+.3f}R." + ("" if passed else " Not significant after counting every experiment run."),
    )
    return SignificanceResult(passed, n, average, t, p, experiments_counted, required_p, required_mean, reasons)
