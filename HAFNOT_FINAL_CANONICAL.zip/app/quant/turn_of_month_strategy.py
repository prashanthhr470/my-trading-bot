"""
Turn of the month - long equity indices around the month boundary.

HYPOTHESIS: US equity returns have historically concentrated in the last trading day of a
month and the first few of the next (the turn-of-the-month effect: month-end pension and
payroll inflows, window dressing, portfolio rebalancing), so holding an index long through
that window, and flat otherwise, earns enough to pay spread, slippage and overnight
financing. Documented in equity markets since the 1980s; tested here, not assumed. Long only.

Rules (closed daily OHLC bars; the session date is the New York trading day of the bar):
  Entry day = the k-th last weekday (Monday-Friday) of its calendar month, k =
              `days_before_month_end` (1 = the last weekday). Exchange holidays are not
              modelled: if the calendar day has no bar, that month has no entry.
  BUY       = at the close of the entry day.
  Stop      = stop_atr x ATR(atr_period) below the close; target_r x that risk is a distant cap.
  Exit      = at the close `hold_bars` bars after entry, unless stopped.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

from app.core.zones import parse_ts
from app.quant.features import average_true_range, fixed_r_levels, validate_params
from app.quant.liquidity_levels import trading_day

STRATEGY_ID = "turn-of-month-long"

DEFAULTS = {
    "days_before_month_end": 1,
    "hold_bars": 4,
    "stop_atr": 3.0,
    "atr_period": 20,
    "target_r": 10.0,
}


def weekdays_left_in_month(day: date) -> int:
    """Weekdays after `day` in its calendar month (0 on the month's last weekday)."""

    count, cursor = 0, day + timedelta(days=1)
    while cursor.month == day.month:
        if cursor.weekday() < 5:
            count += 1
        cursor += timedelta(days=1)
    return count


def evaluate(bars, *, days_before_month_end: int, hold_bars: int, stop_atr: float, atr_period: int,
             target_r: float) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    opened = parse_ts(bars[-1].get("timestamp"))
    if opened is None:
        return None
    session = trading_day(opened)
    if session.weekday() >= 5 or weekdays_left_in_month(session) != days_before_month_end - 1:
        return None
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bars[-1]["close"])
    stop, target = fixed_r_levels("BUY", close, stop_atr * atr, target_r)
    return {
        "direction": "BUY",
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "session_date": session.isoformat(),
        "data_sources_used": ["ohlc_bars", "calendar"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if not 1 <= settings["days_before_month_end"] <= 10 or settings["hold_bars"] < 1 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: days_before_month_end 1-10, hold_bars and atr_period >= 1 required")
    if settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: stop_atr and target_r must be positive")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
