"""
Interest rates from outside the broker, for carry research: OECD 3-month interbank rates
(monthly averages, % a year) from FRED, the Federal Reserve Bank of St. Louis database,
fetched into memory on every run - nothing is stored; a fingerprint is pinned instead.
The user approved an outside source for non-price information on 2026-09-15.

As-of rule (no look-ahead, nothing invented):
  - a month's value counts as known only from the first day of the month `lag_months` later
    (publication delay);
  - at a date, a currency's rate is the latest month known by then;
  - if that month is more than `max_age_months` before the date's month, the rate is
    unavailable (None), so a series that stops being published is not carried forward;
  - missing months are simply absent.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import urllib.request
from bisect import bisect_right
from datetime import date
from typing import Callable, Optional

FRED_CSV = "https://fred.stlouisfed.org/graph/fredgraph.csv?id={}"

THREE_MONTH_INTERBANK = {
    "USD": "IR3TIB01USM156N", "EUR": "IR3TIB01EZM156N", "GBP": "IR3TIB01GBM156N", "JPY": "IR3TIB01JPM156N",
    "CHF": "IR3TIB01CHM156N", "AUD": "IR3TIB01AUM156N", "NZD": "IR3TIB01NZM156N", "CAD": "IR3TIB01CAM156N",
}


AS_OF_RULE = (
    "A month's value is known from the first day of the month lag_months later; a date uses the latest known month; "
    "a rate whose month is more than max_age_months before the date's month is unavailable; missing months are absent."
)


def _download(url: str, timeout: int = 60) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": "HAFNOT-research"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read().decode("utf-8")


def fetch_fred_monthly(series_by_currency: dict = THREE_MONTH_INTERBANK,
                       download: Callable[[str], str] = _download) -> dict[str, list[list]]:
    """{currency: [["YYYY-MM", percent], ...]} in month order; refuses a series with no values."""

    out = {}
    for currency, series_id in series_by_currency.items():
        rows = list(csv.reader(io.StringIO(download(FRED_CSV.format(series_id)))))
        values = [[row[0][:7], float(row[1])] for row in rows[1:] if len(row) >= 2 and row[1] not in ("", ".")]
        if not values:
            raise ValueError(f"FRED series {series_id} ({currency}) returned no values.")
        out[currency] = sorted(values)
    return out


def fingerprint(rates: dict) -> str:
    return hashlib.sha256(json.dumps(rates, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _month_number(year_month: str) -> int:
    year, month = year_month.split("-")
    return int(year) * 12 + int(month) - 1


class RatesAsOf:
    def __init__(self, rates: dict, lag_months: int = 2, max_age_months: int = 3):
        if lag_months < 0 or max_age_months < lag_months:
            raise ValueError("Need 0 <= lag_months <= max_age_months.")
        self.lag, self.max_age = lag_months, max_age_months
        self._series = {c: ([_month_number(m) for m, _ in v], [float(x) for _, x in v]) for c, v in rates.items()}

    @property
    def currencies(self) -> tuple:
        return tuple(sorted(self._series))

    def rate(self, currency: str, day: date) -> Optional[float]:
        if currency not in self._series:
            return None
        months, values = self._series[currency]
        now = day.year * 12 + day.month - 1
        position = bisect_right(months, now - self.lag) - 1
        if position < 0 or now - months[position] > self.max_age:
            return None
        return values[position]

    def rates(self, day: date) -> dict:
        return {currency: self.rate(currency, day) for currency in self._series}
