"""
Range fade - trading the edges of a choppy range.

HYPOTHESIS: when recent price action is choppy rather than trending, price that
reaches the edge of its recent range tends to turn back toward the middle.
Unlike mean reversion (distance from a mean in standard deviations), this uses
the range extremes themselves and trades only when a trend filter says price is
going nowhere.

Rules (OHLC only, closed bars only):
  Range  = high/low of the `range_bars` bars BEFORE the current bar.
  Chop   = Kaufman efficiency ratio over those bars plus the current close must
           be <= max_efficiency_ratio (0 = pure back-and-forth, 1 = straight line).
  Entry  = BUY when the close is inside the range and within the bottom
           `entry_zone` fraction of it; SELL when within the top fraction.
  Stop   = beyond the range edge by stop_buffer_atr x ATR(atr_period).
  Target = the range midpoint.
  Skip   = unless reward:risk >= min_reward_to_risk (the live safety gate's floor).
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import (
    average_true_range, closes, efficiency_ratio, highest_high, lowest_low,
    reward_to_risk, validate_params,
)

STRATEGY_ID = "range-fade"

DEFAULTS = {
    "range_bars": 48,
    "entry_zone": 0.10,
    "max_efficiency_ratio": 0.30,
    "atr_period": 14,
    "stop_buffer_atr": 0.5,
    "min_reward_to_risk": 1.5,
}


def evaluate(
    bars: list[dict], *,
    range_bars: int, entry_zone: float, max_efficiency_ratio: float,
    atr_period: int, stop_buffer_atr: float, min_reward_to_risk: float,
) -> Optional[dict]:

    if len(bars) < max(range_bars + 1, atr_period + 1):
        return None

    reference = bars[-(range_bars + 1):-1]
    high = highest_high(reference)
    low = lowest_low(reference)
    width = high - low
    if width <= 0:
        return None

    chop = efficiency_ratio(closes(bars[-(range_bars + 1):]))
    if chop is None or chop > max_efficiency_ratio:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None

    close = float(bars[-1]["close"])
    midpoint = (high + low) / 2.0

    if low < close <= low + entry_zone * width:
        direction = "BUY"
        stop = low - stop_buffer_atr * atr
    elif high - entry_zone * width <= close < high:
        direction = "SELL"
        stop = high + stop_buffer_atr * atr
    else:
        return None

    ratio = reward_to_risk(direction, close, stop, midpoint)
    if ratio is None or ratio < min_reward_to_risk:
        return None

    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": midpoint,
        "reward_to_risk": ratio,
        "efficiency_ratio": chop,
        "range_high": high,
        "range_low": low,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["range_bars"] < 2 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: range_bars must be >= 2 and atr_period >= 1")
    if not 0 < settings["entry_zone"] < 0.5:
        raise ValueError(f"{STRATEGY_ID}: entry_zone must be between 0 and 0.5 so the zones cannot overlap")
    if not 0 < settings["max_efficiency_ratio"] <= 1 or settings["stop_buffer_atr"] < 0:
        raise ValueError(f"{STRATEGY_ID}: max_efficiency_ratio must be in (0, 1] and stop_buffer_atr >= 0")

    def signal_provider(visible_bars: list, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
