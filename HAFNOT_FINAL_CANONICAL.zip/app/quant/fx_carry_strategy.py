"""
FX carry - hold the higher-yielding currency against the US dollar.

HYPOTHESIS: currencies with higher short-term interest rates tend to earn the interest
differential without losing it all to exchange-rate moves (the forward-premium puzzle,
one of the best-documented return sources in currency markets). Holding the
higher-yielding side of a USD pair when the differential is large, and collecting the
modelled overnight swap, pays for spread, commission and the broker's swap markup.

Rules (daily bars carrying as-of 3-month rates, app.quant.bar_features "interest_rates";
the backtest charges and credits swaps with app.quant.swap_model):
  Differential = base rate - quote rate, as known at the decision bar's close.
  BUY          = differential >= min_diff_pct;  SELL = differential <= -min_diff_pct.
  Stop         = stop_atr x ATR(atr_period) from the close; target_r x that risk is a distant cap.
  Exit         = at the close of `hold_bars` bars after entry (about a month), unless stopped;
                 a pair still qualifying is entered again at a later close.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "fx-carry"

PAIRS = {
    "EURUSD": ("EUR", "USD"), "GBPUSD": ("GBP", "USD"), "AUDUSD": ("AUD", "USD"), "NZDUSD": ("NZD", "USD"),
    "USDJPY": ("USD", "JPY"), "USDCHF": ("USD", "CHF"), "USDCAD": ("USD", "CAD"),
}

DEFAULTS = {
    "min_diff_pct": 1.0,
    "stop_atr": 5.0,
    "atr_period": 20,
    "target_r": 10.0,
    "hold_bars": 21,
}


def evaluate(bars, *, min_diff_pct: float, stop_atr: float, atr_period: int, target_r: float,
             hold_bars: int) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    bar = bars[-1]
    pair = PAIRS.get(str(bar.get("symbol", "")).upper())
    rates = bar.get("rates") or {}
    if pair is None or rates.get(pair[0]) is None or rates.get(pair[1]) is None:
        return None

    differential = float(rates[pair[0]]) - float(rates[pair[1]])
    if differential >= min_diff_pct:
        direction = "BUY"
    elif differential <= -min_diff_pct:
        direction = "SELL"
    else:
        return None

    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bar["close"])
    stop, target = fixed_r_levels(direction, close, stop_atr * atr, target_r)
    return {
        "direction": direction,
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "rate_differential_pct": differential,
        "data_sources_used": ["ohlc_bars", "fred_3m_interbank_rates"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["atr_period"] < 1 or settings["hold_bars"] < 1:
        raise ValueError(f"{STRATEGY_ID}: atr_period and hold_bars must be >= 1")
    if settings["min_diff_pct"] < 0 or settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: min_diff_pct >= 0, stop_atr and target_r > 0 required")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
