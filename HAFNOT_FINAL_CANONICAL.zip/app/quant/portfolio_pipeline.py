"""
Pre-registered PORTFOLIO research pipeline - one parameter set, many symbols.

Why it exists: report section 7i showed that one symbol's slice holds too few
trades to tell a realistic edge (+0.05R per trade) from noise; a zero-edge strategy
passed the validation gate 37% of the time. Pooling every costable symbol under ONE
parameter set multiplies the trades behind each decision and removes per-symbol
tuning, which is itself a source of overfitting.

Stages, all required, in order - a failure stops the run:
  TRAIN         calendar-aligned first slice of every symbol. Each grid combination is
                scored on all symbols' trades pooled. Selection by neighbourhood median
                (app.quant.research_pipeline), a PLATEAU sensitivity verdict, positive
                pooled expectancy, and BREADTH: the edge may not come from a few symbols.
  VALIDATION    the next slice, pooled, against the OUT_OF_SAMPLE gate.
  WALK-FORWARD  calendar windows over train + validation: re-select on pooled in-sample
                trades, score pooled out-of-sample trades.
  LOCKED        the final slice, pooled, scored once per candidate.

Data: fetched straight from the cTrader account for a fixed [data_start, data_end)
range on every run and held in memory - no history is stored. The preregistration
pins a fingerprint of the bars, so a run on data the broker has since changed is
refused rather than silently compared with different history.
Costs: bid bars with one full measured spread per round trip, per symbol, from a
pinned cost profile (app.quant.cost_profile); commission and slippage per RiskConfig.
Pooled accounting: every trade risks the same fixed amount and trades are ordered by
exit time, so symbols with different equity paths cannot distort the drawdown.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from bisect import bisect_left
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import mean
from typing import Any, Callable, Optional

from dataclasses import replace as dataclass_replace

from app.core.data_quality import clean_bars
from app.core.zones import parse_ts
from app.forex_v2.metrics import PromotionDecision, PromotionGate, evaluate_promotion, summarize_trades
from app.forex_v2 import instrument_specs
from app.forex_v2.risk import RiskConfig, register_research_specs
from app.quant import (bar_features, cost_profile, experiment_registry, external_cot, external_daily, external_rates,
                       locked_oos_guard, multiple_testing, signal_filters, strategy_registry, swap_model)
from app.quant.costed_backtest import run_costed_backtest
from app.quant.overfitting_defense import assess_parameter_sensitivity
from app.quant.promotion import STAGE_GATES, WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION, WALK_FORWARD_MIN_WINDOWS
from app.quant.research_pipeline import (
    ExperimentOutcome, FamilyDefinition, PipelineConfig, StageResult, _register_spec, neighbourhood_select,
)
from app.quant.walk_forward import parameter_combinations

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PREREGISTRATION_DIR = PROJECT_ROOT / "data" / "research" / "preregistrations"
# The cTrader client library lives in its own Python environment; the fetch runs there
# and hands the bars back over stdout.
CTRADER_PYTHON = PROJECT_ROOT / ".ctrader_venv" / "Scripts" / "python.exe"
DOWNLOADER = PROJECT_ROOT / "hafnot_download_historical_data.py"
FETCH_TIMEOUT_SECONDS = 1800

STARTING_EQUITY_USD = 10_000.0
TRAIN, VALIDATION, WALK_FORWARD, LOCKED = "TRAIN", "VALIDATION", "WALK_FORWARD", "LOCKED_OUT_OF_SAMPLE"


@dataclass(frozen=True)
class PortfolioConfig:
    series: str
    symbols: tuple
    timeframe: str = "D1"
    data_start: str = "2011-01-01"
    data_end: str = "2026-09-12"  # exclusive; fixed so every fetch of the series sees the same history
    data_start_reason: str = (
        "Before 2011 the broker's daily history has six bars per week, from 2011 five; a lookback of N bars "
        "would span different lengths of time in the two eras."
    )
    # (symbol, first usable date, reason) where a symbol's broker history is unusable before that date.
    symbol_data_starts: tuple = ()
    # UTC hours whose measured spread is charged, and why; empty means the profile's worst hour.
    execution_hours_utc: tuple = ()
    execution_rule: str = ""
    # The measured cost profile (a file in data/broker) this series runs against; empty: the newest one.
    cost_profile_file: str = ""
    # Close trades still open at the end of a slice at its final close, instead of dropping them.
    close_open_trades_at_slice_end: bool = False
    # Longest gap between daily bars accepted without a declared later start.
    max_gap_days: int = 5
    # Instruments beyond the FX majors and gold: contract specs, and round-turn commissions for EVERY
    # symbol, from the broker's own symbol data (app.forex_v2.instrument_specs).
    broker_instrument_specs: bool = False
    # Per-symbol spread cap = max(RiskConfig cap, multiple x the charged spread). "Pips" are not comparable
    # across asset classes - crude's normal 3-cent spread is 3 pips. 0 keeps the RiskConfig cap for all.
    spread_cap_multiple: float = 0.0
    # The locked slice must also be significant after counting every experiment run (app.quant.multiple_testing),
    # so testing many ideas cannot produce a lucky winner.
    require_multiple_testing_significance: bool = False
    # A cross-market feature from app.quant.bar_features, attached to copies of the bars before the run.
    bar_features: str = ""
    # Outside, non-price data (approved by the user 2026-09-15): "fred_3m_interbank" fetches OECD 3-month rates from
    # FRED into memory, used as of each date after a publication lag (app.quant.external_rates).
    external_rates: str = ""
    rates_lag_months: int = 2
    rates_max_age_months: int = 3
    # Charge and credit overnight swaps from those rates and each pair's measured broker markup (daily FX only).
    swap_model: bool = False
    # Outside daily series by name from app.quant.external_daily.DAILY_SERIES (e.g. ("VIX",)), used as of each date.
    external_daily: tuple = ()
    daily_lag_days: int = 1
    daily_max_age_days: int = 5
    # Broker symbols fetched only as signal inputs (never traded or costed), e.g. equity indices for month-end flows.
    feature_symbols: tuple = ()
    feature_timeframe: str = "D1"
    # CFTC Traders in Financial Futures positioning (app.quant.external_cot): yearly files from cot_first_year
    # (0: the data_start year) to the data_end year, used as of each date.
    external_cot: bool = False
    cot_first_year: int = 0
    cot_lag_days: int = 6
    cot_max_age_days: int = 13
    train_fraction: float = 0.5
    validation_fraction: float = 0.25
    warmup_bars: int = 300
    min_train_trades: int = 100
    min_walk_forward_trades: int = 40
    required_sensitivity_verdict: str = "PLATEAU"
    breadth_min_symbol_trades: int = 10
    breadth_min_eligible_symbols: int = 4
    breadth_min_positive_fraction: float = 0.5
    # 4 + 1 years stepping a year gives 7 windows over train + validation of 2011-2026; 6 + 2 gave only 2.
    walk_forward_in_sample_days: int = 4 * 365
    walk_forward_out_of_sample_days: int = 365
    risk_per_trade_usd: float = 50.0

    def start_for(self, symbol: str) -> str:
        return next((start for s, start, _ in self.symbol_data_starts if s == symbol), self.data_start)

    @property
    def out_of_sample_gate(self) -> PromotionGate:
        return STAGE_GATES["OUT_OF_SAMPLE"]

    @property
    def test_type_suffix(self) -> str:
        return self.series.upper().replace("-", "_")


@dataclass
class PortfolioData:
    bars: dict
    bars_sha256: dict
    spreads_pips: dict
    cost_profile_path: Optional[str]
    cost_profile_sha256: Optional[str]
    normalization: dict = field(default_factory=dict)
    commissions_rt_usd: dict = field(default_factory=dict)
    spread_caps_pips: dict = field(default_factory=dict)
    external_rates: dict = field(default_factory=dict)
    external_rates_sha256: Optional[str] = None
    rates_as_of: Any = None
    swap_models: dict = field(default_factory=dict)
    external_daily: dict = field(default_factory=dict)
    external_daily_sha256: Optional[str] = None
    daily_as_of: dict = field(default_factory=dict)
    feature_bars: dict = field(default_factory=dict)
    feature_bars_sha256: dict = field(default_factory=dict)
    external_cot: dict = field(default_factory=dict)
    external_cot_sha256: Optional[str] = None
    cot_as_of: dict = field(default_factory=dict)

    def feature_input(self, feature: str):
        """What a bar feature needs beyond the traded bars: as-of rates, as-of daily series, feature bars, or nothing."""

        return {"interest_rates": self.rates_as_of, "fred_daily": self.daily_as_of,
                "month_end_equity": self.feature_bars, "cot_positioning": self.cot_as_of}.get(feature)

    def costs_for(self, symbol: str) -> "SymbolCosts":
        return SymbolCosts(self.spreads_pips[symbol], self.commissions_rt_usd.get(symbol), self.spread_caps_pips.get(symbol),
                           financing=self.swap_models.get(symbol))


@dataclass(frozen=True)
class SymbolCosts:
    spread_pips: float
    commission_rt_usd: Optional[float] = None   # None: the RiskConfig default
    max_spread_pips: Optional[float] = None      # None: the RiskConfig default
    slippage_pips_per_side: Optional[float] = None   # None: the RiskConfig default (diagnostics set it to zero)
    financing: Any = None                            # an app.quant.swap_model.SwapModel, or None: swaps not modelled


@dataclass(frozen=True)
class CalendarSplit:
    start: datetime
    train_end: datetime
    validation_end: datetime
    end: datetime


def experiment_id_for(definition: FamilyDefinition, config: PortfolioConfig) -> str:
    return f"{config.series}-{definition.strategy_id}-portfolio"


def candidate_id_for(definition: FamilyDefinition, config: PortfolioConfig) -> str:
    return f"{definition.strategy_id}__{definition.version}__PORTFOLIO__{config.series}"


# ---------------------------------------------------------------- data

def fetch_bars_from_ctrader(symbol: str, timeframe: str, start: str, end: str) -> list[dict]:
    """Closed bars for [start, end) straight from the cTrader DEMO account, into memory; nothing is written."""

    completed = subprocess.run(
        [str(CTRADER_PYTHON), "-u", str(DOWNLOADER), "--symbol", symbol, "--period", timeframe,
         "--start", start, "--end", end, "--stdout"],
        cwd=str(PROJECT_ROOT), capture_output=True, text=True, timeout=FETCH_TIMEOUT_SECONDS,
    )
    if completed.returncode != 0 or not completed.stdout.strip():
        raise RuntimeError(f"cTrader fetch failed for {symbol} {timeframe}: {completed.stderr.strip()[-600:]}")
    return json.loads(completed.stdout)["bars"]


def bars_fingerprint(bars: list[dict]) -> str:
    return hashlib.sha256(json.dumps(bars, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


WEEKEND_OPEN_WEEKDAYS = (4, 5)  # Friday, Saturday (UTC)
MAX_DAILY_GAP_DAYS = 5
# Timeframes whose history is refused when it has an undeclared gap longer than max_gap_days.
GAP_CHECKED_TIMEFRAMES = ("D1", "H4", "H1", "M15", "M5")
WEEKEND_BAR_RULE = (
    "Broker daily bars open Sunday to Thursday (21:00/22:00 UTC, the start of the next trading day). Bars opening "
    "on Friday or Saturday - a one-hour Sunday-open stub, or a flat after-close bar - would each count as a trading "
    "day in every lookback and ATR. One with a price range is merged into the next bar within three days (its "
    "prices were real trading at the start of that day); a flat one, or one with no following bar, is dropped."
)


def normalize_daily_bars(bars: list[dict]) -> tuple[list[dict], dict]:
    out, merged, dropped, pending = [], 0, 0, []
    for bar in bars:
        opened = parse_ts(bar["timestamp"])
        if opened.weekday() in WEEKEND_OPEN_WEEKDAYS:
            if bar["high"] == bar["low"]:
                dropped += 1
            else:
                pending.append(bar)
            continue
        stubs = [s for s in pending if opened - parse_ts(s["timestamp"]) <= timedelta(days=3)]
        dropped += len(pending) - len(stubs)
        pending = []
        if stubs:
            merged += len(stubs)
            bar = {**bar, "open": stubs[0]["open"],
                   "high": max([bar["high"]] + [s["high"] for s in stubs]),
                   "low": min([bar["low"]] + [s["low"] for s in stubs]),
                   "volume": (bar.get("volume") or 0) + sum(s.get("volume") or 0 for s in stubs)}
        out.append(bar)
    dropped += len(pending)
    return out, {"merged_weekend_bars": merged, "dropped_weekend_bars": dropped}


def daily_gaps(bars: list[dict], max_gap_days: int = MAX_DAILY_GAP_DAYS) -> list[tuple[str, str, int]]:
    times = [parse_ts(b["timestamp"]) for b in bars]
    return [(a.date().isoformat(), b.date().isoformat(), (b - a).days)
            for a, b in zip(times, times[1:]) if (b - a).days > max_gap_days]


def recorded_path(path: Path) -> str:
    """A path inside the project as recorded in preregistrations: relative to the project, however it was given."""

    try:
        return str(Path(path).resolve().relative_to(PROJECT_ROOT))
    except ValueError:
        return str(path)


def fetch_portfolio_data(config: PortfolioConfig, profile_path: Path, *,
                         fetch: Callable = fetch_bars_from_ctrader, workers: int = 4,
                         fetch_rates: Callable = external_rates.fetch_fred_monthly,
                         fetch_daily: Callable = external_daily.fetch_fred_daily,
                         fetch_cot: Callable = external_cot.fetch_cot) -> PortfolioData:
    rates, rates_sha256, as_of = {}, None, None
    if config.external_rates:
        if config.external_rates != "fred_3m_interbank":
            raise ValueError(f"Unknown external rate source {config.external_rates!r}.")
        rates = fetch_rates(external_rates.THREE_MONTH_INTERBANK)
        rates_sha256 = external_rates.fingerprint(rates)
        as_of = external_rates.RatesAsOf(rates, config.rates_lag_months, config.rates_max_age_months)
    daily, daily_sha256, daily_as_of = {}, None, {}
    if config.external_daily:
        unknown = sorted(set(config.external_daily) - set(external_daily.DAILY_SERIES))
        if unknown:
            raise ValueError(f"Unknown outside daily series {unknown}.")
        daily = fetch_daily({name: external_daily.DAILY_SERIES[name] for name in config.external_daily})
        daily_sha256 = external_daily.fingerprint(daily)
        daily_as_of = {name: external_daily.DailyAsOf(daily[name], config.daily_lag_days, config.daily_max_age_days)
                       for name in config.external_daily}
    cot, cot_sha256, cot_as_of = {}, None, {}
    if config.external_cot:
        first_year = config.cot_first_year or int(config.data_start[:4])
        cot = fetch_cot(range(first_year, int(config.data_end[:4]) + 1))
        cot_sha256 = external_cot.fingerprint(cot)
        cot_as_of = {currency: external_daily.DailyAsOf(values, config.cot_lag_days, config.cot_max_age_days)
                     for currency, values in cot.items()}
    if config.swap_model and (as_of is None or config.timeframe != "D1"):
        raise ValueError("The swap model needs external rates and daily bars.")
    commissions: dict = {}
    if config.broker_instrument_specs:
        entries = instrument_specs.load_specs()
        register_research_specs(instrument_specs.research_specs_for(config.symbols, entries))
        missing = [s for s in config.symbols if s not in entries]
        if missing:
            raise ValueError(f"No broker specification for {missing}; run hafnot_fetch_symbol_specs.py --symbols.")
        commissions = {s: instrument_specs.round_turn_commission_usd(s, entries[s]) for s in config.symbols}

    profile = cost_profile.load_cost_profile(profile_path, symbols=config.symbols,
                                             hours=config.execution_hours_utc or None)
    base_cap = RiskConfig().max_spread_pips
    caps = ({s: max(base_cap, config.spread_cap_multiple * v) for s, v in profile.spreads_pips.items()}
            if config.spread_cap_multiple else {})
    too_wide = {s: v for s, v in profile.spreads_pips.items() if v > caps.get(s, base_cap)}
    if too_wide:
        raise ValueError(f"Charged spreads {too_wide} exceed the spread cap, so every trade would be refused and "
                         "the test would measure nothing. Execute in hours with normal spreads.")

    def one(symbol: str) -> tuple[str, list[dict], dict]:
        cleaned = clean_bars(fetch(symbol, config.timeframe, config.data_start, config.data_end),
                             timeframe=config.timeframe, strict=True).bars
        counts = {}
        if config.timeframe == "D1":
            cleaned, counts = normalize_daily_bars(cleaned)
        start = config.start_for(symbol)
        bars = [b for b in cleaned if start <= str(b["timestamp"]) < config.data_end]
        gaps = daily_gaps(bars, config.max_gap_days) if config.timeframe in GAP_CHECKED_TIMEFRAMES else []
        if gaps:
            raise ValueError(f"{symbol}: broker history has gaps longer than {config.max_gap_days} days {gaps}; declare "
                             "a later start for it in PortfolioConfig.symbol_data_starts, with the reason.")
        return symbol, bars, counts

    with ThreadPoolExecutor(max_workers=workers) as pool:
        fetched = {symbol: (bars, counts) for symbol, bars, counts in pool.map(one, config.symbols)}
    bars = {symbol: fetched[symbol][0] for symbol in config.symbols}
    swaps = build_swap_models(config, bars, as_of) if config.swap_model else {}

    def feature(symbol: str) -> tuple[str, list[dict]]:
        cleaned = clean_bars(fetch(symbol, config.feature_timeframe, config.data_start, config.data_end),
                             timeframe=config.feature_timeframe, strict=True).bars
        if config.feature_timeframe == "D1":
            cleaned, _ = normalize_daily_bars(cleaned)
        return symbol, cleaned

    feature_bars = {}
    if config.feature_symbols:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            feature_bars = dict(pool.map(feature, config.feature_symbols))
        empty = [s for s, b in feature_bars.items() if not b]
        if empty:
            raise ValueError(f"Feature symbols returned no bars: {empty}.")
    return PortfolioData(bars, {s: bars_fingerprint(b) for s, b in bars.items()}, profile.spreads_pips,
                         recorded_path(profile_path), profile.sha256,
                         normalization={symbol: fetched[symbol][1] for symbol in config.symbols},
                         commissions_rt_usd=commissions, spread_caps_pips=caps,
                         external_rates=rates, external_rates_sha256=rates_sha256, rates_as_of=as_of, swap_models=swaps,
                         external_daily=daily, external_daily_sha256=daily_sha256, daily_as_of=daily_as_of,
                         feature_bars=feature_bars,
                         feature_bars_sha256={s: bars_fingerprint(b) for s, b in feature_bars.items()},
                         external_cot=cot, external_cot_sha256=cot_sha256, cot_as_of=cot_as_of)


def build_swap_models(config: PortfolioConfig, bars: dict, as_of) -> dict:
    """One SwapModel per pair from the broker's symbol data; refuses anything the model does not cover."""

    entries = instrument_specs.load_specs()
    models = {}
    for symbol in config.symbols:
        entry = entries.get(symbol)
        if not entry or not bars.get(symbol):
            raise ValueError(f"{symbol}: no broker specification or bars for the swap model.")
        if entry.get("charge_swap_at_weekends") or int(entry.get("swap_period", 0) or 24) != 24:
            raise ValueError(f"{symbol}: weekend or non-daily swap charging is not modelled.")
        kind = int(entry.get("swap_calculation_type", -1))
        triple = swap_model.triple_weekday_from_broker(entry.get("swap_rollover3_days"))
        if kind == 0:   # PIPS: FX pairs
            markup = swap_model.markup_pct(entry["swap_long"], entry["swap_short"], entry["pip_size"], bars[symbol][-1]["close"])
            models[symbol] = swap_model.SwapModel(
                symbol, str(entry["base_asset"]).upper(), str(entry["quote_asset"]).upper(), float(entry["units_per_lot"]),
                markup, as_of, triple,
            )
        elif kind == 1 and str(entry.get("quote_asset", "")).upper() == "USD":   # PERCENTAGE: USD index CFDs
            models[symbol] = swap_model.IndexFinancingModel(
                symbol, float(entry["units_per_lot"]), swap_model.percentage_markup(entry["swap_long"], entry["swap_short"]),
                as_of, triple,
            )
        else:
            raise ValueError(f"{symbol}: swap calculation type {kind} with quote {entry.get('quote_asset')} is not modelled.")
    return models


def calendar_split(bars_by_symbol: dict, config: PortfolioConfig) -> CalendarSplit:
    """Fixed calendar boundaries from the declared range; a symbol with a later start contributes where it has data."""

    if any(not bars for bars in bars_by_symbol.values()):
        raise ValueError("Every symbol needs bars.")
    start, end = parse_ts(config.data_start), parse_ts(config.data_end)
    if end <= start:
        raise ValueError("data_end must be after data_start.")
    span = end - start
    return CalendarSplit(start, start + span * config.train_fraction,
                         start + span * (config.train_fraction + config.validation_fraction), end)


def slice_with_warmup(bars: list, begin: Optional[datetime], finish: Optional[datetime], warmup: int) -> tuple[list, list]:
    """(warm-up bars immediately before `begin`, bars in [begin, finish))."""

    times = [parse_ts(b["timestamp"]) for b in bars]
    lo = bisect_left(times, begin) if begin else 0
    hi = bisect_left(times, finish) if finish else len(bars)
    return bars[max(0, lo - warmup):lo], bars[lo:hi]


# ---------------------------------------------------------------- trades

def run_symbol_trades(warmup: list, evaluation: list, symbol: str, factory: Callable, params: dict,
                      costs, config: PortfolioConfig) -> list[dict]:
    """`costs`: a SymbolCosts, or a bare spread in pips (commission and spread cap then as RiskConfig)."""

    costs = costs if isinstance(costs, SymbolCosts) else SymbolCosts(float(costs))
    defaults = RiskConfig()
    risk_config = RiskConfig(
        commission_per_lot_round_turn_usd=(defaults.commission_per_lot_round_turn_usd
                                           if costs.commission_rt_usd is None else costs.commission_rt_usd),
        max_spread_pips=defaults.max_spread_pips if costs.max_spread_pips is None else costs.max_spread_pips,
        slippage_pips_per_side=(defaults.slippage_pips_per_side if costs.slippage_pips_per_side is None
                                else costs.slippage_pips_per_side),
    )
    bars = list(warmup) + list(evaluation)
    result = run_costed_backtest(
        bars=bars, signal_provider=factory(params), symbol=symbol, starting_equity_usd=STARTING_EQUITY_USD,
        risk_config=risk_config, assumed_spread_pips=costs.spread_pips, bid_bars=True, max_open_positions=1,
        close_open_at_end=config.close_open_trades_at_slice_end,
    )
    offset = len(warmup)
    trades = []
    for t in result.trades:
        if t.entry_index < offset:
            continue
        result_r, extra = t.result_r, {}
        if costs.financing is not None:
            days = swap_model.rollover_days(bars, t.entry_index, t.exit_index, t.exit_reason)
            swap_usd = costs.financing.trade_usd(t.side, t.lots, t.entry_fill_price, days)
            swap_r = swap_usd / t.risk_amount_usd if t.risk_amount_usd else 0.0
            result_r, extra = result_r + swap_r, {"swap_r": swap_r, "rollovers": len(days)}
        trades.append({"symbol": symbol, "result_r": result_r, "pnl_usd": result_r * config.risk_per_trade_usd,
                       "entry_timestamp": bars[t.entry_index]["timestamp"], "exit_timestamp": bars[t.exit_index]["timestamp"],
                       "holding_bars": t.exit_index - t.entry_index, "exit_reason": t.exit_reason, **extra})
    return trades


def pooled_trades(slices: dict, factory: Callable, params: dict, data: PortfolioData,
                  config: PortfolioConfig, runner: Callable) -> list[dict]:
    trades = []
    for symbol, (warmup, evaluation) in slices.items():
        if evaluation:
            trades.extend(runner(warmup, evaluation, symbol, factory, params, data.costs_for(symbol), config))
    return sorted(trades, key=lambda t: t["exit_timestamp"])


def summary_fields(trades: list[dict]) -> dict[str, Any]:
    summary = summarize_trades(trades, initial_equity=STARTING_EQUITY_USD)
    holding = [t["holding_bars"] for t in trades if t.get("holding_bars") is not None]
    return {
        "trade_count": summary.trade_count,
        "win_rate": summary.win_rate,
        "net_r": round(sum(t["result_r"] for t in trades), 3),
        "profit_factor": summary.profit_factor,
        "expectancy_r": summary.expectancy_r,
        "max_drawdown_percent": round(summary.max_drawdown_percent, 3),
        "mean_holding_bars": round(mean(holding), 2) if holding else None,
    }


def per_symbol(trades: list[dict]) -> dict[str, dict]:
    out = {}
    for symbol in sorted({t["symbol"] for t in trades}):
        results = [t["result_r"] for t in trades if t["symbol"] == symbol]
        out[symbol] = {"trade_count": len(results), "expectancy_r": round(sum(results) / len(results), 4)}
    return out


def breadth(trades: list[dict], config: PortfolioConfig) -> tuple[Optional[float], int]:
    """(fraction of eligible symbols with positive expectancy, number of eligible symbols)."""

    eligible = [row for row in per_symbol(trades).values() if row["trade_count"] >= config.breadth_min_symbol_trades]
    if not eligible:
        return None, 0
    return sum(1 for row in eligible if row["expectancy_r"] > 0) / len(eligible), len(eligible)


# ---------------------------------------------------------------- walk-forward

def walk_forward_windows(split: CalendarSplit, config: PortfolioConfig) -> list[tuple[datetime, datetime, datetime]]:
    in_sample = timedelta(days=config.walk_forward_in_sample_days)
    out_of_sample = timedelta(days=config.walk_forward_out_of_sample_days)
    windows, begin = [], split.start
    while begin + in_sample + out_of_sample <= split.validation_end:
        windows.append((begin, begin + in_sample, begin + in_sample + out_of_sample))
        begin += out_of_sample
    return windows


def run_calendar_walk_forward(definition: FamilyDefinition, config: PortfolioConfig, data: PortfolioData,
                              split: CalendarSplit, factory: Callable, trade_runner: Callable) -> dict[str, Any]:
    windows = []
    for index, (begin, in_sample_end, out_of_sample_end) in enumerate(walk_forward_windows(split, config)):
        in_sample = {s: slice_with_warmup(data.bars[s], begin, in_sample_end, config.warmup_bars) for s in config.symbols}
        scored = []
        for params in parameter_combinations(definition.param_grid):
            try:
                trades = pooled_trades(in_sample, factory, params, data, config, trade_runner)
            except ValueError:
                continue
            fields = summary_fields(trades)
            scored.append((params, fields["expectancy_r"], fields["trade_count"]))
        chosen = neighbourhood_select(definition.param_grid, scored, min_trades=config.min_walk_forward_trades)
        row = {"window": index, "in_sample": [begin.isoformat(), in_sample_end.isoformat()],
               "out_of_sample": [in_sample_end.isoformat(), out_of_sample_end.isoformat()], "chosen_params": chosen,
               "out_of_sample_expectancy_r": None, "out_of_sample_trades": 0}
        if chosen is not None:
            out_slices = {s: slice_with_warmup(data.bars[s], in_sample_end, out_of_sample_end, config.warmup_bars)
                          for s in config.symbols}
            out_trades = pooled_trades(out_slices, factory, chosen, data, config, trade_runner)
            fields = summary_fields(out_trades)
            row.update(out_of_sample_expectancy_r=fields["expectancy_r"] if out_trades else None,
                       out_of_sample_trades=fields["trade_count"])
        windows.append(row)
    values = [w["out_of_sample_expectancy_r"] for w in windows if w["out_of_sample_expectancy_r"] is not None]
    return {
        "windows": windows,
        "positive_window_fraction": (sum(1 for v in values if v > 0) / len(windows)) if windows else None,
        "mean_out_of_sample_expectancy_r": mean(values) if values else None,
    }


# ---------------------------------------------------------------- preregistration

def _preregistration_body(definition: FamilyDefinition, config: PortfolioConfig, data: PortfolioData,
                          split: CalendarSplit) -> dict[str, Any]:
    gate = config.out_of_sample_gate
    body = {
        "experiment_id": experiment_id_for(definition, config),
        "series": config.series,
        "design": "PORTFOLIO - one parameter set, all symbols pooled",
        "strategy_id": definition.strategy_id,
        "strategy_version": definition.version,
        "family": definition.family,
        "hypothesis": definition.hypothesis,
        "rules": {"entry": definition.entry_rules, "exit": definition.exit_rules,
                  "stop_loss": definition.stop_loss_logic, "take_profit": definition.take_profit_logic,
                  "session": definition.session_conditions, "regime": definition.regime_conditions},
        "module": definition.module,
        "param_grid": definition.param_grid,
        "fixed_params": definition.fixed_params,
        "symbols": list(config.symbols),
        "timeframe": config.timeframe,
        "data": {
            "source": "cTrader Open API trendbars (DEMO account), fetched into memory on every run; nothing stored",
            "bars_sha256": data.bars_sha256,
            "start": config.data_start,
            "end_exclusive": config.data_end,
            "start_reason": config.data_start_reason,
            "symbol_data_starts": [{"symbol": s, "start": start, "reason": reason}
                                   for s, start, reason in config.symbol_data_starts],
            "weekend_bar_rule": WEEKEND_BAR_RULE if config.timeframe == "D1" else None,
            "weekend_bars": data.normalization,
            "maximum_gap_days": config.max_gap_days if config.timeframe in GAP_CHECKED_TIMEFRAMES else None,
            "bars": {s: {"count": len(b), "first": b[0]["timestamp"], "last": b[-1]["timestamp"]}
                     for s, b in data.bars.items() if b},
        },
        "split": {"train_fraction": config.train_fraction, "validation_fraction": config.validation_fraction,
                  "common_start": split.start.isoformat(), "train_end": split.train_end.isoformat(),
                  "validation_end": split.validation_end.isoformat(), "common_end": split.end.isoformat()},
        "costs": {"spread_model": "bid bars; one full spread per round trip (run_costed_backtest bid_bars=True)",
                  "execution_hours_utc": list(config.execution_hours_utc),
                  "execution_rule": config.execution_rule or "the worst measured hour of the day",
                  "spreads_pips": data.spreads_pips, "cost_profile": data.cost_profile_path,
                  "cost_profile_sha256": data.cost_profile_sha256,
                  "commission_and_slippage": "app.forex_v2.risk default RiskConfig"},
        "pooled_accounting": f"each trade risks a fixed ${config.risk_per_trade_usd:.0f} of ${STARTING_EQUITY_USD:.0f}; "
                             "trades ordered by exit time",
        "execution": "at most one open position per symbol; stop before target on the same bar; no trailing exit",
        "selection_rule": f"median pooled expectancy_r over each combination and its one-step grid neighbours; "
                          f"combinations with fewer than {config.min_train_trades} pooled training trades excluded",
        "gates": {
            TRAIN: {"minimum_pooled_trades_for_selection": config.min_train_trades,
                    "parameter_sensitivity_verdict": config.required_sensitivity_verdict,
                    "chosen_expectancy_r": "> 0",
                    "breadth": {"minimum_trades_per_symbol": config.breadth_min_symbol_trades,
                                "minimum_eligible_symbols": config.breadth_min_eligible_symbols,
                                "minimum_fraction_of_eligible_symbols_positive": config.breadth_min_positive_fraction}},
            VALIDATION: asdict(gate),
            WALK_FORWARD: {"in_sample_days": config.walk_forward_in_sample_days,
                           "out_of_sample_days": config.walk_forward_out_of_sample_days,
                           "minimum_pooled_in_sample_trades_for_selection": config.min_walk_forward_trades,
                           "minimum_windows": WALK_FORWARD_MIN_WINDOWS,
                           "minimum_positive_window_fraction": WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION,
                           "mean_out_of_sample_expectancy_r": "> 0"},
            LOCKED: asdict(gate),
        },
        "known_limitations": [
            "Swaps are not modelled - historical swap rates are unavailable - and trend trades hold for days; "
            "mean_holding_bars is recorded so their effect can be estimated before any promotion.",
            "Positions are limited per symbol, not by the live rule of one position across all symbols.",
            "Entries are at the daily close, inside the broker's rollover hour; the spread charged is the worst "
            "hourly p90 from the cost profile.",
            ("Trades still open at the end of a slice are closed at its final close."
             if config.close_open_trades_at_slice_end else "Trades still open at the end of a slice are not counted."),
            f"Validation, walk-forward and locked slices get {config.warmup_bars} warm-up bars from before their "
            "start; the train slice and the first walk-forward window start cold.",
        ],
    }
    # Added only when used, so earlier series' preregistrations stay byte-identical.
    if config.broker_instrument_specs:
        body["costs"]["commission_and_slippage"] = "commission per symbol from broker specs; slippage per RiskConfig"
        body["costs"]["commissions_round_turn_usd_per_lot"] = data.commissions_rt_usd
        body["costs"]["commission_rule"] = instrument_specs.COMMISSION_RULE
        body["instruments"] = ("Contract size, pip size and lot limits for instruments beyond the FX majors and gold "
                               "come from the broker's symbol data (data/broker/symbol_specs.json); only USD-quoted "
                               "instruments are admitted, so no currency conversion is modelled.")
    if config.bar_features:
        body["bar_features"] = {"name": config.bar_features, "description": bar_features.describe(config.bar_features)}
    if config.external_rates:
        body["external_data"] = {
            "source": "FRED (Federal Reserve Bank of St. Louis): OECD 3-month interbank rates, monthly averages, % a year",
            "series": external_rates.THREE_MONTH_INTERBANK,
            "fetched": "into memory on every run; nothing stored",
            "sha256": data.external_rates_sha256,
            "publication_lag_months": config.rates_lag_months,
            "max_age_months": config.rates_max_age_months,
            "as_of_rule": external_rates.AS_OF_RULE,
            "approval": "Outside, non-price data approved by the user on 2026-09-15.",
        }
    if config.external_cot:
        body["cot_data"] = {
            "source": "CFTC Commitments of Traders, Traders in Financial Futures (futures only), leveraged funds",
            "url_pattern": external_cot.CFTC_TFF_URL,
            "contract_codes": external_cot.CONTRACT_CODES,
            "measure": "(Lev_Money_Positions_Long_All - Lev_Money_Positions_Short_All) / Open_Interest_All",
            "first_year": config.cot_first_year or int(config.data_start[:4]),
            "fetched": "into memory on every run; nothing stored",
            "sha256": data.external_cot_sha256,
            "lag_days": config.cot_lag_days,
            "max_age_days": config.cot_max_age_days,
            "as_of_rule": external_cot.AS_OF_RULE,
            "approval": "Outside, non-price data approved by the user on 2026-09-15.",
        }
    if config.feature_symbols:
        body["feature_data"] = {
            "symbols": list(config.feature_symbols),
            "timeframe": config.feature_timeframe,
            "source": "cTrader Open API trendbars (DEMO account), fetched into memory; signal inputs only, never traded",
            "bars_sha256": data.feature_bars_sha256,
            "bars": {s: {"count": len(b), "first": b[0]["timestamp"], "last": b[-1]["timestamp"]}
                     for s, b in data.feature_bars.items() if b},
        }
    if config.external_daily:
        body["external_daily_data"] = {
            "source": "FRED (Federal Reserve Bank of St. Louis) daily series",
            "series": {name: external_daily.DAILY_SERIES[name] for name in config.external_daily},
            "fetched": "into memory on every run; nothing stored",
            "sha256": data.external_daily_sha256,
            "lag_days": config.daily_lag_days,
            "max_age_days": config.daily_max_age_days,
            "as_of_rule": external_daily.AS_OF_RULE,
            "approval": "Outside, non-price data approved by the user on 2026-09-15.",
        }
    if config.swap_model:
        body["costs"]["swap_model"] = {
            "rule": swap_model.RULE,
            "markup_pct_a_year": {s: round(m.markup, 6) for s, m in sorted(data.swap_models.items())},
            "triple_swap_weekday": {s: m.triple_weekday for s, m in sorted(data.swap_models.items())},
            "markup_source": "broker swap_long / swap_short in data/broker/symbol_specs.json",
        }
        if any(isinstance(m, swap_model.IndexFinancingModel) for m in data.swap_models.values()):
            body["costs"]["swap_model"]["index_rule"] = swap_model.INDEX_RULE
        body["known_limitations"][0] = ("Swaps are modelled from as-of 3-month rates and one measured broker markup per "
                                        "pair (costs.swap_model); the broker's historical swaps are not available.")
    if config.require_multiple_testing_significance:
        body["gates"][LOCKED] = {**body["gates"][LOCKED], "multiple_testing": multiple_testing.RULE}
    if config.spread_cap_multiple:
        body["costs"]["spread_caps_pips"] = data.spread_caps_pips
        body["costs"]["spread_cap_rule"] = (f"per symbol, max({RiskConfig().max_spread_pips} pips, "
                                            f"{config.spread_cap_multiple} x the charged spread)")
    return body


def preregister(definition: FamilyDefinition, config: PortfolioConfig, data: PortfolioData) -> Path:
    """Write the preregistration; keep an identical one; refuse a different one."""

    PREREGISTRATION_DIR.mkdir(parents=True, exist_ok=True)
    body = _preregistration_body(definition, config, data, calendar_split(data.bars, config))
    path = PREREGISTRATION_DIR / f"{body['experiment_id']}.json"
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        existing.pop("preregistered_at", None)
        if existing != json.loads(json.dumps(body)):
            raise ValueError(f"Preregistration {path.name} already exists with different content (data, costs or "
                             "criteria changed). Start a new series instead.")
        return path
    path.write_text(json.dumps({"preregistered_at": datetime.now(timezone.utc).isoformat(), **body}, indent=2),
                    encoding="utf-8")
    return path


# ---------------------------------------------------------------- the run

def run_portfolio_experiment(
    definition: FamilyDefinition,
    config: PortfolioConfig,
    data: PortfolioData,
    *,
    trade_runner: Callable = run_symbol_trades,
    walk_forward_runner: Callable = run_calendar_walk_forward,
) -> ExperimentOutcome:

    experiment_id = experiment_id_for(definition, config)
    candidate_id = candidate_id_for(definition, config)
    suffix = config.test_type_suffix
    symbols = list(config.symbols)

    if not (PREREGISTRATION_DIR / f"{experiment_id}.json").exists():
        raise RuntimeError(f"{experiment_id} has no preregistration; call preregister() before running.")
    if any(e.get("experiment_id") == experiment_id for e in experiment_registry.list_experiments()):
        raise RuntimeError(f"{experiment_id} has already been run; re-running would inflate the experiment count.")
    preregister(definition, config, data)  # refuses if data, costs or criteria no longer match
    if config.bar_features:
        # After the check, on copies: the preregistered fingerprints stay those of the fetched bars.
        data = dataclass_replace(data, bars=bar_features.enrich(config.bar_features, data.bars,
                                                                data.feature_input(config.bar_features)))

    split = calendar_split(data.bars, config)
    factory = definition.factory(timeframe_minutes=signal_filters.TIMEFRAME_MINUTES[config.timeframe])
    _register_spec(definition, PipelineConfig(series=config.series, timeframe=config.timeframe), symbols)
    outcome = ExperimentOutcome(experiment_id=experiment_id, strategy_id=definition.strategy_id,
                                version=definition.version, symbol="PORTFOLIO", decision="REJECTED",
                                stage_reached=TRAIN, chosen_params=None)

    def slices(begin, finish, warmup):
        return {s: slice_with_warmup(data.bars[s], begin, finish, warmup) for s in symbols}

    def record(test_type: str, scorecard: dict, begin: Optional[datetime], finish: Optional[datetime]) -> None:
        strategy_registry.record_result(
            definition.strategy_id, definition.version, test_type=f"{test_type}_{suffix}", symbol="ALL",
            period_start=begin.isoformat() if begin else None, period_end=finish.isoformat() if finish else None,
            scorecard={**scorecard, "symbols": symbols},
        )

    def done() -> ExperimentOutcome:
        experiment_registry.record_experiment(
            experiment_id=experiment_id, hypothesis=definition.hypothesis,
            strategy_id=definition.strategy_id, strategy_version=definition.version,
            symbols=symbols, timeframe=config.timeframe,
            parameters={"param_grid": definition.param_grid, "fixed_params": definition.fixed_params,
                        "chosen_params": outcome.chosen_params, "design": "PORTFOLIO"},
            result={"stage_reached": outcome.stage_reached,
                    "stages": [{"stage": s.stage, "passed": s.passed, "reasons": s.reasons} for s in outcome.stages],
                    "metrics": {s.stage: s.metrics for s in outcome.stages}},
            decision=outcome.decision, period_start=split.start.isoformat(), period_end=split.end.isoformat(),
            notes=f"Preregistered in data/research/preregistrations/{experiment_id}.json",
        )
        return outcome

    # ---- TRAIN
    train_slices = slices(None, split.train_end, 0)
    combos, scored, trades_by_combo = [], [], {}
    for params in parameter_combinations(definition.param_grid):
        try:
            trades = pooled_trades(train_slices, factory, params, data, config, trade_runner)
        except ValueError:
            continue
        fields = summary_fields(trades)
        trades_by_combo[json.dumps(params, sort_keys=True)] = trades
        combos.append({"params": params, **fields, "net_usd": round(sum(t["pnl_usd"] for t in trades), 2)})
        scored.append((params, fields["expectancy_r"], fields["trade_count"]))

    traded = [c for c in combos if c["trade_count"] > 0]
    profitable_fraction = (sum(1 for c in traded if c["net_usd"] > 0) / len(traded)) if traded else None
    sensitivity = assess_parameter_sensitivity(profitable_fraction=profitable_fraction, combos_tried=len(combos),
                                               tuned_parameter_count=len(definition.param_grid))
    chosen = neighbourhood_select(definition.param_grid, scored, min_trades=config.min_train_trades)
    chosen_row = next((c for c in combos if c["params"] == chosen), None)
    chosen_trades = trades_by_combo.get(json.dumps(chosen, sort_keys=True), []) if chosen else []
    breadth_fraction, eligible = breadth(chosen_trades, config)

    reasons = list(sensitivity.flags)
    if chosen is None:
        reasons.append(f"No parameter combination produced at least {config.min_train_trades} pooled training trades.")
    elif chosen_row["expectancy_r"] is None or chosen_row["expectancy_r"] <= 0:
        reasons.append("The neighbourhood-selected parameters do not have positive pooled training expectancy.")
    if sensitivity.verdict != config.required_sensitivity_verdict:
        reasons.append(f"Parameter sensitivity is {sensitivity.verdict}; {config.required_sensitivity_verdict} is required.")
    breadth_ok = (eligible >= config.breadth_min_eligible_symbols and breadth_fraction is not None
                  and breadth_fraction >= config.breadth_min_positive_fraction)
    if chosen is not None and not breadth_ok:
        reasons.append(f"Breadth: {eligible} symbols had at least {config.breadth_min_symbol_trades} trades and "
                       f"{breadth_fraction if breadth_fraction is None else round(breadth_fraction, 3)} of them were "
                       f"positive; at least {config.breadth_min_eligible_symbols} symbols and "
                       f"{config.breadth_min_positive_fraction} positive are required.")

    passed = (chosen is not None and chosen_row["expectancy_r"] is not None and chosen_row["expectancy_r"] > 0
              and sensitivity.verdict == config.required_sensitivity_verdict and breadth_ok)
    outcome.chosen_params = chosen
    metrics = {"combos": combos, "profitable_fraction": profitable_fraction, "sensitivity_verdict": sensitivity.verdict,
               "chosen_params": chosen, "breadth_positive_fraction": breadth_fraction, "breadth_eligible_symbols": eligible,
               "per_symbol": per_symbol(chosen_trades)}
    outcome.stages.append(StageResult(TRAIN, passed, reasons, metrics))
    scorecard = {"combos_tried": len(combos), "profitable_fraction": profitable_fraction,
                 "sensitivity_verdict": sensitivity.verdict, "chosen_params": chosen, "stage_passed": passed,
                 "breadth_positive_fraction": breadth_fraction, "per_symbol": metrics["per_symbol"]}
    if chosen_row:
        scorecard.update({k: chosen_row[k] for k in ("trade_count", "win_rate", "net_r", "profit_factor",
                                                     "expectancy_r", "max_drawdown_percent", "mean_holding_bars")})
    record("IN_SAMPLE", scorecard, split.start, split.train_end)
    if not passed:
        return done()

    # ---- VALIDATION
    outcome.stage_reached = VALIDATION
    trades = pooled_trades(slices(split.train_end, split.validation_end, config.warmup_bars),
                           factory, chosen, data, config, trade_runner)
    fields = summary_fields(trades)
    decision = evaluate_promotion(summarize_trades(trades, initial_equity=STARTING_EQUITY_USD), config.out_of_sample_gate)
    outcome.stages.append(StageResult(VALIDATION, decision.passed, list(decision.reasons),
                                      {**fields, "per_symbol": per_symbol(trades)}))
    record("OUT_OF_SAMPLE", {**fields, "per_symbol": per_symbol(trades), "stage_passed": decision.passed,
                             "gate_reasons": list(decision.reasons)}, split.train_end, split.validation_end)
    if not decision.passed:
        return done()

    # ---- WALK-FORWARD
    outcome.stage_reached = WALK_FORWARD
    walk = walk_forward_runner(definition, config, data, split, factory, trade_runner)
    windows = list(walk["windows"])
    positive_fraction = walk["positive_window_fraction"]
    mean_expectancy = walk["mean_out_of_sample_expectancy_r"]
    reasons = []
    if len(windows) < WALK_FORWARD_MIN_WINDOWS:
        reasons.append(f"Only {len(windows)} walk-forward windows; at least {WALK_FORWARD_MIN_WINDOWS} required.")
    if positive_fraction is None or positive_fraction < WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION:
        reasons.append(f"Positive-window fraction {positive_fraction} is below {WALK_FORWARD_MIN_POSITIVE_WINDOW_FRACTION}.")
    if mean_expectancy is None or mean_expectancy <= 0:
        reasons.append(f"Mean out-of-sample expectancy {mean_expectancy} is not positive.")
    passed = not reasons
    wf_metrics = {"windows": len(windows), "positive_window_fraction": positive_fraction,
                  "mean_out_of_sample_expectancy_r": mean_expectancy, "window_detail": windows}
    outcome.stages.append(StageResult(WALK_FORWARD, passed, reasons, wf_metrics))
    record("WALK_FORWARD", {**wf_metrics, "stage_passed": passed}, split.start, split.validation_end)
    if not passed:
        return done()

    # ---- LOCKED OUT-OF-SAMPLE (one look)
    outcome.stage_reached = LOCKED
    if locked_oos_guard.has_been_consumed(candidate_id):
        raise locked_oos_guard.LockedOutOfSampleAlreadyConsumed(f"{candidate_id} already used its locked out-of-sample look.")
    locked_slices = slices(split.validation_end, None, config.warmup_bars)
    trades = pooled_trades(locked_slices, factory, chosen, data, config, trade_runner)
    fields = summary_fields(trades)
    decision = evaluate_promotion(summarize_trades(trades, initial_equity=STARTING_EQUITY_USD), config.out_of_sample_gate)
    if config.require_multiple_testing_significance:
        # This experiment enters the registry only in done(), so it is counted here.
        significance = multiple_testing.check(trades, len(experiment_registry.list_experiments()) + 1)
        decision = PromotionDecision(decision.passed and significance.passed, tuple(decision.reasons) + significance.reasons)
        fields = {**fields, "multiple_testing": significance.as_dict()}
    locked_oos_guard.consume_locked_out_of_sample(
        candidate_id, [bar for _, evaluation in locked_slices.values() for bar in evaluation],
        evidence={**fields, "passed": decision.passed, "reasons": list(decision.reasons), "chosen_params": chosen},
    )
    outcome.stages.append(StageResult(LOCKED, decision.passed, list(decision.reasons),
                                      {**fields, "per_symbol": per_symbol(trades)}))
    record("LOCKED_OUT_OF_SAMPLE", {**fields, "per_symbol": per_symbol(trades), "stage_passed": decision.passed,
                                    "gate_reasons": list(decision.reasons), "validated": decision.passed},
           split.validation_end, split.end)
    if decision.passed:
        outcome.decision = "ACCEPTED"
    return done()
