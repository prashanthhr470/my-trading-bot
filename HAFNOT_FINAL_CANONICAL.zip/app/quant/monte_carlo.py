"""
Real Monte Carlo trade-sequence analysis.

Replaces the prior "Monte Carlo infrastructure" check (archived
FINAL_NON_OPENAPI_COMPLETION.py), which resampled a hardcoded 15-element
list of made-up R-values with no connection to any real strategy, and
labeled itself infrastructure_only=True. This module resamples the ACTUAL
net-PnL sequence from a real (costed) backtest run - it answers "if the
same trades this strategy actually produced had happened in a different
order, how bad could the drawdown path have gotten by chance?", which is
what trade-sequence risk analysis is for.
"""

from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass
class MonteCarloResult:
    trial_count: int
    starting_equity_usd: float
    final_equity_p05: float
    final_equity_p50: float
    final_equity_p95: float
    max_drawdown_p50_usd: float
    max_drawdown_p95_usd: float
    probability_of_ruin: float


def _max_drawdown(equity_curve: list[float]) -> float:
    peak = equity_curve[0]
    worst = 0.0
    for equity in equity_curve:
        peak = max(peak, equity)
        worst = max(worst, peak - equity)
    return worst


def resample_trade_sequence(
    net_pnl_usd_sequence: list[float],
    *,
    starting_equity_usd: float,
    trials: int = 2000,
    ruin_threshold_fraction: float = 0.5,
    seed: int = 1337,
) -> MonteCarloResult:
    """
    Bootstrap-resample (with replacement) the REAL trade PnL sequence from
    a completed backtest, `trials` times, and report the distribution of
    outcomes. A small/short backtest (few trades) will naturally produce a
    wide, not-very-informative distribution - that itself is useful
    information (it means "not enough trades yet to trust this").
    """

    if not net_pnl_usd_sequence:
        return MonteCarloResult(
            trial_count=0,
            starting_equity_usd=starting_equity_usd,
            final_equity_p05=starting_equity_usd,
            final_equity_p50=starting_equity_usd,
            final_equity_p95=starting_equity_usd,
            max_drawdown_p50_usd=0.0,
            max_drawdown_p95_usd=0.0,
            probability_of_ruin=0.0,
        )

    rng = random.Random(seed)
    trade_count = len(net_pnl_usd_sequence)

    final_equities: list[float] = []
    max_drawdowns: list[float] = []
    ruin_count = 0
    ruin_level = starting_equity_usd * (1.0 - ruin_threshold_fraction)

    for _ in range(trials):

        resampled = [rng.choice(net_pnl_usd_sequence) for _ in range(trade_count)]

        equity = starting_equity_usd
        curve = [equity]
        for pnl in resampled:
            equity += pnl
            curve.append(equity)

        final_equities.append(equity)
        max_drawdowns.append(_max_drawdown(curve))

        if min(curve) <= ruin_level:
            ruin_count += 1

    final_equities.sort()
    max_drawdowns.sort()

    def percentile(sorted_values: list[float], p: float) -> float:
        if not sorted_values:
            return 0.0
        index = min(len(sorted_values) - 1, max(0, int(round(p * (len(sorted_values) - 1)))))
        return sorted_values[index]

    return MonteCarloResult(
        trial_count=trials,
        starting_equity_usd=starting_equity_usd,
        final_equity_p05=percentile(final_equities, 0.05),
        final_equity_p50=percentile(final_equities, 0.50),
        final_equity_p95=percentile(final_equities, 0.95),
        max_drawdown_p50_usd=percentile(max_drawdowns, 0.50),
        max_drawdown_p95_usd=percentile(max_drawdowns, 0.95),
        probability_of_ruin=ruin_count / trials,
    )
