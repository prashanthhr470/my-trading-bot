"""
Liquidity levels from intraday bars: the previous trading day's and week's high and low,
where many traders rest their stops, plus completed daily closes for a higher-timeframe bias.

Trading days follow the broker's 17:00 New York rollover: a bar belongs to the trading day
in which it OPENS, a day running 17:00 to 17:00 New York time (DST-aware). Weekend stubs
(Saturday or Sunday trading dates) belong to the following Monday. Weeks are the ISO
weeks of those trading days. Only COMPLETED days and weeks are exposed as levels, so a
decision never uses anything unknown when its bar closed.

LiquidityLevels is updated incrementally, once per bar; a lower index (a new replay)
starts over.
"""

from __future__ import annotations

from collections import deque
from datetime import date, timedelta
from zoneinfo import ZoneInfo

from app.core.zones import parse_ts

NEW_YORK = ZoneInfo("America/New_York")
ROLLOVER_SHIFT = timedelta(hours=7)   # 17:00 New York + 7 h = midnight of the next trading date


def trading_day(moment) -> date:
    day = (moment.astimezone(NEW_YORK) + ROLLOVER_SHIFT).date()
    if day.weekday() == 5:
        day += timedelta(days=2)
    elif day.weekday() == 6:
        day += timedelta(days=1)
    return day


class LiquidityLevels:
    def __init__(self, max_daily_closes: int = 60):
        self.max_daily_closes = int(max_daily_closes)
        self.reset()

    def reset(self) -> None:
        self.next_index = 0
        self.day = None
        self.day_start_index = None
        self.day_high = self.day_low = self.day_close = None
        self.before_high = self.before_low = None      # today's extremes before the last processed bar
        self.week = None
        self.week_high = self.week_low = None
        self.prev_day_high = self.prev_day_low = None
        self.prev_week_high = self.prev_week_low = None
        self.daily_closes: deque = deque(maxlen=self.max_daily_closes)

    def update(self, bars, last_closed_index: int) -> None:
        if last_closed_index < self.next_index - 1:
            self.reset()
        for i in range(self.next_index, last_closed_index + 1):
            bar = bars[i]
            opened = parse_ts(bar.get("timestamp"))
            if opened is None:
                continue
            high, low, close = float(bar["high"]), float(bar["low"]), float(bar["close"])
            day = trading_day(opened)
            week = day.isocalendar()[:2]

            if day != self.day:
                if self.day is not None:
                    self.prev_day_high, self.prev_day_low = self.day_high, self.day_low
                    self.daily_closes.append(self.day_close)
                self.day, self.day_start_index = day, i
                self.before_high = self.before_low = None
                self.day_high, self.day_low = high, low
            else:
                self.before_high, self.before_low = self.day_high, self.day_low
                self.day_high, self.day_low = max(self.day_high, high), min(self.day_low, low)
            self.day_close = close

            if week != self.week:
                if self.week is not None:
                    self.prev_week_high, self.prev_week_low = self.week_high, self.week_low
                self.week, self.week_high, self.week_low = week, high, low
            else:
                self.week_high, self.week_low = max(self.week_high, high), min(self.week_low, low)
        self.next_index = max(self.next_index, last_closed_index + 1)

    def bias(self, days: int) -> int:
        """+1 if the last completed daily close is above the mean of the last `days` completed closes, -1 if below, else 0."""

        if days < 2 or len(self.daily_closes) < days:
            return 0
        closes = list(self.daily_closes)[-days:]
        average = sum(closes) / days
        return 1 if closes[-1] > average else (-1 if closes[-1] < average else 0)
