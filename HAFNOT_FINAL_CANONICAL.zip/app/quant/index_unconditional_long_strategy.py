"""
Unconditional index long - the "just buy" comparison for timing strategies.

HYPOTHESIS (a benchmark, tested like any strategy): US equity indices carry a positive
risk premium, so buying at every daily close when flat and holding for a fixed number of
days earns more than spread, slippage and overnight financing. A timing rule on the same
indices (dip buying, turn of the month) shows real timing skill only if it beats this;
if this passes too, their profits may be the market's rise rather than their timing.
Long only.

Rules (closed daily OHLC bars):
  BUY  = at every close while no position is open (one position per symbol).
  Stop = stop_atr x ATR(atr_period) below the close; target_r x that risk is a distant cap.
  Exit = at the close `hold_bars` bars after entry, unless stopped.
"""

from __future__ import annotations

from typing import Optional

from app.quant.features import average_true_range, fixed_r_levels, validate_params

STRATEGY_ID = "index-unconditional-long"

DEFAULTS = {
    "hold_bars": 5,
    "stop_atr": 3.0,
    "atr_period": 20,
    "target_r": 10.0,
}


def evaluate(bars, *, hold_bars: int, stop_atr: float, atr_period: int, target_r: float) -> Optional[dict]:
    if len(bars) < atr_period + 1:
        return None
    atr = average_true_range(bars[-(atr_period + 1):], atr_period)
    if not atr:
        return None
    close = float(bars[-1]["close"])
    stop, target = fixed_r_levels("BUY", close, stop_atr * atr, target_r)
    return {
        "direction": "BUY",
        "entry": close,
        "stop_loss": stop,
        "take_profit": target,
        "reward_to_risk": target_r,
        "exit_after_bars": hold_bars,
        "data_sources_used": ["ohlc_bars"],
    }


def make_signal_provider(**params):
    settings = validate_params(params, DEFAULTS, STRATEGY_ID)
    if settings["hold_bars"] < 1 or settings["atr_period"] < 1:
        raise ValueError(f"{STRATEGY_ID}: hold_bars and atr_period must be >= 1")
    if settings["stop_atr"] <= 0 or settings["target_r"] <= 0:
        raise ValueError(f"{STRATEGY_ID}: stop_atr and target_r must be positive")

    def signal_provider(visible_bars, index: int) -> Optional[dict]:
        return evaluate(visible_bars, **settings)

    return signal_provider
