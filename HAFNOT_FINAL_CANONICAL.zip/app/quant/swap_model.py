"""
Overnight financing (swap) for FX positions held through the broker's daily rollover, for
carry research. Earlier backtests ignored swaps; a carry test without them measures nothing.

Model (declared; the broker's historical swap rates are not available):
  annual % for a long position  = r_base - r_quote - markup
                  short position = r_quote - r_base - markup
    r       = as-of 3-month rates (app.quant.external_rates);
    markup  = the pair's broker markup, measured from its current swap_long and swap_short
              (pips a night): -(long + short) / 2, converted to % a year of the notional.
  USD per rollover = notional_usd x annual % / 100 / 360; notional_usd = units x entry price
    for XXXUSD pairs, units for USDXXX pairs. The broker's triple-swap weekday counts three.
  A night without an as-of rate for either currency is charged -markup only: it earns no
  interest and invents none.
  One measured markup is applied to all history.

Rollovers held (daily bars only): a position entered at a daily close executes after that
bar's rollover. It pays the rollover at the close of each later bar before its exit bar,
and at the exit bar's close too when it exits there (time or end-of-data exits).
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from app.core.zones import parse_ts
from app.quant.external_rates import RatesAsOf
from app.quant.liquidity_levels import trading_day

CLOSE_EXITS = frozenset({"TIME", "END_OF_DATA"})

RULE = (
    "Annual % = r_base - r_quote - markup for a long position, r_quote - r_base - markup for a short, from as-of "
    "3-month rates; markup = -(swap_long + swap_short) / 2 converted to % a year at the pair's last fetched daily "
    "close. USD per rollover = notional_usd x % / 100 / 360 (notional = units x entry price for XXXUSD, units for "
    "USDXXX); the broker's triple-swap weekday counts three. A night without an as-of rate for either currency is "
    "charged -markup only. Rollovers held: after entry, each later daily close before the exit bar, plus the exit "
    "bar's close for time and end-of-data exits. One measured markup is applied to all history."
)


def markup_pct(swap_long_pips: float, swap_short_pips: float, pip_size: float, price: float) -> float:
    return -(float(swap_long_pips) + float(swap_short_pips)) / 2 * 360 * float(pip_size) / float(price) * 100


def implied_differential_pct(swap_long_pips: float, swap_short_pips: float, pip_size: float, price: float) -> float:
    """Base minus quote rate implied by the broker's two swaps, % a year (a cross-check against the rate source)."""

    return (float(swap_long_pips) - float(swap_short_pips)) / 2 * 360 * float(pip_size) / float(price) * 100


def rollover_days(bars, entry_index: int, exit_index: int, exit_reason: str) -> list[date]:
    """Trading dates of the daily rollovers a position held (bars are daily)."""

    last = exit_index if exit_reason in CLOSE_EXITS else exit_index - 1
    days = []
    for index in range(entry_index + 1, last + 1):
        opened = parse_ts(bars[index].get("timestamp"))
        if opened is not None:
            days.append(trading_day(opened))
    return days


class SwapModel:
    def __init__(self, symbol: str, base: str, quote: str, units_per_lot: float, markup: float, rates: RatesAsOf,
                 triple_weekday: int):
        if "USD" not in (base, quote):
            raise ValueError(f"{symbol}: only USD pairs are modelled.")
        if not 0 <= int(triple_weekday) <= 6:
            raise ValueError("triple_weekday must be a date.weekday() value, 0 (Monday) to 6.")
        self.symbol, self.base, self.quote = symbol, base, quote
        self.units_per_lot, self.markup, self.rates = float(units_per_lot), float(markup), rates
        self.triple_weekday = int(triple_weekday)

    def night_pct(self, side: str, day: date) -> float:
        base_rate, quote_rate = self.rates.rate(self.base, day), self.rates.rate(self.quote, day)
        if base_rate is None or quote_rate is None:
            return -self.markup
        differential = base_rate - quote_rate
        is_long = str(side).upper() in ("BUY", "LONG")
        return (differential if is_long else -differential) - self.markup

    def trade_usd(self, side: str, lots: float, entry_price: float, days: list[date]) -> float:
        units = float(lots) * self.units_per_lot
        notional = units * float(entry_price) if self.quote == "USD" else units
        return sum(notional * self.night_pct(side, day) / 100 / 360 * (3 if day.weekday() == self.triple_weekday else 1)
                   for day in days)


INDEX_RULE = (
    "USD-quoted index CFDs (broker swap type PERCENTAGE): a long pays the as-of USD 3-month rate plus the markup, a "
    "short earns the USD rate less the markup, % a year of notional (units x entry price) / 360 per rollover; "
    "markup = -(swap_long + swap_short) / 2 from the broker's current percentages; the broker's triple weekday counts "
    "three. A night without an as-of USD rate refuses the calculation rather than guessing."
)


def percentage_markup(swap_long_pct: float, swap_short_pct: float) -> float:
    return -(float(swap_long_pct) + float(swap_short_pct)) / 2


def percentage_implied_rate(swap_long_pct: float, swap_short_pct: float) -> float:
    """The benchmark rate the broker's two percentages imply (a cross-check against the rate source)."""

    return (float(swap_short_pct) - float(swap_long_pct)) / 2


class IndexFinancingModel:
    def __init__(self, symbol: str, units_per_lot: float, markup: float, rates: RatesAsOf, triple_weekday: int):
        if not 0 <= int(triple_weekday) <= 6:
            raise ValueError("triple_weekday must be a date.weekday() value, 0 (Monday) to 6.")
        self.symbol, self.units_per_lot, self.markup, self.rates = symbol, float(units_per_lot), float(markup), rates
        self.triple_weekday = int(triple_weekday)

    def night_pct(self, side: str, day: date) -> float:
        usd = self.rates.rate("USD", day)
        if usd is None:
            raise ValueError(f"{self.symbol}: no as-of USD rate on {day}; index financing cannot be priced.")
        is_long = str(side).upper() in ("BUY", "LONG")
        return -(usd + self.markup) if is_long else usd - self.markup

    def trade_usd(self, side: str, lots: float, entry_price: float, days: list[date]) -> float:
        notional = float(lots) * self.units_per_lot * float(entry_price)
        return sum(notional * self.night_pct(side, day) / 100 / 360 * (3 if day.weekday() == self.triple_weekday else 1)
                   for day in days)


def triple_weekday_from_broker(day_of_week: Optional[int]) -> int:
    """ProtoOADayOfWeek (MONDAY = 1 ... SUNDAY = 7) to date.weekday(); refuses NONE or unknown."""

    if day_of_week is None or not 1 <= int(day_of_week) <= 7:
        raise ValueError(f"Broker triple-swap day {day_of_week!r} is not a weekday.")
    return int(day_of_week) - 1
