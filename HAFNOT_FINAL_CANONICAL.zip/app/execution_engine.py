from dataclasses import dataclass
from typing import Optional, Dict, Any


# ============================================================
# EXECUTION RESULT
# ============================================================

@dataclass
class ExecutionResult:

    allowed: bool
    executed: bool

    symbol: str
    direction: str

    volume: Optional[float]
    volume_type: str

    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]

    reason: str


# ============================================================
# EXECUTION ENGINE
# ============================================================

class ExecutionEngine:

    def __init__(
        self,
        dry_run: bool = True,
    ):

        self.dry_run = dry_run

    # ========================================================
    # VALIDATE TRADE PLAN
    # ========================================================

    def validate_trade_plan(
        self,
        trade_plan,
    ):

        if trade_plan is None:

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol="XAUUSD",
                direction="NONE",
                volume=None,
                volume_type="units",
                entry_price=None,
                stop_loss=None,
                take_profit=None,
                reason="Trade plan is unavailable.",
            )

        # ----------------------------------------------------
        # Execution must never happen unless READY
        # ----------------------------------------------------

        if trade_plan.status != "READY":

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol=trade_plan.symbol,
                direction=trade_plan.direction,
                volume=None,
                volume_type="units",
                entry_price=trade_plan.entry_price,
                stop_loss=trade_plan.stop_loss,
                take_profit=trade_plan.take_profit,
                reason="Trade plan is not READY.",
            )

        # ----------------------------------------------------
        # Decision must be executable
        # ----------------------------------------------------

        if trade_plan.decision not in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol=trade_plan.symbol,
                direction=trade_plan.direction,
                volume=None,
                volume_type="units",
                entry_price=trade_plan.entry_price,
                stop_loss=trade_plan.stop_loss,
                take_profit=trade_plan.take_profit,
                reason="Trade decision is not executable.",
            )

        # ----------------------------------------------------
        # Direction
        # ----------------------------------------------------

        if trade_plan.direction not in {
            "BUY",
            "SELL",
        }:

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol=trade_plan.symbol,
                direction=trade_plan.direction,
                volume=None,
                volume_type="units",
                entry_price=trade_plan.entry_price,
                stop_loss=trade_plan.stop_loss,
                take_profit=trade_plan.take_profit,
                reason="Invalid trade direction.",
            )

        # ----------------------------------------------------
        # Broker validation
        # ----------------------------------------------------

        if not trade_plan.broker_valid:

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol=trade_plan.symbol,
                direction=trade_plan.direction,
                volume=None,
                volume_type="units",
                entry_price=trade_plan.entry_price,
                stop_loss=trade_plan.stop_loss,
                take_profit=trade_plan.take_profit,
                reason="Broker validation failed.",
            )

        # ----------------------------------------------------
        # Position size
        # ----------------------------------------------------

        if (
            trade_plan.position_size is None
            or trade_plan.position_size <= 0
        ):

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol=trade_plan.symbol,
                direction=trade_plan.direction,
                volume=None,
                volume_type="units",
                entry_price=trade_plan.entry_price,
                stop_loss=trade_plan.stop_loss,
                take_profit=trade_plan.take_profit,
                reason="Invalid position size.",
            )

        # ----------------------------------------------------
        # Prices
        # ----------------------------------------------------

        if (
            trade_plan.entry_price is None
            or trade_plan.stop_loss is None
            or trade_plan.take_profit is None
        ):

            return ExecutionResult(
                allowed=False,
                executed=False,
                symbol=trade_plan.symbol,
                direction=trade_plan.direction,
                volume=None,
                volume_type="units",
                entry_price=trade_plan.entry_price,
                stop_loss=trade_plan.stop_loss,
                take_profit=trade_plan.take_profit,
                reason="Entry, stop-loss or take-profit is missing.",
            )

        # ----------------------------------------------------
        # Everything passed
        # ----------------------------------------------------

        return ExecutionResult(
            allowed=True,
            executed=False,
            symbol=trade_plan.symbol,
            direction=trade_plan.direction,
            volume=trade_plan.position_size,
            volume_type="units",
            entry_price=trade_plan.entry_price,
            stop_loss=trade_plan.stop_loss,
            take_profit=trade_plan.take_profit,
            reason="Execution validation passed.",
        )

    # ========================================================
    # DRY RUN
    # ========================================================

    async def execute(
        self,
        session,
        trade_plan,
    ):

        validation = self.validate_trade_plan(
            trade_plan
        )

        if not validation.allowed:

            return validation

        # ----------------------------------------------------
        # HARD SAFETY:
        # dry-run never calls the broker
        # ----------------------------------------------------

        if self.dry_run:

            return ExecutionResult(
                allowed=True,
                executed=False,
                symbol=validation.symbol,
                direction=validation.direction,
                volume=validation.volume,
                volume_type=validation.volume_type,
                entry_price=validation.entry_price,
                stop_loss=validation.stop_loss,
                take_profit=validation.take_profit,
                reason=(
                    "DRY RUN: execution validated. "
                    "No broker order was placed."
                ),
            )

        # ----------------------------------------------------
        # LIVE EXECUTION
        #
        # Intentionally disabled for now.
        # ----------------------------------------------------

        raise RuntimeError(
            "LIVE EXECUTION IS NOT ENABLED YET."
        )