import asyncio
import json

import pandas as pd

from app.ctrader.market_data import (
    get_market_snapshot,
)

from app.analysis_engine import (
    calculate_indicators,
    create_market_summary,
)

from app.market_state import (
    determine_market_state,
)

from app.market_structure import (
    find_swing_points,
    determine_structure,
)

from app.support_resistance import (
    find_support_resistance,
    group_levels,
)

from app.ctrader.mcp_client import (
    connect,
)

from app.news_analyzer import (
    extract_news_from_mcp,
    classify_news,
)

from app.evidence_engine import (
    build_evidence,
)

from app.liquidity_engine import (
    build_liquidity_evidence,
)


# ============================================================
# CONFIGURATION
# ============================================================

SYMBOL = "XAUUSD"

TIMEFRAMES = [
    "m5",
    "m15",
    "h1",
    "h4",
    "d1",
]


# ============================================================
# NEWS
# ============================================================

async def get_news():
    """
    Request and classify news from cTrader MCP.

    This function only collects evidence.
    It does not make trading decisions.
    """

    async with connect() as session:

        result = await session.call_tool(
            "get_news",
            {
                "feed": "general",
                "limit": 20,
            },
        )

    news_items = extract_news_from_mcp(
        result.content
    )

    return classify_news(
        news_items
    )


# ============================================================
# SPOT PRICE
# ============================================================

def extract_current_price(spot):
    """
    Extract an analysis price from the cTrader
    spot-price response.

    Preferred price:
        midpoint = (bid + ask) / 2

    Fallback:
        bid
        ask
    """

    if not spot:
        return None

    # --------------------------------------------------------
    # Spot response normalization
    # --------------------------------------------------------

    first_spot = spot[0]

    if not isinstance(
        first_spot,
        dict
    ):
        return None

    bid = first_spot.get(
        "bid"
    )

    ask = first_spot.get(
        "ask"
    )

    # --------------------------------------------------------
    # Midpoint
    # --------------------------------------------------------

    if (
        bid is not None
        and ask is not None
    ):

        try:

            bid = float(bid)
            ask = float(ask)

            return (
                bid + ask
            ) / 2

        except (
            TypeError,
            ValueError,
        ):

            pass

    # --------------------------------------------------------
    # Bid fallback
    # --------------------------------------------------------

    if bid is not None:

        try:

            return float(bid)

        except (
            TypeError,
            ValueError,
        ):

            pass

    # --------------------------------------------------------
    # Ask fallback
    # --------------------------------------------------------

    if ask is not None:

        try:

            return float(ask)

        except (
            TypeError,
            ValueError,
        ):

            pass

    return None


# ============================================================
# DATAFRAME PREPARATION
# ============================================================

def prepare_dataframe(bars):
    """
    Convert raw cTrader bars into a clean pandas DataFrame.
    """

    if not bars:
        return pd.DataFrame()

    df = pd.DataFrame(
        bars
    )

    required_columns = [
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]

    # --------------------------------------------------------
    # Verify required columns
    # --------------------------------------------------------

    for column in required_columns:

        if column not in df.columns:

            df[column] = None

    # --------------------------------------------------------
    # Convert numeric columns
    # --------------------------------------------------------

    for column in required_columns:

        df[column] = pd.to_numeric(
            df[column],
            errors="coerce",
        )

    # --------------------------------------------------------
    # Remove invalid rows
    # --------------------------------------------------------

    df = (
        df
        .dropna(
            subset=required_columns
        )
        .reset_index(
            drop=True
        )
    )

    return df


# ============================================================
# MAIN
# ============================================================

async def main():

    print(
        "Building complete "
        f"{SYMBOL} evidence package...\n"
    )

    # ========================================================
    # 1. MARKET SNAPSHOT
    # ========================================================

    snapshot = await get_market_snapshot(
        SYMBOL
    )

    # ========================================================
    # 2. TIMEFRAME ANALYSIS
    # ========================================================

    summaries = {}

    print(
        "\n========== TIMEFRAME ANALYSIS =========="
    )

    for timeframe in TIMEFRAMES:

        bars = (
            snapshot
            .get("timeframes", {})
            .get(timeframe, {})
            .get("bars", [])
        )

        print(
            f"{timeframe.upper()} bars: "
            f"{len(bars)}"
        )

        # ----------------------------------------------------
        # Skip unavailable timeframe
        # ----------------------------------------------------

        if not bars:

            print(
                f"WARNING: No {timeframe.upper()} "
                "bars available."
            )

            continue

        # ----------------------------------------------------
        # Prepare DataFrame
        # ----------------------------------------------------

        df = prepare_dataframe(
            bars
        )

        if df.empty:

            print(
                f"WARNING: {timeframe.upper()} "
                "data could not be prepared."
            )

            continue

        # ----------------------------------------------------
        # Calculate indicators
        # ----------------------------------------------------

        df = calculate_indicators(
            df
        )

        # ----------------------------------------------------
        # Create market summary
        # ----------------------------------------------------

        summaries[timeframe] = (
            create_market_summary(
                df
            )
        )

    # ========================================================
    # 3. MARKET STATE
    # ========================================================

    market_state = determine_market_state(
        summaries
    )

    # ========================================================
    # 4. H1 MARKET STRUCTURE
    # ========================================================

    h1_bars = (
        snapshot
        .get("timeframes", {})
        .get("h1", {})
        .get("bars", [])
    )

    h1_df = prepare_dataframe(
        h1_bars
    )

    if h1_df.empty:

        structure = {
            "structure": "unknown",
            "type": "unknown",
            "high_pattern": "unknown",
            "low_pattern": "unknown",
        }

        print(
            "\nWARNING: H1 structure data "
            "is unavailable."
        )

        support_levels = []
        resistance_levels = []

    else:

        # ----------------------------------------------------
        # Find swing points
        # ----------------------------------------------------

        h1_df = find_swing_points(
            h1_df
        )

        # ----------------------------------------------------
        # Determine structure
        # ----------------------------------------------------

        structure = determine_structure(
            h1_df
        )

        # ----------------------------------------------------
        # Support / Resistance
        # ----------------------------------------------------

        levels = find_support_resistance(
            h1_df
        )

        zones = group_levels(
            levels
        )

        support_levels = [
            zone
            for zone in zones
            if zone.get("type")
            == "support"
        ]

        resistance_levels = [
            zone
            for zone in zones
            if zone.get("type")
            == "resistance"
        ]

    # ========================================================
    # 5. NEWS
    # ========================================================

    print(
        "\nRequesting news..."
    )

    try:

        news_analysis = await get_news()

    except Exception as error:

        print(
            "WARNING: News request failed:"
        )

        print(
            str(error)
        )

        news_analysis = None

    # ========================================================
    # 6. CURRENT SPOT PRICE
    # ========================================================

    spot = snapshot.get(
        "spot",
        []
    )

    current_price = (
        extract_current_price(
            spot
        )
    )

    # ========================================================
    # 7. LIQUIDITY ENGINE
    # ========================================================

    print(
        "\n========== LIQUIDITY ENGINE =========="
    )

    m5_bars = (
        snapshot
        .get("timeframes", {})
        .get("m5", {})
        .get("bars", [])
    )

    d1_bars = (
        snapshot
        .get("timeframes", {})
        .get("d1", {})
        .get("bars", [])
    )

    print(
        f"M5 liquidity bars: "
        f"{len(m5_bars)}"
    )

    print(
        f"D1 liquidity bars: "
        f"{len(d1_bars)}"
    )

    if current_price is not None:

        print(
            f"Liquidity price: "
            f"{current_price}"
        )

    else:

        print(
            "WARNING: Current spot price "
            "is unavailable."
        )

    try:

        liquidity_evidence = (
            build_liquidity_evidence(
                m5_bars=m5_bars,
                daily_bars=d1_bars,
                current_price=current_price,
            )
        )

    except Exception as error:

        print(
            "\nERROR: Liquidity engine failed:"
        )

        print(
            str(error)
        )

        liquidity_evidence = {
            "available": False,
            "error": str(error),
        }

    # ========================================================
    # 8. BUILD COMPLETE EVIDENCE
    # ========================================================

    evidence = build_evidence(

        market_state=market_state,

        timeframe_summaries=summaries,

        structure=structure,

        support_levels=support_levels,

        resistance_levels=resistance_levels,

        news_analysis=news_analysis,

        liquidity_evidence=(
            liquidity_evidence
        ),
    )

    # ========================================================
    # 9. ADD SYMBOL / METADATA
    # ========================================================

    evidence["symbol"] = SYMBOL

    evidence["timeframe_data"] = {}

    for timeframe in TIMEFRAMES:

        timeframe_data = (
            snapshot
            .get("timeframes", {})
            .get(timeframe, {})
        )

        evidence[
            "timeframe_data"
        ][timeframe] = {

            "bar_count": (
                timeframe_data.get(
                    "bar_count",
                    0
                )
            ),

            "latest_timestamp": (
                timeframe_data.get(
                    "latest_timestamp"
                )
            ),
        }

    # ========================================================
    # 10. SAVE MARKET EVIDENCE
    # ========================================================

    output_file = (
        "market_evidence.json"
    )

    with open(
        output_file,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            evidence,
            file,
            indent=2,
            ensure_ascii=False,
        )

    print(
        f"\nSaved evidence to "
        f"{output_file}"
    )

    # ========================================================
    # 11. DISPLAY SUMMARY
    # ========================================================

    print(
        "\n"
        "=============================================="
    )

    print(
        "           MARKET EVIDENCE"
    )

    print(
        "=============================================="
    )

    print(
        f"Symbol: "
        f"{evidence.get('symbol')}"
    )

    print(
        f"Evidence bias: "
        f"{evidence.get('evidence_bias')}"
    )

    print(
        f"Confidence state: "
        f"{evidence.get('confidence_state')}"
    )

    # ========================================================
    # BULLISH
    # ========================================================

    print(
        "\nBULLISH EVIDENCE:"
    )

    bullish = evidence.get(
        "bullish_evidence",
        []
    )

    if bullish:

        for item in bullish:

            print(
                f"+ {item}"
            )

    else:

        print(
            "  None"
        )

    # ========================================================
    # BEARISH
    # ========================================================

    print(
        "\nBEARISH EVIDENCE:"
    )

    bearish = evidence.get(
        "bearish_evidence",
        []
    )

    if bearish:

        for item in bearish:

            print(
                f"- {item}"
            )

    else:

        print(
            "  None"
        )

    # ========================================================
    # CAUTION
    # ========================================================

    print(
        "\nCAUTION:"
    )

    caution = evidence.get(
        "caution",
        []
    )

    if caution:

        for item in caution:

            print(
                f"! {item}"
            )

    else:

        print(
            "  None"
        )

    # ========================================================
    # MARKET STATE
    # ========================================================

    print(
        "\nMARKET STATE:"
    )

    print(
        json.dumps(
            evidence.get(
                "market_state",
                {}
            ),
            indent=2,
        )
    )

    # ========================================================
    # STRUCTURE
    # ========================================================

    print(
        "\nSTRUCTURE:"
    )

    print(
        json.dumps(
            evidence.get(
                "structure",
                {}
            ),
            indent=2,
        )
    )

    # ========================================================
    # NEWS
    # ========================================================

    print(
        "\nNEWS:"
    )

    print(
        json.dumps(
            evidence.get(
                "news",
                {}
            ),
            indent=2,
        )
    )

    # ========================================================
    # LEVELS
    # ========================================================

    print(
        "\nSUPPORT / RESISTANCE:"
    )

    print(
        json.dumps(
            evidence.get(
                "levels",
                {}
            ),
            indent=2,
        )
    )

    # ========================================================
    # LIQUIDITY
    # ========================================================

    print(
        "\nLIQUIDITY:"
    )

    liquidity = evidence.get(
        "liquidity",
        {}
    )

    print(
        json.dumps(
            liquidity,
            indent=2,
            ensure_ascii=False,
        )
    )

    # ========================================================
    # DATA QUALITY
    # ========================================================

    print(
        "\nDATA QUALITY:"
    )

    print(
        json.dumps(
            liquidity.get(
                "data_quality",
                {}
            ),
            indent=2,
        )
    )

    # ========================================================
    # DATA SOURCES
    # ========================================================

    print(
        "\nDATA SOURCES:"
    )

    print(
        json.dumps(
            liquidity.get(
                "data_source",
                {}
            ),
            indent=2,
        )
    )

    # ========================================================
    # COMPLETE
    # ========================================================

    print(
        "\n"
        "=============================================="
    )

    print(
        "       EVIDENCE ENGINE COMPLETE"
    )

    print(
        "=============================================="
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    asyncio.run(
        main()
    )