"""
Forward-collected research archive.

The research/validation audit confirmed no historical order-flow, DOM, or
footprint dataset exists anywhere (brokers do not provide that
retroactively) - this module is how HAFNOT starts building its OWN such
dataset, going forward, while running in PAPER or DEMO mode. It does NOT
retroactively fabricate anything; it only ever appends a new record for
data that was genuinely observed at write time.

Deliberately separate from the raw high-frequency capture
(data/openapi/*.jsonl, governed by hafnot_storage_guard.py's rolling
32MB-per-file trim): that capture is optimized for the live pipeline's
immediate needs and is disposable. This archive is optimized for FUTURE
RESEARCH - one compact, periodic snapshot per symbol rather than every
tick, kept for longer, with its own independent size/retention cap so it
never competes with or gets silently trimmed by the raw-capture governor.

Snapshot contents (only what is genuinely useful for future research):
  - timestamp, symbol
  - bid/ask, spread
  - order-flow depth imbalance summary (from
    app.paper.market_snapshot.build_orderflow_evidence) - NOT the full
    raw depth book, which would be large and mostly redundant with the
    imbalance summary already captured
  - the core-strategy evaluation result for that cycle (signal or None,
    and why) - so a future researcher can see what the OHLC-only core
    strategy concluded at the same moment order-flow was observed,
    without needing to re-derive it
  - session/regime context at that moment

Retention: SAMPLE_INTERVAL_SECONDS controls how often a snapshot is
written per symbol (default 300s = one snapshot per 5 minutes, not every
cycle) to keep volume low. MAX_ARCHIVE_BYTES caps total on-disk size;
when exceeded, the OLDEST daily files are deleted first.
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ARCHIVE_DIR = PROJECT_ROOT / "data" / "research_archive"

SAMPLE_INTERVAL_SECONDS = 300  # one snapshot per symbol per 5 minutes

MAX_ARCHIVE_BYTES = 500 * 1024 * 1024  # 500MB hard cap, independent of
# hafnot_storage_guard.py's 5GB data\ cap - this archive should never be
# the thing that eats the whole budget; it is capped much lower and on
# its own schedule.

_last_write_at: dict[str, float] = {}


def _today_file(symbol: str) -> Path:
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    symbol_dir = ARCHIVE_DIR / symbol.lower()
    symbol_dir.mkdir(parents=True, exist_ok=True)
    return symbol_dir / f"{date_str}.jsonl"


def should_sample(symbol: str) -> bool:
    """Rate-limit: True only if SAMPLE_INTERVAL_SECONDS has elapsed since
    the last recorded snapshot for this symbol (in this process's
    lifetime - a fresh process will sample once immediately, which is
    fine, not a correctness issue)."""

    last = _last_write_at.get(symbol, 0.0)
    return (time.monotonic() - last) >= SAMPLE_INTERVAL_SECONDS


def record_snapshot(
    *,
    symbol: str,
    bid: Optional[float],
    ask: Optional[float],
    orderflow_evidence: Optional[dict[str, Any]] = None,
    core_strategy_result: Optional[dict[str, Any]] = None,
    session_label: Optional[str] = None,
    regime: Optional[dict[str, Any]] = None,
    market_open: Optional[bool] = None,
    force: bool = False,
) -> bool:
    """
    Append one research snapshot for `symbol`, if the sample interval has
    elapsed (or `force=True`). Returns True if a snapshot was written.

    This function never raises on a write failure - research archiving
    must never be able to interrupt the live trading pipeline it is
    observing. Failures are silently absorbed (no partial/corrupt record
    is ever written, since the write is a single atomic append of one
    JSON line).
    """

    if not force and not should_sample(symbol):
        return False

    spread = None
    if bid is not None and ask is not None:
        spread = ask - bid

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "symbol": symbol.upper(),
        "bid": bid,
        "ask": ask,
        "spread": spread,
        "orderflow": orderflow_evidence,
        "core_strategy_result": core_strategy_result,
        "session_label": session_label,
        "regime": regime,
        "market_open": market_open,
    }

    try:
        path = _today_file(symbol)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str, separators=(",", ":")) + "\n")
        _last_write_at[symbol] = time.monotonic()
        return True
    except OSError:
        return False


def archive_total_bytes() -> int:
    if not ARCHIVE_DIR.exists():
        return 0
    return sum(p.stat().st_size for p in ARCHIVE_DIR.rglob("*.jsonl") if p.is_file())


def enforce_retention(max_bytes: int = MAX_ARCHIVE_BYTES) -> int:
    """
    If the archive exceeds max_bytes, delete the OLDEST daily files
    (across all symbols) until back under the cap. Returns bytes freed.
    Call this periodically (e.g. from hafnot_storage_guard.py's existing
    60-second loop, or a dedicated scheduled task) - it is not called
    automatically by record_snapshot, to keep the hot write path cheap
    and free of filesystem-wide scans on every single call.
    """

    if not ARCHIVE_DIR.exists():
        return 0

    total = archive_total_bytes()
    if total <= max_bytes:
        return 0

    files = sorted(
        (p for p in ARCHIVE_DIR.rglob("*.jsonl") if p.is_file()),
        key=lambda p: p.stat().st_mtime,
    )

    freed = 0
    for f in files:
        if total - freed <= max_bytes:
            break
        try:
            size = f.stat().st_size
            f.unlink()
            freed += size
        except OSError:
            continue

    return freed
