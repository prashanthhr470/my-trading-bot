"""
HAFNOT AI Trading Agent
Core Data Quality Engine

Purpose
-------
Evaluate whether market data is reliable enough for analysis.

This module does NOT:
- make trading decisions
- call the broker
- execute trades
- override the risk engine
- decide BUY/SELL

It answers one question:

    "Can the downstream system reasonably trust this data?"

Quality levels
--------------
EXCELLENT
GOOD
DEGRADED
POOR
UNAVAILABLE

The result can be consumed by:
    Market Data
        ↓
    Data Quality
        ↓
    Evidence Engine
        ↓
    AI Reasoner
        ↓
    Decision Gate
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from math import isfinite
from typing import Any, Iterable, Mapping, Optional


# ============================================================
# ENUMS
# ============================================================


class QualityLevel(str, Enum):
    """Overall quality classification."""

    EXCELLENT = "EXCELLENT"
    GOOD = "GOOD"
    DEGRADED = "DEGRADED"
    POOR = "POOR"
    UNAVAILABLE = "UNAVAILABLE"


class QualityStatus(str, Enum):
    """Availability state of a data source."""

    AVAILABLE = "AVAILABLE"
    PARTIAL = "PARTIAL"
    STALE = "STALE"
    INVALID = "INVALID"
    UNAVAILABLE = "UNAVAILABLE"


# ============================================================
# DATA QUALITY REPORT
# ============================================================


@dataclass(frozen=True)
class DataQualityReport:
    """
    Complete quality assessment.

    score:
        0.0 → 1.0

    usable:
        Whether the data is sufficiently reliable for
        downstream analysis.

    trade_ready:
        Whether the quality is strong enough to permit
        consideration for a trading decision.

    Important:
        trade_ready=True does NOT mean a trade is allowed.
        Risk, evidence, setup, decision gate and final safety
        checks remain authoritative.
    """

    source: str

    symbol: Optional[str] = None

    timeframe: Optional[str] = None

    status: QualityStatus = QualityStatus.UNAVAILABLE

    level: QualityLevel = QualityLevel.UNAVAILABLE

    score: float = 0.0

    sample_count: int = 0

    expected_count: Optional[int] = None

    missing_count: int = 0

    duplicate_count: int = 0

    invalid_count: int = 0

    gap_count: int = 0

    large_gap_count: int = 0

    stale_seconds: Optional[float] = None

    spread: Optional[float] = None

    issues: tuple[str, ...] = field(default_factory=tuple)

    warnings: tuple[str, ...] = field(default_factory=tuple)

    checks: Mapping[str, bool] = field(
        default_factory=dict
    )

    metadata: Mapping[str, Any] = field(
        default_factory=dict
    )

    @property
    def usable(self) -> bool:
        """
        Data can be consumed by analytical components.
        """

        return (
            self.status
            not in {
                QualityStatus.UNAVAILABLE,
                QualityStatus.INVALID,
            }
            and self.score >= 0.50
        )

    @property
    def trade_ready(self) -> bool:
        """
        Data is sufficiently strong for trading analysis.

        This is intentionally stricter than `usable`.
        """

        return (
            self.usable
            and self.level
            in {
                QualityLevel.EXCELLENT,
                QualityLevel.GOOD,
            }
            and self.score >= 0.70
        )

    @property
    def is_blocking(self) -> bool:
        """
        Whether data quality should block trading consideration.
        """

        return not self.trade_ready

    def to_dict(self) -> dict[str, Any]:
        """Convert the report into JSON-friendly data."""

        return {
            "source": self.source,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "status": self.status.value,
            "level": self.level.value,
            "score": self.score,
            "usable": self.usable,
            "trade_ready": self.trade_ready,
            "is_blocking": self.is_blocking,
            "sample_count": self.sample_count,
            "expected_count": self.expected_count,
            "missing_count": self.missing_count,
            "duplicate_count": self.duplicate_count,
            "invalid_count": self.invalid_count,
            "gap_count": self.gap_count,
            "large_gap_count": self.large_gap_count,
            "stale_seconds": self.stale_seconds,
            "spread": self.spread,
            "issues": list(self.issues),
            "warnings": list(self.warnings),
            "checks": dict(self.checks),
            "metadata": dict(self.metadata),
        }


# ============================================================
# INTERNAL HELPERS
# ============================================================


def _utc_now() -> datetime:
    """Return timezone-aware UTC now."""

    return datetime.now(timezone.utc)


def _ensure_datetime(value: Any) -> Optional[datetime]:
    """
    Convert common timestamp representations to UTC datetime.

    Supported:
        datetime
        Unix seconds
        Unix milliseconds
        ISO strings
    """

    if value is None:
        return None

    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(
                tzinfo=timezone.utc
            )

        return value.astimezone(timezone.utc)

    if isinstance(value, (int, float)):
        try:
            numeric = float(value)

            # Detect milliseconds.
            if abs(numeric) > 10_000_000_000:
                numeric /= 1000.0

            return datetime.fromtimestamp(
                numeric,
                tz=timezone.utc,
            )
        except (ValueError, OverflowError, OSError):
            return None

    if isinstance(value, str):
        text = value.strip()

        if not text:
            return None

        try:
            parsed = datetime.fromisoformat(
                text.replace("Z", "+00:00")
            )

            if parsed.tzinfo is None:
                parsed = parsed.replace(
                    tzinfo=timezone.utc
                )

            return parsed.astimezone(timezone.utc)

        except ValueError:
            return None

    return None


def _safe_float(value: Any) -> Optional[float]:
    """Convert a value to finite float."""

    if value is None:
        return None

    try:
        number = float(value)

        if not isfinite(number):
            return None

        return number

    except (TypeError, ValueError):
        return None


def _extract_value(item: Any, *keys: str) -> Any:
    """
    Extract a value from either:
        dict-like data
        object attributes
    """

    if isinstance(item, Mapping):
        for key in keys:
            if key in item:
                return item[key]

    for key in keys:
        if hasattr(item, key):
            return getattr(item, key)

    return None


def _normalize_timestamps(
    timestamps: Iterable[Any],
) -> list[datetime]:
    """
    Convert timestamps to UTC and discard invalid timestamps.
    """

    normalized: list[datetime] = []

    for timestamp in timestamps:
        parsed = _ensure_datetime(timestamp)

        if parsed is not None:
            normalized.append(parsed)

    return normalized


def _timeframe_seconds(timeframe: Optional[str]) -> Optional[int]:
    """
    Convert common timeframe names to seconds.
    """

    if not timeframe:
        return None

    tf = timeframe.upper().strip()

    mapping = {
        "M1": 60,
        "M2": 120,
        "M3": 180,
        "M4": 240,
        "M5": 300,
        "M10": 600,
        "M15": 900,
        "M30": 1800,
        "H1": 3600,
        "H2": 7200,
        "H3": 10800,
        "H4": 14400,
        "H6": 21600,
        "H8": 28800,
        "H12": 43200,
        "D1": 86400,
        "W1": 604800,
    }

    return mapping.get(tf)


# ============================================================
# OHLC VALIDATION
# ============================================================


def validate_ohlc_bar(bar: Any) -> tuple[bool, str]:
    """
    Validate one OHLC bar.

    Rules:
        high >= open
        high >= close
        high >= low
        low <= open
        low <= close
        all prices finite
        prices > 0
    """

    open_price = _safe_float(
        _extract_value(bar, "open", "open_price")
    )

    high_price = _safe_float(
        _extract_value(bar, "high", "high_price")
    )

    low_price = _safe_float(
        _extract_value(bar, "low", "low_price")
    )

    close_price = _safe_float(
        _extract_value(bar, "close", "close_price")
    )

    values = (
        open_price,
        high_price,
        low_price,
        close_price,
    )

    if any(value is None for value in values):
        return False, "Missing or invalid OHLC value."

    if any(value <= 0 for value in values if value is not None):
        return False, "OHLC prices must be greater than zero."

    assert (
        open_price is not None
        and high_price is not None
        and low_price is not None
        and close_price is not None
    )

    if high_price < low_price:
        return False, "High is below low."

    if high_price < open_price:
        return False, "High is below open."

    if high_price < close_price:
        return False, "High is below close."

    if low_price > open_price:
        return False, "Low is above open."

    if low_price > close_price:
        return False, "Low is above close."

    return True, ""


# ============================================================
# BAR SERIES INTEGRITY
# ============================================================


@dataclass(frozen=True)
class BarCleaningResult:
    bars: list
    raw_count: int
    invalid_removed: int
    duplicates_removed: int
    conflicting_timestamps: tuple
    timestamp_report: "DataQualityReport"

    @property
    def changed(self) -> bool:
        return bool(self.invalid_removed or self.duplicates_removed)


def _ohlcv_signature(bar: Any) -> tuple:
    return tuple(
        _safe_float(_extract_value(bar, key))
        for key in ("open", "high", "low", "close", "volume")
    )


def clean_bars(
    bars: Iterable[Any],
    *,
    timeframe: Optional[str] = None,
    strict: bool = False,
) -> BarCleaningResult:
    """
    Sort, validate and de-duplicate an OHLC bar series before use.

    Identical duplicates (the same bar fetched twice, e.g. at a download
    chunk boundary) collapse to one. Duplicates that disagree on OHLCV keep
    the last occurrence and are listed in conflicting_timestamps; with
    strict=True they raise, because guessing the correct version is not
    acceptable for research data. Timestamps compare as instants, so
    "...+00:00" and "...Z" for the same moment are the same bar.
    """

    raw = list(bars)
    invalid_removed = 0
    by_time: dict = {}
    conflicts: set = set()

    for bar in raw:
        timestamp = _ensure_datetime(_extract_value(bar, "timestamp", "time"))
        valid, _ = validate_ohlc_bar(bar)

        if timestamp is None or not valid:
            invalid_removed += 1
            continue

        existing = by_time.get(timestamp)
        if existing is not None and _ohlcv_signature(existing) != _ohlcv_signature(bar):
            conflicts.add(timestamp.isoformat())

        by_time[timestamp] = bar

    if conflicts and strict:
        example = sorted(conflicts)[0]
        raise ValueError(
            f"{len(conflicts)} timestamp(s) carry conflicting OHLCV values, e.g. {example}."
        )

    ordered_times = sorted(by_time)
    ordered = [by_time[ts] for ts in ordered_times]

    return BarCleaningResult(
        bars=ordered,
        raw_count=len(raw),
        invalid_removed=invalid_removed,
        duplicates_removed=len(raw) - invalid_removed - len(ordered),
        conflicting_timestamps=tuple(sorted(conflicts)),
        # "now" is the last bar, so historical data is not flagged stale for being historical.
        timestamp_report=assess_timestamp_quality(
            ordered_times,
            timeframe=timeframe,
            now=ordered_times[-1] if ordered_times else None,
        ),
    )


def load_bar_file(path: Any, *, strict: bool = False) -> BarCleaningResult:
    """Load a {"period": ..., "bars": [...]} JSON file through clean_bars."""

    import json
    from pathlib import Path

    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return clean_bars(
        payload.get("bars") or [],
        timeframe=payload.get("period"),
        strict=strict,
    )


# ============================================================
# TIMESTAMP QUALITY
# ============================================================


def assess_timestamp_quality(
    timestamps: Iterable[Any],
    *,
    timeframe: Optional[str] = None,
    expected_count: Optional[int] = None,
    now: Optional[datetime] = None,
    stale_after_seconds: float = 60.0,
) -> DataQualityReport:
    """
    Assess timestamp sequence quality.

    Checks:
        - availability
        - invalid timestamps
        - chronological ordering
        - duplicates
        - gaps
        - large gaps
        - freshness
    """

    raw_values = list(timestamps)

    if not raw_values:
        return DataQualityReport(
            source="timestamp",
            timeframe=timeframe,
            status=QualityStatus.UNAVAILABLE,
            level=QualityLevel.UNAVAILABLE,
            score=0.0,
            expected_count=expected_count,
            issues=("No timestamps supplied.",),
        )

    parsed: list[datetime] = []

    invalid_count = 0

    for value in raw_values:
        timestamp = _ensure_datetime(value)

        if timestamp is None:
            invalid_count += 1
        else:
            parsed.append(timestamp)

    if not parsed:
        return DataQualityReport(
            source="timestamp",
            timeframe=timeframe,
            status=QualityStatus.INVALID,
            level=QualityLevel.UNAVAILABLE,
            score=0.0,
            expected_count=expected_count,
            invalid_count=invalid_count,
            issues=("No valid timestamps available.",),
        )

    duplicate_count = (
        len(parsed) - len(set(parsed))
    )

    ordered = sorted(parsed)

    gap_count = 0
    large_gap_count = 0

    timeframe_seconds = _timeframe_seconds(timeframe)

    if timeframe_seconds:
        for previous, current in zip(
            ordered,
            ordered[1:],
        ):
            delta = (
                current - previous
            ).total_seconds()

            # More than one expected candle interval.
            if delta > timeframe_seconds * 1.5:
                gap_count += 1

            # More than three expected intervals.
            if delta > timeframe_seconds * 3:
                large_gap_count += 1

    latest = max(ordered)

    current_time = (
        _ensure_datetime(now)
        if now is not None
        else _utc_now()
    )

    assert current_time is not None

    stale_seconds = max(
        0.0,
        (
            current_time - latest
        ).total_seconds(),
    )

    missing_count = 0

    if expected_count is not None:
        missing_count = max(
            0,
            expected_count - len(parsed),
        )

    issues: list[str] = []

    warnings: list[str] = []

    if invalid_count:
        issues.append(
            f"{invalid_count} invalid timestamp(s)."
        )

    if duplicate_count:
        issues.append(
            f"{duplicate_count} duplicate timestamp(s)."
        )

    if large_gap_count:
        issues.append(
            f"{large_gap_count} large timestamp gap(s)."
        )
    elif gap_count:
        warnings.append(
            f"{gap_count} timestamp gap(s) detected."
        )

    if missing_count:
        warnings.append(
            f"{missing_count} expected sample(s) missing."
        )

    if stale_seconds > stale_after_seconds:
        issues.append(
            f"Data is stale by {stale_seconds:.1f} seconds."
        )

    # Score starts at perfect quality.
    score = 1.0

    if invalid_count:
        score -= min(
            0.30,
            invalid_count / max(len(raw_values), 1),
        )

    if duplicate_count:
        score -= min(
            0.20,
            duplicate_count / max(len(parsed), 1),
        )

    if gap_count:
        score -= min(
            0.20,
            gap_count * 0.05,
        )

    if large_gap_count:
        score -= min(
            0.25,
            large_gap_count * 0.10,
        )

    if missing_count and expected_count:
        score -= min(
            0.20,
            missing_count / max(expected_count, 1),
        )

    if stale_seconds > stale_after_seconds:
        score -= 0.30

    score = max(0.0, min(1.0, score))

    if stale_seconds > stale_after_seconds:
        status = QualityStatus.STALE
    elif invalid_count == len(raw_values):
        status = QualityStatus.INVALID
    elif (
        invalid_count
        or duplicate_count
        or gap_count
        or missing_count
    ):
        status = QualityStatus.PARTIAL
    else:
        status = QualityStatus.AVAILABLE

    level = classify_score(
        score,
        status=status,
    )

    return DataQualityReport(
        source="timestamp",
        timeframe=timeframe,
        status=status,
        level=level,
        score=score,
        sample_count=len(parsed),
        expected_count=expected_count,
        missing_count=missing_count,
        duplicate_count=duplicate_count,
        invalid_count=invalid_count,
        gap_count=gap_count,
        large_gap_count=large_gap_count,
        stale_seconds=stale_seconds,
        issues=tuple(issues),
        warnings=tuple(warnings),
        checks={
            "timestamps_available": bool(parsed),
            "timestamps_valid": invalid_count == 0,
            "duplicates_absent": duplicate_count == 0,
            "gaps_absent": gap_count == 0,
            "fresh": stale_seconds <= stale_after_seconds,
        },
    )


# ============================================================
# OHLC DATA QUALITY
# ============================================================


def assess_ohlc_quality(
    bars: Iterable[Any],
    *,
    symbol: Optional[str] = None,
    timeframe: Optional[str] = None,
    expected_count: Optional[int] = None,
    now: Optional[datetime] = None,
    stale_after_seconds: float = 60.0,
) -> DataQualityReport:
    """
    Assess complete OHLC bar data.

    This combines:
        - OHLC validation
        - timestamp validation
        - duplicates
        - gaps
        - missing samples
        - freshness
    """

    bar_list = list(bars)

    if not bar_list:
        return DataQualityReport(
            source="ohlc",
            symbol=symbol,
            timeframe=timeframe,
            status=QualityStatus.UNAVAILABLE,
            level=QualityLevel.UNAVAILABLE,
            score=0.0,
            expected_count=expected_count,
            issues=("No OHLC bars supplied.",),
        )

    invalid_count = 0
    ohlc_issues: list[str] = []

    timestamps: list[Any] = []

    for index, bar in enumerate(bar_list):
        valid, reason = validate_ohlc_bar(bar)

        if not valid:
            invalid_count += 1

            if len(ohlc_issues) < 10:
                ohlc_issues.append(
                    f"Bar {index}: {reason}"
                )

        timestamps.append(
            _extract_value(
                bar,
                "timestamp",
                "time",
                "open_time",
                "date",
            )
        )

    timestamp_report = assess_timestamp_quality(
        timestamps,
        timeframe=timeframe,
        expected_count=expected_count,
        now=now,
        stale_after_seconds=stale_after_seconds,
    )

    score = timestamp_report.score

    if invalid_count:
        score -= min(
            0.35,
            invalid_count / max(len(bar_list), 1),
        )

    score = max(0.0, min(1.0, score))

    issues = list(timestamp_report.issues)

    issues.extend(ohlc_issues)

    warnings = list(timestamp_report.warnings)

    if invalid_count:
        warnings.append(
            f"{invalid_count} invalid OHLC bar(s)."
        )

    status = timestamp_report.status

    if invalid_count == len(bar_list):
        status = QualityStatus.INVALID
    elif invalid_count:
        status = QualityStatus.PARTIAL

    level = classify_score(
        score,
        status=status,
    )

    checks = dict(timestamp_report.checks)

    checks.update(
        {
            "ohlc_valid": invalid_count == 0,
            "bars_available": len(bar_list) > 0,
        }
    )

    return DataQualityReport(
        source="ohlc",
        symbol=symbol,
        timeframe=timeframe,
        status=status,
        level=level,
        score=score,
        sample_count=len(bar_list),
        expected_count=expected_count,
        missing_count=timestamp_report.missing_count,
        duplicate_count=timestamp_report.duplicate_count,
        invalid_count=invalid_count,
        gap_count=timestamp_report.gap_count,
        large_gap_count=timestamp_report.large_gap_count,
        stale_seconds=timestamp_report.stale_seconds,
        issues=tuple(issues),
        warnings=tuple(warnings),
        checks=checks,
    )


# ============================================================
# SPOT / PRICE QUALITY
# ============================================================


def assess_price_quality(
    *,
    bid: Any,
    ask: Any,
    last: Any = None,
    symbol: Optional[str] = None,
    source: str = "spot",
    max_spread: Optional[float] = None,
) -> DataQualityReport:
    """
    Assess current bid/ask/last price quality.
    """

    bid_value = _safe_float(bid)
    ask_value = _safe_float(ask)
    last_value = _safe_float(last)

    issues: list[str] = []
    warnings: list[str] = []

    invalid_count = 0

    if bid_value is None or bid_value <= 0:
        invalid_count += 1
        issues.append("Invalid bid price.")

    if ask_value is None or ask_value <= 0:
        invalid_count += 1
        issues.append("Invalid ask price.")

    if (
        last is not None
        and last_value is None
    ):
        invalid_count += 1
        warnings.append("Last price is invalid.")

    spread: Optional[float] = None

    if (
        bid_value is not None
        and ask_value is not None
        and bid_value > 0
        and ask_value > 0
    ):
        if ask_value < bid_value:
            invalid_count += 1
            issues.append(
                "Ask price is below bid price."
            )
        else:
            spread = ask_value - bid_value

    if (
        max_spread is not None
        and spread is not None
        and spread > max_spread
    ):
        issues.append(
            f"Spread {spread:.6f} exceeds "
            f"maximum {max_spread:.6f}."
        )

    if invalid_count:
        score = 0.0
        status = QualityStatus.INVALID
    else:
        score = 1.0
        status = QualityStatus.AVAILABLE

        if (
            max_spread is not None
            and spread is not None
            and spread > max_spread
        ):
            score = 0.40
            status = QualityStatus.PARTIAL
            warnings.append(
                "Spread is wider than the configured limit."
            )

    level = classify_score(
        score,
        status=status,
    )

    return DataQualityReport(
        source=source,
        symbol=symbol,
        status=status,
        level=level,
        score=score,
        sample_count=1 if status != QualityStatus.UNAVAILABLE else 0,
        invalid_count=invalid_count,
        spread=spread,
        issues=tuple(issues),
        warnings=tuple(warnings),
        checks={
            "bid_valid": (
                bid_value is not None
                and bid_value > 0
            ),
            "ask_valid": (
                ask_value is not None
                and ask_value > 0
            ),
            "ask_above_bid": (
                bid_value is not None
                and ask_value is not None
                and ask_value >= bid_value
            ),
            "spread_valid": (
                spread is not None
            ),
            "spread_within_limit": (
                max_spread is None
                or (
                    spread is not None
                    and spread <= max_spread
                )
            ),
        },
    )


# ============================================================
# QUALITY CLASSIFICATION
# ============================================================


def classify_score(
    score: float,
    *,
    status: QualityStatus = QualityStatus.AVAILABLE,
) -> QualityLevel:
    """
    Convert numeric score into quality level.
    """

    score = max(
        0.0,
        min(1.0, float(score)),
    )

    if status == QualityStatus.UNAVAILABLE:
        return QualityLevel.UNAVAILABLE

    if status == QualityStatus.INVALID:
        return QualityLevel.UNAVAILABLE

    if score >= 0.90:
        return QualityLevel.EXCELLENT

    if score >= 0.75:
        return QualityLevel.GOOD

    if score >= 0.50:
        return QualityLevel.DEGRADED

    return QualityLevel.POOR


# ============================================================
# COMBINING QUALITY REPORTS
# ============================================================


def combine_quality_reports(
    reports: Iterable[DataQualityReport],
    *,
    source: str = "combined",
    symbol: Optional[str] = None,
    timeframe: Optional[str] = None,
) -> DataQualityReport:
    """
    Combine multiple quality reports.

    The weakest critical component influences the result.

    This is intentional.

    Example:

        Price quality = 1.00
        OHLC quality  = 0.95
        News quality  = 0.20

    The combined market-data quality should not blindly
    average to a high number if a critical source is poor.
    """

    report_list = list(reports)

    if not report_list:
        return DataQualityReport(
            source=source,
            symbol=symbol,
            timeframe=timeframe,
            status=QualityStatus.UNAVAILABLE,
            level=QualityLevel.UNAVAILABLE,
            score=0.0,
            issues=("No quality reports supplied.",),
        )

    scores = [
        report.score
        for report in report_list
    ]

    average_score = (
        sum(scores) / len(scores)
    )

    minimum_score = min(scores)

    # Weighted toward the weakest source.
    score = (
        average_score * 0.60
        + minimum_score * 0.40
    )

    statuses = {
        report.status
        for report in report_list
    }

    issues: list[str] = []
    warnings: list[str] = []

    checks: dict[str, bool] = {}

    for index, report in enumerate(report_list):
        prefix = (
            f"{report.source}"
            if report.source
            else f"source_{index}"
        )

        checks[
            f"{prefix}_usable"
        ] = report.usable

        checks[
            f"{prefix}_trade_ready"
        ] = report.trade_ready

        issues.extend(
            f"{prefix}: {issue}"
            for issue in report.issues
        )

        warnings.extend(
            f"{prefix}: {warning}"
            for warning in report.warnings
        )

    if QualityStatus.INVALID in statuses:
        status = QualityStatus.INVALID
    elif QualityStatus.UNAVAILABLE in statuses:
        status = QualityStatus.UNAVAILABLE
    elif QualityStatus.STALE in statuses:
        status = QualityStatus.STALE
    elif QualityStatus.PARTIAL in statuses:
        status = QualityStatus.PARTIAL
    else:
        status = QualityStatus.AVAILABLE

    level = classify_score(
        score,
        status=status,
    )

    return DataQualityReport(
        source=source,
        symbol=symbol,
        timeframe=timeframe,
        status=status,
        level=level,
        score=score,
        sample_count=sum(
            report.sample_count
            for report in report_list
        ),
        missing_count=sum(
            report.missing_count
            for report in report_list
        ),
        duplicate_count=sum(
            report.duplicate_count
            for report in report_list
        ),
        invalid_count=sum(
            report.invalid_count
            for report in report_list
        ),
        gap_count=sum(
            report.gap_count
            for report in report_list
        ),
        large_gap_count=sum(
            report.large_gap_count
            for report in report_list
        ),
        issues=tuple(issues),
        warnings=tuple(warnings),
        checks=checks,
        metadata={
            "component_count": len(report_list),
            "average_score": average_score,
            "minimum_score": minimum_score,
        },
    )


# ============================================================
# SIMPLE GATE
# ============================================================


def quality_allows_analysis(
    report: DataQualityReport,
) -> bool:
    """
    Return whether data is sufficient for analysis.
    """

    return report.usable


def quality_allows_trade_analysis(
    report: DataQualityReport,
) -> bool:
    """
    Return whether data quality is sufficient for trading
    analysis.

    Again:
        True != trade permission.

    It only means the data itself is not the blocker.
    """

    return report.trade_ready


# ============================================================
# PUBLIC API
# ============================================================


__all__ = [
    "QualityLevel",
    "QualityStatus",
    "DataQualityReport",
    "validate_ohlc_bar",
    "assess_timestamp_quality",
    "assess_ohlc_quality",
    "assess_price_quality",
    "classify_score",
    "combine_quality_reports",
    "quality_allows_analysis",
    "quality_allows_trade_analysis",
]