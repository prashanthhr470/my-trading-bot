"""
Timezone-aware trading session detection.

Nothing in the live canonical pipeline computed this before (confirmed by
repo-wide search - the only session-window code that existed lived in the
archived, never-wired-in app/ai_intelligence subsystem). Session opens/
closes are defined in LOCAL exchange time using IANA tzdata (zoneinfo),
so daylight-saving transitions are handled correctly by the timezone
database itself rather than by a hardcoded UTC-offset table that silently
drifts wrong twice a year.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, time, timezone
from zoneinfo import ZoneInfo

TOKYO_TZ = ZoneInfo("Asia/Tokyo")
LONDON_TZ = ZoneInfo("Europe/London")
NEW_YORK_TZ = ZoneInfo("America/New_York")

# Standard exchange-local session hours. These are conventional trading-
# session approximations, not official exchange hours (FX has no single
# central exchange) - they are the commonly used Tokyo/London/New York
# windows for session-based analysis.
TOKYO_OPEN = time(9, 0)
TOKYO_CLOSE = time(18, 0)
LONDON_OPEN = time(8, 0)
LONDON_CLOSE = time(17, 0)
NEW_YORK_OPEN = time(8, 0)
NEW_YORK_CLOSE = time(17, 0)


@dataclass(frozen=True)
class SessionState:
    utc_timestamp: str
    tokyo_open: bool
    london_open: bool
    new_york_open: bool
    london_new_york_overlap: bool
    active_sessions: tuple
    session_label: str


def _in_window(local_dt: datetime, open_time: time, close_time: time) -> bool:
    current = local_dt.time()
    if open_time <= close_time:
        return open_time <= current < close_time
    # Session wraps past local midnight.
    return current >= open_time or current < close_time


def get_session_state(reference_utc: datetime | None = None) -> SessionState:
    """
    reference_utc: an aware UTC datetime, or None to use the current time.
    """

    if reference_utc is None:
        reference_utc = datetime.now(timezone.utc)
    elif reference_utc.tzinfo is None:
        reference_utc = reference_utc.replace(tzinfo=timezone.utc)

    tokyo_local = reference_utc.astimezone(TOKYO_TZ)
    london_local = reference_utc.astimezone(LONDON_TZ)
    new_york_local = reference_utc.astimezone(NEW_YORK_TZ)

    tokyo_open = _in_window(tokyo_local, TOKYO_OPEN, TOKYO_CLOSE)
    london_open = _in_window(london_local, LONDON_OPEN, LONDON_CLOSE)
    new_york_open = _in_window(new_york_local, NEW_YORK_OPEN, NEW_YORK_CLOSE)

    active = []
    if tokyo_open:
        active.append("TOKYO")
    if london_open:
        active.append("LONDON")
    if new_york_open:
        active.append("NEW_YORK")

    london_ny_overlap = london_open and new_york_open

    if london_ny_overlap:
        label = "LONDON_NEW_YORK_OVERLAP"
    elif active:
        label = "_".join(active)
    else:
        label = "OFF_HOURS"

    return SessionState(
        utc_timestamp=reference_utc.isoformat(),
        tokyo_open=tokyo_open,
        london_open=london_open,
        new_york_open=new_york_open,
        london_new_york_overlap=london_ny_overlap,
        active_sessions=tuple(active),
        session_label=label,
    )
