"""
Windows process-tree helpers for the supervisor.

TerminateProcess - what Popen.terminate()/kill() and Stop-Process call - stops
ONE process. The cTrader worker is a chain: the .venv launcher, the worker
interpreter, the .ctrader_venv launcher and finally
multi_symbol_market_data.py, which holds the broker connection. Stopping only
the top of that chain left the market-data process running with its own
cTrader session (two such orphans were found on 2026-09-12).

So a caller snapshots the tree BEFORE stopping a child - afterwards the
children can no longer be found by parent PID - and then terminates whatever
in that snapshot is still alive. Each record carries the process creation
time, and a process is terminated only while a handle to it proves both PID
and creation time still match, so a PID Windows has since reused for an
unrelated process is never touched.
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes
from dataclasses import dataclass
from typing import Iterable, Optional

TH32CS_SNAPPROCESS = 0x00000002
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value


class _ProcessEntry32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_size_t),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", ctypes.c_wchar * 260),
    ]


@dataclass(frozen=True)
class ProcessRecord:
    pid: int
    parent_pid: int
    exe: str
    created: int  # FILETIME as one 64-bit integer; identifies the process together with pid


_KERNEL32 = None


def _kernel32():
    global _KERNEL32
    if sys.platform != "win32":
        raise OSError("process_tree requires Windows")
    if _KERNEL32 is None:
        # A private WinDLL instance, so these argtypes never affect other ctypes users of kernel32.
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
        k.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_ProcessEntry32W)]
        k.Process32FirstW.restype = wintypes.BOOL
        k.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_ProcessEntry32W)]
        k.Process32NextW.restype = wintypes.BOOL
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.OpenProcess.restype = ctypes.c_void_p
        k.GetProcessTimes.argtypes = [ctypes.c_void_p] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        k.GetProcessTimes.restype = wintypes.BOOL
        k.TerminateProcess.argtypes = [ctypes.c_void_p, wintypes.UINT]
        k.TerminateProcess.restype = wintypes.BOOL
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        k.CloseHandle.restype = wintypes.BOOL
        _KERNEL32 = k
    return _KERNEL32


def _snapshot(k) -> list[tuple[int, int, str]]:
    snap = k.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if not snap or snap == INVALID_HANDLE_VALUE:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        entry = _ProcessEntry32W()
        entry.dwSize = ctypes.sizeof(entry)
        rows = []
        ok = k.Process32FirstW(snap, ctypes.byref(entry))
        while ok:
            rows.append((entry.th32ProcessID, entry.th32ParentProcessID, entry.szExeFile))
            ok = k.Process32NextW(snap, ctypes.byref(entry))
        return rows
    finally:
        k.CloseHandle(snap)


def _handle_creation_time(k, handle) -> Optional[int]:
    times = [wintypes.FILETIME() for _ in range(4)]
    if not k.GetProcessTimes(handle, *(ctypes.byref(t) for t in times)):
        return None
    return (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime


def _creation_time(k, pid: int) -> Optional[int]:
    handle = k.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None
    try:
        return _handle_creation_time(k, handle)
    finally:
        k.CloseHandle(handle)


def running_pids() -> set[int]:
    return {pid for pid, _, _ in _snapshot(_kernel32())}


def descendants(pid: int) -> list[ProcessRecord]:
    """Every live process below `pid`, parents listed before their children."""
    k = _kernel32()
    children_of: dict[int, list[tuple[int, str]]] = {}
    for child, parent, exe in _snapshot(k):
        children_of.setdefault(parent, []).append((child, exe))

    root_created = _creation_time(k, pid)
    if root_created is None:
        return []

    found: list[ProcessRecord] = []
    seen = {pid}
    pending = [(pid, root_created)]
    while pending:
        parent, parent_created = pending.pop(0)
        for child, exe in children_of.get(parent, []):
            if child in seen:
                continue
            created = _creation_time(k, child)
            # A child is never older than its parent. An "older child" is an unrelated
            # process whose recorded parent PID has since been reused.
            if created is None or created < parent_created:
                continue
            seen.add(child)
            found.append(ProcessRecord(child, parent, exe, created))
            pending.append((child, created))
    return found


def terminate_survivors(records: Iterable[ProcessRecord]) -> list[ProcessRecord]:
    """
    Terminate each recorded process that is still the same process (PID and
    creation time), deepest first. Returns the records actually terminated.
    """
    records = list(records)
    if not records:
        return []
    k = _kernel32()
    alive = {pid for pid, _, _ in _snapshot(k)}
    terminated = []
    for record in reversed(records):
        if record.pid not in alive:
            continue
        handle = k.OpenProcess(PROCESS_TERMINATE | PROCESS_QUERY_LIMITED_INFORMATION, False, record.pid)
        if not handle:
            continue
        try:
            # Checked on the open handle, which pins the process: the PID cannot be reused under us.
            if _handle_creation_time(k, handle) != record.created:
                continue
            if k.TerminateProcess(handle, 1):
                terminated.append(record)
        finally:
            k.CloseHandle(handle)
    return terminated
