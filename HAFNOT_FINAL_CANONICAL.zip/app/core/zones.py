"""
Shared liquidity-zone computation, usable identically by the historical
backtester (app.quant.core_strategy) and the live pipeline.

Everything here is derived ONLY from OHLC price bars - no order-flow, no
DOM, no footprint. That is deliberate: this module is the boundary of what
is honestly available historically. See app/live/confirmation_layer.py for
the live-only additions (order flow, news, sentiment) that are NEVER
available to a historical backtest and must never be faked into one.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

EQUAL_LEVEL_TOLERANCE_PCT = 0.0005
ASIAN_SESSION_WINDOW_UTC = (0, 8)


def parse_ts(raw) -> Optional[datetime]:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
    try:
        text = str(raw).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def in_session_window(ts: datetime, window: tuple[int, int]) -> bool:
    start_hour, end_hour = window
    return start_hour <= ts.hour < end_hour


@dataclass
class SwingPoint:
    index: int
    price: float
    kind: str  # "high" or "low"


def find_confirmed_swings(bars: list[dict], confirm_bars: int = 3) -> list[SwingPoint]:
    """
    Fractal swing points, confirmed only within the given slice (never
    looks past the end of `bars` - the caller is responsible for only
    passing an anti-lookahead-safe prefix of the real series).
    """

    swings: list[SwingPoint] = []
    n = len(bars)

    for i in range(confirm_bars, n - confirm_bars):
        w = bars[i - confirm_bars: i + confirm_bars + 1]
        high_i = bars[i]["high"]
        low_i = bars[i]["low"]

        if high_i == max(b["high"] for b in w):
            swings.append(SwingPoint(index=i, price=high_i, kind="high"))
        if low_i == min(b["low"] for b in w):
            swings.append(SwingPoint(index=i, price=low_i, kind="low"))

    return swings


def equal_level_cluster(swings: list[SwingPoint], kind: str, tolerance_pct: float = EQUAL_LEVEL_TOLERANCE_PCT) -> Optional[float]:
    """Most recent pair of same-kind swings within tolerance of each other."""

    points = [s for s in swings if s.kind == kind]
    for i in range(len(points) - 1, 0, -1):
        a, b = points[i], points[i - 1]
        tolerance = abs(a.price) * tolerance_pct
        if abs(a.price - b.price) <= tolerance:
            return (a.price + b.price) / 2.0
    return None


@dataclass
class LiquidityZones:
    previous_day_high: Optional[float] = None
    previous_day_low: Optional[float] = None
    previous_week_high: Optional[float] = None
    previous_week_low: Optional[float] = None
    asian_session_high: Optional[float] = None
    asian_session_low: Optional[float] = None
    equal_highs: Optional[float] = None
    equal_lows: Optional[float] = None

    def high_levels(self) -> list[float]:
        return [v for v in (
            self.previous_day_high, self.previous_week_high,
            self.asian_session_high, self.equal_highs,
        ) if v is not None]

    def low_levels(self) -> list[float]:
        return [v for v in (
            self.previous_day_low, self.previous_week_low,
            self.asian_session_low, self.equal_lows,
        ) if v is not None]


def compute_daily_weekly_zones(bars: list[dict]) -> LiquidityZones:
    """
    PDH/PDL and PWH/PWL only. These depend exclusively on bars from
    PRIOR completed calendar days/weeks, so once computed for a given
    "today", the result is stable for the rest of that day regardless of
    how many more bars of *today* arrive - safe to cache by date. This is
    the expensive part (scans a large trailing window), which is exactly
    why it is split out from the cheap, intraday-evolving parts below.
    """

    dated_bars = [(ts, b) for b in bars if (ts := parse_ts(b.get("timestamp"))) is not None]
    if not dated_bars:
        return LiquidityZones()

    latest_ts = dated_bars[-1][0]
    today = latest_ts.date()
    yesterday = today - timedelta(days=1)
    this_week_start = today - timedelta(days=today.weekday())
    last_week_start = this_week_start - timedelta(days=7)
    last_week_end = this_week_start - timedelta(days=1)

    pdh = pdl = None
    pwh = pwl = None

    for ts, b in dated_bars:
        d = ts.date()

        if d == yesterday:
            pdh = b["high"] if pdh is None else max(pdh, b["high"])
            pdl = b["low"] if pdl is None else min(pdl, b["low"])

        if last_week_start <= d <= last_week_end:
            pwh = b["high"] if pwh is None else max(pwh, b["high"])
            pwl = b["low"] if pwl is None else min(pwl, b["low"])

    return LiquidityZones(
        previous_day_high=pdh, previous_day_low=pdl,
        previous_week_high=pwh, previous_week_low=pwl,
    )


def compute_asian_session_zone(bars: list[dict]) -> tuple[Optional[float], Optional[float]]:
    """
    Asian session high/low for "today" (the latest bar's date). Unlike
    PDH/PDL/PWH/PWL, this DOES change as today's Asian-session bars
    arrive (00:00-08:00 UTC) and must NEVER be cached across an entire
    calendar day, or an evaluation that happens before 08:00 UTC would
    permanently freeze an incomplete session range for the rest of the
    day. Intentionally cheap: only scans bars matching today's date, not
    the full zone lookback window.
    """

    dated_bars = [(ts, b) for b in bars if (ts := parse_ts(b.get("timestamp"))) is not None]
    if not dated_bars:
        return None, None

    today = dated_bars[-1][0].date()
    asian_high = asian_low = None

    for ts, b in dated_bars:
        if ts.date() == today and in_session_window(ts, ASIAN_SESSION_WINDOW_UTC):
            asian_high = b["high"] if asian_high is None else max(asian_high, b["high"])
            asian_low = b["low"] if asian_low is None else min(asian_low, b["low"])

    return asian_high, asian_low


def compute_zones(bars: list[dict], swings: Optional[list[SwingPoint]] = None) -> LiquidityZones:
    """
    Full zone computation (PDH/PDL/PWH/PWL + Asian session H/L + equal
    highs/lows) from a trailing window of bars, in one call. Convenient
    for one-off/standalone use and tests. Performance-sensitive callers
    that evaluate many bars in sequence (a backtest) should instead cache
    compute_daily_weekly_zones() by date and call
    compute_asian_session_zone() fresh each time - see
    app.quant.core_strategy.make_signal_provider for the pattern that
    avoids both the O(large window) re-scan AND the stale-Asian-session
    bug that a naive whole-zones cache would introduce.
    """

    daily_weekly = compute_daily_weekly_zones(bars)
    asian_high, asian_low = compute_asian_session_zone(bars)

    if swings is None:
        swings = find_confirmed_swings(bars)

    daily_weekly.asian_session_high = asian_high
    daily_weekly.asian_session_low = asian_low
    daily_weekly.equal_highs = equal_level_cluster(swings, "high")
    daily_weekly.equal_lows = equal_level_cluster(swings, "low")

    return daily_weekly
