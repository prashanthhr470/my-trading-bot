"""
Shared market-structure classification: trend direction from swing
sequences, plus explicit Break of Structure (BOS - a break that CONTINUES
the prevailing trend) vs Change of Character (CHoCH - a break AGAINST the
prevailing trend, the first signal of a possible reversal).

OHLC-only, historically testable - see app/core/zones.py's module
docstring for why that boundary matters.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from app.core.zones import SwingPoint, find_confirmed_swings


@dataclass
class StructureEvent:
    kind: str  # "BOS" or "CHoCH"
    direction: str  # "BULLISH" or "BEARISH"
    index: int
    broken_level: float


def classify_trend(swings: list[SwingPoint]) -> str:
    """
    "BULLISH" if the most recent confirmed highs and lows are both rising
    (higher highs, higher lows), "BEARISH" if both falling, else "RANGING".
    """

    highs = [s for s in swings if s.kind == "high"]
    lows = [s for s in swings if s.kind == "low"]

    if len(highs) < 2 or len(lows) < 2:
        return "RANGING"

    higher_highs = highs[-1].price > highs[-2].price
    higher_lows = lows[-1].price > lows[-2].price
    lower_highs = highs[-1].price < highs[-2].price
    lower_lows = lows[-1].price < lows[-2].price

    if higher_highs and higher_lows:
        return "BULLISH"
    if lower_highs and lower_lows:
        return "BEARISH"
    return "RANGING"


def find_structure_events(bars: list[dict], swings: Optional[list[SwingPoint]] = None) -> list[StructureEvent]:
    """
    Scan `bars` for structure breaks: a bar that closes beyond the most
    recently confirmed opposing swing point. Classified as BOS if it
    continues the trend that was already in place at that point, CHoCH if
    it reverses it. Only uses swings confirmed strictly before the
    breaking bar - anti-lookahead-safe.
    """

    if swings is None:
        swings = find_confirmed_swings(bars)

    events: list[StructureEvent] = []

    for i, bar in enumerate(bars):
        prior_swings = [s for s in swings if s.index < i]
        if len(prior_swings) < 4:
            continue

        prior_highs = [s for s in prior_swings if s.kind == "high"]
        prior_lows = [s for s in prior_swings if s.kind == "low"]
        if not prior_highs or not prior_lows:
            continue

        prevailing_trend = classify_trend(prior_swings)

        last_high = prior_highs[-1]
        last_low = prior_lows[-1]

        if bar["close"] > last_high.price:
            direction = "BULLISH"
            kind = "BOS" if prevailing_trend == "BULLISH" else "CHoCH"
            events.append(StructureEvent(kind=kind, direction=direction, index=i, broken_level=last_high.price))

        elif bar["close"] < last_low.price:
            direction = "BEARISH"
            kind = "BOS" if prevailing_trend == "BEARISH" else "CHoCH"
            events.append(StructureEvent(kind=kind, direction=direction, index=i, broken_level=last_low.price))

    return events
