"""
HAFNOT AI Trading Agent
Core Configuration

Purpose
-------
Central configuration for the entire trading-agent architecture.

This module does NOT:
- execute trades
- call the broker
- call the AI
- make trading decisions

It only provides validated configuration.

Architecture
------------
Core Config
    ↓
Agent
Market Data
Fundamentals
News
Sentiment
Regime
Evidence
AI
Risk
Trade Management
Storage
Backtesting
Audit
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Final


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parents[2]

APP_DIR: Final[Path] = PROJECT_ROOT / "app"

DATA_DIR: Final[Path] = PROJECT_ROOT / "data"

HISTORICAL_DATA_DIR: Final[Path] = DATA_DIR / "historical"

TICK_DATA_DIR: Final[Path] = HISTORICAL_DATA_DIR / "ticks"

BAR_DATA_DIR: Final[Path] = HISTORICAL_DATA_DIR / "bars"

NEWS_DATA_DIR: Final[Path] = HISTORICAL_DATA_DIR / "news"

FUNDAMENTAL_DATA_DIR: Final[Path] = HISTORICAL_DATA_DIR / "fundamentals"

BACKTEST_DATA_DIR: Final[Path] = DATA_DIR / "backtests"

LOG_DIR: Final[Path] = PROJECT_ROOT / "logs"

AUDIT_DIR: Final[Path] = LOG_DIR / "audit"

REPORT_DIR: Final[Path] = PROJECT_ROOT / "reports"


# ============================================================
# DEFAULT SYMBOLS
# ============================================================

DEFAULT_SYMBOLS: Final[tuple[str, ...]] = (
    "XAUUSD",
    "USDJPY",
    "GBPUSD",
    "AUDUSD",
)


DEFAULT_TIMEFRAMES: Final[tuple[str, ...]] = (
    "M1",
    "M5",
    "M15",
    "M30",
    "H1",
    "H4",
    "D1",
)


# ============================================================
# ENVIRONMENT HELPERS
# ============================================================

def _env_bool(name: str, default: bool) -> bool:
    """
    Read a boolean environment variable.

    Accepted true values:
        1, true, yes, on

    Accepted false values:
        0, false, no, off
    """

    value = os.getenv(name)

    if value is None:
        return default

    normalized = value.strip().lower()

    if normalized in {"1", "true", "yes", "on"}:
        return True

    if normalized in {"0", "false", "no", "off"}:
        return False

    raise ValueError(
        f"Invalid boolean value for {name}: {value!r}"
    )


def _env_int(name: str, default: int) -> int:
    """Read an integer environment variable."""

    value = os.getenv(name)

    if value is None:
        return default

    try:
        return int(value.strip())
    except ValueError as exc:
        raise ValueError(
            f"Invalid integer value for {name}: {value!r}"
        ) from exc


def _env_float(name: str, default: float) -> float:
    """Read a floating-point environment variable."""

    value = os.getenv(name)

    if value is None:
        return default

    try:
        return float(value.strip())
    except ValueError as exc:
        raise ValueError(
            f"Invalid float value for {name}: {value!r}"
        ) from exc


def _env_str(name: str, default: str) -> str:
    """Read a string environment variable."""

    value = os.getenv(name)

    if value is None:
        return default

    value = value.strip()

    return value if value else default


# ============================================================
# MCP CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class MCPConfig:
    """
    Configuration for the local cTrader MCP server.
    """

    url: str = field(
        default_factory=lambda: _env_str(
            "CTRADER_MCP_URL",
            "http://127.0.0.1:9876/mcp/",
        )
    )

    timeout_seconds: float = field(
        default_factory=lambda: _env_float(
            "CTRADER_MCP_TIMEOUT",
            30.0,
        )
    )

    enabled: bool = field(
        default_factory=lambda: _env_bool(
            "CTRADER_MCP_ENABLED",
            True,
        )
    )


# ============================================================
# AI CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class AIConfig:
    """
    Configuration for the AI reasoning layer.

    The AI remains advisory.

    Python safety systems remain authoritative.
    """

    provider: str = field(
        default_factory=lambda: _env_str(
            "AI_PROVIDER",
            "ollama",
        )
    )

    model: str = field(
        default_factory=lambda: _env_str(
            "AI_MODEL",
            "qwen3:4b",
        )
    )

    base_url: str = field(
        default_factory=lambda: _env_str(
            "OLLAMA_BASE_URL",
            "http://localhost:11434",
        )
    )

    timeout_seconds: float = field(
        default_factory=lambda: _env_float(
            "AI_TIMEOUT_SECONDS",
            90.0,
        )
    )

    max_output_tokens: int = field(
        default_factory=lambda: _env_int(
            "AI_MAX_OUTPUT_TOKENS",
            600,
        )
    )

    enabled: bool = field(
        default_factory=lambda: _env_bool(
            "AI_ENABLED",
            True,
        )
    )


# ============================================================
# TRADING SAFETY CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class RiskConfig:
    """
    Deterministic risk-management configuration.

    These limits must never be overridden by the AI.
    """

    max_risk_percent: float = field(
        default_factory=lambda: _env_float(
            "MAX_RISK_PERCENT",
            2.0,
        )
    )

    default_risk_percent: float = field(
        default_factory=lambda: _env_float(
            "DEFAULT_RISK_PERCENT",
            1.0,
        )
    )

    minimum_reward_risk: float = field(
        default_factory=lambda: _env_float(
            "MINIMUM_REWARD_RISK",
            1.5,
        )
    )

    maximum_open_positions: int = field(
        default_factory=lambda: _env_int(
            "MAX_OPEN_POSITIONS",
            1,
        )
    )

    maximum_daily_loss_percent: float = field(
        default_factory=lambda: _env_float(
            "MAX_DAILY_LOSS_PERCENT",
            3.0,
        )
    )

    maximum_spread: float = field(
        default_factory=lambda: _env_float(
            "MAX_SPREAD",
            5.0,
        )
    )


# ============================================================
# EXECUTION CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class ExecutionConfig:
    """
    Execution safety configuration.

    LIVE execution remains disabled by default.
    """

    dry_run: bool = field(
        default_factory=lambda: _env_bool(
            "DRY_RUN",
            True,
        )
    )

    live_trading_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "LIVE_TRADING_ENABLED",
            False,
        )
    )

    require_final_safety_gate: bool = field(
        default_factory=lambda: _env_bool(
            "REQUIRE_FINAL_SAFETY_GATE",
            True,
        )
    )

    require_broker_validation: bool = field(
        default_factory=lambda: _env_bool(
            "REQUIRE_BROKER_VALIDATION",
            True,
        )
    )

    kill_switch: bool = field(
        default_factory=lambda: _env_bool(
            "TRADING_KILL_SWITCH",
            False,
        )
    )


# ============================================================
# MARKET DATA CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class MarketDataConfig:
    """
    Market-data collection configuration.
    """

    symbols: tuple[str, ...] = DEFAULT_SYMBOLS

    timeframes: tuple[str, ...] = DEFAULT_TIMEFRAMES

    snapshot_max_age_seconds: float = field(
        default_factory=lambda: _env_float(
            "SNAPSHOT_MAX_AGE_SECONDS",
            10.0,
        )
    )

    bar_limit: int = field(
        default_factory=lambda: _env_int(
            "BAR_LIMIT",
            500,
        )
    )

    tick_collection_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "TICK_COLLECTION_ENABLED",
            True,
        )
    )

    depth_collection_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "DEPTH_COLLECTION_ENABLED",
            False,
        )
    )


# ============================================================
# NEWS / SENTIMENT CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class IntelligenceConfig:
    """
    Configuration for news, sentiment and macro intelligence.
    """

    news_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "NEWS_ENABLED",
            True,
        )
    )

    sentiment_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "SENTIMENT_ENABLED",
            True,
        )
    )

    fundamental_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "FUNDAMENTAL_ENABLED",
            True,
        )
    )

    news_limit: int = field(
        default_factory=lambda: _env_int(
            "NEWS_LIMIT",
            50,
        )
    )

    news_stale_after_minutes: int = field(
        default_factory=lambda: _env_int(
            "NEWS_STALE_AFTER_MINUTES",
            180,
        )
    )


# ============================================================
# AGENT CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class AgentConfig:
    """
    Configuration for the intelligent agent/orchestrator.
    """

    enabled: bool = field(
        default_factory=lambda: _env_bool(
            "AGENT_ENABLED",
            True,
        )
    )

    max_tool_calls_per_cycle: int = field(
        default_factory=lambda: _env_int(
            "MAX_TOOL_CALLS_PER_CYCLE",
            20,
        )
    )

    max_cycle_seconds: float = field(
        default_factory=lambda: _env_float(
            "MAX_AGENT_CYCLE_SECONDS",
            120.0,
        )
    )

    allow_ai_tool_selection: bool = field(
        default_factory=lambda: _env_bool(
            "ALLOW_AI_TOOL_SELECTION",
            True,
        )
    )

    require_tool_validation: bool = field(
        default_factory=lambda: _env_bool(
            "REQUIRE_TOOL_VALIDATION",
            True,
        )
    )


# ============================================================
# TRADE MANAGEMENT CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class TradeManagementConfig:
    """
    Configuration for future position-management logic.
    """

    enabled: bool = field(
        default_factory=lambda: _env_bool(
            "TRADE_MANAGEMENT_ENABLED",
            True,
        )
    )

    manage_open_positions: bool = field(
        default_factory=lambda: _env_bool(
            "MANAGE_OPEN_POSITIONS",
            True,
        )
    )

    allow_stop_adjustment: bool = field(
        default_factory=lambda: _env_bool(
            "ALLOW_STOP_ADJUSTMENT",
            False,
        )
    )

    allow_take_profit_adjustment: bool = field(
        default_factory=lambda: _env_bool(
            "ALLOW_TAKE_PROFIT_ADJUSTMENT",
            False,
        )
    )

    allow_partial_close: bool = field(
        default_factory=lambda: _env_bool(
            "ALLOW_PARTIAL_CLOSE",
            False,
        )
    )


# ============================================================
# STORAGE CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class StorageConfig:
    """
    Historical-data and audit-storage configuration.
    """

    enabled: bool = field(
        default_factory=lambda: _env_bool(
            "STORAGE_ENABLED",
            True,
        )
    )

    project_root: Path = PROJECT_ROOT

    data_dir: Path = DATA_DIR

    historical_dir: Path = HISTORICAL_DATA_DIR

    tick_dir: Path = TICK_DATA_DIR

    bar_dir: Path = BAR_DATA_DIR

    news_dir: Path = NEWS_DATA_DIR

    fundamental_dir: Path = FUNDAMENTAL_DATA_DIR

    backtest_dir: Path = BACKTEST_DATA_DIR

    log_dir: Path = LOG_DIR

    audit_dir: Path = AUDIT_DIR

    report_dir: Path = REPORT_DIR


# ============================================================
# BACKTEST CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class BacktestConfig:
    """
    Historical replay/backtesting configuration.
    """

    enabled: bool = field(
        default_factory=lambda: _env_bool(
            "BACKTEST_ENABLED",
            True,
        )
    )

    initial_balance: float = field(
        default_factory=lambda: _env_float(
            "BACKTEST_INITIAL_BALANCE",
            10000.0,
        )
    )

    commission_per_trade: float = field(
        default_factory=lambda: _env_float(
            "BACKTEST_COMMISSION_PER_TRADE",
            0.0,
        )
    )

    slippage_points: float = field(
        default_factory=lambda: _env_float(
            "BACKTEST_SLIPPAGE_POINTS",
            0.0,
        )
    )

    spread_points: float = field(
        default_factory=lambda: _env_float(
            "BACKTEST_SPREAD_POINTS",
            0.0,
        )
    )


# ============================================================
# LOGGING CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class LoggingConfig:
    """
    System logging and audit configuration.
    """

    level: str = field(
        default_factory=lambda: _env_str(
            "LOG_LEVEL",
            "INFO",
        ).upper()
    )

    console_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "LOG_CONSOLE_ENABLED",
            True,
        )
    )

    file_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "LOG_FILE_ENABLED",
            True,
        )
    )

    audit_enabled: bool = field(
        default_factory=lambda: _env_bool(
            "AUDIT_ENABLED",
            True,
        )
    )


# ============================================================
# MASTER CONFIGURATION
# ============================================================

@dataclass(frozen=True)
class AppConfig:
    """
    Complete application configuration.

    Every major subsystem receives its configuration through
    this object instead of independently reading environment
    variables.
    """

    mcp: MCPConfig = field(
        default_factory=MCPConfig
    )

    ai: AIConfig = field(
        default_factory=AIConfig
    )

    risk: RiskConfig = field(
        default_factory=RiskConfig
    )

    execution: ExecutionConfig = field(
        default_factory=ExecutionConfig
    )

    market_data: MarketDataConfig = field(
        default_factory=MarketDataConfig
    )

    intelligence: IntelligenceConfig = field(
        default_factory=IntelligenceConfig
    )

    agent: AgentConfig = field(
        default_factory=AgentConfig
    )

    trade_management: TradeManagementConfig = field(
        default_factory=TradeManagementConfig
    )

    storage: StorageConfig = field(
        default_factory=StorageConfig
    )

    backtest: BacktestConfig = field(
        default_factory=BacktestConfig
    )

    logging: LoggingConfig = field(
        default_factory=LoggingConfig
    )


# ============================================================
# VALIDATION
# ============================================================

def validate_config(config: AppConfig) -> None:
    """
    Validate critical safety and configuration constraints.

    Raises:
        ValueError: if an invalid configuration is detected.
    """

    # --------------------------------------------------------
    # Risk
    # --------------------------------------------------------

    if config.risk.default_risk_percent <= 0:
        raise ValueError(
            "DEFAULT_RISK_PERCENT must be greater than 0."
        )

    if config.risk.max_risk_percent <= 0:
        raise ValueError(
            "MAX_RISK_PERCENT must be greater than 0."
        )

    if (
        config.risk.default_risk_percent
        > config.risk.max_risk_percent
    ):
        raise ValueError(
            "DEFAULT_RISK_PERCENT cannot exceed "
            "MAX_RISK_PERCENT."
        )

    if config.risk.minimum_reward_risk < 1.0:
        raise ValueError(
            "MINIMUM_REWARD_RISK must be at least 1.0."
        )

    if config.risk.maximum_open_positions < 1:
        raise ValueError(
            "MAX_OPEN_POSITIONS must be at least 1."
        )

    if config.risk.maximum_daily_loss_percent <= 0:
        raise ValueError(
            "MAX_DAILY_LOSS_PERCENT must be greater than 0."
        )

    if config.risk.maximum_spread < 0:
        raise ValueError(
            "MAX_SPREAD cannot be negative."
        )

    # --------------------------------------------------------
    # Execution safety
    # --------------------------------------------------------

    if config.execution.live_trading_enabled:
        raise ValueError(
            "LIVE_TRADING_ENABLED=True is intentionally "
            "blocked by the current safety configuration. "
            "Live execution must be enabled only after "
            "explicit production-readiness changes."
        )

    # --------------------------------------------------------
    # AI
    # --------------------------------------------------------

    if config.ai.timeout_seconds <= 0:
        raise ValueError(
            "AI_TIMEOUT_SECONDS must be greater than 0."
        )

    if config.ai.max_output_tokens <= 0:
        raise ValueError(
            "AI_MAX_OUTPUT_TOKENS must be greater than 0."
        )

    # --------------------------------------------------------
    # MCP
    # --------------------------------------------------------

    if not config.mcp.url:
        raise ValueError(
            "CTRADER_MCP_URL cannot be empty."
        )

    if config.mcp.timeout_seconds <= 0:
        raise ValueError(
            "CTRADER_MCP_TIMEOUT must be greater than 0."
        )

    # --------------------------------------------------------
    # Market data
    # --------------------------------------------------------

    if not config.market_data.symbols:
        raise ValueError(
            "At least one trading symbol is required."
        )

    if not config.market_data.timeframes:
        raise ValueError(
            "At least one timeframe is required."
        )

    if config.market_data.bar_limit <= 0:
        raise ValueError(
            "BAR_LIMIT must be greater than 0."
        )

    # --------------------------------------------------------
    # Agent
    # --------------------------------------------------------

    if config.agent.max_tool_calls_per_cycle <= 0:
        raise ValueError(
            "MAX_TOOL_CALLS_PER_CYCLE must be greater than 0."
        )

    if config.agent.max_cycle_seconds <= 0:
        raise ValueError(
            "MAX_AGENT_CYCLE_SECONDS must be greater than 0."
        )

    # --------------------------------------------------------
    # Backtesting
    # --------------------------------------------------------

    if config.backtest.initial_balance <= 0:
        raise ValueError(
            "BACKTEST_INITIAL_BALANCE must be greater than 0."
        )

    if config.backtest.commission_per_trade < 0:
        raise ValueError(
            "BACKTEST_COMMISSION_PER_TRADE cannot be negative."
        )

    if config.backtest.slippage_points < 0:
        raise ValueError(
            "BACKTEST_SLIPPAGE_POINTS cannot be negative."
        )

    if config.backtest.spread_points < 0:
        raise ValueError(
            "BACKTEST_SPREAD_POINTS cannot be negative."
        )


# ============================================================
# DIRECTORY INITIALIZATION
# ============================================================

def ensure_directories(config: AppConfig) -> None:
    """
    Create required application directories.

    This does not modify broker/account state.
    """

    directories = (
        config.storage.data_dir,
        config.storage.historical_dir,
        config.storage.tick_dir,
        config.storage.bar_dir,
        config.storage.news_dir,
        config.storage.fundamental_dir,
        config.storage.backtest_dir,
        config.storage.log_dir,
        config.storage.audit_dir,
        config.storage.report_dir,
    )

    for directory in directories:
        directory.mkdir(
            parents=True,
            exist_ok=True,
        )


# ============================================================
# CONFIGURATION FACTORY
# ============================================================

def load_config() -> AppConfig:
    """
    Build, validate and initialize the application configuration.

    Returns:
        AppConfig
    """

    config = AppConfig()

    validate_config(config)

    ensure_directories(config)

    return config


# ============================================================
# DEFAULT GLOBAL CONFIG
# ============================================================

CONFIG = load_config()


# ============================================================
# PUBLIC API
# ============================================================

__all__ = [
    "PROJECT_ROOT",
    "APP_DIR",
    "DATA_DIR",
    "HISTORICAL_DATA_DIR",
    "TICK_DATA_DIR",
    "BAR_DATA_DIR",
    "NEWS_DATA_DIR",
    "FUNDAMENTAL_DATA_DIR",
    "BACKTEST_DATA_DIR",
    "LOG_DIR",
    "AUDIT_DIR",
    "REPORT_DIR",
    "DEFAULT_SYMBOLS",
    "DEFAULT_TIMEFRAMES",
    "MCPConfig",
    "AIConfig",
    "RiskConfig",
    "ExecutionConfig",
    "MarketDataConfig",
    "IntelligenceConfig",
    "AgentConfig",
    "TradeManagementConfig",
    "StorageConfig",
    "BacktestConfig",
    "LoggingConfig",
    "AppConfig",
    "validate_config",
    "ensure_directories",
    "load_config",
    "CONFIG",
]