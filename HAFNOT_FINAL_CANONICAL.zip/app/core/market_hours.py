"""
Broker-defined market hours: is an instrument actually tradeable right now?

WHY THIS EXISTS
---------------
The supervisor treated any market feed older than 90 seconds as a fault:
it restarted the cTrader worker and the paper engine. When the market is
simply CLOSED, feeds go quiet by design - so every weekend, and during
XAUUSD's daily one-hour break, it restart-looped roughly every 100
seconds. Worse, each reconnect writes subscription data into the event
files, which made the freshness check report "MARKET RECOVERY COMPLETE"
even though no real market data had returned.

The fix is to know when a market is closed, from the broker's own data
rather than hardcoded session times. hafnot_fetch_symbol_specs.py stores
each symbol's schedule (ProtoOASymbol.schedule / scheduleTimeZone /
holiday) in data/broker/symbol_specs.json.

HOW THE BROKER SCHEDULE IS ENCODED (verified against live behaviour)
--------------------------------------------------------------------
- Each interval is [start_second, end_second): seconds from Sunday 00:00
  in the schedule's own IANA time zone (America/New_York for Pepperstone
  FX and gold). DST is handled by zoneinfo, not by a fixed UTC offset.
  e.g. EURUSD 61260 -> Sunday 17:01 NY; XAUUSD 64860 -> Sunday 18:01 NY,
  with a daily 16:59-18:01 NY break that FX does not have.
- Holidays carry their own time zone, a date as days since the Unix
  epoch, and a seconds-of-day window. MessageToDict omits proto3 default
  values, so an absent startSecond means 0 and an absent isRecurring
  means False.

RELATIONSHIP TO app.core.sessions
---------------------------------
app.core.sessions labels ANALYTICAL sessions (Tokyo/London/New York) from
conventional clock hours and has no notion of weekends - it will report
london_open=True on a Saturday morning. That is correct for its purpose.
This module answers a different question: whether the broker will
actually quote and fill the instrument.

FAIL-SAFE DIRECTION
-------------------
is_market_open returns None when no schedule is known. Callers must NOT
read None as "closed": suppressing outage recovery on a guess could hide
a real broken feed. Only a positive "closed" from broker data suppresses
recovery.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Optional
from zoneinfo import ZoneInfo

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SYMBOL_SPECS_FILE = PROJECT_ROOT / "data" / "broker" / "symbol_specs.json"

SECONDS_PER_DAY = 86_400
SECONDS_PER_WEEK = 7 * SECONDS_PER_DAY
UNIX_EPOCH_DATE = date(1970, 1, 1)


@dataclass(frozen=True)
class Holiday:
    name: str
    time_zone: str
    holiday_date: date
    start_second: int
    end_second: int
    is_recurring: bool


@dataclass(frozen=True)
class SymbolSchedule:
    symbol: str
    time_zone: str
    intervals: tuple[tuple[int, int], ...]
    holidays: tuple[Holiday, ...] = ()


@dataclass(frozen=True)
class StaleFeedAssessment:
    """How to interpret a set of stale market feeds at one instant."""

    expected_closed: tuple[str, ...]
    unexpected: tuple[str, ...]

    @property
    def requires_recovery(self) -> bool:
        return bool(self.unexpected)


def _as_utc(instant: Optional[datetime]) -> datetime:
    if instant is None:
        return datetime.now(timezone.utc)
    if instant.tzinfo is None:
        return instant.replace(tzinfo=timezone.utc)
    return instant


def _zone(name: str) -> Optional[ZoneInfo]:
    try:
        return ZoneInfo(name)
    except Exception:
        return None


def _week_second(instant_utc: datetime, zone: ZoneInfo) -> int:
    local = instant_utc.astimezone(zone)
    days_since_sunday = (local.weekday() + 1) % 7
    return (
        days_since_sunday * SECONDS_PER_DAY
        + local.hour * 3600
        + local.minute * 60
        + local.second
    )


def _in_interval(week_second: int, start: int, end: int) -> bool:
    # An interval may run past the end of the week (e.g. Saturday night
    # into Sunday); the second comparison catches the wrapped portion.
    return start <= week_second < end or start <= week_second + SECONDS_PER_WEEK < end


def _in_holiday(instant_utc: datetime, holiday: Holiday) -> bool:
    zone = _zone(holiday.time_zone)
    if zone is None:
        return False

    local = instant_utc.astimezone(zone)

    if holiday.is_recurring:
        same_day = (local.month, local.day) == (holiday.holiday_date.month, holiday.holiday_date.day)
    else:
        same_day = local.date() == holiday.holiday_date

    if not same_day:
        return False

    second_of_day = local.hour * 3600 + local.minute * 60 + local.second
    # The broker uses 86399 (23:59:59) as an inclusive end of day.
    return holiday.start_second <= second_of_day <= holiday.end_second


def parse_schedule(symbol: str, spec: dict[str, Any]) -> Optional[SymbolSchedule]:
    """Build a SymbolSchedule from one entry of symbol_specs.json."""

    time_zone = spec.get("schedule_time_zone")
    raw_intervals = spec.get("schedule") or []

    if not time_zone or not raw_intervals or _zone(time_zone) is None:
        return None

    try:
        intervals = tuple(
            (int(item["start_second"]), int(item["end_second"]))
            for item in raw_intervals
        )
    except (KeyError, TypeError, ValueError):
        return None

    holidays: list[Holiday] = []

    for raw in spec.get("holidays") or []:
        try:
            holidays.append(
                Holiday(
                    name=str(raw.get("name", "")),
                    time_zone=str(raw.get("scheduleTimeZone") or time_zone),
                    holiday_date=UNIX_EPOCH_DATE + timedelta(days=int(raw["holidayDate"])),
                    start_second=int(raw.get("startSecond", 0)),
                    end_second=int(raw.get("endSecond", SECONDS_PER_DAY - 1)),
                    is_recurring=bool(raw.get("isRecurring", False)),
                )
            )
        except (KeyError, TypeError, ValueError):
            continue

    return SymbolSchedule(
        symbol=symbol.upper(),
        time_zone=time_zone,
        intervals=intervals,
        holidays=tuple(holidays),
    )


def load_schedules(path: Optional[Path] = None) -> dict[str, SymbolSchedule]:
    source = path or SYMBOL_SPECS_FILE

    if not source.exists():
        return {}

    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
    except Exception:
        return {}

    schedules: dict[str, SymbolSchedule] = {}

    for symbol, spec in (payload.get("symbols") or {}).items():
        schedule = parse_schedule(symbol, spec)
        if schedule is not None:
            schedules[symbol.upper()] = schedule

    return schedules


def is_market_open(
    symbol: str,
    instant_utc: Optional[datetime] = None,
    schedules: Optional[dict[str, SymbolSchedule]] = None,
) -> Optional[bool]:
    """
    True / False from the broker's schedule and holidays; None when no
    usable schedule is known for the symbol. None is not "closed".
    """

    instant = _as_utc(instant_utc)
    known = load_schedules() if schedules is None else schedules
    schedule = known.get(symbol.upper())

    if schedule is None:
        return None

    zone = _zone(schedule.time_zone)
    if zone is None:
        return None

    week_second = _week_second(instant, zone)

    if not any(_in_interval(week_second, start, end) for start, end in schedule.intervals):
        return False

    if any(_in_holiday(instant, holiday) for holiday in schedule.holidays):
        return False

    return True


def assess_stale_feeds(
    stale_symbols: Iterable[str],
    instant_utc: Optional[datetime] = None,
    schedules: Optional[dict[str, SymbolSchedule]] = None,
) -> StaleFeedAssessment:
    """
    Split stale feeds into those explained by a closed market and those
    that are not. A symbol with no known schedule is 'unexpected', so a
    genuine outage is never hidden behind a missing schedule.
    """

    instant = _as_utc(instant_utc)
    known = load_schedules() if schedules is None else schedules

    expected: list[str] = []
    unexpected: list[str] = []

    for symbol in stale_symbols:
        if is_market_open(symbol, instant, known) is False:
            expected.append(symbol)
        else:
            unexpected.append(symbol)

    return StaleFeedAssessment(
        expected_closed=tuple(expected),
        unexpected=tuple(unexpected),
    )


def open_symbols(
    symbols: Iterable[str],
    instant_utc: Optional[datetime] = None,
    schedules: Optional[dict[str, SymbolSchedule]] = None,
) -> list[str]:
    """Symbols whose market is not positively known to be closed."""

    instant = _as_utc(instant_utc)
    known = load_schedules() if schedules is None else schedules
    return [s for s in symbols if is_market_open(s, instant, known) is not False]
