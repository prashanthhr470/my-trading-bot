"""
Deterministic kill switch.

Two independent trip conditions, both fail-safe (default is "not tripped"
only when nothing indicates a problem):

1. MANUAL: an operator creates data/control/KILL_SWITCH (any content, even
   empty). Delete the file to resume. This is the emergency stop a human
   can hit at any time without touching code.

2. AUTOMATIC: consecutive-loss protection. If a symbol's paper account has
   hit or exceeded MAX_CONSECUTIVE_LOSSES trailing losing trades, the
   switch trips for that account until a winning trade resets the streak
   or an operator clears it manually (deleting the paper account's losing
   streak requires deleting KILL_SWITCH and acknowledging the situation;
   the streak itself only resets on a real win).

This module makes no trading decision. It only reports a boolean that the
deterministic ExecutionSafetyGate consumes.
"""

from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]

CONTROL_DIR = PROJECT_ROOT / "data" / "control"
MANUAL_KILL_SWITCH_FILE = CONTROL_DIR / "KILL_SWITCH"

MAX_CONSECUTIVE_LOSSES = 5


def is_manually_tripped() -> bool:
    """True if an operator has placed the manual kill-switch file."""

    try:
        return MANUAL_KILL_SWITCH_FILE.exists()
    except OSError:
        # Fail closed: if we cannot even check, assume the worst.
        return True


def trip_manual_kill_switch(reason: str = "") -> None:
    """Create the manual kill-switch file (operator or automated call)."""

    CONTROL_DIR.mkdir(parents=True, exist_ok=True)

    MANUAL_KILL_SWITCH_FILE.write_text(
        reason or "Kill switch engaged.",
        encoding="utf-8",
    )


def clear_manual_kill_switch() -> None:
    """Remove the manual kill-switch file, if present."""

    try:
        MANUAL_KILL_SWITCH_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def is_tripped(consecutive_losses: int = 0) -> bool:
    """
    Combined kill-switch state: manual flag OR consecutive-loss breach.
    """

    if is_manually_tripped():
        return True

    if consecutive_losses >= MAX_CONSECUTIVE_LOSSES:
        return True

    return False
