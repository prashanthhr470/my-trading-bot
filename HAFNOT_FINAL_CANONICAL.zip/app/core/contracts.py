"""
HAFNOT AI TRADING AGENT
CORE DATA CONTRACTS

Phase 2 foundation.

Purpose:
    Provide stable, typed, serializable data contracts shared by:

    - Market data
    - Tick data
    - Technical analysis
    - Fundamentals
    - News
    - Sentiment
    - Market regime
    - Liquidity
    - Evidence
    - AI reasoning
    - Tool selection
    - Risk management
    - Trade planning
    - Execution
    - Trade management
    - Historical storage
    - Backtesting
    - Logging / audit
    - Health monitoring

IMPORTANT:
    These contracts do not execute trades.
    They do not call brokers.
    They do not call AI.
    They are data structures only.

SAFETY:
    Execution remains controlled by the existing deterministic
    risk and execution-safety layers.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional


# ============================================================
# ENUMS
# ============================================================


class Decision(str, Enum):
    BUY_CANDIDATE = "BUY_CANDIDATE"
    SELL_CANDIDATE = "SELL_CANDIDATE"
    WAIT = "WAIT"
    NO_TRADE = "NO_TRADE"


class Direction(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    NONE = "NONE"


class Confidence(str, Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    NONE = "NONE"


class DataStatus(str, Enum):
    AVAILABLE = "AVAILABLE"
    PARTIAL = "PARTIAL"
    STALE = "STALE"
    MISSING = "MISSING"
    INVALID = "INVALID"
    UNAVAILABLE = "UNAVAILABLE"


class DataQuality(str, Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    UNKNOWN = "UNKNOWN"


class SentimentDirection(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"
    MIXED = "MIXED"
    UNKNOWN = "UNKNOWN"


class MarketRegime(str, Enum):
    TRENDING_BULLISH = "TRENDING_BULLISH"
    TRENDING_BEARISH = "TRENDING_BEARISH"
    RANGING = "RANGING"
    EXPANSION = "EXPANSION"
    CONTRACTION = "CONTRACTION"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    LOW_VOLATILITY = "LOW_VOLATILITY"
    NEWS_DRIVEN = "NEWS_DRIVEN"
    TRANSITION = "TRANSITION"
    UNKNOWN = "UNKNOWN"


class AgentState(str, Enum):
    IDLE = "IDLE"
    COLLECTING_DATA = "COLLECTING_DATA"
    ANALYZING = "ANALYZING"
    WAITING_FOR_CONFIRMATION = "WAITING_FOR_CONFIRMATION"
    TRADE_CANDIDATE = "TRADE_CANDIDATE"
    RISK_CHECK = "RISK_CHECK"
    EXECUTION_READY = "EXECUTION_READY"
    IN_TRADE = "IN_TRADE"
    MANAGING_TRADE = "MANAGING_TRADE"
    EXITING = "EXITING"
    COOLDOWN = "COOLDOWN"
    ERROR = "ERROR"


class ToolStatus(str, Enum):
    SELECTED = "SELECTED"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    STALE = "STALE"


class TradeLifecycle(str, Enum):
    PLANNED = "PLANNED"
    VALIDATED = "VALIDATED"
    READY = "READY"
    SUBMITTED = "SUBMITTED"
    OPEN = "OPEN"
    MANAGING = "MANAGING"
    PARTIALLY_CLOSED = "PARTIALLY_CLOSED"
    CLOSED = "CLOSED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    ERROR = "ERROR"


# ============================================================
# TIME HELPERS
# ============================================================


def utc_now() -> datetime:
    """
    Return the current UTC time as a timezone-aware datetime.
    """
    return datetime.now(timezone.utc)


def ensure_utc(value: Optional[datetime]) -> datetime:
    """
    Normalize a datetime to timezone-aware UTC.

    Naive datetimes are interpreted as UTC because the trading
    system must never silently mix local time with market time.
    """
    if value is None:
        return utc_now()

    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)

    return value.astimezone(timezone.utc)


# ============================================================
# DATA QUALITY
# ============================================================


@dataclass
class DataQualityReport:
    """
    Describes the reliability of a piece of market information.
    """

    status: DataStatus = DataStatus.UNAVAILABLE
    quality: DataQuality = DataQuality.UNKNOWN

    source: Optional[str] = None

    collected_at: datetime = field(default_factory=utc_now)

    source_timestamp: Optional[datetime] = None

    age_seconds: Optional[float] = None

    expected_max_age_seconds: Optional[float] = None

    completeness: float = 0.0

    issues: List[str] = field(default_factory=list)

    warnings: List[str] = field(default_factory=list)

    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.collected_at = ensure_utc(self.collected_at)

        if self.source_timestamp is not None:
            self.source_timestamp = ensure_utc(
                self.source_timestamp
            )

        self.completeness = max(
            0.0,
            min(1.0, float(self.completeness)),
        )

    @property
    def usable(self) -> bool:
        return self.status in {
            DataStatus.AVAILABLE,
            DataStatus.PARTIAL,
        } and self.quality != DataQuality.UNKNOWN


# ============================================================
# TICK
# ============================================================


@dataclass
class Tick:
    """
    Normalized market tick.

    This contract intentionally supports both the currently
    available spot-price architecture and the future cTrader
    Open API tick stream.
    """

    symbol: str

    timestamp: datetime

    bid: Optional[float] = None

    ask: Optional[float] = None

    last: Optional[float] = None

    bid_size: Optional[float] = None

    ask_size: Optional[float] = None

    last_size: Optional[float] = None

    volume: Optional[float] = None

    source: str = "unknown"

    sequence: Optional[int] = None

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(self.timestamp)

    @property
    def mid(self) -> Optional[float]:
        if self.bid is not None and self.ask is not None:
            return (self.bid + self.ask) / 2.0

        if self.last is not None:
            return self.last

        return None

    @property
    def spread(self) -> Optional[float]:
        if self.bid is None or self.ask is None:
            return None

        return max(0.0, self.ask - self.bid)


# ============================================================
# OHLC BAR
# ============================================================


@dataclass
class OHLCBar:
    """
    Normalized historical or live OHLC bar.
    """

    symbol: str

    timeframe: str

    timestamp: datetime

    open: float

    high: float

    low: float

    close: float

    volume: Optional[float] = None

    tick_volume: Optional[float] = None

    spread: Optional[float] = None

    source: str = "unknown"

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(self.timestamp)


# ============================================================
# MARKET SNAPSHOT
# ============================================================


@dataclass
class MarketSnapshot:
    """
    Unified market snapshot.

    Existing market_data.py dictionaries can be adapted into
    this contract without forcing the rest of the system to
    understand cTrader-specific response formats.
    """

    symbol: str

    timestamp: datetime

    spot: Dict[str, Any] = field(default_factory=dict)

    timeframes: Dict[str, Dict[str, Any]] = field(
        default_factory=dict
    )

    indicators: Dict[str, Any] = field(
        default_factory=dict
    )

    sessions: Dict[str, Any] = field(
        default_factory=dict
    )

    capabilities: Dict[str, Any] = field(
        default_factory=dict
    )

    quality: Optional[DataQualityReport] = None

    source: str = "unknown"

    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(self.timestamp)


# ============================================================
# SENTIMENT
# ============================================================


@dataclass
class SentimentSignal:
    """
    A single normalized sentiment signal.

    Sentiment is evidence only.
    It does not directly authorize trading.
    """

    subject: str

    direction: SentimentDirection

    strength: float = 0.0

    confidence: Confidence = Confidence.NONE

    source: Optional[str] = None

    timestamp: datetime = field(default_factory=utc_now)

    expires_at: Optional[datetime] = None

    reasons: List[str] = field(default_factory=list)

    conflicts: List[str] = field(default_factory=list)

    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(self.timestamp)

        if self.expires_at is not None:
            self.expires_at = ensure_utc(
                self.expires_at
            )

        self.strength = max(
            -1.0,
            min(1.0, float(self.strength)),
        )


@dataclass
class SentimentSnapshot:
    """
    Aggregated sentiment state for the current analysis cycle.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    overall_direction: SentimentDirection = (
        SentimentDirection.UNKNOWN
    )

    overall_strength: float = 0.0

    confidence: Confidence = Confidence.NONE

    risk_on_off: SentimentDirection = (
        SentimentDirection.UNKNOWN
    )

    currency_sentiment: Dict[
        str,
        SentimentSignal
    ] = field(default_factory=dict)

    gold_sentiment: Optional[SentimentSignal] = None

    signals: List[SentimentSignal] = field(
        default_factory=list
    )

    conflicts: List[str] = field(
        default_factory=list
    )

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )

        self.overall_strength = max(
            -1.0,
            min(
                1.0,
                float(self.overall_strength),
            ),
        )


# ============================================================
# MARKET REGIME
# ============================================================


@dataclass
class MarketRegimeSnapshot:
    """
    Current market regime and supporting measurements.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    regime: MarketRegime = MarketRegime.UNKNOWN

    confidence: Confidence = Confidence.NONE

    trend_strength: float = 0.0

    volatility_level: float = 0.0

    range_score: float = 0.0

    expansion_score: float = 0.0

    contraction_score: float = 0.0

    news_driven: bool = False

    reasons: List[str] = field(
        default_factory=list
    )

    conflicts: List[str] = field(
        default_factory=list
    )

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# FUNDAMENTAL
# ============================================================


@dataclass
class FundamentalSnapshot:
    """
    Normalized fundamental evidence.

    Existing fundamental_engine.py remains responsible for
    producing the actual fundamental analysis.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    direction: str = "NEUTRAL"

    strength: float = 0.0

    confidence: Confidence = Confidence.NONE

    actionable: bool = False

    conflict: bool = False

    currency: Dict[str, Any] = field(
        default_factory=dict
    )

    pair: Dict[str, Any] = field(
        default_factory=dict
    )

    monetary_policy: Dict[str, Any] = field(
        default_factory=dict
    )

    upcoming_event_risk: Dict[str, Any] = field(
        default_factory=dict
    )

    released_events: Dict[str, Any] = field(
        default_factory=dict
    )

    quality: Optional[DataQualityReport] = None

    reasons: List[str] = field(
        default_factory=list
    )

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )

        self.strength = max(
            0.0,
            min(
                1.0,
                float(self.strength),
            ),
        )


# ============================================================
# NEWS
# ============================================================


@dataclass
class NewsSnapshot:
    """
    Normalized news-risk information.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    status: str = "UNAVAILABLE"

    risk_level: str = "UNKNOWN"

    high_impact_count: int = 0

    relevant_count: int = 0

    imminent_count: int = 0

    events: List[Dict[str, Any]] = field(
        default_factory=list
    )

    restrictions: List[str] = field(
        default_factory=list
    )

    reasons: List[str] = field(
        default_factory=list
    )

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# LIQUIDITY
# ============================================================


@dataclass
class LiquiditySnapshot:
    """
    Normalized liquidity evidence.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    nearest_level: Optional[float] = None

    nearest_level_type: Optional[str] = None

    buy_side_levels: List[float] = field(
        default_factory=list
    )

    sell_side_levels: List[float] = field(
        default_factory=list
    )

    sweeps: List[Dict[str, Any]] = field(
        default_factory=list
    )

    liquidity_bias: str = "NEUTRAL"

    confidence: Confidence = Confidence.NONE

    reasons: List[str] = field(
        default_factory=list
    )

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# STRUCTURE
# ============================================================


@dataclass
class StructureSnapshot:
    """
    Normalized market-structure evidence.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    structure_type: str = "UNKNOWN"

    higher_timeframe_structure: str = "UNKNOWN"

    lower_timeframe_structure: str = "UNKNOWN"

    bullish_score: float = 0.0

    bearish_score: float = 0.0

    swing_highs: List[float] = field(
        default_factory=list
    )

    swing_lows: List[float] = field(
        default_factory=list
    )

    break_of_structure: bool = False

    change_of_character: bool = False

    confirmation: bool = False

    reasons: List[str] = field(
        default_factory=list
    )

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# EVIDENCE
# ============================================================


@dataclass
class EvidenceSnapshot:
    """
    Unified evidence state.

    This becomes the common input to the reasoning layer.
    """

    symbol: str

    timestamp: datetime = field(default_factory=utc_now)

    bias: str = "UNKNOWN"

    confidence: Confidence = Confidence.NONE

    market: Dict[str, Any] = field(
        default_factory=dict
    )

    technical: Dict[str, Any] = field(
        default_factory=dict
    )

    structure: Dict[str, Any] = field(
        default_factory=dict
    )

    liquidity: Dict[str, Any] = field(
        default_factory=dict
    )

    fundamentals: Dict[str, Any] = field(
        default_factory=dict
    )

    news: Dict[str, Any] = field(
        default_factory=dict
    )

    sentiment: Dict[str, Any] = field(
        default_factory=dict
    )

    regime: Dict[str, Any] = field(
        default_factory=dict
    )

    conflicts: List[str] = field(
        default_factory=list
    )

    missing_information: List[str] = field(
        default_factory=list
    )

    warnings: List[str] = field(
        default_factory=list
    )

    quality: Optional[DataQualityReport] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# AI
# ============================================================


@dataclass
class AIDecision:
    """
    Normalized AI response.

    This represents what AI suggests.
    It does NOT authorize execution.
    """

    symbol: str

    decision: Decision = Decision.NO_TRADE

    direction: Direction = Direction.NONE

    bias: str = "UNKNOWN"

    confidence: Confidence = Confidence.NONE

    setup_quality: str = "LOW"

    reasoning: str = ""

    conflicts: List[str] = field(
        default_factory=list
    )

    missing_information: List[str] = field(
        default_factory=list
    )

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    timestamp: datetime = field(
        default_factory=utc_now
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# TOOL SELECTION
# ============================================================


@dataclass
class ToolRequest:
    """
    Request made by the agent for additional evidence.
    """

    tool_name: str

    purpose: str

    symbol: Optional[str] = None

    timeframe: Optional[str] = None

    priority: int = 0

    required: bool = False

    reason: str = ""

    parameters: Dict[str, Any] = field(
        default_factory=dict
    )

    requested_at: datetime = field(
        default_factory=utc_now
    )

    def __post_init__(self) -> None:
        self.requested_at = ensure_utc(
            self.requested_at
        )


@dataclass
class ToolResult:
    """
    Result returned by an agent-selected tool.
    """

    tool_name: str

    status: ToolStatus

    requested_at: datetime

    completed_at: datetime = field(
        default_factory=utc_now
    )

    data: Any = None

    quality: Optional[DataQualityReport] = None

    error: Optional[str] = None

    warnings: List[str] = field(
        default_factory=list
    )

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.requested_at = ensure_utc(
            self.requested_at
        )

        self.completed_at = ensure_utc(
            self.completed_at
        )


# ============================================================
# AGENT STATE
# ============================================================


@dataclass
class AgentStateSnapshot:
    """
    State of the autonomous analysis agent.
    """

    state: AgentState = AgentState.IDLE

    symbol: Optional[str] = None

    cycle_id: Optional[str] = None

    started_at: datetime = field(
        default_factory=utc_now
    )

    updated_at: datetime = field(
        default_factory=utc_now
    )

    reason: str = ""

    error: Optional[str] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.started_at = ensure_utc(
            self.started_at
        )

        self.updated_at = ensure_utc(
            self.updated_at
        )


# ============================================================
# TRADE PLAN
# ============================================================


@dataclass
class TradePlanContract:
    """
    Unified trade-plan contract.

    This does not replace the existing TradePlan immediately.
    It provides the Phase-2 common representation.
    """

    symbol: str

    status: str = "WAIT"

    decision: Decision = Decision.WAIT

    direction: Direction = Direction.NONE

    entry_price: Optional[float] = None

    stop_loss: Optional[float] = None

    take_profit: Optional[float] = None

    risk_percent: Optional[float] = None

    risk_amount: Optional[float] = None

    position_size: Optional[float] = None

    position_lots: Optional[float] = None

    reward_risk: Optional[float] = None

    broker_valid: bool = False

    execution_allowed: bool = False

    reason: str = ""

    created_at: datetime = field(
        default_factory=utc_now
    )

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.created_at = ensure_utc(
            self.created_at
        )


# ============================================================
# POSITION
# ============================================================


@dataclass
class PositionSnapshot:
    """
    Normalized open-position representation.

    Designed for future trade management and broker
    synchronization.
    """

    position_id: Optional[str]

    symbol: str

    direction: Direction = Direction.NONE

    volume_units: Optional[float] = None

    volume_lots: Optional[float] = None

    entry_price: Optional[float] = None

    current_price: Optional[float] = None

    stop_loss: Optional[float] = None

    take_profit: Optional[float] = None

    unrealized_pnl: Optional[float] = None

    realized_pnl: Optional[float] = None

    open_time: Optional[datetime] = None

    lifecycle: TradeLifecycle = TradeLifecycle.OPEN

    broker_source: Optional[str] = None

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        if self.open_time is not None:
            self.open_time = ensure_utc(
                self.open_time
            )


# ============================================================
# TRADE EVENT
# ============================================================


@dataclass
class TradeEvent:
    """
    Immutable-style event used by trade management and audit.
    """

    event_type: str

    symbol: str

    timestamp: datetime = field(
        default_factory=utc_now
    )

    position_id: Optional[str] = None

    order_id: Optional[str] = None

    direction: Direction = Direction.NONE

    price: Optional[float] = None

    volume_units: Optional[float] = None

    pnl: Optional[float] = None

    reason: str = ""

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# AUDIT
# ============================================================


@dataclass
class AuditRecord:
    """
    Structured record explaining what the agent did and why.
    """

    event_type: str

    timestamp: datetime = field(
        default_factory=utc_now
    )

    cycle_id: Optional[str] = None

    symbol: Optional[str] = None

    component: Optional[str] = None

    action: Optional[str] = None

    decision: Optional[str] = None

    state: Optional[str] = None

    reason: Optional[str] = None

    inputs: Dict[str, Any] = field(
        default_factory=dict
    )

    outputs: Dict[str, Any] = field(
        default_factory=dict
    )

    warnings: List[str] = field(
        default_factory=list
    )

    errors: List[str] = field(
        default_factory=list
    )

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )


# ============================================================
# HEALTH
# ============================================================


@dataclass
class ComponentHealth:
    """
    Health state of an individual subsystem.
    """

    component: str

    status: str = "UNKNOWN"

    timestamp: datetime = field(
        default_factory=utc_now
    )

    latency_ms: Optional[float] = None

    last_success: Optional[datetime] = None

    last_error: Optional[datetime] = None

    consecutive_failures: int = 0

    message: str = ""

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        self.timestamp = ensure_utc(
            self.timestamp
        )

        if self.last_success is not None:
            self.last_success = ensure_utc(
                self.last_success
            )

        if self.last_error is not None:
            self.last_error = ensure_utc(
                self.last_error
            )


# ============================================================
# SERIALIZATION
# ============================================================


def to_dict(value: Any) -> Any:
    """
    Recursively convert contracts, enums, datetimes,
    mappings and collections into JSON-compatible values.

    Existing engines can continue using normal dictionaries.
    This helper provides the bridge for the new contracts.
    """

    if isinstance(value, Enum):
        return value.value

    if isinstance(value, datetime):
        return ensure_utc(value).isoformat()

    if is_dataclass(value):
        return {
            key: to_dict(item)
            for key, item in asdict(value).items()
        }

    if isinstance(value, Mapping):
        return {
            str(key): to_dict(item)
            for key, item in value.items()
        }

    if isinstance(value, (list, tuple, set)):
        return [
            to_dict(item)
            for item in value
        ]

    return value


def contract_from_dict(
    contract_type,
    data: Mapping[str, Any],
):
    """
    Lightweight constructor helper.

    It intentionally does not perform aggressive coercion.
    Validation belongs in the relevant subsystem.
    """

    if not is_dataclass(contract_type):
        raise TypeError(
            "contract_type must be a dataclass type."
        )

    if not isinstance(data, Mapping):
        raise TypeError(
            "data must be a mapping."
        )

    return contract_type(**dict(data))


# ============================================================
# CONTRACT VALIDATION HELPERS
# ============================================================


def validate_symbol(symbol: str) -> str:
    """
    Normalize and validate a trading symbol.
    """

    if not isinstance(symbol, str):
        raise TypeError(
            "symbol must be a string."
        )

    normalized = symbol.strip().upper()

    if not normalized:
        raise ValueError(
            "symbol cannot be empty."
        )

    return normalized


def validate_price(
    price: Optional[float],
) -> Optional[float]:
    """
    Validate a price without silently changing it.
    """

    if price is None:
        return None

    value = float(price)

    if value <= 0:
        raise ValueError(
            "price must be greater than zero."
        )

    return value


def clamp_score(
    value: float,
    minimum: float = -1.0,
    maximum: float = 1.0,
) -> float:
    """
    Safely constrain analytical scores.
    """

    value = float(value)

    return max(
        minimum,
        min(maximum, value),
    )


# ============================================================
# PUBLIC EXPORTS
# ============================================================


__all__ = [
    # Enums
    "Decision",
    "Direction",
    "Confidence",
    "DataStatus",
    "DataQuality",
    "SentimentDirection",
    "MarketRegime",
    "AgentState",
    "ToolStatus",
    "TradeLifecycle",

    # Core contracts
    "DataQualityReport",
    "Tick",
    "OHLCBar",
    "MarketSnapshot",
    "SentimentSignal",
    "SentimentSnapshot",
    "MarketRegimeSnapshot",
    "FundamentalSnapshot",
    "NewsSnapshot",
    "LiquiditySnapshot",
    "StructureSnapshot",
    "EvidenceSnapshot",
    "AIDecision",
    "ToolRequest",
    "ToolResult",
    "AgentStateSnapshot",
    "TradePlanContract",
    "PositionSnapshot",
    "TradeEvent",
    "AuditRecord",
    "ComponentHealth",

    # Helpers
    "utc_now",
    "ensure_utc",
    "to_dict",
    "contract_from_dict",
    "validate_symbol",
    "validate_price",
    "clamp_score",
]