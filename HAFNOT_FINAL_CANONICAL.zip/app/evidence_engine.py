# ============================================================
# HAFNOT AI TRADING AGENT
# EVIDENCE ENGINE
# ============================================================
#
# Purpose:
#   Combine all available market evidence into one structured
#   package for the AI reasoning layer.
#
# Evidence sources:
#   1. Market state
#   2. Multi-timeframe momentum
#   3. Market structure
#   4. Support / resistance
#   5. News
#   6. Liquidity
#   7. Fundamental intelligence
#
# IMPORTANT:
#   This module:
#       - DOES NOT place trades
#       - DOES NOT calculate position size
#       - DOES NOT execute orders
#       - DOES NOT bypass the decision gate
#       - DOES NOT turn one evidence source into an
#         unconditional BUY/SELL
#
# CONFIDENCE MODEL:
#
#   This engine distinguishes between:
#
#       A. Directional evidence
#          Evidence that actually supports BUY/SELL.
#
#       B. Genuine uncertainty/conflict
#          Information that reduces confidence.
#
#       C. Neutral observations
#          Useful information that should NOT automatically
#          reduce confidence.
#
#   Examples of neutral observations:
#       - "5 support levels detected."
#       - "2 resistance levels detected."
#       - "Nearest liquidity level..."
#       - "News conditions are currently normal."
#       - "Previous-day liquidity sweep detected."
#
#   These are not automatically negative evidence.
#
# ============================================================


def build_evidence(
    market_state,
    timeframe_summaries,
    structure,
    support_levels=None,
    resistance_levels=None,
    news_analysis=None,
    liquidity_evidence=None,
    fundamental_evidence=None,
):
    """
    Combine all available market intelligence into one
    structured evidence package.

    Parameters
    ----------
    market_state : dict
        Overall / higher / lower timeframe market bias.

    timeframe_summaries : dict
        Per-timeframe analysis and momentum.

    structure : dict
        Market structure information.

    support_levels : list
        Support zones/levels.

    resistance_levels : list
        Resistance zones/levels.

    news_analysis : dict or list or None
        News engine output.

    liquidity_evidence : dict or None
        Liquidity engine output.

    fundamental_evidence : dict or None
        Fundamental engine output.

    Returns
    -------
    dict
        Complete evidence package for downstream AI analysis.
    """

    # ========================================================
    # 1. INPUT NORMALIZATION
    # ========================================================

    if not isinstance(market_state, dict):
        market_state = {}

    if not isinstance(timeframe_summaries, dict):
        timeframe_summaries = {}

    if not isinstance(structure, dict):
        structure = {}

    if support_levels is None:
        support_levels = []

    if not isinstance(support_levels, list):
        support_levels = []

    if resistance_levels is None:
        resistance_levels = []

    if not isinstance(resistance_levels, list):
        resistance_levels = []

    news_available_input = news_analysis is not None

    if news_analysis is None:
        news_analysis = []

    liquidity_available_input = liquidity_evidence is not None

    if liquidity_evidence is None:
        liquidity_evidence = {}

    if not isinstance(liquidity_evidence, dict):
        liquidity_evidence = {}

    fundamental_available_input = fundamental_evidence is not None

    if fundamental_evidence is None:
        fundamental_evidence = {}

    if not isinstance(fundamental_evidence, dict):
        fundamental_evidence = {}

    # ========================================================
    # 2. EVIDENCE CONTAINERS
    # ========================================================

    bullish_evidence = []
    bearish_evidence = []

    # "caution" is kept for compatibility with the rest of
    # the application.
    #
    # IMPORTANT:
    # Not every caution is a confidence penalty.
    caution = []

    # Genuine uncertainty/conflict affecting confidence.
    confidence_issues = []

    # Useful neutral observations.
    observations = []

    # ========================================================
    # 3. MARKET DIRECTION
    # ========================================================

    overall_bias = str(
        market_state.get(
            "overall_bias",
            "unknown",
        )
    ).lower()

    higher_bias = str(
        market_state.get(
            "higher_timeframe_bias",
            "unknown",
        )
    ).lower()

    lower_bias = str(
        market_state.get(
            "lower_timeframe_bias",
            "unknown",
        )
    ).lower()

    # --------------------------------------------------------
    # Overall bias
    # --------------------------------------------------------

    if overall_bias == "bullish":

        bullish_evidence.append(
            "Overall timeframe bias is bullish."
        )

    elif overall_bias == "bearish":

        bearish_evidence.append(
            "Overall timeframe bias is bearish."
        )

    else:

        caution.append(
            "Overall timeframe bias is mixed or unknown."
        )

        confidence_issues.append(
            "Overall timeframe bias is mixed or unknown."
        )

    # --------------------------------------------------------
    # Higher timeframe
    # --------------------------------------------------------

    if higher_bias == "bullish":

        bullish_evidence.append(
            "Higher timeframes have bullish bias."
        )

    elif higher_bias == "bearish":

        bearish_evidence.append(
            "Higher timeframes have bearish bias."
        )

    else:

        caution.append(
            "Higher timeframe bias is mixed."
        )

        confidence_issues.append(
            "Higher timeframe bias is mixed or unknown."
        )

    # --------------------------------------------------------
    # Lower timeframe
    # --------------------------------------------------------

    if lower_bias == "bullish":

        bullish_evidence.append(
            "Lower timeframes have bullish bias."
        )

    elif lower_bias == "bearish":

        bearish_evidence.append(
            "Lower timeframes have bearish bias."
        )

    else:

        caution.append(
            "Lower timeframe bias is mixed or unknown."
        )

        confidence_issues.append(
            "Lower timeframe bias is mixed or unknown."
        )

    # ========================================================
    # 4. MOMENTUM
    # ========================================================

    oversold_timeframes = []
    overbought_timeframes = []

    momentum_values = []

    for timeframe, summary in timeframe_summaries.items():

        if not isinstance(summary, dict):
            continue

        momentum = str(
            summary.get(
                "momentum",
                "",
            )
        ).lower()

        if momentum:
            momentum_values.append(
                momentum
            )

        if momentum == "oversold":

            oversold_timeframes.append(
                str(timeframe).upper()
            )

        elif momentum == "overbought":

            overbought_timeframes.append(
                str(timeframe).upper()
            )

    if oversold_timeframes:

        observation = (
            "Oversold: "
            + ", ".join(
                oversold_timeframes
            )
        )

        caution.append(observation)
        observations.append(observation)

    if overbought_timeframes:

        observation = (
            "Overbought: "
            + ", ".join(
                overbought_timeframes
            )
        )

        caution.append(observation)
        observations.append(observation)

    # ========================================================
    # 5. MARKET STRUCTURE
    # ========================================================

    structure_type = str(
        structure.get(
            "structure",
            structure.get(
                "type",
                "unknown",
            ),
        )
    ).lower()

    high_pattern = str(
        structure.get(
            "high_pattern",
            "unknown",
        )
    ).lower()

    low_pattern = str(
        structure.get(
            "low_pattern",
            "unknown",
        )
    ).lower()

    dominant_structure = str(
        structure.get(
            "dominant_structure",
            structure_type,
        )
    ).lower()

    recent_structure = str(
        structure.get(
            "recent_structure",
            structure_type,
        )
    ).lower()

    structure_context = str(
        structure.get(
            "structure_context",
            "unknown",
        )
    ).lower()

    swing_high_count = structure.get(
        "swing_high_count",
        0,
    )

    swing_low_count = structure.get(
        "swing_low_count",
        0,
    )

    # --------------------------------------------------------
    # Dominant structure
    # --------------------------------------------------------

    if dominant_structure == "bullish":

        bullish_evidence.append(
            "Dominant market structure is bullish."
        )

    elif dominant_structure == "bearish":

        bearish_evidence.append(
            "Dominant market structure is bearish."
        )

    elif dominant_structure == "mixed":

        caution.append(
            "Market structure is mixed."
        )

        confidence_issues.append(
            "Market structure is mixed."
        )

    else:

        caution.append(
            "Dominant market structure is insufficient."
        )

        confidence_issues.append(
            "Dominant market structure is insufficient."
        )

    # --------------------------------------------------------
    # Recent structure
    # --------------------------------------------------------

    if recent_structure in {
        "bullish",
        "bearish",
    }:

        if (
            dominant_structure in {
                "bullish",
                "bearish",
            }
            and recent_structure != dominant_structure
        ):

            message = (
                "Recent structure differs from "
                "dominant structure."
            )

            caution.append(message)
            confidence_issues.append(message)

        else:

            message = (
                f"Recent structure confirms "
                f"{recent_structure} direction."
            )

            caution.append(message)
            observations.append(message)

    # --------------------------------------------------------
    # Structure context
    # --------------------------------------------------------

    if structure_context not in {
        "",
        "unknown",
        "insufficient_data",
        "none",
    }:

        message = (
            f"Structure context: "
            f"{structure_context}."
        )

        caution.append(message)
        observations.append(message)

    # --------------------------------------------------------
    # Swing data quality
    # --------------------------------------------------------

    try:
        swing_high_count_value = int(
            swing_high_count
        )
    except (
        TypeError,
        ValueError,
    ):
        swing_high_count_value = 0

    try:
        swing_low_count_value = int(
            swing_low_count
        )
    except (
        TypeError,
        ValueError,
    ):
        swing_low_count_value = 0

    if (
        swing_high_count_value <= 0
        or swing_low_count_value <= 0
    ):

        confidence_issues.append(
            "Insufficient swing-point information."
        )

    # ========================================================
    # 6. SUPPORT / RESISTANCE
    # ========================================================

    if support_levels:

        message = (
            f"{len(support_levels)} "
            f"support levels detected."
        )

        caution.append(message)
        observations.append(message)

    if resistance_levels:

        message = (
            f"{len(resistance_levels)} "
            f"resistance levels detected."
        )

        caution.append(message)
        observations.append(message)

    # --------------------------------------------------------
    # Normalize levels
    # --------------------------------------------------------

    def _normalize_levels(levels):

        normalized = []

        for level in levels:

            if not isinstance(level, dict):
                continue

            try:

                price = float(
                    level.get(
                        "price"
                    )
                )

            except (
                TypeError,
                ValueError,
            ):

                continue

            if price <= 0:
                continue

            item = dict(level)

            item["price"] = price

            normalized.append(
                item
            )

        return normalized

    support_evidence = _normalize_levels(
        support_levels
    )

    resistance_evidence = _normalize_levels(
        resistance_levels
    )

    # --------------------------------------------------------
    # Level strength
    # --------------------------------------------------------

    def _level_strength(level):

        value = level.get(
            "strength",
            level.get(
                "touch_count",
                1,
            ),
        )

        try:

            return int(value)

        except (
            TypeError,
            ValueError,
        ):

            return 1

    support_evidence.sort(
        key=lambda x: (
            -_level_strength(x),
            x["price"],
        )
    )

    resistance_evidence.sort(
        key=lambda x: (
            -_level_strength(x),
            x["price"],
        )
    )

    # ========================================================
    # 7. NEWS
    # ========================================================

    # Fail-safe default.
    #
    # If news is unavailable, this is a genuine information
    # quality issue. However, it is NOT automatically treated
    # as a market-direction conflict.
    news_summary = {

        "available": False,

        "status": "UNAVAILABLE",

        "risk_level": "UNKNOWN",

        "trading_restriction": True,

        "total_news": 0,

        "classified_news": 0,

        "recent_news": 0,

        "stale_news": 0,

        "high_relevance_count": 0,

        "medium_relevance_count": 0,

        "low_relevance_count": 0,

        "high_impact_count": 0,

        "geopolitical_count": 0,

        "gold_count": 0,

        "usd_macro_count": 0,

        "reason": (
            "News data is unavailable."
        ),

        "recent_items": [],
    }

    # --------------------------------------------------------
    # Full news engine result
    # --------------------------------------------------------

    if isinstance(
        news_analysis,
        dict,
    ):

        news_summary = dict(
            news_analysis
        )

        news_summary.setdefault(
            "available",
            False,
        )

        news_summary.setdefault(
            "status",
            "UNAVAILABLE",
        )

        news_summary.setdefault(
            "risk_level",
            "UNKNOWN",
        )

        news_summary.setdefault(
            "trading_restriction",
            True,
        )

        news_summary.setdefault(
            "total_news",
            0,
        )

        news_summary.setdefault(
            "classified_news",
            0,
        )

        news_summary.setdefault(
            "recent_news",
            0,
        )

        news_summary.setdefault(
            "stale_news",
            0,
        )

        news_summary.setdefault(
            "high_relevance_count",
            0,
        )

        news_summary.setdefault(
            "medium_relevance_count",
            0,
        )

        news_summary.setdefault(
            "low_relevance_count",
            0,
        )

        news_summary.setdefault(
            "high_impact_count",
            0,
        )

        news_summary.setdefault(
            "geopolitical_count",
            0,
        )

        news_summary.setdefault(
            "gold_count",
            0,
        )

        news_summary.setdefault(
            "usd_macro_count",
            0,
        )

        news_summary.setdefault(
            "reason",
            "News risk analysis completed.",
        )

        news_summary.setdefault(
            "recent_items",
            [],
        )

    # --------------------------------------------------------
    # Legacy classified-news list
    # --------------------------------------------------------

    elif isinstance(
        news_analysis,
        list,
    ):

        high_news = 0
        medium_news = 0
        low_news = 0

        for item in news_analysis:

            if not isinstance(
                item,
                dict,
            ):
                continue

            relevance = str(
                item.get(
                    "relevance",
                    "NONE",
                )
            ).upper()

            if relevance == "HIGH":

                high_news += 1

            elif relevance == "MEDIUM":

                medium_news += 1

            elif relevance == "LOW":

                low_news += 1

        news_summary.update({

            "available": True,

            "status": (
                "CAUTION"
                if high_news > 0
                else "NORMAL"
            ),

            "risk_level": (
                "MEDIUM"
                if high_news > 0
                else "LOW"
            ),

            "trading_restriction": False,

            "total_news": len(
                news_analysis
            ),

            "classified_news": (
                high_news
                + medium_news
                + low_news
            ),

            "high_relevance_count": (
                high_news
            ),

            "medium_relevance_count": (
                medium_news
            ),

            "low_relevance_count": (
                low_news
            ),

            "reason": (
                "Legacy classified news data."
            ),

            "recent_items": [],
        })

    # --------------------------------------------------------
    # Extract news state
    # --------------------------------------------------------

    news_available = bool(
        news_summary.get(
            "available",
            False,
        )
    )

    news_status = str(
        news_summary.get(
            "status",
            "UNAVAILABLE",
        )
    ).upper()

    news_risk = str(
        news_summary.get(
            "risk_level",
            "UNKNOWN",
        )
    ).upper()

    news_restriction = bool(
        news_summary.get(
            "trading_restriction",
            True,
        )
    )

    high_news = news_summary.get(
        "high_relevance_count",
        0,
    )

    medium_news = news_summary.get(
        "medium_relevance_count",
        0,
    )

    low_news = news_summary.get(
        "low_relevance_count",
        0,
    )

    try:
        high_news = int(
            high_news
        )
    except (
        TypeError,
        ValueError,
    ):
        high_news = 0

    try:
        medium_news = int(
            medium_news
        )
    except (
        TypeError,
        ValueError,
    ):
        medium_news = 0

    try:
        low_news = int(
            low_news
        )
    except (
        TypeError,
        ValueError,
    ):
        low_news = 0

    # --------------------------------------------------------
    # News → caution / confidence / observations
    # --------------------------------------------------------

    if not news_available:

        message = (
            "News data is unavailable."
        )

        caution.append(message)

        # Missing news is a genuine information-quality issue.
        confidence_issues.append(message)

    elif news_status == "HIGH_RISK":

        caution.append(
            "News risk is HIGH."
        )

        caution.append(
            "Directional trading is restricted "
            "by the news engine."
        )

        # High-risk news is a risk blocker.
        #
        # It should NOT automatically mean that the entire
        # market evidence is low quality.
        observations.append(
            "News risk is HIGH."
        )

    elif news_status == "CAUTION":

        caution.append(
            "News conditions require caution."
        )

        observations.append(
            "News conditions require caution."
        )

    elif news_status == "STALE":

        caution.append(
            "News data is stale."
        )

        confidence_issues.append(
            "News data is stale."
        )

    elif news_status == "UNAVAILABLE":

        caution.append(
            "News data is unavailable."
        )

        confidence_issues.append(
            "News data is unavailable."
        )

    elif news_status == "NORMAL":

        message = (
            "News conditions are currently normal."
        )

        caution.append(message)

        # NORMAL is explicitly neutral.
        observations.append(message)

    else:

        observations.append(
            f"News status: {news_status}."
        )

    # --------------------------------------------------------
    # News counts
    # --------------------------------------------------------

    if high_news > 0:

        message = (
            f"{high_news} high-relevance "
            "news items detected."
        )

        caution.append(message)
        observations.append(message)

    if medium_news > 0:

        message = (
            f"{medium_news} medium-relevance "
            "news items detected."
        )

        caution.append(message)
        observations.append(message)

    if low_news > 0:

        message = (
            f"{low_news} low-relevance "
            "news items detected."
        )

        caution.append(message)
        observations.append(message)

    # ========================================================
    # 8. LIQUIDITY
    # ========================================================

    liquidity_summary = {

        "available": False,

        "current_price": None,

        "levels": {},

        "nearest_level": None,

        "sweeps": {},

        "data_quality": {},

        "data_source": {},
    }

    if liquidity_available_input:

        liquidity_summary = {

            "available": bool(
                liquidity_evidence.get(
                    "available",
                    False,
                )
            ),

            "current_price": (
                liquidity_evidence.get(
                    "current_price"
                )
            ),

            "levels": (
                liquidity_evidence.get(
                    "levels",
                    {},
                )
            ),

            "nearest_level": (
                liquidity_evidence.get(
                    "nearest_level"
                )
            ),

            "sweeps": (
                liquidity_evidence.get(
                    "sweeps",
                    {},
                )
            ),

            "data_quality": (
                liquidity_evidence.get(
                    "data_quality",
                    {},
                )
            ),

            "data_source": (
                liquidity_evidence.get(
                    "data_source",
                    {},
                )
            ),
        }

        # ----------------------------------------------------
        # Availability
        # ----------------------------------------------------

        if not liquidity_evidence.get(
            "available",
            False,
        ):

            message = (
                "Liquidity data is unavailable."
            )

            caution.append(message)
            confidence_issues.append(message)

        # ----------------------------------------------------
        # Current price
        # ----------------------------------------------------

        current_price = (
            liquidity_evidence.get(
                "current_price"
            )
        )

        if current_price is None:

            message = (
                "Liquidity current price is unavailable."
            )

            caution.append(message)
            confidence_issues.append(message)

        # ----------------------------------------------------
        # Sweeps
        #
        # Sweeps are objective observations.
        #
        # They are NOT automatically converted into
        # bullish/bearish bias.
        # ----------------------------------------------------

        sweeps = liquidity_evidence.get(
            "sweeps",
            {},
        )

        if not isinstance(
            sweeps,
            dict,
        ):
            sweeps = {}

        previous_day_high_sweep = (
            sweeps.get(
                "previous_day_high",
                {},
            )
        )

        if not isinstance(
            previous_day_high_sweep,
            dict,
        ):
            previous_day_high_sweep = {}

        previous_day_low_sweep = (
            sweeps.get(
                "previous_day_low",
                {},
            )
        )

        if not isinstance(
            previous_day_low_sweep,
            dict,
        ):
            previous_day_low_sweep = {}

        if previous_day_high_sweep.get(
            "detected",
            False,
        ):

            message = (
                "Previous-day high liquidity "
                "sweep detected."
            )

            caution.append(message)
            observations.append(message)

        if previous_day_low_sweep.get(
            "detected",
            False,
        ):

            message = (
                "Previous-day low liquidity "
                "sweep detected."
            )

            caution.append(message)
            observations.append(message)

        # ----------------------------------------------------
        # Nearest liquidity level
        # ----------------------------------------------------

        nearest_level = (
            liquidity_evidence.get(
                "nearest_level"
            )
        )

        if isinstance(
            nearest_level,
            dict,
        ):

            level_name = nearest_level.get(
                "name",
                "unknown",
            )

            level_price = nearest_level.get(
                "price"
            )

            distance = nearest_level.get(
                "distance"
            )

            if (
                level_price is not None
                and distance is not None
            ):

                try:

                    distance_float = float(
                        distance
                    )

                    message = (
                        "Nearest liquidity level: "
                        f"{level_name} "
                        f"at {level_price} "
                        f"({distance_float:.2f} away)."
                    )

                except (
                    TypeError,
                    ValueError,
                ):

                    message = (
                        "Nearest liquidity level: "
                        f"{level_name} "
                        f"at {level_price}."
                    )

                caution.append(message)
                observations.append(message)

    else:

        message = (
            "Liquidity data is unavailable."
        )

        caution.append(message)
        confidence_issues.append(message)

    # ========================================================
    # 9. FUNDAMENTALS
    # ========================================================
    #
    # Fundamental information is treated as a separate
    # evidence domain.
    #
    # IMPORTANT:
    #
    # Fundamentals do NOT automatically create a trade.
    #
    # A directional fundamental signal is only added to
    # bullish/bearish evidence when:
    #
    #   - it is available
    #   - it has directional information
    #   - it is marked actionable
    #   - it is not conflicting
    #
    # Otherwise it remains contextual/caution evidence.
    #
    # ========================================================

    fundamental_summary = {

        "available": False,

        "instrument": None,

        "mode": None,

        "direction": "NEUTRAL",

        "strength": 0.0,

        "confidence": "NONE",

        "conflict": False,

        "bias": "NO_EDGE",

        "actionable": False,

        "base_currency": None,

        "quote_currency": None,

        "currency": {},

        "pair": None,

        "monetary_policy": {},

        "released_events": {},

        "upcoming_event_risk": {},

        "data_quality": {},

        "reason": (
            "Fundamental data is unavailable."
        ),
    }

    if fundamental_available_input:

        if isinstance(
            fundamental_evidence,
            dict,
        ):

            fundamental_summary = dict(
                fundamental_evidence
            )

        else:

            message = (
                "Fundamental data has an invalid format."
            )

            caution.append(message)
            confidence_issues.append(message)

            fundamental_summary = {

                "available": False,

                "instrument": None,

                "mode": None,

                "direction": "NEUTRAL",

                "strength": 0.0,

                "confidence": "NONE",

                "conflict": False,

                "bias": "NO_EDGE",

                "actionable": False,

                "base_currency": None,

                "quote_currency": None,

                "currency": {},

                "pair": None,

                "monetary_policy": {},

                "released_events": {},

                "upcoming_event_risk": {},

                "data_quality": {},

                "reason": (
                    "Fundamental data format is invalid."
                ),
            }

    # --------------------------------------------------------
    # Required fundamental fields
    # --------------------------------------------------------

    fundamental_summary.setdefault(
        "available",
        False,
    )

    fundamental_summary.setdefault(
        "instrument",
        None,
    )

    fundamental_summary.setdefault(
        "mode",
        None,
    )

    fundamental_summary.setdefault(
        "direction",
        "NEUTRAL",
    )

    fundamental_summary.setdefault(
        "strength",
        0.0,
    )

    fundamental_summary.setdefault(
        "confidence",
        "NONE",
    )

    fundamental_summary.setdefault(
        "conflict",
        False,
    )

    fundamental_summary.setdefault(
        "bias",
        "NO_EDGE",
    )

    fundamental_summary.setdefault(
        "actionable",
        False,
    )

    fundamental_summary.setdefault(
        "base_currency",
        None,
    )

    fundamental_summary.setdefault(
        "quote_currency",
        None,
    )

    fundamental_summary.setdefault(
        "currency",
        {},
    )

    fundamental_summary.setdefault(
        "pair",
        None,
    )

    fundamental_summary.setdefault(
        "monetary_policy",
        {},
    )

    fundamental_summary.setdefault(
        "released_events",
        {},
    )

    fundamental_summary.setdefault(
        "upcoming_event_risk",
        {},
    )

    fundamental_summary.setdefault(
        "data_quality",
        {},
    )

    fundamental_summary.setdefault(
        "reason",
        "Fundamental analysis completed.",
    )

    # --------------------------------------------------------
    # Fundamental state
    # --------------------------------------------------------

    fundamental_is_available = bool(
        fundamental_summary.get(
            "available",
            False,
        )
    )

    fundamental_direction = str(
        fundamental_summary.get(
            "direction",
            "NEUTRAL",
        )
    ).upper()

    fundamental_confidence = str(
        fundamental_summary.get(
            "confidence",
            "NONE",
        )
    ).upper()

    fundamental_conflict = bool(
        fundamental_summary.get(
            "conflict",
            False,
        )
    )

    fundamental_actionable = bool(
        fundamental_summary.get(
            "actionable",
            False,
        )
    )

    try:

        fundamental_strength = float(
            fundamental_summary.get(
                "strength",
                0.0,
            )
        )

    except (
        TypeError,
        ValueError,
    ):

        fundamental_strength = 0.0

    # Keep strength in a safe machine-readable range.

    fundamental_strength = max(
        0.0,
        min(
            1.0,
            fundamental_strength,
        ),
    )

    # --------------------------------------------------------
    # Fundamental unavailable
    # --------------------------------------------------------

    if not fundamental_is_available:

        message = (
            "Fundamental data is unavailable."
        )

        caution.append(message)

        confidence_issues.append(message)

    else:

        # ----------------------------------------------------
        # Directional fundamental evidence
        # ----------------------------------------------------

        if (
            fundamental_actionable
            and not fundamental_conflict
            and fundamental_strength > 0.0
        ):

            if fundamental_direction == "BULLISH":

                bullish_evidence.append(
                    "Fundamental analysis provides "
                    "actionable bullish pressure."
                )

            elif fundamental_direction == "BEARISH":

                bearish_evidence.append(
                    "Fundamental analysis provides "
                    "actionable bearish pressure."
                )

            else:

                message = (
                    "Fundamental analysis is not "
                    "directionally decisive."
                )

                caution.append(message)
                observations.append(message)

        else:

            # ------------------------------------------------
            # Non-actionable fundamental information remains
            # contextual evidence.
            # ------------------------------------------------

            if fundamental_direction == "BULLISH":

                message = (
                    "Fundamental analysis shows bullish "
                    "pressure, but it is not actionable."
                )

                caution.append(message)
                observations.append(message)

            elif fundamental_direction == "BEARISH":

                message = (
                    "Fundamental analysis shows bearish "
                    "pressure, but it is not actionable."
                )

                caution.append(message)
                observations.append(message)

            else:

                message = (
                    "Fundamental analysis is neutral or "
                    "insufficient for direction."
                )

                caution.append(message)
                observations.append(message)

        # ----------------------------------------------------
        # Fundamental conflict
        # ----------------------------------------------------

        if fundamental_conflict:

            message = (
                "Fundamental evidence contains conflicting "
                "macroeconomic signals."
            )

            caution.append(message)
            confidence_issues.append(message)

        # ----------------------------------------------------
        # Fundamental confidence
        # ----------------------------------------------------

        if fundamental_confidence == "LOW":

            message = (
                "Fundamental confidence is LOW."
            )

            caution.append(message)
            confidence_issues.append(message)

        elif fundamental_confidence == "NONE":

            message = (
                "Fundamental confidence is unavailable."
            )

            caution.append(message)
            confidence_issues.append(message)

        # ----------------------------------------------------
        # Upcoming event risk
        # ----------------------------------------------------

        upcoming_risk = (
            fundamental_summary.get(
                "upcoming_event_risk",
                {},
            )
        )

        if not isinstance(
            upcoming_risk,
            dict,
        ):

            upcoming_risk = {}

        risk_level = str(
            upcoming_risk.get(
                "risk_level",
                upcoming_risk.get(
                    "level",
                    "LOW",
                ),
            )
        ).upper()

        if risk_level in {
            "BLOCKED",
            "HIGH",
            "HIGH_RISK",
        }:

            message = (
                "Upcoming fundamental event risk is HIGH."
            )

            caution.append(message)

            # This is a risk condition, not necessarily an
            # evidence-quality failure.
            observations.append(message)

        elif risk_level in {
            "CAUTION",
            "MEDIUM",
        }:

            message = (
                "Upcoming fundamental event risk "
                "requires caution."
            )

            caution.append(message)
            observations.append(message)

        elif risk_level == "TIME_UNKNOWN":

            message = (
                "Relevant upcoming fundamental event "
                "has unknown timing."
            )

            caution.append(message)
            confidence_issues.append(message)

    # ========================================================
    # 10. FINAL EVIDENCE BALANCE
    # ========================================================

    bullish_count = len(
        bullish_evidence
    )

    bearish_count = len(
        bearish_evidence
    )

    if bullish_count > bearish_count:

        evidence_bias = "bullish"

    elif bearish_count > bullish_count:

        evidence_bias = "bearish"

    else:

        evidence_bias = "mixed"

    # ========================================================
    # 11. CONFIDENCE
    # ========================================================
    #
    # NEW MODEL
    #
    # We no longer count every caution.
    #
    # Instead we classify actual evidence quality.
    #
    # Genuine confidence issues:
    #   - unknown/mixed HTF
    #   - unknown/mixed overall bias
    #   - insufficient structure
    #   - contradictory structure
    #   - missing news
    #   - stale news
    #   - unavailable fundamentals
    #   - conflicting fundamentals
    #   - low-quality fundamentals
    #   - insufficient liquidity data
    #   - unknown event timing
    #
    # Neutral observations do NOT lower confidence:
    #   - support count
    #   - resistance count
    #   - nearest liquidity
    #   - liquidity sweeps
    #   - normal news
    #   - oversold/overbought
    #   - non-actionable fundamental context
    #
    # This confidence describes evidence quality.
    #
    # It does NOT override:
    #   - news blockers
    #   - decision gate
    #   - risk management
    #   - execution safety
    #
    # ========================================================

    # --------------------------------------------------------
    # Deduplicate confidence issues
    # --------------------------------------------------------

    unique_confidence_issues = []

    for issue in confidence_issues:

        issue_text = str(issue).strip()

        if not issue_text:
            continue

        if issue_text not in unique_confidence_issues:

            unique_confidence_issues.append(
                issue_text
            )

    confidence_issue_count = len(
        unique_confidence_issues
    )

    # --------------------------------------------------------
    # Confidence state
    #
    # 0-1 genuine issues  -> higher
    # 2-3 genuine issues  -> moderate
    # 4+ genuine issues   -> low
    #
    # IMPORTANT:
    # This is intentionally different from the old
    # "count every caution" model.
    # --------------------------------------------------------

    if confidence_issue_count >= 4:

        confidence_state = "low"

    elif confidence_issue_count >= 2:

        confidence_state = "moderate"

    else:

        confidence_state = "higher"

    # --------------------------------------------------------
    # Evidence quality score
    #
    # This is supplemental and does not replace the categorical
    # confidence_state.
    # --------------------------------------------------------

    confidence_score = 100

    confidence_score -= (
        confidence_issue_count * 15
    )

    confidence_score = max(
        0,
        min(
            100,
            confidence_score,
        ),
    )

    # --------------------------------------------------------
    # Directional alignment diagnostics
    # --------------------------------------------------------

    bullish_alignment = (
        overall_bias == "bullish"
        and higher_bias == "bullish"
        and lower_bias == "bullish"
        and structure_type == "bullish"
    )

    bearish_alignment = (
        overall_bias == "bearish"
        and higher_bias == "bearish"
        and lower_bias == "bearish"
        and structure_type == "bearish"
    )

    # --------------------------------------------------------
    # Structure directional conflict
    # --------------------------------------------------------

    structure_direction_conflict = False

    if (
        dominant_structure in {
            "bullish",
            "bearish",
        }
        and structure_type in {
            "bullish",
            "bearish",
        }
        and dominant_structure != structure_type
    ):

        structure_direction_conflict = True

        message = (
            "Structure type conflicts with "
            "dominant structure."
        )

        if message not in unique_confidence_issues:

            unique_confidence_issues.append(
                message
            )

        confidence_issue_count = len(
            unique_confidence_issues
        )

        if confidence_issue_count >= 4:

            confidence_state = "low"

        elif confidence_issue_count >= 2:

            confidence_state = "moderate"

        else:

            confidence_state = "higher"

        confidence_score = max(
            0,
            min(
                100,
                100 - (
                    confidence_issue_count * 15
                ),
            ),
        )

    # ========================================================
    # 12. FINAL EVIDENCE PACKAGE
    # ========================================================

    return {

        # ----------------------------------------------------
        # Overall evidence
        # ----------------------------------------------------

        "evidence_bias": evidence_bias,

        "confidence_state": confidence_state,

        "confidence_score": confidence_score,

        "confidence_issue_count": (
            confidence_issue_count
        ),

        "confidence_issues": (
            unique_confidence_issues
        ),

        "bullish_alignment": (
            bullish_alignment
        ),

        "bearish_alignment": (
            bearish_alignment
        ),

        "structure_direction_conflict": (
            structure_direction_conflict
        ),

        "bullish_evidence": (
            bullish_evidence
        ),

        "bearish_evidence": (
            bearish_evidence
        ),

        "caution": (
            caution
        ),

        "observations": (
            observations
        ),

        # ----------------------------------------------------
        # Market state
        # ----------------------------------------------------

        "market_state": {

            "overall_bias": (
                overall_bias
            ),

            "higher_timeframe_bias": (
                higher_bias
            ),

            "lower_timeframe_bias": (
                lower_bias
            ),
        },

        # ----------------------------------------------------
        # Timeframe summaries
        # ----------------------------------------------------

        "timeframe_summaries": (
            timeframe_summaries
        ),

        # ----------------------------------------------------
        # Market structure
        # ----------------------------------------------------

        "structure": {

            "type": (
                structure_type
            ),

            "dominant_structure": (
                dominant_structure
            ),

            "recent_structure": (
                recent_structure
            ),

            "structure_context": (
                structure_context
            ),

            "high_pattern": (
                high_pattern
            ),

            "low_pattern": (
                low_pattern
            ),

            "swing_high_count": (
                swing_high_count_value
            ),

            "swing_low_count": (
                swing_low_count_value
            ),
        },

        # ----------------------------------------------------
        # News
        # ----------------------------------------------------

        "news": news_summary,

        # ----------------------------------------------------
        # Support / Resistance
        # ----------------------------------------------------

        "levels": {

            "support_count": (
                len(support_evidence)
            ),

            "resistance_count": (
                len(resistance_evidence)
            ),

            "support": (
                support_evidence
            ),

            "resistance": (
                resistance_evidence
            ),

            "strongest_support": (
                support_evidence[0]
                if support_evidence
                else None
            ),

            "strongest_resistance": (
                resistance_evidence[0]
                if resistance_evidence
                else None
            ),
        },

        # ----------------------------------------------------
        # Liquidity
        # ----------------------------------------------------

        "liquidity": (
            liquidity_summary
        ),

        # ----------------------------------------------------
        # Fundamentals
        # ----------------------------------------------------

        "fundamentals": {

            "available": (
                fundamental_is_available
            ),

            "instrument": (
                fundamental_summary.get(
                    "instrument"
                )
            ),

            "mode": (
                fundamental_summary.get(
                    "mode"
                )
            ),

            "direction": (
                fundamental_direction
            ),

            "strength": (
                round(
                    fundamental_strength,
                    4,
                )
            ),

            "confidence": (
                fundamental_confidence
            ),

            "conflict": (
                fundamental_conflict
            ),

            "bias": (
                fundamental_summary.get(
                    "bias",
                    "NO_EDGE",
                )
            ),

            "actionable": (
                fundamental_actionable
            ),

            "base_currency": (
                fundamental_summary.get(
                    "base_currency"
                )
            ),

            "quote_currency": (
                fundamental_summary.get(
                    "quote_currency"
                )
            ),

            "currency": (
                fundamental_summary.get(
                    "currency",
                    {},
                )
            ),

            "pair": (
                fundamental_summary.get(
                    "pair"
                )
            ),

            "monetary_policy": (
                fundamental_summary.get(
                    "monetary_policy",
                    {},
                )
            ),

            "released_events": (
                fundamental_summary.get(
                    "released_events",
                    {},
                )
            ),

            "upcoming_event_risk": (
                fundamental_summary.get(
                    "upcoming_event_risk",
                    {},
                )
            ),

            "data_quality": (
                fundamental_summary.get(
                    "data_quality",
                    {},
                )
            ),

            "reason": (
                fundamental_summary.get(
                    "reason",
                    "Fundamental analysis completed.",
                )
            ),
        },
    }