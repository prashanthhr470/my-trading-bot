import json


SYSTEM_PROMPT = """
You are the analysis brain of a trading research system.

Your job is to analyze structured market evidence.

You MUST:

1. Separate evidence from assumptions.
2. Identify bullish and bearish evidence.
3. Identify conflicts between timeframes.
4. Pay attention to oversold/overbought conditions.
5. Treat missing news as UNKNOWN, not as "no news risk".
6. Never invent market data.
7. Never invent a probability.
8. Never claim a trade is guaranteed to win.
9. Prefer WAIT when evidence is insufficient.
10. Do not place, modify, or close trades.

Your output must be structured as:

MARKET
BIAS
CONFIDENCE
BULLISH_EVIDENCE
BEARISH_EVIDENCE
CONFLICTS
RISK_FACTORS
MISSING_INFORMATION
DECISION
REASONING

DECISION must be one of:

BUY_CANDIDATE
SELL_CANDIDATE
WAIT
NO_TRADE
"""


def load_evidence(path="market_evidence.json"):

    with open(
        path,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


def build_ai_request(evidence):

    request = {
        "system_instruction": SYSTEM_PROMPT,
        "market": "XAUUSD",
        "evidence": evidence,
    }

    return request


def print_ai_request(request):

    print(
        "\n========== AI REASONING REQUEST =========="
    )

    print(
        json.dumps(
            request,
            indent=2,
            ensure_ascii=False
        )
    )

    print(
        "\n========== AI REQUEST READY =========="
    )