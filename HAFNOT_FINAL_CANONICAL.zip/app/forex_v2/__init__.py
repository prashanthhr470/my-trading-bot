"""Paper-only building blocks for the Forex V2 trading system."""

from .risk import (
    AccountState,
    FxPairSpec,
    FxQuote,
    PaperClose,
    PaperPosition,
    PositionSizing,
    RiskConfig,
    RiskDecision,
    TradeRequest,
    close_paper_position,
    evaluate_paper_trade,
    size_position,
)

__all__ = [
    "AccountState",
    "FxPairSpec",
    "FxQuote",
    "PaperClose",
    "PaperPosition",
    "PositionSizing",
    "RiskConfig",
    "RiskDecision",
    "TradeRequest",
    "close_paper_position",
    "evaluate_paper_trade",
    "size_position",
]
