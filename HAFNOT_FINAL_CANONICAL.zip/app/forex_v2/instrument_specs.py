"""
Contract specifications for instruments beyond the USD FX majors and gold - US equity
indices, energies, other metals - built from the broker's own data
(data/broker/symbol_specs.json, fetched with ProtoOASymbolByIdReq by
hafnot_fetch_symbol_specs.py).

Research only. Specs built here are registered with app.forex_v2.risk through
register_research_specs(), which the costed backtest consults. The live paper and DEMO
path checks FX_USD_MAJOR_SPECS directly, so nothing registered here becomes tradable.

Only USD-quoted instruments are supported: a move in their price is already in USD, so
no currency conversion is needed (none is modelled).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Optional

from app.forex_v2.risk import FX_USD_MAJOR_SPECS, FxPairSpec

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SPECS_FILE = PROJECT_ROOT / "data" / "broker" / "symbol_specs.json"

USD_PER_LOT = 2  # ProtoOACommissionType

COMMISSION_RULE = (
    "Round-turn commission per lot from the broker's symbol data. Type USD_PER_LOT charges the listed amount "
    "(in cents) per side, so twice per round trip: EURUSD lists 300, i.e. $6 per lot round trip, confirmed by the "
    "14 Sep DEMO fill (3 cents per side at 0.01 lot). An instrument listing no commission pays none. Other "
    "commission types and minimum commissions are not modelled, and are refused rather than guessed."
)


def load_specs(path: Path = SPECS_FILE) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))["symbols"]


def usd_quoted_spec(symbol: str, entry: dict) -> FxPairSpec:
    symbol = symbol.upper()
    quote = str(entry.get("quote_asset") or "").upper()
    if quote != "USD":
        raise ValueError(f"{symbol} is quoted in {quote or 'an unknown currency'}, not USD; conversion is not modelled.")
    lot_size = int(entry.get("lot_size_raw") or 0)
    units = lot_size / 100.0
    if lot_size <= 0 or units != int(units):
        raise ValueError(f"{symbol}: {units} units per lot is not a whole contract size.")
    return FxPairSpec(
        symbol=symbol,
        base_currency=str(entry.get("base_asset") or symbol).upper(),
        quote_currency="USD",
        pip_size=float(entry["pip_size"]),
        contract_size=int(units),
        min_lot=float(entry["min_lots"]),
        lot_step=float(entry["lot_step"]),
        max_lot=int(entry["max_volume_raw"]) / lot_size,
    )


def research_specs_for(symbols: Iterable[str], entries: Optional[dict] = None) -> dict[str, FxPairSpec]:
    """Specs for every symbol NOT already built into FX_USD_MAJOR_SPECS; refuses any it cannot model."""

    entries = load_specs() if entries is None else entries
    specs = {}
    for symbol in (s.upper() for s in symbols):
        if symbol in FX_USD_MAJOR_SPECS:
            continue
        if symbol not in entries:
            raise ValueError(f"{symbol} has no broker specification; run hafnot_fetch_symbol_specs.py --symbols {symbol}.")
        specs[symbol] = usd_quoted_spec(symbol, entries[symbol])
    return specs


def round_turn_commission_usd(symbol: str, entry: dict) -> float:
    kind = int(entry.get("commission_type") or 0)
    value = int(entry.get("commission") or 0)
    if value == 0 and int(entry.get("precise_trading_commission_rate") or 0) == 0:
        return 0.0
    if kind == USD_PER_LOT:
        return 2 * value / 100.0
    raise ValueError(f"{symbol}: commission type {kind} with value {value} is not modelled.")
