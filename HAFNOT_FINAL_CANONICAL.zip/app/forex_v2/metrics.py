"""Performance metrics and promotion gates for paper-only FX research."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from math import isfinite
from typing import Any


@dataclass(frozen=True)
class PerformanceSummary:
    trade_count: int
    wins: int
    losses: int
    breakeven: int
    win_rate: float | None
    net_pnl_usd: float
    gross_profit_usd: float
    gross_loss_usd: float
    profit_factor: float | None
    average_pnl_usd: float | None
    expectancy_r: float | None
    max_drawdown_usd: float
    max_drawdown_percent: float
    final_equity: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PromotionGate:
    """Minimum evidence thresholds before considering the next test stage.

    Passing this gate is *not* permission for live trading.  It only says the
    supplied paper/backtest sample meets basic statistical hygiene checks.
    """

    minimum_closed_trades: int = 100
    minimum_profit_factor: float = 1.15
    minimum_expectancy_r: float = 0.05
    maximum_drawdown_percent: float = 12.0


@dataclass(frozen=True)
class PromotionDecision:
    passed: bool
    reasons: tuple[str, ...]


def _number(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if isfinite(result) else default


def summarize_trades(
    trades: Iterable[Mapping[str, Any]],
    *,
    initial_equity: float,
) -> PerformanceSummary:
    """Calculate metrics from closed trades in chronological order.

    Every supplied trade must contain ``pnl_usd``; ``result_r`` is optional.
    Invalid records are ignored instead of being treated as wins or losses.
    """

    equity = _number(initial_equity)
    if equity <= 0:
        raise ValueError("initial_equity must be greater than zero.")

    peak_equity = equity
    max_drawdown_usd = 0.0
    max_drawdown_percent = 0.0
    wins = losses = breakeven = 0
    gross_profit = gross_loss = 0.0
    pnl_values: list[float] = []
    r_values: list[float] = []

    for trade in trades:
        if not isinstance(trade, Mapping) or "pnl_usd" not in trade:
            continue

        pnl = _number(trade.get("pnl_usd"), default=float("nan"))
        if not isfinite(pnl):
            continue

        pnl_values.append(pnl)
        equity += pnl
        peak_equity = max(peak_equity, equity)
        drawdown_usd = max(0.0, peak_equity - equity)
        max_drawdown_usd = max(max_drawdown_usd, drawdown_usd)
        max_drawdown_percent = max(
            max_drawdown_percent,
            (drawdown_usd / peak_equity * 100.0) if peak_equity > 0 else 0.0,
        )

        if pnl > 0:
            wins += 1
            gross_profit += pnl
        elif pnl < 0:
            losses += 1
            gross_loss += abs(pnl)
        else:
            breakeven += 1

        if "result_r" in trade:
            result_r = _number(trade.get("result_r"), default=float("nan"))
            if isfinite(result_r):
                r_values.append(result_r)

    trade_count = len(pnl_values)
    return PerformanceSummary(
        trade_count=trade_count,
        wins=wins,
        losses=losses,
        breakeven=breakeven,
        win_rate=(wins / trade_count) if trade_count else None,
        net_pnl_usd=sum(pnl_values),
        gross_profit_usd=gross_profit,
        gross_loss_usd=gross_loss,
        profit_factor=(gross_profit / gross_loss) if gross_loss > 0 else None,
        average_pnl_usd=(sum(pnl_values) / trade_count) if trade_count else None,
        expectancy_r=(sum(r_values) / len(r_values)) if r_values else None,
        max_drawdown_usd=max_drawdown_usd,
        max_drawdown_percent=max_drawdown_percent,
        final_equity=equity,
    )


@dataclass(frozen=True)
class ExtendedMetrics:
    """
    The risk-adjusted and distribution metrics the core PerformanceSummary
    does not carry. Every field is Optional and is None when the sample
    genuinely cannot support it - a Sharpe ratio computed from 12 trades
    is a number, not evidence, so it is withheld rather than reported.
    """

    trade_count: int
    payoff_ratio: float | None
    average_win_usd: float | None
    average_loss_usd: float | None
    sharpe_ratio: float | None
    sortino_ratio: float | None
    max_consecutive_losses: int
    max_consecutive_wins: int
    longest_drawdown_trades: int
    sample_sufficient_for_ratios: bool
    withheld_reason: str | None


# Below this many closed trades, Sharpe/Sortino are withheld. Ratio
# estimates from tiny samples are dominated by noise; 30 is the
# conventional minimum and still generous for trading data, which is
# non-normal and serially correlated.
MIN_TRADES_FOR_RATIOS = 30


def extended_metrics(
    trades: Iterable[Mapping[str, Any]],
    *,
    initial_equity: float,
) -> ExtendedMetrics:
    """Compute risk-adjusted metrics alongside summarize_trades()."""

    pnl_values: list[float] = []
    for trade in trades:
        if not isinstance(trade, Mapping) or "pnl_usd" not in trade:
            continue
        pnl = _number(trade.get("pnl_usd"), default=float("nan"))
        if isfinite(pnl):
            pnl_values.append(pnl)

    count = len(pnl_values)

    wins = [p for p in pnl_values if p > 0]
    losses = [p for p in pnl_values if p < 0]

    average_win = (sum(wins) / len(wins)) if wins else None
    average_loss = (sum(losses) / len(losses)) if losses else None

    payoff = None
    if average_win is not None and average_loss is not None and average_loss != 0:
        payoff = average_win / abs(average_loss)

    # Streaks.
    max_loss_streak = max_win_streak = 0
    loss_streak = win_streak = 0
    for pnl in pnl_values:
        if pnl < 0:
            loss_streak += 1
            win_streak = 0
        elif pnl > 0:
            win_streak += 1
            loss_streak = 0
        else:
            loss_streak = win_streak = 0
        max_loss_streak = max(max_loss_streak, loss_streak)
        max_win_streak = max(max_win_streak, win_streak)

    # Longest stretch (in trades) spent below a previous equity peak.
    equity = _number(initial_equity)
    peak = equity
    longest_underwater = 0
    underwater = 0
    for pnl in pnl_values:
        equity += pnl
        if equity >= peak:
            peak = equity
            underwater = 0
        else:
            underwater += 1
            longest_underwater = max(longest_underwater, underwater)

    # Risk-adjusted ratios, per-trade (NOT annualized - annualizing would
    # require an assumption about trade frequency this function does not
    # have, and would inflate the number).
    sharpe = sortino = None
    withheld_reason = None
    sufficient = count >= MIN_TRADES_FOR_RATIOS

    if not sufficient:
        withheld_reason = (
            f"Only {count} closed trade(s); Sharpe/Sortino withheld below "
            f"{MIN_TRADES_FOR_RATIOS} as such estimates are dominated by noise."
        )
    else:
        mean = sum(pnl_values) / count
        variance = sum((p - mean) ** 2 for p in pnl_values) / (count - 1)
        stdev = variance ** 0.5

        if stdev > 0:
            sharpe = mean / stdev
        else:
            withheld_reason = "Zero dispersion in trade P&L; Sharpe undefined."

        downside = [p for p in pnl_values if p < 0]
        if downside:
            downside_variance = sum(p ** 2 for p in downside) / len(downside)
            downside_dev = downside_variance ** 0.5
            if downside_dev > 0:
                sortino = mean / downside_dev
        else:
            withheld_reason = (
                (withheld_reason + " ") if withheld_reason else ""
            ) + "No losing trades; Sortino undefined."

    return ExtendedMetrics(
        trade_count=count,
        payoff_ratio=payoff,
        average_win_usd=average_win,
        average_loss_usd=average_loss,
        sharpe_ratio=sharpe,
        sortino_ratio=sortino,
        max_consecutive_losses=max_loss_streak,
        max_consecutive_wins=max_win_streak,
        longest_drawdown_trades=longest_underwater,
        sample_sufficient_for_ratios=sufficient,
        withheld_reason=withheld_reason,
    )


def evaluate_promotion(
    summary: PerformanceSummary,
    gate: PromotionGate = PromotionGate(),
) -> PromotionDecision:
    """Return transparent evidence failures; never grants live authorization."""

    reasons: list[str] = []
    if summary.trade_count < gate.minimum_closed_trades:
        reasons.append(
            f"Only {summary.trade_count} closed trades; need at least "
            f"{gate.minimum_closed_trades}."
        )

    if summary.profit_factor is None:
        reasons.append("Profit factor is unavailable because there are no losing trades.")
    elif summary.profit_factor < gate.minimum_profit_factor:
        reasons.append(
            f"Profit factor {summary.profit_factor:.2f} is below "
            f"{gate.minimum_profit_factor:.2f}."
        )

    if summary.expectancy_r is None:
        reasons.append("Expectancy in R is unavailable.")
    elif summary.expectancy_r < gate.minimum_expectancy_r:
        reasons.append(
            f"Expectancy {summary.expectancy_r:.3f}R is below "
            f"{gate.minimum_expectancy_r:.3f}R."
        )

    if summary.max_drawdown_percent > gate.maximum_drawdown_percent:
        reasons.append(
            f"Maximum drawdown {summary.max_drawdown_percent:.2f}% exceeds "
            f"{gate.maximum_drawdown_percent:.2f}%."
        )

    return PromotionDecision(passed=not reasons, reasons=tuple(reasons))
