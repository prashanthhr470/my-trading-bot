"""Data preparation for the isolated, paper-only FX V2 research path.

The existing cTrader collector persists spot events as JSONL.  This module
turns those events into regular mid-price OHLC bars without connecting to a
broker or writing to the market-data feed.  It deliberately keeps bid/ask
observations separate long enough to report observed spread statistics; a
backtest must still apply its own conservative execution costs.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class OhlcBar:
    """A UTC, mid-price OHLC bar suitable for deterministic research."""

    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    tick_count: int
    mean_spread: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp.isoformat(),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "tick_count": self.tick_count,
            "mean_spread": self.mean_spread,
        }


def _parse_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None

    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)

    return parsed.astimezone(timezone.utc)


def _bucket_start(timestamp: datetime, interval: timedelta) -> datetime:
    interval_seconds = int(interval.total_seconds())
    if interval_seconds <= 0:
        raise ValueError("timeframe_minutes must be greater than zero.")

    epoch_seconds = int(timestamp.timestamp())
    return datetime.fromtimestamp(
        epoch_seconds - (epoch_seconds % interval_seconds),
        tz=timezone.utc,
    )


def iter_spot_quotes(
    path: str | Path,
    *,
    symbol: str | None = None,
) -> Iterator[tuple[datetime, float, float]]:
    """Yield valid timestamp/bid/ask observations from a cTrader JSONL file.

    Malformed rows, depth updates and inverted prices are ignored.  This is
    intentionally a streaming reader so large capture files do not have to
    fit into memory.
    """

    requested_symbol = symbol.upper() if symbol else None

    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue

            if not isinstance(payload, Mapping):
                continue

            if payload.get("type") != "spot":
                continue

            row_symbol = str(payload.get("symbol", "")).upper()
            if requested_symbol and row_symbol != requested_symbol:
                continue

            timestamp = _parse_timestamp(payload.get("timestamp"))

            try:
                bid = float(payload["bid"])
                ask = float(payload["ask"])
            except (KeyError, TypeError, ValueError):
                continue

            if timestamp is None or bid <= 0 or ask <= 0 or ask < bid:
                continue

            yield timestamp, bid, ask


def aggregate_spot_quotes(
    quotes: Iterable[tuple[datetime, float, float]],
    *,
    timeframe_minutes: int,
) -> list[OhlcBar]:
    """Aggregate chronological bid/ask quotes into UTC mid-price bars.

    The source collector is expected to be chronological.  An out-of-order
    quote is skipped rather than silently reordering a live capture, because
    reordering can conceal a feed-quality problem and introduce bias.
    """

    interval = timedelta(minutes=timeframe_minutes)
    if interval <= timedelta(0):
        raise ValueError("timeframe_minutes must be greater than zero.")

    bars: list[OhlcBar] = []
    current_start: datetime | None = None
    current_open = current_high = current_low = current_close = 0.0
    spread_sum = 0.0
    tick_count = 0
    previous_timestamp: datetime | None = None

    def finish_current() -> None:
        if current_start is None or tick_count == 0:
            return
        bars.append(
            OhlcBar(
                timestamp=current_start,
                open=current_open,
                high=current_high,
                low=current_low,
                close=current_close,
                tick_count=tick_count,
                mean_spread=spread_sum / tick_count,
            )
        )

    for timestamp, bid, ask in quotes:
        if previous_timestamp is not None and timestamp < previous_timestamp:
            continue
        previous_timestamp = timestamp

        bucket = _bucket_start(timestamp, interval)
        mid = (bid + ask) / 2.0
        spread = ask - bid

        if current_start is None or bucket != current_start:
            finish_current()
            current_start = bucket
            current_open = current_high = current_low = current_close = mid
            spread_sum = spread
            tick_count = 1
            continue

        current_high = max(current_high, mid)
        current_low = min(current_low, mid)
        current_close = mid
        spread_sum += spread
        tick_count += 1

    finish_current()
    return bars


def build_bars_from_spot_jsonl(
    path: str | Path,
    *,
    symbol: str,
    timeframe_minutes: int = 15,
) -> list[dict[str, Any]]:
    """Load a cTrader capture and return standard mapping-style OHLC bars."""

    bars = aggregate_spot_quotes(
        iter_spot_quotes(path, symbol=symbol),
        timeframe_minutes=timeframe_minutes,
    )
    return [bar.as_dict() for bar in bars]
