"""Deterministic, paper-only risk and execution calculations for USD FX majors.

This module deliberately has no I/O, clock access, global mutable account state,
or broker dependency.  A caller supplies a quote, a proposed stop/target, and an
immutable account snapshot; every result is a value object that can be journaled
or replayed in a backtest.

Price convention
----------------
``TradeRequest.stop_loss`` and ``take_profit`` are executable exit prices: a
long position exits against the bid and a short position exits against the ask.
The entry fill therefore includes the current bid/ask spread, while both entry
and exit fills include configured adverse slippage.  Round-turn commission is
included in both the maximum-loss estimate and reward/risk calculation.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import floor, isfinite
from types import MappingProxyType
from typing import Final, Mapping


_EPSILON: Final[float] = 1e-9


@dataclass(frozen=True, slots=True)
class FxPairSpec:
    """Contract metadata for a spot-FX pair quoted against a USD account."""

    symbol: str
    base_currency: str
    quote_currency: str
    pip_size: float
    contract_size: int = 100_000
    min_lot: float = 0.01
    lot_step: float = 0.01
    max_lot: float = 100.0


@dataclass(frozen=True, slots=True)
class RiskConfig:
    """Safety limits and deterministic execution-cost assumptions.

    Percent values use conventional percentage units: ``0.5`` means 0.5%, not
    0.005.  Commission is the full open-and-close amount for one standard lot.
    """

    account_currency: str = "USD"
    risk_per_trade_pct: float = 0.5
    max_risk_per_trade_usd: float | None = None
    max_total_open_risk_pct: float = 2.0
    max_total_open_risk_usd: float | None = None
    daily_loss_limit_pct: float = 2.0
    max_positions: int = 3
    max_positions_per_symbol: int = 1
    # Cap on same-direction risk in any one currency, summed over open
    # positions: long EURUSD and long GBPUSD are both short USD, a stacked
    # bet the position-count and total-risk caps cannot see. It binds only
    # when a trade adds to an existing same-direction exposure.
    max_currency_exposure_pct: float = 1.0
    min_reward_to_risk: float = 1.5
    max_spread_pips: float = 2.0
    slippage_pips_per_side: float = 0.10
    commission_per_lot_round_turn_usd: float = 7.0


@dataclass(frozen=True, slots=True)
class FxQuote:
    """A contemporaneous bid/ask quote used only for a paper-fill estimate."""

    symbol: str
    bid: float
    ask: float


@dataclass(frozen=True, slots=True)
class TradeRequest:
    """A strategy proposal; it is not an order and cannot reach a broker."""

    symbol: str
    side: str
    stop_loss: float
    take_profit: float


@dataclass(frozen=True, slots=True)
class PaperPosition:
    """An accepted paper position with its complete pre-trade loss model."""

    symbol: str
    side: str
    lots: float
    units: int
    entry_fill_price: float
    stop_exit_price: float
    take_profit_exit_price: float
    risk_amount_usd: float
    expected_reward_usd: float
    round_turn_commission_usd: float


@dataclass(frozen=True, slots=True)
class AccountState:
    """Immutable USD account snapshot supplied by the journal/backtester."""

    equity_usd: float
    day_start_equity_usd: float
    realized_pnl_today_usd: float = 0.0
    open_positions: tuple[PaperPosition, ...] = ()


@dataclass(frozen=True, slots=True)
class PositionSizing:
    """Result of sizing an already-estimated entry and stop fill."""

    accepted: bool
    reason: str
    units: int | None = None
    lots: float | None = None
    risk_budget_usd: float | None = None
    risk_amount_usd: float | None = None
    loss_per_lot_usd: float | None = None
    stop_distance_pips: float | None = None
    commission_per_lot_usd: float | None = None


@dataclass(frozen=True, slots=True)
class RiskDecision:
    """Complete paper-only admission result for a proposed market trade."""

    accepted: bool
    reason: str
    sizing: PositionSizing
    symbol: str | None = None
    side: str | None = None
    entry_fill_price: float | None = None
    stop_exit_price: float | None = None
    take_profit_exit_price: float | None = None
    spread_pips: float | None = None
    reward_to_risk: float | None = None
    position: PaperPosition | None = None


@dataclass(frozen=True, slots=True)
class PaperClose:
    """A deterministic simulated close; no account or position is mutated."""

    accepted: bool
    reason: str
    exit_fill_price: float | None = None
    gross_pnl_usd: float | None = None
    net_pnl_usd: float | None = None
    result_r: float | None = None


FX_USD_MAJOR_SPECS: Final[Mapping[str, FxPairSpec]] = MappingProxyType(
    {
        "EURUSD": FxPairSpec("EURUSD", "EUR", "USD", 0.0001),
        "GBPUSD": FxPairSpec("GBPUSD", "GBP", "USD", 0.0001),
        "AUDUSD": FxPairSpec("AUDUSD", "AUD", "USD", 0.0001),
        "NZDUSD": FxPairSpec("NZDUSD", "NZD", "USD", 0.0001),
        "USDJPY": FxPairSpec("USDJPY", "USD", "JPY", 0.01),
        "USDCHF": FxPairSpec("USDCHF", "USD", "CHF", 0.0001),
        "USDCAD": FxPairSpec("USDCAD", "USD", "CAD", 0.0001),
        # Spot gold vs. USD. Quoted in USD, so _price_move_to_usd needs no
        # currency conversion - same code path as the USD-quote FX pairs
        # above.
        #
        # pip_size=0.1 is the broker's OWN value, not an assumption:
        # ProtoOASymbolByIdRes reports pipPosition=1 for XAUUSD on the
        # authorized DEMO account (see data/broker/symbol_specs.json,
        # produced by hafnot_fetch_symbol_specs.py). An earlier hand-written
        # 0.01 here was a 10x units error with a real live consequence - a
        # normal ~$0.10 gold spread measured as 10 pips against
        # RiskConfig.max_spread_pips=2.0, so every gold candidate was
        # refused on spread. pip_size does NOT affect position sizing
        # (_price_move_to_usd uses contract_size only); it affects the
        # spread-cap measurement, slippage expressed in price terms, and
        # pip-denominated reporting. contract_size=100 troy oz/lot,
        # min_lot/lot_step=0.01 also match the broker (lotSize=10000,
        # minVolume=stepVolume=100 -> 100/10000 = 0.01 lots).
        "XAUUSD": FxPairSpec("XAUUSD", "XAU", "USD", 0.1, contract_size=100, min_lot=0.01, lot_step=0.01, max_lot=50.0),
    }
)

# Symbols in the project's actual trading universe that this USD-major-only
# risk model does NOT support: GBPJPY, AUDJPY, GBPAUD (neither leg is USD,
# so P/L would need a live cross-rate conversion this module deliberately
# does not implement - see the module docstring). Costed backtesting,
# walk-forward validation, and the promotion pipeline in app/quant/ can
# only be used for the symbols listed in FX_USD_MAJOR_SPECS above until a
# conversion-aware extension is built.
UNSUPPORTED_CROSS_PAIRS: Final[tuple[str, ...]] = ("GBPJPY", "AUDJPY", "GBPAUD")

# Research-only instruments (US indices, energies, other metals quoted in USD), built from
# broker data by app.forex_v2.instrument_specs and registered by a research run. This is the
# one mutable table in the module, kept apart on purpose: the live paper and DEMO path checks
# FX_USD_MAJOR_SPECS itself, so a registered research instrument never becomes tradable there.
_RESEARCH_SPECS: dict = {}


def register_research_specs(specs: Mapping[str, FxPairSpec]) -> None:
    for symbol, spec in specs.items():
        canonical = _normalize_symbol(symbol)
        if canonical in FX_USD_MAJOR_SPECS:
            raise ValueError(f"{canonical} already has a built-in specification.")
        if not _valid_spec(spec) or _normalize_symbol(spec.symbol) != canonical:
            raise ValueError(f"Invalid research specification for {canonical}.")
        _RESEARCH_SPECS[canonical] = spec


def resolve_spec(symbol: str) -> "FxPairSpec | None":
    """A built-in FX/gold spec, else a registered research spec, else None."""

    return _resolve_pair(symbol)


def _normalize_symbol(symbol: object) -> str:
    if not isinstance(symbol, str):
        return ""
    return (
        symbol.strip()
        .upper()
        .replace("/", "")
        .replace("_", "")
        .replace("-", "")
        .replace(" ", "")
    )


def _normalize_side(side: object) -> str:
    return side.strip().upper() if isinstance(side, str) else ""


def _finite(value: object) -> bool:
    try:
        return isfinite(float(value))
    except (TypeError, ValueError):
        return False


def _positive(value: object) -> bool:
    return _finite(value) and float(value) > 0.0


def _positive_or_none(value: object) -> bool:
    return value is None or _positive(value)


def _valid_spec(spec: FxPairSpec) -> bool:
    if not isinstance(spec, FxPairSpec):
        return False
    if not _normalize_symbol(spec.symbol):
        return False
    if not isinstance(spec.base_currency, str) or not isinstance(spec.quote_currency, str):
        return False
    if spec.base_currency.upper() == spec.quote_currency.upper():
        return False
    if "USD" not in {spec.base_currency.upper(), spec.quote_currency.upper()}:
        return False
    return (
        _positive(spec.pip_size)
        and isinstance(spec.contract_size, int)
        and spec.contract_size > 0
        and _positive(spec.min_lot)
        and _positive(spec.lot_step)
        and _positive(spec.max_lot)
        and spec.max_lot + _EPSILON >= spec.min_lot
    )


def _resolve_pair(symbol_or_spec: str | FxPairSpec) -> FxPairSpec | None:
    if isinstance(symbol_or_spec, FxPairSpec):
        return symbol_or_spec if _valid_spec(symbol_or_spec) else None
    canonical = _normalize_symbol(symbol_or_spec)
    return FX_USD_MAJOR_SPECS.get(canonical) or _RESEARCH_SPECS.get(canonical)


def _validate_config(config: object) -> str | None:
    if not isinstance(config, RiskConfig):
        return "INVALID_RISK_CONFIG"
    if not isinstance(config.account_currency, str) or config.account_currency.upper() != "USD":
        return "UNSUPPORTED_ACCOUNT_CURRENCY"
    if not _positive(config.risk_per_trade_pct):
        return "INVALID_RISK_PER_TRADE"
    if not _positive_or_none(config.max_risk_per_trade_usd):
        return "INVALID_MAX_RISK_PER_TRADE"
    if not _positive(config.max_total_open_risk_pct):
        return "INVALID_TOTAL_OPEN_RISK_CAP"
    if not _positive_or_none(config.max_total_open_risk_usd):
        return "INVALID_TOTAL_OPEN_RISK_USD_CAP"
    if not _positive(config.daily_loss_limit_pct):
        return "INVALID_DAILY_LOSS_CAP"
    if not isinstance(config.max_positions, int) or config.max_positions < 1:
        return "INVALID_MAX_POSITIONS"
    if not isinstance(config.max_positions_per_symbol, int) or config.max_positions_per_symbol < 1:
        return "INVALID_MAX_SYMBOL_POSITIONS"
    if not _positive(config.max_currency_exposure_pct):
        return "INVALID_CURRENCY_EXPOSURE_CAP"
    if not _positive(config.min_reward_to_risk):
        return "INVALID_MIN_REWARD_TO_RISK"
    if not _finite(config.max_spread_pips) or config.max_spread_pips < 0.0:
        return "INVALID_MAX_SPREAD"
    if not _finite(config.slippage_pips_per_side) or config.slippage_pips_per_side < 0.0:
        return "INVALID_SLIPPAGE"
    if not _finite(config.commission_per_lot_round_turn_usd) or config.commission_per_lot_round_turn_usd < 0.0:
        return "INVALID_COMMISSION"
    return None


def _price_move_to_usd(
    spec: FxPairSpec,
    price_move: float,
    conversion_price: float,
) -> float:
    """Return USD value of a positive price move for one standard lot."""

    if spec.quote_currency.upper() == "USD":
        return price_move * spec.contract_size
    # For USDJPY/USDCHF/USDCAD, P/L is first expressed in the quote currency.
    return price_move * spec.contract_size / conversion_price


def _round_lots_down(raw_lots: float, lot_step: float) -> float:
    steps = floor((raw_lots + _EPSILON) / lot_step)
    rounded = steps * lot_step
    # A stable decimal representation is useful in JSON journals and test replay.
    return round(rounded, 10)


def _sizing_rejection(
    reason: str,
    *,
    risk_budget_usd: float | None = None,
    loss_per_lot_usd: float | None = None,
    stop_distance_pips: float | None = None,
    commission_per_lot_usd: float | None = None,
) -> PositionSizing:
    return PositionSizing(
        accepted=False,
        reason=reason,
        risk_budget_usd=risk_budget_usd,
        loss_per_lot_usd=loss_per_lot_usd,
        stop_distance_pips=stop_distance_pips,
        commission_per_lot_usd=commission_per_lot_usd,
    )


def size_position(
    *,
    account_equity_usd: float,
    symbol: str | FxPairSpec,
    side: str,
    entry_price: float,
    stop_loss: float,
    config: RiskConfig = RiskConfig(),
) -> PositionSizing:
    """Size a USD-major FX position from executable entry and stop-fill prices.

    The function is intentionally usable by a historical backtester without a
    quote object.  Pass already-costed prices here; use ``evaluate_paper_trade``
    when a bid/ask quote should be converted into paper fills automatically.
    """

    config_error = _validate_config(config)
    if config_error:
        return _sizing_rejection(config_error)

    spec = _resolve_pair(symbol)
    if spec is None:
        return _sizing_rejection("UNSUPPORTED_SYMBOL")
    if not _valid_spec(spec):
        return _sizing_rejection("INVALID_PAIR_SPEC")
    if not _positive(account_equity_usd):
        return _sizing_rejection("INVALID_ACCOUNT_EQUITY")
    if not _positive(entry_price) or not _positive(stop_loss):
        return _sizing_rejection("INVALID_PRICE")

    normalized_side = _normalize_side(side)
    if normalized_side not in {"BUY", "SELL"}:
        return _sizing_rejection("INVALID_SIDE")

    entry = float(entry_price)
    stop = float(stop_loss)
    if normalized_side == "BUY" and stop >= entry:
        return _sizing_rejection("INVALID_STOP_DIRECTION")
    if normalized_side == "SELL" and stop <= entry:
        return _sizing_rejection("INVALID_STOP_DIRECTION")

    equity = float(account_equity_usd)
    risk_budget = equity * float(config.risk_per_trade_pct) / 100.0
    if config.max_risk_per_trade_usd is not None:
        risk_budget = min(risk_budget, float(config.max_risk_per_trade_usd))

    stop_distance = abs(entry - stop)
    stop_distance_pips = stop_distance / spec.pip_size
    price_loss_per_lot = _price_move_to_usd(spec, stop_distance, stop)
    commission = float(config.commission_per_lot_round_turn_usd)
    loss_per_lot = price_loss_per_lot + commission
    if not _positive(loss_per_lot):
        return _sizing_rejection(
            "INVALID_LOSS_MODEL",
            risk_budget_usd=risk_budget,
            stop_distance_pips=stop_distance_pips,
            commission_per_lot_usd=commission,
        )

    raw_lots = risk_budget / loss_per_lot
    if raw_lots + _EPSILON < spec.min_lot:
        return _sizing_rejection(
            "POSITION_BELOW_MIN_LOT",
            risk_budget_usd=risk_budget,
            loss_per_lot_usd=loss_per_lot,
            stop_distance_pips=stop_distance_pips,
            commission_per_lot_usd=commission,
        )
    if raw_lots > spec.max_lot + _EPSILON:
        return _sizing_rejection(
            "POSITION_ABOVE_MAX_LOT",
            risk_budget_usd=risk_budget,
            loss_per_lot_usd=loss_per_lot,
            stop_distance_pips=stop_distance_pips,
            commission_per_lot_usd=commission,
        )

    lots = _round_lots_down(raw_lots, spec.lot_step)
    if lots + _EPSILON < spec.min_lot:
        return _sizing_rejection(
            "POSITION_BELOW_MIN_LOT",
            risk_budget_usd=risk_budget,
            loss_per_lot_usd=loss_per_lot,
            stop_distance_pips=stop_distance_pips,
            commission_per_lot_usd=commission,
        )

    units = int(round(lots * spec.contract_size))
    risk_amount = lots * loss_per_lot
    # `lots` was rounded DOWN specifically to keep risk within budget, but
    # floating-point multiplication can still overshoot the budget by a
    # sub-cent epsilon (e.g. 100.0000000000112 vs 100.0). Clamp to the
    # budget rather than let the reported risk ever exceed what was
    # actually authorized.
    risk_amount = min(risk_amount, risk_budget)
    return PositionSizing(
        accepted=True,
        reason="OK",
        units=units,
        lots=lots,
        risk_budget_usd=risk_budget,
        risk_amount_usd=risk_amount,
        loss_per_lot_usd=loss_per_lot,
        stop_distance_pips=stop_distance_pips,
        commission_per_lot_usd=commission,
    )


def _rejected_decision(
    reason: str,
    *,
    sizing: PositionSizing | None = None,
    symbol: str | None = None,
    side: str | None = None,
    entry_fill_price: float | None = None,
    stop_exit_price: float | None = None,
    take_profit_exit_price: float | None = None,
    spread_pips: float | None = None,
    reward_to_risk: float | None = None,
) -> RiskDecision:
    return RiskDecision(
        accepted=False,
        reason=reason,
        sizing=sizing or _sizing_rejection(reason),
        symbol=symbol,
        side=side,
        entry_fill_price=entry_fill_price,
        stop_exit_price=stop_exit_price,
        take_profit_exit_price=take_profit_exit_price,
        spread_pips=spread_pips,
        reward_to_risk=reward_to_risk,
    )


def _validate_account(account: object) -> str | None:
    if not isinstance(account, AccountState):
        return "INVALID_ACCOUNT_STATE"
    if not _positive(account.equity_usd) or not _positive(account.day_start_equity_usd):
        return "INVALID_ACCOUNT_STATE"
    if not _finite(account.realized_pnl_today_usd):
        return "INVALID_ACCOUNT_STATE"
    if not isinstance(account.open_positions, tuple):
        return "INVALID_ACCOUNT_STATE"
    for position in account.open_positions:
        if not isinstance(position, PaperPosition):
            return "INVALID_ACCOUNT_STATE"
        if not _positive(position.risk_amount_usd):
            return "INVALID_ACCOUNT_STATE"
        if not _normalize_symbol(position.symbol):
            return "INVALID_ACCOUNT_STATE"
    return None


def _adverse_entry_fill(side: str, quote: FxQuote, pip_size: float, slippage_pips: float) -> float:
    slippage = pip_size * slippage_pips
    return float(quote.ask) + slippage if side == "BUY" else float(quote.bid) - slippage


def _adverse_exit_fill(side: str, trigger_price: float, pip_size: float, slippage_pips: float) -> float:
    slippage = pip_size * slippage_pips
    return trigger_price - slippage if side == "BUY" else trigger_price + slippage


def evaluate_paper_trade(
    *,
    request: TradeRequest,
    quote: FxQuote,
    account: AccountState,
    config: RiskConfig = RiskConfig(),
) -> RiskDecision:
    """Validate and cost a market entry without creating or sending an order.

    A successful result contains a ``PaperPosition`` value.  The caller chooses
    whether to append it to a journal or to a new immutable account snapshot.
    """

    config_error = _validate_config(config)
    if config_error:
        return _rejected_decision(config_error)
    account_error = _validate_account(account)
    if account_error:
        return _rejected_decision(account_error)
    if not isinstance(request, TradeRequest):
        return _rejected_decision("INVALID_TRADE_REQUEST")
    if not isinstance(quote, FxQuote):
        return _rejected_decision("INVALID_QUOTE")

    spec = _resolve_pair(request.symbol)
    if spec is None:
        return _rejected_decision("UNSUPPORTED_SYMBOL")
    canonical_symbol = _normalize_symbol(spec.symbol)
    side = _normalize_side(request.side)
    if side not in {"BUY", "SELL"}:
        return _rejected_decision("INVALID_SIDE", symbol=canonical_symbol)
    if _normalize_symbol(quote.symbol) != canonical_symbol:
        return _rejected_decision("QUOTE_SYMBOL_MISMATCH", symbol=canonical_symbol, side=side)
    if not _positive(quote.bid) or not _positive(quote.ask) or float(quote.ask) < float(quote.bid):
        return _rejected_decision("INVALID_QUOTE", symbol=canonical_symbol, side=side)
    if not _positive(request.stop_loss) or not _positive(request.take_profit):
        return _rejected_decision("INVALID_PRICE", symbol=canonical_symbol, side=side)

    spread_pips = (float(quote.ask) - float(quote.bid)) / spec.pip_size
    if spread_pips > float(config.max_spread_pips) + _EPSILON:
        return _rejected_decision(
            "SPREAD_CAP",
            symbol=canonical_symbol,
            side=side,
            spread_pips=spread_pips,
        )

    entry_fill = _adverse_entry_fill(side, quote, spec.pip_size, float(config.slippage_pips_per_side))
    stop_exit = _adverse_exit_fill(side, float(request.stop_loss), spec.pip_size, float(config.slippage_pips_per_side))
    target_exit = _adverse_exit_fill(side, float(request.take_profit), spec.pip_size, float(config.slippage_pips_per_side))
    if not _positive(entry_fill) or not _positive(stop_exit) or not _positive(target_exit):
        return _rejected_decision(
            "INVALID_COSTED_FILL",
            symbol=canonical_symbol,
            side=side,
            entry_fill_price=entry_fill,
            stop_exit_price=stop_exit,
            take_profit_exit_price=target_exit,
            spread_pips=spread_pips,
        )

    sizing = size_position(
        account_equity_usd=account.equity_usd,
        symbol=spec,
        side=side,
        entry_price=entry_fill,
        stop_loss=stop_exit,
        config=config,
    )
    if not sizing.accepted:
        return _rejected_decision(
            sizing.reason,
            sizing=sizing,
            symbol=canonical_symbol,
            side=side,
            entry_fill_price=entry_fill,
            stop_exit_price=stop_exit,
            take_profit_exit_price=target_exit,
            spread_pips=spread_pips,
        )

    target_is_favorable = (
        target_exit > entry_fill if side == "BUY" else target_exit < entry_fill
    )
    if not target_is_favorable:
        return _rejected_decision(
            "INVALID_TARGET_DIRECTION",
            sizing=sizing,
            symbol=canonical_symbol,
            side=side,
            entry_fill_price=entry_fill,
            stop_exit_price=stop_exit,
            take_profit_exit_price=target_exit,
            spread_pips=spread_pips,
        )

    target_distance = abs(target_exit - entry_fill)
    gross_reward_per_lot = _price_move_to_usd(spec, target_distance, target_exit)
    commission_per_lot = float(config.commission_per_lot_round_turn_usd)
    net_reward_per_lot = gross_reward_per_lot - commission_per_lot
    reward_to_risk = net_reward_per_lot / float(sizing.loss_per_lot_usd)
    if reward_to_risk + _EPSILON < float(config.min_reward_to_risk):
        return _rejected_decision(
            "REWARD_TO_RISK_BELOW_MINIMUM",
            sizing=sizing,
            symbol=canonical_symbol,
            side=side,
            entry_fill_price=entry_fill,
            stop_exit_price=stop_exit,
            take_profit_exit_price=target_exit,
            spread_pips=spread_pips,
            reward_to_risk=reward_to_risk,
        )

    portfolio_problem = portfolio_limit_problem(
        open_positions=account.open_positions,
        symbol=canonical_symbol,
        side=side,
        risk_amount_usd=float(sizing.risk_amount_usd),
        equity_usd=float(account.equity_usd),
        config=config,
    )
    if portfolio_problem:
        return _rejected_decision(
            portfolio_problem,
            sizing=sizing,
            symbol=canonical_symbol,
            side=side,
            entry_fill_price=entry_fill,
            stop_exit_price=stop_exit,
            take_profit_exit_price=target_exit,
            spread_pips=spread_pips,
            reward_to_risk=reward_to_risk,
        )

    daily_loss_used = max(0.0, -float(account.realized_pnl_today_usd))
    daily_loss_cap = float(account.day_start_equity_usd) * float(config.daily_loss_limit_pct) / 100.0
    if daily_loss_used + float(sizing.risk_amount_usd) > daily_loss_cap + _EPSILON:
        return _rejected_decision(
            "DAILY_LOSS_CAP",
            sizing=sizing,
            symbol=canonical_symbol,
            side=side,
            entry_fill_price=entry_fill,
            stop_exit_price=stop_exit,
            take_profit_exit_price=target_exit,
            spread_pips=spread_pips,
            reward_to_risk=reward_to_risk,
        )

    commission_usd = float(sizing.lots) * commission_per_lot
    expected_reward_usd = float(sizing.lots) * net_reward_per_lot
    position = PaperPosition(
        symbol=canonical_symbol,
        side=side,
        lots=float(sizing.lots),
        units=int(sizing.units),
        entry_fill_price=entry_fill,
        stop_exit_price=stop_exit,
        take_profit_exit_price=target_exit,
        risk_amount_usd=float(sizing.risk_amount_usd),
        expected_reward_usd=expected_reward_usd,
        round_turn_commission_usd=commission_usd,
    )
    return RiskDecision(
        accepted=True,
        reason="OK",
        sizing=sizing,
        symbol=canonical_symbol,
        side=side,
        entry_fill_price=entry_fill,
        stop_exit_price=stop_exit,
        take_profit_exit_price=target_exit,
        spread_pips=spread_pips,
        reward_to_risk=reward_to_risk,
        position=position,
    )


def currency_legs(symbol: str, side: str) -> tuple[tuple[str, int], ...]:
    """(currency, +1 long / -1 short) for each leg of a BUY or SELL on `symbol`."""

    canonical = _normalize_symbol(symbol)
    spec = FX_USD_MAJOR_SPECS.get(canonical) or _RESEARCH_SPECS.get(canonical)
    if spec is not None:
        base, quote = spec.base_currency.upper(), spec.quote_currency.upper()
    elif len(canonical) == 6 and canonical.isalpha():
        base, quote = canonical[:3], canonical[3:]
    else:
        return ()
    direction = 1 if _normalize_side(side) == "BUY" else -1
    return ((base, direction), (quote, -direction))


def currency_risk_exposure(open_positions) -> dict[str, float]:
    """Signed USD risk per currency across open positions (positive = long)."""

    exposure: dict[str, float] = {}
    for position in open_positions:
        for currency, sign in currency_legs(position.symbol, position.side):
            exposure[currency] = exposure.get(currency, 0.0) + sign * float(position.risk_amount_usd)
    return exposure


def portfolio_limit_problem(
    *,
    open_positions,
    symbol: str,
    side: str,
    risk_amount_usd: float,
    equity_usd: float,
    config: RiskConfig,
) -> str | None:
    """Return the portfolio cap a new position would breach, or None.

    One function, so the admission check here and the paper account's
    open-time re-check (made under its lock, where concurrent symbols cannot
    both slip under a cap) cannot drift apart. ``open_positions`` items need
    only ``symbol``, ``side`` and ``risk_amount_usd``.
    """

    positions = tuple(open_positions)
    canonical_symbol = _normalize_symbol(symbol)

    if len(positions) >= config.max_positions:
        return "MAX_POSITIONS_REACHED"

    symbol_positions = sum(1 for position in positions if _normalize_symbol(position.symbol) == canonical_symbol)
    if symbol_positions >= config.max_positions_per_symbol:
        return "MAX_SYMBOL_POSITIONS_REACHED"

    open_risk = sum(float(position.risk_amount_usd) for position in positions)
    total_open_risk_cap = float(equity_usd) * float(config.max_total_open_risk_pct) / 100.0
    if config.max_total_open_risk_usd is not None:
        total_open_risk_cap = min(total_open_risk_cap, float(config.max_total_open_risk_usd))
    if open_risk + float(risk_amount_usd) > total_open_risk_cap + _EPSILON:
        return "TOTAL_OPEN_RISK_CAP"

    exposure = currency_risk_exposure(positions)
    currency_cap = float(equity_usd) * float(config.max_currency_exposure_pct) / 100.0
    for currency, sign in currency_legs(canonical_symbol, side):
        before = exposure.get(currency, 0.0)
        after = before + sign * float(risk_amount_usd)
        # Only stacking onto an existing same-direction exposure can breach the cap;
        # a lone position, or one that offsets exposure, never does.
        if before * sign > _EPSILON and abs(after) > currency_cap + _EPSILON:
            return "CURRENCY_EXPOSURE_CAP"

    return None


def close_paper_position(
    *,
    position: PaperPosition,
    exit_price: float,
    config: RiskConfig = RiskConfig(),
) -> PaperClose:
    """Calculate a paper close from an executable exit trigger price.

    The supplied ``exit_price`` is adverse-slippage-free.  This function applies
    one closing slippage charge and the round-turn commission already reserved in
    ``position``.  It does not alter the position or account snapshot.
    """

    config_error = _validate_config(config)
    if config_error:
        return PaperClose(False, config_error)
    if not isinstance(position, PaperPosition):
        return PaperClose(False, "INVALID_POSITION")
    spec = _resolve_pair(position.symbol)
    if spec is None or not _positive(position.entry_fill_price) or not _positive(position.lots):
        return PaperClose(False, "INVALID_POSITION")
    if not _positive(position.round_turn_commission_usd) and position.round_turn_commission_usd != 0.0:
        return PaperClose(False, "INVALID_POSITION")
    side = _normalize_side(position.side)
    if side not in {"BUY", "SELL"} or not _positive(exit_price):
        return PaperClose(False, "INVALID_CLOSE_PRICE")

    exit_fill = _adverse_exit_fill(side, float(exit_price), spec.pip_size, float(config.slippage_pips_per_side))
    if not _positive(exit_fill):
        return PaperClose(False, "INVALID_COSTED_FILL")

    price_delta = (
        exit_fill - position.entry_fill_price
        if side == "BUY"
        else position.entry_fill_price - exit_fill
    )
    gross_per_lot = _price_move_to_usd(spec, abs(price_delta), exit_fill)
    gross_pnl = gross_per_lot * position.lots
    if price_delta < 0.0:
        gross_pnl = -gross_pnl
    net_pnl = gross_pnl - position.round_turn_commission_usd
    result_r = net_pnl / position.risk_amount_usd if position.risk_amount_usd > 0.0 else None
    return PaperClose(
        accepted=True,
        reason="OK",
        exit_fill_price=exit_fill,
        gross_pnl_usd=gross_pnl,
        net_pnl_usd=net_pnl,
        result_r=result_r,
    )
