"""Deterministic, paper/research-only intraday spot-FX strategy.

The module deliberately has no broker, network, persistence, or AI dependency.
It turns a chronological sequence of *closed* OHLC bars into an explainable
``BUY``, ``SELL``, or ``FLAT`` signal.  A caller must pass only bars that were
complete at the decision time; the strategy neither reorders bars nor reads
outside the supplied sequence.

The setup is intentionally modest and testable:

* trend: fast/slow EMA alignment, price location, and slow-EMA slope;
* pullback: a recent retracement reaches the fast EMA without becoming too
  deep relative to the slow EMA; and
* momentum: the newest closed bar resumes the trend with a meaningful body.

It is research infrastructure, not a claim of profitability and not an order
execution component.  Downstream risk and paper-execution layers must validate
every non-flat signal independently.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite
from typing import Any, Iterable, List, Mapping, Optional, Sequence, Tuple, Union


__all__ = [
    "Bar",
    "Signal",
    "StrategyConfig",
    "ForexIntradayStrategy",
    "generate_signal",
]


_DIRECTIONS = {"BUY", "SELL", "FLAT"}


def _finite_float(value: Any, field_name: str) -> float:
    """Return a finite float or raise a useful validation error."""

    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a finite number, not a boolean")

    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be a finite number") from exc

    if not isfinite(number):
        raise ValueError(f"{field_name} must be finite")

    return number


@dataclass(frozen=True)
class Bar:
    """One completed OHLC bar, in oldest-to-newest sequence order.

    ``timestamp`` is intentionally opaque: it can be an ISO string, a
    ``datetime``, or another value supplied by the market-data adapter.  The
    strategy returns it unchanged in ``Signal.signal_timestamp``.
    """

    open: float
    high: float
    low: float
    close: float
    timestamp: Optional[Any] = None
    volume: Optional[float] = None

    def __post_init__(self) -> None:
        open_price = _finite_float(self.open, "open")
        high_price = _finite_float(self.high, "high")
        low_price = _finite_float(self.low, "low")
        close_price = _finite_float(self.close, "close")

        if low_price > min(open_price, close_price):
            raise ValueError("low cannot exceed open or close")
        if high_price < max(open_price, close_price):
            raise ValueError("high cannot be below open or close")
        if low_price > high_price:
            raise ValueError("low cannot exceed high")

        object.__setattr__(self, "open", open_price)
        object.__setattr__(self, "high", high_price)
        object.__setattr__(self, "low", low_price)
        object.__setattr__(self, "close", close_price)

        if self.volume is not None:
            volume = _finite_float(self.volume, "volume")
            if volume < 0:
                raise ValueError("volume cannot be negative")
            object.__setattr__(self, "volume", volume)


@dataclass(frozen=True)
class StrategyConfig:
    """Parameters for :class:`ForexIntradayStrategy`.

    Periods refer to completed bars, not wall-clock minutes.  For example, the
    defaults can be used with M5, M15, or H1 bars, provided backtests use the
    same timeframe.  ``confidence`` is a deterministic setup-strength score;
    it is not a calibrated probability of profit.
    """

    fast_ema_period: int = 8
    slow_ema_period: int = 21
    atr_period: int = 14
    pullback_lookback: int = 3
    trend_slope_lookback: int = 3
    minimum_trend_separation_atr: float = 0.05
    maximum_pullback_depth_atr: float = 1.25
    minimum_confirmation_body_atr: float = 0.15
    stop_atr_buffer: float = 0.25
    reward_to_risk: float = 1.5

    def __post_init__(self) -> None:
        for field_name in (
            "fast_ema_period",
            "slow_ema_period",
            "atr_period",
            "pullback_lookback",
            "trend_slope_lookback",
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{field_name} must be a positive integer")

        if self.fast_ema_period >= self.slow_ema_period:
            raise ValueError("fast_ema_period must be smaller than slow_ema_period")

        for field_name in (
            "minimum_trend_separation_atr",
            "maximum_pullback_depth_atr",
            "minimum_confirmation_body_atr",
            "stop_atr_buffer",
            "reward_to_risk",
        ):
            value = _finite_float(getattr(self, field_name), field_name)
            if value <= 0:
                raise ValueError(f"{field_name} must be greater than zero")
            object.__setattr__(self, field_name, value)

    @property
    def minimum_history(self) -> int:
        """Closed bars required before the strategy can evaluate a setup.

        The amount explicitly covers the slow EMA, its requested slope, ATR,
        and one current confirmation bar after the pullback window.
        """

        return max(
            self.slow_ema_period + self.trend_slope_lookback,
            self.atr_period,
            self.pullback_lookback + 2,
        )


@dataclass(frozen=True)
class Signal:
    """An explainable paper/research signal produced at one closed bar.

    ``entry``, ``stop_loss``, and ``take_profit`` are illustrative levels for
    research and must not be interpreted as executable quotes.  They are
    ``None`` for ``FLAT`` signals.  ``confidence`` is in the inclusive range
    0.0--1.0 and is a heuristic setup-strength score, not a probability.
    """

    direction: str
    entry: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    confidence: float
    reasons: Tuple[str, ...]
    signal_bar_index: Optional[int]
    signal_timestamp: Optional[Any]
    trend: str = "NEUTRAL"
    atr: Optional[float] = None
    fast_ema: Optional[float] = None
    slow_ema: Optional[float] = None

    def __post_init__(self) -> None:
        direction = str(self.direction).upper()
        if direction not in _DIRECTIONS:
            raise ValueError("direction must be BUY, SELL, or FLAT")
        object.__setattr__(self, "direction", direction)

        confidence = _finite_float(self.confidence, "confidence")
        if not 0.0 <= confidence <= 1.0:
            raise ValueError("confidence must be between 0.0 and 1.0")
        object.__setattr__(self, "confidence", confidence)

        reasons = tuple(str(reason) for reason in self.reasons)
        if not reasons:
            raise ValueError("signals must include at least one reason")
        object.__setattr__(self, "reasons", reasons)

        for field_name in ("entry", "stop_loss", "take_profit", "atr", "fast_ema", "slow_ema"):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, _finite_float(value, field_name))

        if direction == "FLAT":
            if any(
                value is not None
                for value in (self.entry, self.stop_loss, self.take_profit)
            ):
                raise ValueError("FLAT signals cannot contain trade levels")
            return

        if None in (self.entry, self.stop_loss, self.take_profit):
            raise ValueError("BUY and SELL signals require entry, stop_loss, and take_profit")

        if direction == "BUY" and not self.stop_loss < self.entry < self.take_profit:
            raise ValueError("BUY levels must satisfy stop_loss < entry < take_profit")
        if direction == "SELL" and not self.take_profit < self.entry < self.stop_loss:
            raise ValueError("SELL levels must satisfy take_profit < entry < stop_loss")

    @property
    def is_trade(self) -> bool:
        """Whether this signal proposes a paper/research trade setup."""

        return self.direction in {"BUY", "SELL"}

    @property
    def confidence_label(self) -> str:
        """A coarse display label for the deterministic confidence score."""

        if self.confidence >= 0.75:
            return "HIGH"
        if self.confidence >= 0.55:
            return "MEDIUM"
        return "LOW"

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-friendly representation of this signal."""

        result = asdict(self)
        result["reasons"] = list(self.reasons)
        result["is_trade"] = self.is_trade
        result["confidence_label"] = self.confidence_label
        return result


BarInput = Union[Bar, Mapping[str, Any], Any]


class ForexIntradayStrategy:
    """Trend-pullback-momentum strategy that only evaluates completed bars.

    The instance is stateless.  Calling it repeatedly with the same bar prefix
    produces the same result, and it cannot inspect bars that were not passed
    to that call.  This makes it safe to use inside a chronological backtest
    loop that supplies ``bars[:decision_index + 1]``.
    """

    def __init__(self, config: Optional[StrategyConfig] = None) -> None:
        self.config = config if config is not None else StrategyConfig()
        if not isinstance(self.config, StrategyConfig):
            raise TypeError("config must be a StrategyConfig instance")

    @property
    def minimum_history(self) -> int:
        """Minimum number of closed bars required for evaluation."""

        return self.config.minimum_history

    def evaluate(self, bars: Sequence[BarInput]) -> Signal:
        """Evaluate the newest supplied *closed* bar without lookahead.

        ``bars`` must already be ordered from oldest to newest.  This method
        does not mutate, sort, cache, or augment the sequence, so values from a
        future bar cannot affect the result for a supplied prefix.
        """

        normalized = tuple(_coerce_bar(raw, index) for index, raw in enumerate(bars))
        bar_index = len(normalized) - 1 if normalized else None
        timestamp = normalized[-1].timestamp if normalized else None

        if len(normalized) < self.minimum_history:
            return self._flat(
                bar_index=bar_index,
                timestamp=timestamp,
                reasons=(
                    "INSUFFICIENT_HISTORY: received "
                    f"{len(normalized)} closed bars; requires at least "
                    f"{self.minimum_history}.",
                ),
            )

        closes = [bar.close for bar in normalized]
        fast_emas = _ema_series(closes, self.config.fast_ema_period)
        slow_emas = _ema_series(closes, self.config.slow_ema_period)
        atrs = _atr_series(normalized, self.config.atr_period)

        fast_ema = fast_emas[-1]
        slow_ema = slow_emas[-1]
        prior_slow_ema = slow_emas[-1 - self.config.trend_slope_lookback]
        atr = atrs[-1]

        # minimum_history guarantees that these values exist; preserve the
        # guard so future config changes fail safely rather than emit a trade.
        if (
            fast_ema is None
            or slow_ema is None
            or prior_slow_ema is None
            or atr is None
            or atr <= 0.0
        ):
            return self._flat(
                bar_index=bar_index,
                timestamp=timestamp,
                reasons=(
                    "INDICATOR_UNAVAILABLE: EMA or ATR could not be derived "
                    "from the supplied closed bars.",
                ),
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        current = normalized[-1]
        separation_atr = abs(fast_ema - slow_ema) / atr
        trend_up = (
            current.close > slow_ema
            and fast_ema > slow_ema
            and slow_ema > prior_slow_ema
            and separation_atr >= self.config.minimum_trend_separation_atr
        )
        trend_down = (
            current.close < slow_ema
            and fast_ema < slow_ema
            and slow_ema < prior_slow_ema
            and separation_atr >= self.config.minimum_trend_separation_atr
        )

        if not trend_up and not trend_down:
            return self._flat(
                bar_index=bar_index,
                timestamp=timestamp,
                reasons=(
                    "TREND_FILTER_NOT_MET: "
                    f"close={current.close:.6f}, fast_ema={fast_ema:.6f}, "
                    f"slow_ema={slow_ema:.6f}, "
                    f"slow_ema_{self.config.trend_slope_lookback}_bars_ago="
                    f"{prior_slow_ema:.6f}, separation_atr={separation_atr:.3f}.",
                ),
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        if trend_up:
            return self._evaluate_uptrend(
                normalized,
                fast_emas,
                slow_emas,
                atrs,
                fast_ema,
                slow_ema,
                prior_slow_ema,
                atr,
            )

        return self._evaluate_downtrend(
            normalized,
            fast_emas,
            slow_emas,
            atrs,
            fast_ema,
            slow_ema,
            prior_slow_ema,
            atr,
        )

    def generate_signal(self, bars: Sequence[BarInput]) -> Signal:
        """Alias for :meth:`evaluate` for simple signal-provider adapters."""

        return self.evaluate(bars)

    def analyze(self, bars: Sequence[BarInput]) -> Signal:
        """Alias for :meth:`evaluate` for analysis-oriented callers."""

        return self.evaluate(bars)

    def __call__(self, bars: Sequence[BarInput]) -> Signal:
        return self.evaluate(bars)

    def _evaluate_uptrend(
        self,
        bars: Tuple[Bar, ...],
        fast_emas: Sequence[Optional[float]],
        slow_emas: Sequence[Optional[float]],
        atrs: Sequence[Optional[float]],
        fast_ema: float,
        slow_ema: float,
        prior_slow_ema: float,
        atr: float,
    ) -> Signal:
        pullback_index = self._pullback_index(
            bars, fast_emas, slow_emas, atrs, direction="BUY"
        )
        current_index = len(bars) - 1
        current = bars[-1]

        trend_reason = (
            "UPTREND_CONFIRMED: "
            f"close={current.close:.6f} > slow_ema={slow_ema:.6f}; "
            f"fast_ema={fast_ema:.6f} > slow_ema; "
            f"slow_ema rose from {prior_slow_ema:.6f}."
        )

        if pullback_index is None:
            return self._flat(
                bar_index=current_index,
                timestamp=current.timestamp,
                reasons=(
                    trend_reason,
                    "PULLBACK_NOT_FOUND: no recent bar touched the fast EMA "
                    "within the permitted depth below the slow EMA.",
                ),
                trend="UP",
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        body = current.close - current.open
        previous_close = bars[-2].close
        if not (
            body >= self.config.minimum_confirmation_body_atr * atr
            and current.close > fast_ema
            and current.close > previous_close
        ):
            return self._flat(
                bar_index=current_index,
                timestamp=current.timestamp,
                reasons=(
                    trend_reason,
                    self._pullback_reason(bars, pullback_index, fast_emas, "BUY"),
                    "MOMENTUM_NOT_CONFIRMED: buy confirmation requires a bullish "
                    "body of at least "
                    f"{self.config.minimum_confirmation_body_atr:.2f} ATR, a close "
                    "above the fast EMA, and a close above the previous close.",
                ),
                trend="UP",
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        swing_low = min(bar.low for bar in bars[pullback_index:])
        entry = current.close
        stop_loss = swing_low - self.config.stop_atr_buffer * atr
        if stop_loss >= entry:
            return self._flat(
                bar_index=current_index,
                timestamp=current.timestamp,
                reasons=(
                    trend_reason,
                    "INVALID_RESEARCH_LEVELS: calculated buy stop is not below "
                    "the current close.",
                ),
                trend="UP",
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        risk = entry - stop_loss
        take_profit = entry + self.config.reward_to_risk * risk
        confidence = self._confidence(fast_ema, slow_ema, atr, abs(body))
        return Signal(
            direction="BUY",
            entry=entry,
            stop_loss=stop_loss,
            take_profit=take_profit,
            confidence=confidence,
            reasons=(
                trend_reason,
                self._pullback_reason(bars, pullback_index, fast_emas, "BUY"),
                "MOMENTUM_CONFIRMED: bullish close resumed above the fast EMA "
                f"with body={body:.6f} ({body / atr:.2f} ATR).",
                "RESEARCH_LEVELS: stop is the pullback swing low minus "
                f"{self.config.stop_atr_buffer:.2f} ATR; target is "
                f"{self.config.reward_to_risk:.2f}R.",
            ),
            signal_bar_index=current_index,
            signal_timestamp=current.timestamp,
            trend="UP",
            atr=atr,
            fast_ema=fast_ema,
            slow_ema=slow_ema,
        )

    def _evaluate_downtrend(
        self,
        bars: Tuple[Bar, ...],
        fast_emas: Sequence[Optional[float]],
        slow_emas: Sequence[Optional[float]],
        atrs: Sequence[Optional[float]],
        fast_ema: float,
        slow_ema: float,
        prior_slow_ema: float,
        atr: float,
    ) -> Signal:
        pullback_index = self._pullback_index(
            bars, fast_emas, slow_emas, atrs, direction="SELL"
        )
        current_index = len(bars) - 1
        current = bars[-1]

        trend_reason = (
            "DOWNTREND_CONFIRMED: "
            f"close={current.close:.6f} < slow_ema={slow_ema:.6f}; "
            f"fast_ema={fast_ema:.6f} < slow_ema; "
            f"slow_ema fell from {prior_slow_ema:.6f}."
        )

        if pullback_index is None:
            return self._flat(
                bar_index=current_index,
                timestamp=current.timestamp,
                reasons=(
                    trend_reason,
                    "PULLBACK_NOT_FOUND: no recent bar touched the fast EMA "
                    "within the permitted depth above the slow EMA.",
                ),
                trend="DOWN",
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        body = current.open - current.close
        previous_close = bars[-2].close
        if not (
            body >= self.config.minimum_confirmation_body_atr * atr
            and current.close < fast_ema
            and current.close < previous_close
        ):
            return self._flat(
                bar_index=current_index,
                timestamp=current.timestamp,
                reasons=(
                    trend_reason,
                    self._pullback_reason(bars, pullback_index, fast_emas, "SELL"),
                    "MOMENTUM_NOT_CONFIRMED: sell confirmation requires a bearish "
                    "body of at least "
                    f"{self.config.minimum_confirmation_body_atr:.2f} ATR, a close "
                    "below the fast EMA, and a close below the previous close.",
                ),
                trend="DOWN",
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        swing_high = max(bar.high for bar in bars[pullback_index:])
        entry = current.close
        stop_loss = swing_high + self.config.stop_atr_buffer * atr
        if stop_loss <= entry:
            return self._flat(
                bar_index=current_index,
                timestamp=current.timestamp,
                reasons=(
                    trend_reason,
                    "INVALID_RESEARCH_LEVELS: calculated sell stop is not above "
                    "the current close.",
                ),
                trend="DOWN",
                fast_ema=fast_ema,
                slow_ema=slow_ema,
                atr=atr,
            )

        risk = stop_loss - entry
        take_profit = entry - self.config.reward_to_risk * risk
        confidence = self._confidence(fast_ema, slow_ema, atr, abs(body))
        return Signal(
            direction="SELL",
            entry=entry,
            stop_loss=stop_loss,
            take_profit=take_profit,
            confidence=confidence,
            reasons=(
                trend_reason,
                self._pullback_reason(bars, pullback_index, fast_emas, "SELL"),
                "MOMENTUM_CONFIRMED: bearish close resumed below the fast EMA "
                f"with body={body:.6f} ({body / atr:.2f} ATR).",
                "RESEARCH_LEVELS: stop is the pullback swing high plus "
                f"{self.config.stop_atr_buffer:.2f} ATR; target is "
                f"{self.config.reward_to_risk:.2f}R.",
            ),
            signal_bar_index=current_index,
            signal_timestamp=current.timestamp,
            trend="DOWN",
            atr=atr,
            fast_ema=fast_ema,
            slow_ema=slow_ema,
        )

    def _pullback_index(
        self,
        bars: Sequence[Bar],
        fast_emas: Sequence[Optional[float]],
        slow_emas: Sequence[Optional[float]],
        atrs: Sequence[Optional[float]],
        direction: str,
    ) -> Optional[int]:
        """Return the most recent pre-confirmation pullback bar, if any."""

        start = max(0, len(bars) - 1 - self.config.pullback_lookback)
        for index in range(len(bars) - 2, start - 1, -1):
            fast_ema = fast_emas[index]
            slow_ema = slow_emas[index]
            atr = atrs[index]
            if fast_ema is None or slow_ema is None or atr is None or atr <= 0.0:
                continue

            if direction == "BUY":
                reached_fast_ema = bars[index].low <= fast_ema
                within_depth = (
                    bars[index].low
                    >= slow_ema - self.config.maximum_pullback_depth_atr * atr
                )
            else:
                reached_fast_ema = bars[index].high >= fast_ema
                within_depth = (
                    bars[index].high
                    <= slow_ema + self.config.maximum_pullback_depth_atr * atr
                )

            if reached_fast_ema and within_depth:
                return index

        return None

    @staticmethod
    def _pullback_reason(
        bars: Sequence[Bar],
        index: int,
        fast_emas: Sequence[Optional[float]],
        direction: str,
    ) -> str:
        if direction == "BUY":
            return (
                f"PULLBACK_CONFIRMED: bar {index} low={bars[index].low:.6f} "
                f"reached fast_ema={fast_emas[index]:.6f}."
            )
        return (
            f"PULLBACK_CONFIRMED: bar {index} high={bars[index].high:.6f} "
            f"reached fast_ema={fast_emas[index]:.6f}."
        )

    def _confidence(
        self,
        fast_ema: float,
        slow_ema: float,
        atr: float,
        body: float,
    ) -> float:
        """Return a bounded, interpretable setup-strength heuristic.

        This deliberately rewards only observable alignment and confirmation;
        it is not trained or calibrated on future returns.
        """

        separation_atr = abs(fast_ema - slow_ema) / atr
        body_atr = body / atr
        score = (
            0.55
            + min(0.20, separation_atr * 0.10)
            + min(0.15, body_atr * 0.05)
            + 0.05  # trend, pullback, and momentum all passed
        )
        return round(min(0.95, score), 4)

    @staticmethod
    def _flat(
        *,
        bar_index: Optional[int],
        timestamp: Optional[Any],
        reasons: Tuple[str, ...],
        trend: str = "NEUTRAL",
        atr: Optional[float] = None,
        fast_ema: Optional[float] = None,
        slow_ema: Optional[float] = None,
    ) -> Signal:
        return Signal(
            direction="FLAT",
            entry=None,
            stop_loss=None,
            take_profit=None,
            confidence=0.0,
            reasons=reasons,
            signal_bar_index=bar_index,
            signal_timestamp=timestamp,
            trend=trend,
            atr=atr,
            fast_ema=fast_ema,
            slow_ema=slow_ema,
        )


def generate_signal(
    bars: Sequence[BarInput], config: Optional[StrategyConfig] = None
) -> Signal:
    """Convenience wrapper around :class:`ForexIntradayStrategy`.

    A new stateless strategy is created for the call, which makes accidental
    cross-run state leakage impossible in simple backtest adapters.
    """

    return ForexIntradayStrategy(config).evaluate(bars)


def _coerce_bar(raw: BarInput, index: int) -> Bar:
    if isinstance(raw, Bar):
        return raw

    if isinstance(raw, Mapping):
        source = raw
        try:
            return Bar(
                open=_mapping_value(source, "open"),
                high=_mapping_value(source, "high"),
                low=_mapping_value(source, "low"),
                close=_mapping_value(source, "close"),
                timestamp=_optional_mapping_value(source, "timestamp", "time", "datetime"),
                volume=_optional_mapping_value(source, "volume"),
            )
        except ValueError as exc:
            raise ValueError(f"invalid bar at index {index}: {exc}") from exc

    try:
        return Bar(
            open=getattr(raw, "open"),
            high=getattr(raw, "high"),
            low=getattr(raw, "low"),
            close=getattr(raw, "close"),
            timestamp=_optional_attribute_value(raw, "timestamp", "time", "datetime"),
            volume=_optional_attribute_value(raw, "volume"),
        )
    except AttributeError as exc:
        raise ValueError(
            f"bar at index {index} must be a Bar, mapping, or object with "
            "open/high/low/close attributes"
        ) from exc
    except ValueError as exc:
        raise ValueError(f"invalid bar at index {index}: {exc}") from exc


def _mapping_value(source: Mapping[str, Any], name: str) -> Any:
    value = _optional_mapping_value(source, name)
    if value is None:
        raise ValueError(f"missing required '{name}' field")
    return value


def _optional_mapping_value(source: Mapping[str, Any], *names: str) -> Optional[Any]:
    for name in names:
        if name in source:
            return source[name]

    lower_names = {name.lower() for name in names}
    for key, value in source.items():
        if isinstance(key, str) and key.lower() in lower_names:
            return value
    return None


def _optional_attribute_value(source: Any, *names: str) -> Optional[Any]:
    for name in names:
        if hasattr(source, name):
            return getattr(source, name)
    return None


def _ema_series(values: Sequence[float], period: int) -> List[Optional[float]]:
    """Compute a causal EMA series seeded from the first full SMA window."""

    result: List[Optional[float]] = [None] * len(values)
    if len(values) < period:
        return result

    ema = sum(values[:period]) / period
    result[period - 1] = ema
    multiplier = 2.0 / (period + 1.0)
    for index in range(period, len(values)):
        ema = (values[index] - ema) * multiplier + ema
        result[index] = ema
    return result


def _atr_series(bars: Sequence[Bar], period: int) -> List[Optional[float]]:
    """Compute a causal Wilder ATR series from completed OHLC bars."""

    result: List[Optional[float]] = [None] * len(bars)
    if len(bars) < period:
        return result

    true_ranges: List[float] = []
    for index, bar in enumerate(bars):
        if index == 0:
            true_range = bar.high - bar.low
        else:
            previous_close = bars[index - 1].close
            true_range = max(
                bar.high - bar.low,
                abs(bar.high - previous_close),
                abs(bar.low - previous_close),
            )
        true_ranges.append(true_range)

    atr = sum(true_ranges[:period]) / period
    result[period - 1] = atr
    for index in range(period, len(bars)):
        atr = ((atr * (period - 1)) + true_ranges[index]) / period
        result[index] = atr
    return result
