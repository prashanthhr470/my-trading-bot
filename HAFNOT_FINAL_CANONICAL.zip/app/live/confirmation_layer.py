"""
LIVE CONFIRMATION LAYER.

Wraps a candidate produced by app.quant.core_strategy (historically
testable, OHLC-only) and adds confirmation/veto checks from data that is
ONLY available live: order flow / depth, news, fundamentals, sentiment,
and current real execution conditions (live spread).

This module never fetches data itself - it CONSUMES evidence that the
live pipeline has already gathered through the existing, tested code
paths (app.paper.market_snapshot.build_orderflow_evidence,
app.fundamental_engine, app.sentiment_engine, called from
app.agent.agent_runtime / app.agent.intelligence_pipeline). That keeps
this module simple, avoids duplicating network calls, and means it is
architecturally IMPOSSIBLE for a historical backtest to accidentally
pull this module in and silently get live data it shouldn't have - the
backtester (app.quant.costed_backtest) simply never imports app.live.*.

Every live input is OPTIONAL. Missing live data does not invent a
favorable or neutral result - see _missing_data_policy below, which
fails toward caution (does not upgrade confidence) rather than toward
silently ignoring the gap.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ConfirmationResult:
    approved: bool
    reason: str
    confirmations: list = field(default_factory=list)
    vetoes: list = field(default_factory=list)
    live_data_available: dict = field(default_factory=dict)


def _orderflow_confirms(core_direction: str, orderflow_evidence: Optional[dict]) -> Optional[bool]:
    """
    True if depth imbalance agrees with the candidate direction, False if
    it meaningfully disagrees, None if no usable orderflow data is
    available (distinct from False - absence is not disagreement).
    """

    if not isinstance(orderflow_evidence, dict):
        return None

    imbalance = orderflow_evidence.get("depth_imbalance")
    if imbalance is None:
        return None

    try:
        imbalance = float(imbalance)
    except (TypeError, ValueError):
        return None

    # depth_imbalance > 0 means more resting bid volume than ask volume
    # (per app.agent.intelligence_pipeline._build_native_orderflow) - a
    # loose proxy for buy-side interest, not true executed trade delta.
    threshold = 0.10
    if imbalance > threshold:
        return core_direction == "BUY"
    if imbalance < -threshold:
        return core_direction == "SELL"
    return None  # imbalance too small to mean anything


def _news_permits_trading(news_evidence: Optional[dict]) -> tuple[Optional[bool], str]:
    """
    Mirrors app.ai.decision_gate's news firewall logic (HIGH_RISK/
    trading_restriction/UNAVAILABLE/STALE all block). Returns
    (permits, reason). permits=None means "no news evidence was supplied
    at all" (distinct from permits=False, an active block).
    """

    if news_evidence is None:
        return None, "No news evidence supplied."

    if not isinstance(news_evidence, dict):
        return False, "News evidence malformed - failing closed."

    status = news_evidence.get("status")
    if status == "HIGH_RISK":
        return False, "HIGH_RISK news conditions."
    if news_evidence.get("trading_restriction"):
        return False, "News engine imposed a trading restriction."
    if status in {"UNAVAILABLE", "STALE"}:
        return False, f"News status is {status}."
    if news_evidence.get("high", 0) and news_evidence.get("high", 0) > 0:
        return False, "High-relevance news detected."

    return True, "No active news restriction."


def _sentiment_confirms(core_direction: str, sentiment_evidence: Optional[dict]) -> Optional[bool]:
    if not isinstance(sentiment_evidence, dict):
        return None

    if not sentiment_evidence.get("available", False):
        return None

    direction = str(sentiment_evidence.get("direction", "")).lower()
    if sentiment_evidence.get("risk_override"):
        return None

    if direction == "bullish":
        return core_direction == "BUY"
    if direction == "bearish":
        return core_direction == "SELL"
    return None


def _spread_acceptable(current_spread_pips: Optional[float], max_spread_pips: Optional[float]) -> Optional[bool]:
    if current_spread_pips is None or max_spread_pips is None:
        return None
    return current_spread_pips <= max_spread_pips


def apply_live_confirmation(
    core_candidate: dict[str, Any],
    *,
    orderflow_evidence: Optional[dict] = None,
    news_evidence: Optional[dict] = None,
    sentiment_evidence: Optional[dict] = None,
    current_spread_pips: Optional[float] = None,
    max_spread_pips: Optional[float] = None,
    require_orderflow_confirmation: bool = False,
    require_sentiment_confirmation: bool = False,
) -> ConfirmationResult:
    """
    core_candidate: the dict returned by app.quant.core_strategy.evaluate()
    (must have at least "direction"). This function does not modify it -
    it only decides whether to approve execution proceeding.

    require_orderflow_confirmation / require_sentiment_confirmation: if
    True, a candidate is REJECTED when that live signal is unavailable or
    disagrees (stricter). If False (default), those signals only add a
    note when they agree/disagree but never block on their own - only
    news can hard-block, matching the existing decision_gate's firewall
    design (app.ai.decision_gate).
    """

    direction = core_candidate.get("direction")
    confirmations: list[str] = []
    vetoes: list[str] = []

    live_data_available = {
        "orderflow": orderflow_evidence is not None,
        "news": news_evidence is not None,
        "sentiment": sentiment_evidence is not None,
        "spread": current_spread_pips is not None,
    }

    # --------------------------------------------------------------
    # NEWS: hard block, same policy as the live decision gate.
    # --------------------------------------------------------------

    news_ok, news_reason = _news_permits_trading(news_evidence)
    if news_ok is False:
        return ConfirmationResult(
            approved=False,
            reason=f"Blocked by news firewall: {news_reason}",
            vetoes=[news_reason],
            live_data_available=live_data_available,
        )

    # --------------------------------------------------------------
    # SPREAD: hard block if live spread data says it's too wide.
    # --------------------------------------------------------------

    spread_ok = _spread_acceptable(current_spread_pips, max_spread_pips)
    if spread_ok is False:
        reason = f"Live spread {current_spread_pips} exceeds max {max_spread_pips}."
        return ConfirmationResult(
            approved=False, reason=reason, vetoes=[reason],
            live_data_available=live_data_available,
        )
    if spread_ok is True:
        confirmations.append("Live spread within limit.")

    # --------------------------------------------------------------
    # ORDER FLOW: confirmation/veto, hard-required only if configured.
    # --------------------------------------------------------------

    of_result = _orderflow_confirms(direction, orderflow_evidence)
    if of_result is True:
        confirmations.append("Order-flow depth imbalance agrees with candidate direction.")
    elif of_result is False:
        vetoes.append("Order-flow depth imbalance disagrees with candidate direction.")
        if require_orderflow_confirmation:
            return ConfirmationResult(
                approved=False,
                reason="Order flow disagreed and confirmation was required.",
                confirmations=confirmations, vetoes=vetoes,
                live_data_available=live_data_available,
            )
    elif require_orderflow_confirmation:
        return ConfirmationResult(
            approved=False,
            reason="Order-flow confirmation required but unavailable.",
            confirmations=confirmations, vetoes=vetoes,
            live_data_available=live_data_available,
        )

    # --------------------------------------------------------------
    # SENTIMENT: confirmation/veto, hard-required only if configured.
    # --------------------------------------------------------------

    sentiment_result = _sentiment_confirms(direction, sentiment_evidence)
    if sentiment_result is True:
        confirmations.append("Sentiment agrees with candidate direction.")
    elif sentiment_result is False:
        vetoes.append("Sentiment disagrees with candidate direction.")
        if require_sentiment_confirmation:
            return ConfirmationResult(
                approved=False,
                reason="Sentiment disagreed and confirmation was required.",
                confirmations=confirmations, vetoes=vetoes,
                live_data_available=live_data_available,
            )
    elif require_sentiment_confirmation:
        return ConfirmationResult(
            approved=False,
            reason="Sentiment confirmation required but unavailable.",
            confirmations=confirmations, vetoes=vetoes,
            live_data_available=live_data_available,
        )

    return ConfirmationResult(
        approved=True,
        reason="Core candidate approved" + (" with live confirmations." if confirmations else "; no live data disagreed."),
        confirmations=confirmations,
        vetoes=vetoes,
        live_data_available=live_data_available,
    )
