"""
Live-only enhancement layer. Everything imported from here depends on
data that is only available going forward, in real time - never inside a
historical backtest. See app.live.confirmation_layer's module docstring.
"""
