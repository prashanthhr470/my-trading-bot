from datetime import datetime, timedelta, timezone


# ============================================================
# CONFIGURATION
# ============================================================

# cTrader XAUUSD D1 candles observed in this account:
# 21:00 UTC trading-day boundary.
BROKER_DAY_START_UTC = 21


# Maximum age for a liquidity sweep to be considered fresh.
#
# A sweep can still be historically detected after this period,
# but it will no longer be considered an active/fresh sweep.
MAX_SWEEP_AGE_MINUTES = 180


# Session definitions in UTC.
#
# These are configuration values.
# They can be changed later without rewriting the engine.
SESSION_CONFIG = {
    "asia": {
        "start": 0,
        "end": 8,
    },
    "london": {
        "start": 8,
        "end": 13,
    },
    "new_york": {
        "start": 13,
        "end": 21,
    },
}


# ============================================================
# TIME HELPERS
# ============================================================

def parse_timestamp(value):

    if value is None:
        return None

    if isinstance(value, datetime):

        if value.tzinfo is None:
            return value.replace(
                tzinfo=timezone.utc
            )

        return value.astimezone(
            timezone.utc
        )

    if isinstance(value, str):

        value = value.strip()

        if not value:
            return None

        value = value.replace(
            "Z",
            "+00:00"
        )

        try:

            dt = datetime.fromisoformat(
                value
            )

        except ValueError:

            return None

        if dt.tzinfo is None:
            dt = dt.replace(
                tzinfo=timezone.utc
            )

        return dt.astimezone(
            timezone.utc
        )

    return None


def sort_bars(bars):

    return sorted(
        bars or [],
        key=lambda bar: (
            parse_timestamp(
                bar.get("timestamp")
            )
            or datetime.min.replace(
                tzinfo=timezone.utc
            )
        )
    )


def valid_bar(bar):

    if not isinstance(bar, dict):
        return False

    required = (
        "timestamp",
        "open",
        "high",
        "low",
        "close",
    )

    if not all(
        key in bar
        for key in required
    ):
        return False

    try:

        float(bar["open"])
        float(bar["high"])
        float(bar["low"])
        float(bar["close"])

    except (
        TypeError,
        ValueError,
    ):

        return False

    return (
        parse_timestamp(
            bar["timestamp"]
        )
        is not None
    )


def clean_bars(bars):

    return sort_bars(
        [
            bar
            for bar in (bars or [])
            if valid_bar(bar)
        ]
    )


# ============================================================
# BROKER TRADING DAY
# ============================================================

def trading_day_start(
    timestamp,
    broker_start_hour=BROKER_DAY_START_UTC,
):
    """
    Determine the broker trading-day start for a timestamp.

    For this XAUUSD feed the observed D1 boundary is 21:00 UTC.

    Example:

        2026-09-01 15:30 UTC
            belongs to trading day starting
            2026-08-31 21:00 UTC.

        2026-09-01 20:30 UTC
            same trading day.

        2026-09-01 21:30 UTC
            belongs to the next trading day.
    """

    dt = parse_timestamp(
        timestamp
    )

    if dt is None:
        return None

    boundary = dt.replace(
        hour=broker_start_hour,
        minute=0,
        second=0,
        microsecond=0,
    )

    if dt < boundary:

        boundary -= timedelta(
            days=1
        )

    return boundary


def trading_day_key(timestamp):

    start = trading_day_start(
        timestamp
    )

    if start is None:
        return None

    return start.date()


# ============================================================
# RANGE HELPERS
# ============================================================

def range_from_bars(bars):

    bars = clean_bars(
        bars
    )

    if not bars:

        return {
            "available": False,
            "high": None,
            "low": None,
        }

    return {
        "available": True,

        "high": max(
            float(bar["high"])
            for bar in bars
        ),

        "low": min(
            float(bar["low"])
            for bar in bars
        ),
    }


def ohlc_from_bars(bars):

    bars = clean_bars(
        bars
    )

    if not bars:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
        }

    return {
        "available": True,

        "open": float(
            bars[0]["open"]
        ),

        "high": max(
            float(bar["high"])
            for bar in bars
        ),

        "low": min(
            float(bar["low"])
            for bar in bars
        ),

        "close": float(
            bars[-1]["close"]
        ),
    }


# ============================================================
# GROUP BARS BY BROKER TRADING DAY
# ============================================================

def group_by_trading_day(
    bars,
    broker_start_hour=BROKER_DAY_START_UTC,
):
    """
    Group intraday bars according to the broker's
    trading-day boundary.
    """

    groups = {}

    for bar in clean_bars(bars):

        dt = parse_timestamp(
            bar["timestamp"]
        )

        if dt is None:
            continue

        start = trading_day_start(
            dt,
            broker_start_hour
        )

        if start is None:
            continue

        key = start.isoformat()

        groups.setdefault(
            key,
            []
        ).append(bar)

    return groups


# ============================================================
# PREVIOUS BROKER TRADING DAY
# ============================================================

def calculate_previous_day(
    daily_bars,
    reference_time=None,
):
    """
    Calculate the latest completed D1 candle.

    We intentionally use the broker's candle sequence.

    This avoids incorrectly assuming that a candle timestamped
    21:00 UTC belongs to the ordinary UTC calendar date.
    """

    bars = clean_bars(
        daily_bars
    )

    if reference_time is None:

        reference_time = datetime.now(
            timezone.utc
        )

    else:

        reference_time = parse_timestamp(
            reference_time
        )

    if reference_time is None:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
            "timestamp": None,
            "trading_day_start": None,
        }

    completed = []

    for bar in bars:

        dt = parse_timestamp(
            bar["timestamp"]
        )

        if dt is None:
            continue

        if dt < reference_time:

            completed.append(
                bar
            )

    if not completed:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
            "timestamp": None,
            "trading_day_start": None,
        }

    bar = completed[-1]

    dt = parse_timestamp(
        bar["timestamp"]
    )

    return {
        "available": True,

        "open": float(
            bar["open"]
        ),

        "high": float(
            bar["high"]
        ),

        "low": float(
            bar["low"]
        ),

        "close": float(
            bar["close"]
        ),

        "timestamp": bar[
            "timestamp"
        ],

        "trading_day_start": (
            trading_day_start(
                dt
            ).isoformat()
            if dt
            else None
        ),
    }


# ============================================================
# PREVIOUS BROKER TRADING WEEK
# ============================================================

def trading_week_start(
    timestamp,
):
    """
    Determine the Monday trading-week date.

    The broker-day adjustment is applied before determining
    the ISO week.
    """

    dt = parse_timestamp(
        timestamp
    )

    if dt is None:
        return None

    broker_day = trading_day_start(
        dt
    )

    return (
        broker_day
        - timedelta(
            days=broker_day.weekday()
        )
    )


def calculate_previous_week(
    daily_bars,
    reference_time=None,
):
    """
    Calculate the most recently completed broker trading week.

    We use the broker trading-day boundary first and then
    group D1 candles by trading week.
    """

    bars = clean_bars(
        daily_bars
    )

    if reference_time is None:

        reference_time = datetime.now(
            timezone.utc
        )

    else:

        reference_time = parse_timestamp(
            reference_time
        )

    if reference_time is None:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
            "week_start": None,
        }

    current_week_start = (
        trading_week_start(
            reference_time
        )
    )

    if current_week_start is None:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
            "week_start": None,
        }

    groups = {}

    for bar in bars:

        dt = parse_timestamp(
            bar["timestamp"]
        )

        if dt is None:
            continue

        if dt >= reference_time:
            continue

        week_start = trading_week_start(
            dt
        )

        if week_start is None:
            continue

        # Only weeks before the current broker week.
        if week_start >= current_week_start:
            continue

        key = week_start.isoformat()

        groups.setdefault(
            key,
            []
        ).append(bar)

    if not groups:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
            "week_start": None,
        }

    latest_week_key = max(
        groups.keys()
    )

    week_bars = clean_bars(
        groups[
            latest_week_key
        ]
    )

    if not week_bars:

        return {
            "available": False,
            "open": None,
            "high": None,
            "low": None,
            "close": None,
            "week_start": None,
        }

    return {
        "available": True,

        "open": float(
            week_bars[0]["open"]
        ),

        "high": max(
            float(bar["high"])
            for bar in week_bars
        ),

        "low": min(
            float(bar["low"])
            for bar in week_bars
        ),

        "close": float(
            week_bars[-1]["close"]
        ),

        "week_start": latest_week_key,
    }


# ============================================================
# SESSION HELPERS
# ============================================================

def filter_session(
    bars,
    start_hour,
    end_hour,
    target_date,
):
    """
    Filter bars using UTC calendar time.

    Session configuration is kept separate from broker-day
    calculations.
    """

    result = []

    for bar in clean_bars(bars):

        dt = parse_timestamp(
            bar["timestamp"]
        )

        if dt is None:
            continue

        if dt.date() != target_date:
            continue

        hour = dt.hour

        if start_hour < end_hour:

            inside = (
                start_hour
                <= hour
                < end_hour
            )

        else:

            inside = (
                hour >= start_hour
                or hour < end_hour
            )

        if inside:

            result.append(
                bar
            )

    return result


def calculate_session(
    bars,
    name,
    start_hour,
    end_hour,
    target_date,
):
    """
    Calculate one configured session.
    """

    session_bars = filter_session(
        bars,
        start_hour,
        end_hour,
        target_date,
    )

    result = range_from_bars(
        session_bars
    )

    result.update(
        {
            "session": name,

            "utc_start": (
                f"{start_hour:02d}:00"
            ),

            "utc_end": (
                f"{end_hour:02d}:00"
            ),

            "bar_count": len(
                session_bars
            ),
        }
    )

    return result


def calculate_sessions(
    m5_bars,
    reference_time=None,
):
    """
    Calculate configured sessions for the current UTC date.

    Session times are configuration values and can be changed
    later without changing the engine.
    """

    if reference_time is None:

        reference_time = datetime.now(
            timezone.utc
        )

    else:

        reference_time = parse_timestamp(
            reference_time
        )

    if reference_time is None:
        return {}

    target_date = (
        reference_time.date()
    )

    result = {}

    for name, config in (
        SESSION_CONFIG.items()
    ):

        result[name] = (
            calculate_session(
                m5_bars,
                name,
                config["start"],
                config["end"],
                target_date,
            )
        )

    return result


# ============================================================
# SWEEP DETECTION
# ============================================================

def detect_sweep(
    bars,
    level,
    side,
    reference_time=None,
    max_age_minutes=MAX_SWEEP_AGE_MINUTES,
):
    """
    Detect a price-action sweep.

    BUY-SIDE:

        price trades above level
        then closes below level.

    SELL-SIDE:

        price trades below level
        then closes above level.

    The function records both:

        detected
        fresh

    A sweep can therefore remain historically detected while
    being marked stale.

    This identifies a price pattern.

    It does NOT prove institutional intent.
    """

    bars = clean_bars(
        bars
    )

    if reference_time is None:

        reference_time = datetime.now(
            timezone.utc
        )

    else:

        reference_time = parse_timestamp(
            reference_time
        )

    if (
        not bars
        or level is None
        or reference_time is None
    ):

        return {
            "detected": False,
            "fresh": False,
            "side": "none",
            "level": level,
            "timestamp": None,
            "age_minutes": None,
        }

    try:

        level = float(
            level
        )

    except (
        TypeError,
        ValueError,
    ):

        return {
            "detected": False,
            "fresh": False,
            "side": "none",
            "level": None,
            "timestamp": None,
            "age_minutes": None,
        }

    for bar in reversed(bars):

        high = float(
            bar["high"]
        )

        low = float(
            bar["low"]
        )

        close = float(
            bar["close"]
        )

        timestamp = bar[
            "timestamp"
        ]

        dt = parse_timestamp(
            timestamp
        )

        if dt is None:
            continue

        # ----------------------------------------------------
        # BUY-SIDE LIQUIDITY
        # ----------------------------------------------------

        if side == "buy_side":

            if (
                high > level
                and close < level
            ):

                age_minutes = (
                    reference_time - dt
                ).total_seconds() / 60

                fresh = (
                    0 <= age_minutes
                    <= max_age_minutes
                )

                return {
                    "detected": True,
                    "fresh": fresh,
                    "side": "buy_side",
                    "level": level,
                    "timestamp": timestamp,
                    "age_minutes": round(
                        age_minutes,
                        2,
                    ),
                }

        # ----------------------------------------------------
        # SELL-SIDE LIQUIDITY
        # ----------------------------------------------------

        elif side == "sell_side":

            if (
                low < level
                and close > level
            ):

                age_minutes = (
                    reference_time - dt
                ).total_seconds() / 60

                fresh = (
                    0 <= age_minutes
                    <= max_age_minutes
                )

                return {
                    "detected": True,
                    "fresh": fresh,
                    "side": "sell_side",
                    "level": level,
                    "timestamp": timestamp,
                    "age_minutes": round(
                        age_minutes,
                        2,
                    ),
                }

    return {
        "detected": False,
        "fresh": False,
        "side": "none",
        "level": level,
        "timestamp": None,
        "age_minutes": None,
    }


# ============================================================
# DISTANCE
# ============================================================

def calculate_distance(
    current_price,
    level,
):
    """
    Absolute distance.
    """

    if (
        current_price is None
        or level is None
    ):

        return None

    return abs(
        float(current_price)
        - float(level)
    )


def calculate_signed_distance(
    current_price,
    level,
):
    """
    Positive:
        price is above level.

    Negative:
        price is below level.
    """

    if (
        current_price is None
        or level is None
    ):

        return None

    return (
        float(current_price)
        - float(level)
    )


# ============================================================
# NEAREST LEVEL
# ============================================================

def find_nearest_level(
    current_price,
    levels,
):
    """
    Find the nearest valid liquidity level.
    """

    if current_price is None:
        return None

    candidates = []

    for name, price in levels.items():

        if price is None:
            continue

        try:

            price = float(
                price
            )

        except (
            TypeError,
            ValueError,
        ):

            continue

        candidates.append(
            {
                "name": name,
                "price": price,
                "distance": abs(
                    float(
                        current_price
                    )
                    - price
                ),
            }
        )

    if not candidates:
        return None

    return min(
        candidates,
        key=lambda item: item[
            "distance"
        ]
    )


# ============================================================
# COMPLETE LIQUIDITY ENGINE
# ============================================================

def build_liquidity_evidence(
    m5_bars,
    daily_bars,
    current_price,
    reference_time=None,
):
    """
    Build complete objective price-based liquidity evidence.

    Available:

        M5
            - session ranges
            - sweep detection

        D1
            - previous trading day
            - previous trading week

        Spot
            - current price

    Not available:

        - footprint
        - delta
        - DOM
        - heatmap
        - institutional order-flow intent
    """

    if reference_time is None:

        reference_time = datetime.now(
            timezone.utc
        )

    else:

        reference_time = parse_timestamp(
            reference_time
        )

    m5_bars = clean_bars(
        m5_bars
    )

    daily_bars = clean_bars(
        daily_bars
    )

    # --------------------------------------------------------
    # PREVIOUS DAY
    # --------------------------------------------------------

    previous_day = (
        calculate_previous_day(
            daily_bars,
            reference_time,
        )
    )

    # --------------------------------------------------------
    # PREVIOUS WEEK
    # --------------------------------------------------------

    previous_week = (
        calculate_previous_week(
            daily_bars,
            reference_time,
        )
    )

    # --------------------------------------------------------
    # SESSIONS
    # --------------------------------------------------------

    sessions = calculate_sessions(
        m5_bars,
        reference_time,
    )

    # --------------------------------------------------------
    # SWEEPS
    # --------------------------------------------------------

    previous_day_high = (
        previous_day.get(
            "high"
        )
    )

    previous_day_low = (
        previous_day.get(
            "low"
        )
    )

    buy_side_sweep = detect_sweep(
        m5_bars,
        previous_day_high,
        "buy_side",
        reference_time=reference_time,
    )

    sell_side_sweep = detect_sweep(
        m5_bars,
        previous_day_low,
        "sell_side",
        reference_time=reference_time,
    )

    # --------------------------------------------------------
    # LEVELS
    # --------------------------------------------------------

    levels = {

        "previous_day_high": (
            previous_day.get(
                "high"
            )
        ),

        "previous_day_low": (
            previous_day.get(
                "low"
            )
        ),

        "previous_week_high": (
            previous_week.get(
                "high"
            )
        ),

        "previous_week_low": (
            previous_week.get(
                "low"
            )
        ),

        "asia_high": (
            sessions
            .get("asia", {})
            .get("high")
        ),

        "asia_low": (
            sessions
            .get("asia", {})
            .get("low")
        ),

        "london_high": (
            sessions
            .get("london", {})
            .get("high")
        ),

        "london_low": (
            sessions
            .get("london", {})
            .get("low")
        ),

        "new_york_high": (
            sessions
            .get("new_york", {})
            .get("high")
        ),

        "new_york_low": (
            sessions
            .get("new_york", {})
            .get("low")
        ),
    }

    # --------------------------------------------------------
    # DISTANCES
    # --------------------------------------------------------

    distances = {}

    signed_distances = {}

    for name, level in levels.items():

        distances[name] = (
            calculate_distance(
                current_price,
                level,
            )
        )

        signed_distances[name] = (
            calculate_signed_distance(
                current_price,
                level,
            )
        )

    # --------------------------------------------------------
    # NEAREST LEVEL
    # --------------------------------------------------------

    nearest_level = (
        find_nearest_level(
            current_price,
            levels,
        )
    )

    # --------------------------------------------------------
    # DATA QUALITY
    # --------------------------------------------------------

    data_quality = {

        "m5_bars": len(
            m5_bars
        ),

        "daily_bars": len(
            daily_bars
        ),

        "current_price_available": (
            current_price is not None
        ),

        "previous_day_available": (
            previous_day.get(
                "available",
                False,
            )
        ),

        "previous_week_available": (
            previous_week.get(
                "available",
                False,
            )
        ),

        "sessions_available": {
            name: session.get(
                "available",
                False,
            )
            for name, session in (
                sessions.items()
            )
        },
    }

    # --------------------------------------------------------
    # FINAL RESULT
    # --------------------------------------------------------

    return {

        "available": bool(
            m5_bars
            or daily_bars
            or current_price is not None
        ),

        "reference_time": (
            reference_time.isoformat()
            if reference_time
            else None
        ),

        "current_price": (
            float(current_price)
            if current_price is not None
            else None
        ),

        "previous_day": (
            previous_day
        ),

        "previous_week": (
            previous_week
        ),

        "sessions": (
            sessions
        ),

        "levels": (
            levels
        ),

        "distances": (
            distances
        ),

        "signed_distances": (
            signed_distances
        ),

        "nearest_level": (
            nearest_level
        ),

        "sweeps": {

            "previous_day_high": (
                buy_side_sweep
            ),

            "previous_day_low": (
                sell_side_sweep
            ),
        },

        "data_quality": (
            data_quality
        ),

        "configuration": {

            "broker_day_start_utc": (
                BROKER_DAY_START_UTC
            ),

            "max_sweep_age_minutes": (
                MAX_SWEEP_AGE_MINUTES
            ),

            "sessions": (
                SESSION_CONFIG
            ),
        },

        "data_source": {

            "m5": bool(
                m5_bars
            ),

            "daily": bool(
                daily_bars
            ),

            "spot": (
                current_price is not None
            ),

            "order_flow": False,

            "footprint": False,

            "heatmap": False,

            "dom": False,
        },
    }