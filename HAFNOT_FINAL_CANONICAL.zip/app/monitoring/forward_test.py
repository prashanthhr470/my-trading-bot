from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ForwardTestAccount:
    starting_equity: float = 10000.0
    equity: float = 10000.0
    peak_equity: float = 10000.0
    max_drawdown_percent: float = 0.0
    trades: int = 0


class ForwardTestEngine:
    """Paper-trading accounting. Never sends broker orders."""

    def __init__(self, starting_equity: float = 10000.0):
        self.account = ForwardTestAccount(
            starting_equity=float(starting_equity),
            equity=float(starting_equity),
            peak_equity=float(starting_equity),
        )

    def record_trade(self, pnl: float):
        self.account.trades += 1
        self.account.equity += float(pnl)
        self.account.peak_equity = max(
            self.account.peak_equity,
            self.account.equity,
        )

        if self.account.peak_equity:
            drawdown = (
                (self.account.peak_equity - self.account.equity)
                / self.account.peak_equity
                * 100
            )
            self.account.max_drawdown_percent = max(
                self.account.max_drawdown_percent,
                drawdown,
            )

    def snapshot(self):
        return {
            "starting_equity": self.account.starting_equity,
            "equity": self.account.equity,
            "peak_equity": self.account.peak_equity,
            "max_drawdown_percent": self.account.max_drawdown_percent,
            "trades": self.account.trades,
            "paper_trading": True,
            "live_execution": False,
        }
