"""
Honest system health reporting.

Previously a bare-bones per-component boolean (see git history / prior
versions of this file). Extended to report the explicit states the
project owner asked for (READY / DEGRADED / WAITING_FOR_DATA / BLOCKED /
ERROR) rather than a single healthy/unhealthy flag, so a caller cannot
report READY while a critical dependency is actually disconnected.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Ordered worst-to-best is NOT what this is; ERROR/BLOCKED are the worst
# outcomes, READY is the best. Used to pick the overall state as the worst
# of all reported component states.
_SEVERITY = {
    "ERROR": 4,
    "BLOCKED": 3,
    "WAITING_FOR_DATA": 2,
    "DEGRADED": 1,
    "READY": 0,
}

VALID_STATES = tuple(_SEVERITY.keys())


@dataclass
class ComponentHealth:
    component: str
    state: str
    detail: str = ""
    timestamp: str = ""

    def __post_init__(self) -> None:
        if self.state not in VALID_STATES:
            raise ValueError(f"Invalid health state {self.state!r}; must be one of {VALID_STATES}")


@dataclass
class HealthMonitor:
    components: dict = field(default_factory=dict)

    def report(self, component: str, state: str, detail: str = "") -> ComponentHealth:
        result = ComponentHealth(
            component=component,
            state=state,
            detail=detail,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        self.components[component] = result
        return result

    def overall_state(self) -> str:
        if not self.components:
            # No components have reported anything yet - that is itself
            # not READY, since nothing has been confirmed working.
            return "WAITING_FOR_DATA"
        return max(
            (c.state for c in self.components.values()),
            key=lambda s: _SEVERITY[s],
        )

    def status(self) -> dict:
        return {
            "overall_state": self.overall_state(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "components": {
                key: asdict(value)
                for key, value in self.components.items()
            },
        }

    def write(self, path: Optional[Path] = None) -> Path:
        """Persist the current status as JSON for external tools (e.g.
        CHECK_HAFNOT_STATUS.ps1, a future dashboard) to read without
        needing to import this module."""

        if path is None:
            path = Path(__file__).resolve().parents[2] / "data" / "runtime" / "health_status.json"

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.status(), indent=2, default=str), encoding="utf-8")
        return path
