"""
Automated forward-performance degradation monitoring.

app.quant.promotion already models the lifecycle states
(CONTINUOUS_MONITORING, REVIEW_REQUIRED) and the enforceable
new_trades_allowed() gate, but nothing watched live results and moved a
strategy between them. This module is that watcher: it reads REAL
forward paper-trading results (app.paper.paper_account's persisted
closed_trades) plus the cycle journal, compares them against the
strategy's validated historical baseline from
app.quant.strategy_registry, and reports whether the strategy has
meaningfully deteriorated.

DESIGN HONESTY, three points that matter more than the checks themselves:

1. Degradation monitoring presupposes a VALIDATED BASELINE. If the
   registry holds no positive-expectancy out-of-sample result for a
   strategy, there is nothing to degrade FROM, and this module says
   NO_VALIDATED_BASELINE rather than inventing an expectation. Such a
   strategy should not be trading forward at all - that is a promotion
   problem, not a monitoring one.

2. Small samples cannot establish degradation. Below
   MIN_TRADES_FOR_ASSESSMENT the verdict is INSUFFICIENT_DATA and no
   degradation is ever flagged, however bad the handful of trades look.
   Disabling a strategy on three unlucky trades is the mirror image of
   promoting one on three lucky ones.

3. Losing streaks are judged probabilistically, not by a round number.
   Under a validated win rate p, the chance of n consecutive losses is
   (1-p)^n; a streak is only "abnormal" when that probability drops
   below UNUSUAL_STREAK_PROBABILITY. A 5-loss streak is unremarkable at
   a 30% win rate and alarming at 70%.

Nothing here changes strategy parameters. Per the project's rules, a
degraded strategy is quarantined for human review and must re-enter the
research lifecycle as a NEW candidate; it is never silently retuned.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from app.forex_v2.metrics import summarize_trades
from app.quant.strategy_registry import get_results

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PAPER_DIR = PROJECT_ROOT / "data" / "paper"
JOURNAL_FILE = PROJECT_ROOT / "data" / "journals" / "multi_symbol_24x7.jsonl"

# Below this many closed forward trades, no degradation verdict is given.
MIN_TRADES_FOR_ASSESSMENT = 20

# Forward expectancy may sit this far below the validated baseline before
# it counts as a decline (in R). Forward samples are noisy; a small
# shortfall is not evidence of a broken edge.
EXPECTANCY_TOLERANCE_R = 0.10

# A forward profit factor at or below this is a collapse regardless of
# baseline - it means losses outweigh wins outright.
PROFIT_FACTOR_FLOOR = 0.80

# Forward drawdown may exceed the validated maximum by this multiple
# before it counts as abnormal.
DRAWDOWN_TOLERANCE_MULTIPLE = 1.5

# A losing streak counts as abnormal when its probability under the
# validated win rate falls below this.
UNUSUAL_STREAK_PROBABILITY = 0.01

# Realized spread may exceed the spread the backtest assumed by this
# multiple before execution conditions count as deteriorated.
SPREAD_TOLERANCE_MULTIPLE = 2.0


@dataclass
class DegradationCheck:
    name: str
    triggered: bool
    detail: str


@dataclass
class DegradationReport:
    symbol: str
    strategy_id: Optional[str] = None
    strategy_version: Optional[str] = None
    forward_trade_count: int = 0
    baseline: dict[str, Any] = field(default_factory=dict)
    checks: list[DegradationCheck] = field(default_factory=list)
    degraded: bool = False
    verdict: str = ""

    @property
    def triggered_reasons(self) -> list[str]:
        return [c.detail for c in self.checks if c.triggered]


def _load_closed_trades(symbol: str) -> list[dict[str, Any]]:
    # One portfolio account holds every symbol's paper trades
    # (app.paper.multi_symbol_paper.PORTFOLIO_ACCOUNT_FILE).
    path = PAPER_DIR / "portfolio_account.json"
    if not path.exists():
        return []

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []

    return [
        trade for trade in (data.get("closed_trades") or [])
        if str(trade.get("symbol", "")).upper() == symbol.upper()
    ]


def find_validated_baseline(strategy_id: str, version: str) -> Optional[dict[str, Any]]:
    """
    The expectation forward results are judged against: an out-of-sample
    result with positive expectancy that the research pipeline marked
    `validated: true` - meaning it also passed training, validation and
    walk-forward before its locked out-of-sample look. A positive
    out-of-sample number on its own is not enough: a strategy can pass
    validation and still fail walk-forward or the locked set. Returns None
    when no such result exists, which is reported rather than papered over.
    """

    best: Optional[dict[str, Any]] = None

    for record in get_results(strategy_id, version):
        test_type = str(record.get("test_type", "")).upper()
        if "OUT_OF_SAMPLE" not in test_type:
            continue

        scorecard = record.get("scorecard") or {}
        if scorecard.get("validated") is not True:
            continue

        expectancy = scorecard.get("expectancy_r")
        trade_count = scorecard.get("trade_count")

        if expectancy is None or not isinstance(trade_count, int):
            continue
        if expectancy <= 0 or trade_count < MIN_TRADES_FOR_ASSESSMENT:
            continue

        if best is None or expectancy > best["expectancy_r"]:
            best = {
                "test_type": test_type,
                "expectancy_r": float(expectancy),
                "trade_count": trade_count,
                "win_rate": scorecard.get("win_rate"),
                "profit_factor": scorecard.get("profit_factor"),
                "max_drawdown_percent": scorecard.get("max_drawdown_percent"),
            }

    return best


def _trailing_loss_streak(trades: list[dict[str, Any]]) -> int:
    streak = 0
    for trade in reversed(trades):
        pnl = trade.get("pnl")
        if pnl is None:
            continue
        if float(pnl) < 0:
            streak += 1
        else:
            break
    return streak


def _recent_spread_pips(symbol: str, pip_size: float, max_cycles: int = 400) -> Optional[float]:
    """Median spread in pips from recent journal cycles for this symbol."""

    if not JOURNAL_FILE.exists() or pip_size <= 0:
        return None

    spreads: list[float] = []

    try:
        with JOURNAL_FILE.open("r", encoding="utf-8") as handle:
            lines = handle.readlines()[-20_000:]
    except Exception:
        return None

    for line in reversed(lines):
        if len(spreads) >= max_cycles:
            break
        line = line.strip()
        if not line or symbol.upper() not in line:
            continue
        try:
            record = json.loads(line)
        except Exception:
            continue
        if record.get("event") != "CYCLE" or str(record.get("symbol", "")).upper() != symbol.upper():
            continue
        bid, ask = record.get("bid"), record.get("ask")
        if bid is None or ask is None:
            continue
        spread = (float(ask) - float(bid)) / pip_size
        if spread >= 0:
            spreads.append(spread)

    if not spreads:
        return None

    spreads.sort()
    return spreads[len(spreads) // 2]


def assess_symbol(
    symbol: str, *,
    strategy_id: Optional[str] = None,
    strategy_version: Optional[str] = None,
    assumed_backtest_spread_pips: Optional[float] = None,
    pip_size: Optional[float] = None,
    closed_trades: Optional[list[dict[str, Any]]] = None,
) -> DegradationReport:
    """
    Assess one symbol's forward paper-trading results. `closed_trades`
    can be injected for testing; otherwise they are read from the
    persisted paper account.
    """

    symbol = symbol.upper()
    trades = closed_trades if closed_trades is not None else _load_closed_trades(symbol)

    report = DegradationReport(
        symbol=symbol,
        strategy_id=strategy_id,
        strategy_version=strategy_version,
        forward_trade_count=len(trades),
    )

    baseline = None
    if strategy_id and strategy_version:
        baseline = find_validated_baseline(strategy_id, strategy_version)

    if baseline is None:
        report.verdict = "NO_VALIDATED_BASELINE"
        report.checks.append(DegradationCheck(
            name="validated_baseline",
            triggered=False,
            detail=(
                f"No positive-expectancy out-of-sample result with at least "
                f"{MIN_TRADES_FOR_ASSESSMENT} trades exists for "
                f"{strategy_id or 'this strategy'} {strategy_version or ''}. "
                "There is no validated expectation to measure degradation against; "
                "this strategy has not earned forward trading in the first place."
            ),
        ))
        return report

    report.baseline = baseline

    if len(trades) < MIN_TRADES_FOR_ASSESSMENT:
        report.verdict = "INSUFFICIENT_DATA"
        report.checks.append(DegradationCheck(
            name="sample_size",
            triggered=False,
            detail=(
                f"Only {len(trades)} closed forward trade(s); at least "
                f"{MIN_TRADES_FOR_ASSESSMENT} are needed before degradation can be "
                "established. No action taken."
            ),
        ))
        return report

    summary = summarize_trades(
        [
            {"pnl_usd": t.get("pnl"), "result_r": t.get("result_r")}
            for t in trades
            if t.get("pnl") is not None
        ],
        initial_equity=10_000.0,
    )

    # --- expectancy decline ---
    if summary.expectancy_r is None:
        report.checks.append(DegradationCheck(
            name="expectancy_decline", triggered=False,
            detail="Forward expectancy unavailable (no result_r on the closed trades).",
        ))
    else:
        threshold = baseline["expectancy_r"] - EXPECTANCY_TOLERANCE_R
        declined = summary.expectancy_r < threshold
        report.checks.append(DegradationCheck(
            name="expectancy_decline",
            triggered=declined,
            detail=(
                f"Forward expectancy {summary.expectancy_r:.3f}R vs validated "
                f"{baseline['expectancy_r']:.3f}R (tolerance {EXPECTANCY_TOLERANCE_R:.2f}R)"
                + (" - sustained decline." if declined else " - within tolerance.")
            ),
        ))

    # --- profit factor collapse ---
    if summary.profit_factor is None:
        report.checks.append(DegradationCheck(
            name="profit_factor_collapse", triggered=False,
            detail="Forward profit factor undefined (no losing trades yet).",
        ))
    else:
        collapsed = summary.profit_factor <= PROFIT_FACTOR_FLOOR
        report.checks.append(DegradationCheck(
            name="profit_factor_collapse",
            triggered=collapsed,
            detail=(
                f"Forward profit factor {summary.profit_factor:.2f} "
                f"(floor {PROFIT_FACTOR_FLOOR:.2f})"
                + (" - collapsed." if collapsed else " - acceptable.")
            ),
        ))

    # --- abnormal drawdown ---
    baseline_dd = baseline.get("max_drawdown_percent")
    if baseline_dd is None:
        report.checks.append(DegradationCheck(
            name="abnormal_drawdown", triggered=False,
            detail=(
                f"Forward drawdown {summary.max_drawdown_percent:.2f}% recorded, but the "
                "validated baseline has no max_drawdown_percent to compare against."
            ),
        ))
    else:
        limit = float(baseline_dd) * DRAWDOWN_TOLERANCE_MULTIPLE
        abnormal = summary.max_drawdown_percent > limit
        report.checks.append(DegradationCheck(
            name="abnormal_drawdown",
            triggered=abnormal,
            detail=(
                f"Forward drawdown {summary.max_drawdown_percent:.2f}% vs validated "
                f"{float(baseline_dd):.2f}% (limit {limit:.2f}%)"
                + (" - abnormal." if abnormal else " - within limit.")
            ),
        ))

    # --- statistically unusual losing streak ---
    baseline_win_rate = baseline.get("win_rate")
    streak = _trailing_loss_streak(trades)

    if baseline_win_rate is None or not (0.0 < float(baseline_win_rate) < 1.0):
        report.checks.append(DegradationCheck(
            name="unusual_losing_streak", triggered=False,
            detail=f"Trailing losing streak {streak}, but the baseline has no usable win rate.",
        ))
    else:
        loss_rate = 1.0 - float(baseline_win_rate)
        probability = loss_rate ** streak if streak > 0 else 1.0
        unusual = probability < UNUSUAL_STREAK_PROBABILITY
        report.checks.append(DegradationCheck(
            name="unusual_losing_streak",
            triggered=unusual,
            detail=(
                f"Trailing losing streak {streak}; probability under the validated "
                f"{float(baseline_win_rate):.1%} win rate is {probability:.4f}"
                + (
                    f" (< {UNUSUAL_STREAK_PROBABILITY}) - statistically unusual."
                    if unusual else " - not unusual."
                )
            ),
        ))

    # --- spread / execution deterioration ---
    if assumed_backtest_spread_pips is None or pip_size is None:
        report.checks.append(DegradationCheck(
            name="spread_deterioration", triggered=False,
            detail="Spread comparison skipped (no assumed backtest spread / pip size supplied).",
        ))
    else:
        observed = _recent_spread_pips(symbol, float(pip_size))
        if observed is None:
            report.checks.append(DegradationCheck(
                name="spread_deterioration", triggered=False,
                detail="No recent journal quotes available to measure realized spread.",
            ))
        else:
            limit = float(assumed_backtest_spread_pips) * SPREAD_TOLERANCE_MULTIPLE
            deteriorated = observed > limit
            report.checks.append(DegradationCheck(
                name="spread_deterioration",
                triggered=deteriorated,
                detail=(
                    f"Median realized spread {observed:.2f} pips vs backtest assumption "
                    f"{float(assumed_backtest_spread_pips):.2f} (limit {limit:.2f})"
                    + (
                        " - execution conditions materially worse than tested."
                        if deteriorated else " - consistent with the backtest."
                    )
                ),
            ))

    report.degraded = any(c.triggered for c in report.checks)
    report.verdict = "DEGRADED" if report.degraded else "HEALTHY"

    return report


def enforce(report: DegradationReport, candidate_id: str) -> Optional[str]:
    """
    Act on a DEGRADED report by moving the promotion candidate into
    REVIEW_REQUIRED, which makes app.quant.promotion.new_trades_allowed()
    return False for it. Returns the new stage, or None if no action was
    warranted or possible.

    Deliberately separate from assess_symbol so that assessment is always
    safe to run (read-only) and only an explicit call changes state.
    """

    if not report.degraded:
        return None

    from app.quant import promotion

    try:
        candidate = promotion.load_candidate(candidate_id)
    except FileNotFoundError:
        return None

    if not promotion.new_trades_allowed(candidate):
        return candidate.current_stage

    if candidate.current_stage not in promotion.DEGRADABLE_STAGES:
        return candidate.current_stage

    updated = promotion.flag_performance_degradation(
        candidate,
        reasons=report.triggered_reasons,
        evidence={
            "symbol": report.symbol,
            "strategy_id": report.strategy_id,
            "strategy_version": report.strategy_version,
            "forward_trade_count": report.forward_trade_count,
            "baseline": report.baseline,
        },
    )

    return updated.current_stage


def print_report(report: DegradationReport) -> None:
    print()
    print("=" * 78)
    print(f" DEGRADATION REPORT: {report.symbol}"
          + (f"  [{report.strategy_id} v{report.strategy_version}]" if report.strategy_id else ""))
    print("=" * 78)
    print(f"Forward closed trades : {report.forward_trade_count}")
    if report.baseline:
        print(f"Validated baseline    : expectancy {report.baseline['expectancy_r']:.3f}R "
              f"over {report.baseline['trade_count']} trades ({report.baseline['test_type']})")
    else:
        print("Validated baseline    : NONE")
    print()
    for check in report.checks:
        marker = "TRIGGERED" if check.triggered else "ok"
        print(f"  [{marker:^9}] {check.name}: {check.detail}")
    print()
    print(f"VERDICT: {report.verdict}")
    print("=" * 78)
