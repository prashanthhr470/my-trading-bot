from __future__ import annotations

import asyncio
import json
import os
import signal
import time
import uuid

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


# =================================================================
# HARD SAFETY CONTRACT
# =================================================================

DRY_RUN = True
LIVE_EXECUTION = False
BROKER_ORDERS = 0
AI_DIRECT_EXECUTION = False
READ_ONLY = True
PAPER_TRADING = True


# =================================================================
# CONFIGURATION
# =================================================================

ROOT = Path(__file__).resolve().parents[2]

SYMBOL = os.getenv(
    "HAFNOT_PAPER_SYMBOL",
    "XAUUSD",
).upper()

TIMEFRAMES = (
    "H4",
    "H1",
    "M15",
    "M5",
)

STARTING_EQUITY = float(
    os.getenv(
        "HAFNOT_PAPER_STARTING_EQUITY",
        "10000",
    )
)

RISK_PERCENT = float(
    os.getenv(
        "HAFNOT_PAPER_RISK_PERCENT",
        "1.0",
    )
)

MAX_OPEN_POSITIONS = int(
    os.getenv(
        "HAFNOT_PAPER_MAX_POSITIONS",
        "1",
    )
)

CYCLE_INTERVAL_SECONDS = max(
    10.0,
    float(
        os.getenv(
            "HAFNOT_PAPER_INTERVAL",
            "60",
        )
    ),
)

MAX_CYCLES = int(
    os.getenv(
        "HAFNOT_PAPER_MAX_CYCLES",
        "0",
    )
)

DATA_DIR = (
    ROOT
    / "data"
    / "autonomous"
)

STATE_FILE = (
    DATA_DIR
    / "paper_account.json"
)

CYCLE_LOG = (
    DATA_DIR
    / "cycles.jsonl"
)

TRADE_LOG = (
    DATA_DIR
    / "paper_trades.jsonl"
)

PERFORMANCE_FILE = (
    DATA_DIR
    / "performance.json"
)


# =================================================================
# UTILITIES
# =================================================================

def utc_now() -> str:

    return datetime.now(
        timezone.utc
    ).isoformat()


def json_safe(
    value: Any,
) -> Any:

    if value is None:
        return None

    if isinstance(
        value,
        (
            str,
            int,
            float,
            bool,
        ),
    ):
        return value

    if isinstance(
        value,
        dict,
    ):

        return {
            str(k): json_safe(v)
            for k, v in value.items()
        }

    if isinstance(
        value,
        (list, tuple),
    ):

        return [
            json_safe(v)
            for v in value
        ]

    if hasattr(
        value,
        "__dict__",
    ):

        return {
            str(k): json_safe(v)
            for k, v in vars(value).items()
        }

    return str(value)


def append_jsonl(
    path: Path,
    payload: Dict[str, Any],
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "a",
        encoding="utf-8",
    ) as fh:

        fh.write(
            json.dumps(
                json_safe(payload),
                ensure_ascii=False,
                separators=(",", ":"),
            )
        )

        fh.write("\n")


def write_json(
    path: Path,
    payload: Dict[str, Any],
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    temporary = path.with_suffix(
        path.suffix + ".tmp"
    )

    temporary.write_text(
        json.dumps(
            json_safe(payload),
            indent=2,
        ),
        encoding="utf-8",
    )

    temporary.replace(path)


def as_dict(
    value: Any,
) -> Dict[str, Any]:

    if isinstance(
        value,
        dict,
    ):
        return value

    return {}


# =================================================================
# PAPER POSITION
# =================================================================

@dataclass
class PaperPosition:

    trade_id: str
    symbol: str
    direction: str

    entry: float
    stop_loss: float
    take_profit: float

    risk_amount: float

    opened_at: str

    source_cycle_id: str = ""

    def to_dict(
        self,
    ) -> Dict[str, Any]:

        return asdict(self)

    @classmethod
    def from_dict(
        cls,
        payload: Dict[str, Any],
    ) -> "PaperPosition":

        return cls(
            trade_id=str(
                payload["trade_id"]
            ),
            symbol=str(
                payload["symbol"]
            ),
            direction=str(
                payload["direction"]
            ),
            entry=float(
                payload["entry"]
            ),
            stop_loss=float(
                payload["stop_loss"]
            ),
            take_profit=float(
                payload["take_profit"]
            ),
            risk_amount=float(
                payload["risk_amount"]
            ),
            opened_at=str(
                payload["opened_at"]
            ),
            source_cycle_id=str(
                payload.get(
                    "source_cycle_id",
                    "",
                )
            ),
        )

    def calculate_r(
        self,
        exit_price: float,
    ) -> float:

        exit_price = float(
            exit_price
        )

        if self.direction == "BUY":

            denominator = (
                self.entry
                - self.stop_loss
            )

            if denominator <= 0:
                return 0.0

            return (
                exit_price
                - self.entry
            ) / denominator

        if self.direction == "SELL":

            denominator = (
                self.stop_loss
                - self.entry
            )

            if denominator <= 0:
                return 0.0

            return (
                self.entry
                - exit_price
            ) / denominator

        return 0.0

    def check_exit(
        self,
        bid: float,
        ask: float,
    ) -> Optional[
        Dict[str, Any]
    ]:

        bid = float(bid)
        ask = float(ask)

        if self.direction == "BUY":

            if bid <= self.stop_loss:

                return self.close(
                    bid,
                    "STOP_LOSS",
                )

            if bid >= self.take_profit:

                return self.close(
                    bid,
                    "TAKE_PROFIT",
                )

        elif self.direction == "SELL":

            if ask >= self.stop_loss:

                return self.close(
                    ask,
                    "STOP_LOSS",
                )

            if ask <= self.take_profit:

                return self.close(
                    ask,
                    "TAKE_PROFIT",
                )

        return None

    def close(
        self,
        exit_price: float,
        reason: str,
    ) -> Dict[str, Any]:

        result_r = self.calculate_r(
            exit_price
        )

        pnl = (
            self.risk_amount
            * result_r
        )

        return {
            "trade_id":
                self.trade_id,

            "symbol":
                self.symbol,

            "direction":
                self.direction,

            "entry":
                self.entry,

            "exit":
                float(exit_price),

            "stop_loss":
                self.stop_loss,

            "take_profit":
                self.take_profit,

            "risk_amount":
                self.risk_amount,

            "result_r":
                float(result_r),

            "pnl":
                float(pnl),

            "exit_reason":
                reason,

            "opened_at":
                self.opened_at,

            "closed_at":
                utc_now(),

            "source_cycle_id":
                self.source_cycle_id,
        }


# =================================================================
# PERSISTENT PAPER ACCOUNT
# =================================================================

class PaperAccount:

    VERSION = 1

    def __init__(
        self,
        starting_equity: float = STARTING_EQUITY,
    ):

        self.starting_equity = float(
            starting_equity
        )

        self.equity = float(
            starting_equity
        )

        self.positions: Dict[
            str,
            PaperPosition,
        ] = {}

        self.closed_trades: list[
            Dict[str, Any]
        ] = []

        self.total_entries = 0
        self.total_exits = 0

        self.load()

    # -----------------------------------------------------------------

    def load(self) -> None:

        if not STATE_FILE.exists():
            return

        try:

            payload = json.loads(
                STATE_FILE.read_text(
                    encoding="utf-8"
                )
            )

            self.starting_equity = float(
                payload.get(
                    "starting_equity",
                    self.starting_equity,
                )
            )

            self.equity = float(
                payload.get(
                    "equity",
                    self.equity,
                )
            )

            self.total_entries = int(
                payload.get(
                    "total_entries",
                    0,
                )
            )

            self.total_exits = int(
                payload.get(
                    "total_exits",
                    0,
                )
            )

            positions = (
                payload.get(
                    "positions",
                    {},
                )
            )

            if isinstance(
                positions,
                dict,
            ):

                for trade_id, data in positions.items():

                    try:

                        position = (
                            PaperPosition.from_dict(
                                data
                            )
                        )

                        self.positions[
                            trade_id
                        ] = position

                    except Exception:
                        continue

            trades = (
                payload.get(
                    "closed_trades",
                    [],
                )
            )

            if isinstance(
                trades,
                list,
            ):

                self.closed_trades = trades

        except Exception:

            # Corrupt state must never silently
            # alter trading logic.

            raise RuntimeError(
                "Paper account state is unreadable: "
                f"{STATE_FILE}"
            )

    # -----------------------------------------------------------------

    def save(self) -> None:

        write_json(
            STATE_FILE,
            {
                "version":
                    self.VERSION,

                "updated_at":
                    utc_now(),

                "starting_equity":
                    self.starting_equity,

                "equity":
                    self.equity,

                "total_entries":
                    self.total_entries,

                "total_exits":
                    self.total_exits,

                "positions": {
                    trade_id:
                        position.to_dict()

                    for trade_id, position
                    in self.positions.items()
                },

                "closed_trades":
                    self.closed_trades,

                "safety": {
                    "paper_trading":
                        True,

                    "live_execution":
                        False,

                    "broker_orders":
                        0,

                    "ai_direct_execution":
                        False,

                    "read_only":
                        True,
                },
            },
        )

    # -----------------------------------------------------------------

    def open_position(
        self,
        *,
        symbol: str,
        direction: str,
        entry: float,
        stop_loss: float,
        take_profit: float,
        cycle_id: str,
    ) -> Optional[
        Dict[str, Any]
    ]:

        if (
            len(self.positions)
            >= MAX_OPEN_POSITIONS
        ):
            return None

        direction = direction.upper()

        entry = float(entry)
        stop_loss = float(stop_loss)
        take_profit = float(take_profit)

        if direction == "BUY":

            if not (
                stop_loss
                < entry
                < take_profit
            ):
                return None

        elif direction == "SELL":

            if not (
                take_profit
                < entry
                < stop_loss
            ):
                return None

        else:
            return None

        # Risk is calculated from CURRENT paper equity.

        risk_amount = (
            self.equity
            * RISK_PERCENT
            / 100.0
        )

        trade_id = (
            "PAPER-"
            + datetime.now(
                timezone.utc
            ).strftime(
                "%Y%m%d-%H%M%S"
            )
            + "-"
            + uuid.uuid4().hex[:8]
        )

        position = PaperPosition(
            trade_id=trade_id,
            symbol=symbol,
            direction=direction,
            entry=entry,
            stop_loss=stop_loss,
            take_profit=take_profit,
            risk_amount=risk_amount,
            opened_at=utc_now(),
            source_cycle_id=cycle_id,
        )

        self.positions[
            trade_id
        ] = position

        self.total_entries += 1

        self.save()

        return {
            "trade_id":
                trade_id,

            "symbol":
                symbol,

            "direction":
                direction,

            "entry":
                entry,

            "stop_loss":
                stop_loss,

            "take_profit":
                take_profit,

            "risk_amount":
                risk_amount,

            "status":
                "OPEN",

            "source_cycle_id":
                cycle_id,
        }

    # -----------------------------------------------------------------

    def update_market(
        self,
        symbol: str,
        bid: float,
        ask: float,
    ) -> list[
        Dict[str, Any]
    ]:

        closed = []

        for trade_id, position in list(
            self.positions.items()
        ):

            if (
                position.symbol
                != symbol
            ):
                continue

            result = (
                position.check_exit(
                    bid,
                    ask,
                )
            )

            if result is None:
                continue

            self.equity += float(
                result["pnl"]
            )

            self.closed_trades.append(
                result
            )

            self.positions.pop(
                trade_id,
                None,
            )

            self.total_exits += 1

            closed.append(
                result
            )

        if closed:
            self.save()

        return closed

    # -----------------------------------------------------------------

    def metrics(
        self,
    ) -> Dict[str, Any]:

        results = [
            float(
                trade.get(
                    "result_r",
                    0,
                )
            )
            for trade
            in self.closed_trades
        ]

        wins = [
            value
            for value in results
            if value > 0
        ]

        losses = [
            value
            for value in results
            if value < 0
        ]

        gross_profit = sum(
            value
            for value in wins
        )

        gross_loss = abs(
            sum(
                value
                for value in losses
            )
        )

        net_r = sum(
            results
        )

        max_drawdown_r = 0.0
        running_r = 0.0
        peak_r = 0.0

        for value in results:

            running_r += value

            peak_r = max(
                peak_r,
                running_r,
            )

            drawdown = (
                peak_r
                - running_r
            )

            max_drawdown_r = max(
                max_drawdown_r,
                drawdown,
            )

        return {
            "starting_equity":
                self.starting_equity,

            "equity":
                self.equity,

            "equity_change":
                self.equity
                - self.starting_equity,

            "closed_trades":
                len(results),

            "wins":
                len(wins),

            "losses":
                len(losses),

            "win_rate_percent":
                (
                    len(wins)
                    / len(results)
                    * 100.0
                    if results
                    else 0.0
                ),

            "net_r":
                net_r,

            "expectancy_r":
                (
                    net_r
                    / len(results)
                    if results
                    else 0.0
                ),

            "profit_factor":
                (
                    gross_profit
                    / gross_loss
                    if gross_loss > 0
                    else 0.0
                ),

            "max_drawdown_r":
                max_drawdown_r,

            "open_positions":
                len(self.positions),

            "total_entries":
                self.total_entries,

            "total_exits":
                self.total_exits,

            "paper_trading":
                True,

            "live_execution":
                False,

            "broker_orders":
                0,

            "ai_direct_execution":
                False,

            "read_only":
                True,
        }


# =================================================================
# AUTONOMOUS ENGINE
# =================================================================

class AutonomousPaperEngine:

    def __init__(self):

        # Absolute safety assertions.

        assert DRY_RUN is True
        assert LIVE_EXECUTION is False
        assert BROKER_ORDERS == 0
        assert AI_DIRECT_EXECUTION is False
        assert READ_ONLY is True
        assert PAPER_TRADING is True

        self.runtime = None

        self.account = PaperAccount()

        self.running = False

        self.cycles = 0

        self.last_cycle_id = None
        self.last_result = None
        self.last_error = None

    # -----------------------------------------------------------------

    async def initialize(self):

        from app.agent.agent_runtime import (
            AgentRuntime,
        )

        self.runtime = AgentRuntime(
            dry_run=True,
            max_calls_per_cycle=20,
            max_cycle_seconds=120.0,
        )

    # -----------------------------------------------------------------

    @staticmethod
    def recursive_find_price(
        value: Any,
    ) -> Optional[
        tuple[float, float]
    ]:

        if isinstance(
            value,
            dict,
        ):

            # Direct bid/ask pair.

            if (
                "bid" in value
                and "ask" in value
            ):

                try:

                    bid = float(
                        value["bid"]
                    )

                    ask = float(
                        value["ask"]
                    )

                    if (
                        bid > 0
                        and ask > 0
                    ):

                        return (
                            bid,
                            ask,
                        )

                except (
                    TypeError,
                    ValueError,
                ):
                    pass

            for child in value.values():

                result = (
                    AutonomousPaperEngine
                    .recursive_find_price(
                        child
                    )
                )

                if result:
                    return result

        elif isinstance(
            value,
            (list, tuple),
        ):

            for child in value:

                result = (
                    AutonomousPaperEngine
                    .recursive_find_price(
                        child
                    )
                )

                if result:
                    return result

        return None

    # -----------------------------------------------------------------

    @staticmethod
    def extract_prices(
        cycle: Any,
        intelligence: Any,
        available_data: Any,
    ) -> Optional[
        tuple[float, float]
    ]:

        for source in (
            available_data,
            intelligence,
            cycle,
        ):

            result = (
                AutonomousPaperEngine
                .recursive_find_price(
                    source
                )
            )

            if result:
                return result

        return None

    # -----------------------------------------------------------------

    @staticmethod
    def extract_decision(
        ai_reasoning: Dict[str, Any],
        metadata: Dict[str, Any],
    ) -> Dict[str, Any]:

        candidates = [
            ai_reasoning.get(
                "ai_decision"
            ),
            ai_reasoning.get(
                "final_decision"
            ),
            metadata.get(
                "ai_decision"
            ),
        ]

        for candidate in candidates:

            if isinstance(
                candidate,
                dict,
            ):
                return candidate

        if (
            "decision"
            in ai_reasoning
        ):
            return ai_reasoning

        return {}

    # -----------------------------------------------------------------

    @staticmethod
    def extract_setup(
        intelligence: Dict[str, Any],
        decision: Dict[str, Any],
    ) -> Dict[str, Any]:

        setup = intelligence.get(
            "setup"
        )

        if isinstance(
            setup,
            dict,
        ):
            return setup

        setup = decision.get(
            "setup"
        )

        if isinstance(
            setup,
            dict,
        ):
            return setup

        return {}

    # -----------------------------------------------------------------

    @staticmethod
    def extract_levels(
        setup: Dict[str, Any],
    ) -> Optional[
        tuple[float, float, float]
    ]:

        entry = setup.get(
            "entry_price",
            setup.get(
                "entry"
            ),
        )

        stop = setup.get(
            "stop_loss"
        )

        target = setup.get(
            "take_profit"
        )

        if target is None:

            targets = setup.get(
                "targets"
            )

            if isinstance(
                targets,
                list,
            ) and targets:

                first = targets[0]

                if isinstance(
                    first,
                    dict,
                ):

                    target = first.get(
                        "price",
                        first.get(
                            "target"
                        ),
                    )

                elif isinstance(
                    first,
                    (int, float),
                ):

                    target = first

        try:

            if (
                entry is None
                or stop is None
                or target is None
            ):
                return None

            return (
                float(entry),
                float(stop),
                float(target),
            )

        except (
            TypeError,
            ValueError,
        ):

            return None

    # -----------------------------------------------------------------

    async def cycle(
        self,
    ) -> Dict[str, Any]:

        if self.runtime is None:

            await self.initialize()

        started = time.monotonic()

        self.cycles += 1

        cycle_id = (
            f"AUTO-{self.cycles:08d}-"
            f"{uuid.uuid4().hex[:8]}"
        )

        self.last_cycle_id = cycle_id

        try:

            # ======================================================
            # EXISTING HAFNOT AGENT
            # ======================================================

            cycle = (
                await self.runtime.run_cycle(
                    symbol=SYMBOL,
                    timeframes=TIMEFRAMES,
                )
            )

            available_data = (
                getattr(
                    cycle,
                    "available_data",
                    {},
                )
                or {}
            )

            metadata = (
                getattr(
                    cycle,
                    "metadata",
                    {},
                )
                or {}
            )

            if not isinstance(
                metadata,
                dict,
            ):
                metadata = {}

            intelligence = (
                metadata.get(
                    "intelligence",
                    {},
                )
                or {}
            )

            ai_reasoning = (
                metadata.get(
                    "ai_reasoning",
                    {},
                )
                or {}
            )

            if not isinstance(
                intelligence,
                dict,
            ):
                intelligence = {}

            if not isinstance(
                ai_reasoning,
                dict,
            ):
                ai_reasoning = {}

            # ======================================================
            # MARKET PRICE
            # ======================================================

            prices = (
                self.extract_prices(
                    cycle,
                    intelligence,
                    available_data,
                )
            )

            bid = None
            ask = None

            if prices:

                bid, ask = prices

                # Existing paper positions are
                # always monitored BEFORE any new entry.

                closed = (
                    self.account.update_market(
                        SYMBOL,
                        bid,
                        ask,
                    )
                )

                for trade in closed:

                    append_jsonl(
                        TRADE_LOG,
                        {
                            "event":
                                "CLOSE",

                            "timestamp":
                                utc_now(),

                            "trade":
                                trade,

                            "cycle_id":
                                cycle_id,

                            "safety": {
                                "live_execution":
                                    False,

                                "broker_orders":
                                    0,

                                "ai_direct_execution":
                                    False,

                                "read_only":
                                    True,

                                "paper_trading":
                                    True,
                            },
                        },
                    )

            else:

                closed = []

            # ======================================================
            # AI DECISION
            # ======================================================

            decision_payload = (
                self.extract_decision(
                    ai_reasoning,
                    metadata,
                )
            )

            decision = str(
                decision_payload.get(
                    "decision",
                    metadata.get(
                        "final_decision",
                        "NO_TRADE",
                    ),
                )
            ).upper()

            # ======================================================
            # PAPER ENTRY
            # ======================================================

            paper_entry = None

            # Never stack positions.

            if (
                not self.account.positions
                and decision
                in {
                    "BUY_CANDIDATE",
                    "SELL_CANDIDATE",
                }
            ):

                setup = (
                    self.extract_setup(
                        intelligence,
                        decision_payload,
                    )
                )

                levels = (
                    self.extract_levels(
                        setup
                    )
                )

                if levels:

                    entry, stop, target = (
                        levels
                    )

                    direction = (
                        "BUY"
                        if decision
                        == "BUY_CANDIDATE"
                        else "SELL"
                    )

                    # Independent final geometry check.

                    valid_geometry = (
                        (
                            direction == "BUY"
                            and stop < entry < target
                        )
                        or
                        (
                            direction == "SELL"
                            and target < entry < stop
                        )
                    )

                    if valid_geometry:

                        paper_entry = (
                            self.account.open_position(
                                symbol=SYMBOL,
                                direction=direction,
                                entry=entry,
                                stop_loss=stop,
                                take_profit=target,
                                cycle_id=cycle_id,
                            )
                        )

                        if paper_entry:

                            append_jsonl(
                                TRADE_LOG,
                                {
                                    "event":
                                        "OPEN",

                                    "timestamp":
                                        utc_now(),

                                    "trade":
                                        paper_entry,

                                    "decision":
                                        decision_payload,

                                    "cycle_id":
                                        cycle_id,

                                    "safety": {
                                        "live_execution":
                                            False,

                                        "broker_orders":
                                            0,

                                        "ai_direct_execution":
                                            False,

                                        "read_only":
                                            True,

                                        "paper_trading":
                                            True,
                                    },
                                },
                            )

            # ======================================================
            # PERFORMANCE
            # ======================================================

            metrics = (
                self.account.metrics()
            )

            write_json(
                PERFORMANCE_FILE,
                metrics,
            )

            # ======================================================
            # FULL CYCLE RECORD
            # ======================================================

            result = {
                "cycle_id":
                    cycle_id,

                "timestamp":
                    utc_now(),

                "symbol":
                    SYMBOL,

                "timeframes":
                    list(
                        TIMEFRAMES
                    ),

                "status":
                    "COMPLETED",

                "decision":
                    decision,

                "ai_decision":
                    decision_payload,

                "prices": {
                    "bid":
                        bid,

                    "ask":
                        ask,
                },

                "paper_entry":
                    paper_entry,

                "paper_closures":
                    closed,

                "paper_account":
                    metrics,

                "intelligence":
                    intelligence,

                "ai_reasoning":
                    ai_reasoning,

                "elapsed_seconds":
                    time.monotonic()
                    - started,

                "safety": {
                    "dry_run":
                        True,

                    "live_execution":
                        False,

                    "broker_orders":
                        0,

                    "ai_direct_execution":
                        False,

                    "read_only":
                        True,

                    "paper_trading":
                        True,
                },
            }

            self.last_result = result
            self.last_error = None

            append_jsonl(
                CYCLE_LOG,
                result,
            )

            self.account.save()

            return result

        except Exception as exc:

            self.last_error = (
                f"{type(exc).__name__}: {exc}"
            )

            result = {
                "cycle_id":
                    cycle_id,

                "timestamp":
                    utc_now(),

                "symbol":
                    SYMBOL,

                "status":
                    "ERROR",

                "error":
                    self.last_error,

                "paper_account":
                    self.account.metrics(),

                "safety": {
                    "live_execution":
                        False,

                    "broker_orders":
                        0,

                    "ai_direct_execution":
                        False,

                    "read_only":
                        True,

                    "paper_trading":
                        True,
                },
            }

            self.last_result = result

            append_jsonl(
                CYCLE_LOG,
                result,
            )

            self.account.save()

            return result

    # -----------------------------------------------------------------

    async def run(
        self,
    ) -> None:

        self.running = True

        print()
        print("=" * 72)
        print(
            "HAFNOT AUTONOMOUS PAPER FORWARD ENGINE"
        )
        print("=" * 72)

        print(
            f"Symbol       : {SYMBOL}"
        )

        print(
            f"Timeframes   : {', '.join(TIMEFRAMES)}"
        )

        print(
            f"Interval     : {CYCLE_INTERVAL_SECONDS}s"
        )

        print(
            f"Paper equity : {self.account.equity:.2f}"
        )

        print()
        print(
            "PAPER TRADING       = TRUE"
        )

        print(
            "LIVE EXECUTION      = FALSE"
        )

        print(
            "BROKER ORDERS       = 0"
        )

        print(
            "AI DIRECT EXECUTION = FALSE"
        )

        print(
            "READ ONLY           = TRUE"
        )

        print("=" * 72)

        count = 0

        while self.running:

            if (
                MAX_CYCLES > 0
                and count >= MAX_CYCLES
            ):
                break

            count += 1

            result = await self.cycle()

            metrics = (
                result.get(
                    "paper_account",
                    {},
                )
            )

            print()
            print(
                f"[CYCLE {count:06d}] "
                f"{result.get('status')} "
                f"decision={result.get('decision')}"
            )

            print(
                f"Equity={metrics.get('equity', 0):.2f} "
                f"Closed={metrics.get('closed_trades', 0)} "
                f"Open={metrics.get('open_positions', 0)} "
                f"NetR={metrics.get('net_r', 0):.3f}"
            )

            if result.get("error"):

                print(
                    "ERROR:",
                    result["error"],
                )

            await asyncio.sleep(
                CYCLE_INTERVAL_SECONDS
            )

        self.running = False

        self.account.save()

        print()
        print("=" * 72)
        print(
            "PAPER FORWARD ENGINE STOPPED"
        )
        print("=" * 72)

        print(
            json.dumps(
                self.account.metrics(),
                indent=2,
            )
        )

        print()
        print(
            "LIVE EXECUTION = FALSE"
        )

        print(
            "BROKER ORDERS = 0"
        )

        print("=" * 72)


async def main():

    engine = (
        AutonomousPaperEngine()
    )

    def stop(*_args):

        engine.running = False

    try:

        signal.signal(
            signal.SIGINT,
            stop,
        )

        signal.signal(
            signal.SIGTERM,
            stop,
        )

    except Exception:
        pass

    await engine.run()


if __name__ == "__main__":

    asyncio.run(
        main()
    )
