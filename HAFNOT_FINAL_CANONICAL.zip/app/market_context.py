"""Unified, read-only market context assembler."""
from __future__ import annotations
from typing import Any, Dict


def build_market_context(
    *,
    symbol: str,
    spot: Any = None,
    timeframe_summaries: Dict[str, Any] | None = None,
    structure: Any = None,
    liquidity: Any = None,
    fundamentals: Any = None,
    news: Any = None,
    sentiment: Any = None,
    data_quality: Any = None,
    setup: Any = None,
) -> Dict[str, Any]:
    from app.market_regime import classify_market_regime
    from app.core.sessions import get_session_state
    from dataclasses import asdict

    timeframe_summaries = timeframe_summaries or {}
    regime = classify_market_regime(timeframe_summaries)
    session = asdict(get_session_state())

    return {
        "symbol": symbol,
        "spot": spot,
        "timeframes": timeframe_summaries,
        "structure": structure,
        "liquidity": liquidity,
        "fundamentals": fundamentals,
        "news": news,
        "sentiment": sentiment,
        "data_quality": data_quality,
        "regime": regime,
        "session": session,
        "setup": setup,
        "read_only": True,
    }
