def determine_market_state(timeframe_summaries):
    """
    Combine multiple timeframe summaries into
    a simple overall market state.
    """

    bullish = 0
    bearish = 0

    for timeframe, summary in timeframe_summaries.items():

        trend = summary.get("trend")

        if trend == "bullish":
            bullish += 1

        elif trend == "bearish":
            bearish += 1

    if bullish > bearish:
        directional_bias = "bullish"

    elif bearish > bullish:
        directional_bias = "bearish"

    else:
        directional_bias = "mixed"

    # Higher timeframe bias
    higher_timeframes = ["h4", "d1"]

    higher_bullish = 0
    higher_bearish = 0

    for timeframe in higher_timeframes:

        if timeframe not in timeframe_summaries:
            continue

        trend = timeframe_summaries[timeframe].get("trend")

        if trend == "bullish":
            higher_bullish += 1

        elif trend == "bearish":
            higher_bearish += 1

    if higher_bullish > higher_bearish:
        higher_timeframe_bias = "bullish"

    elif higher_bearish > higher_bullish:
        higher_timeframe_bias = "bearish"

    else:
        higher_timeframe_bias = "mixed"

    # Lower timeframe bias
    lower_timeframes = ["m5", "m15", "h1"]

    lower_bullish = 0
    lower_bearish = 0

    for timeframe in lower_timeframes:

        if timeframe not in timeframe_summaries:
            continue

        trend = timeframe_summaries[timeframe].get("trend")

        if trend == "bullish":
            lower_bullish += 1

        elif trend == "bearish":
            lower_bearish += 1

    if lower_bullish > lower_bearish:
        lower_timeframe_bias = "bullish"

    elif lower_bearish > lower_bullish:
        lower_timeframe_bias = "bearish"

    else:
        lower_timeframe_bias = "mixed"

    # Detect disagreement
    conflict = (
        higher_timeframe_bias != lower_timeframe_bias
        and higher_timeframe_bias != "mixed"
        and lower_timeframe_bias != "mixed"
    )

    return {
        "overall_bias": directional_bias,
        "higher_timeframe_bias": higher_timeframe_bias,
        "lower_timeframe_bias": lower_timeframe_bias,
        "timeframe_conflict": conflict,
    }