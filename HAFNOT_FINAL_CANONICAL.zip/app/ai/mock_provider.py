import json


def analyze_market(evidence):
    """
    Temporary mock AI provider.

    This simulates an AI response so we can test
    the trading-agent architecture without using
    an external API.
    """

    caution = evidence.get("caution", [])

    higher_timeframe_mixed = any(
        "Higher timeframe bias is mixed"
        in item
        for item in caution
    )

    structure_mixed = any(
        "Market structure is mixed"
        in item
        for item in caution
    )

    oversold = any(
        "Oversold:"
        in item
        for item in caution
    )

    news = evidence.get(
        "news",
        {}
    )

    high_news = news.get(
        "high",
        0
    )

    # ------------------------------------------
    # Conservative decision logic
    # ------------------------------------------

    if (
        evidence.get("evidence_bias") == "bearish"
        and not higher_timeframe_mixed
        and not structure_mixed
        and not oversold
        and high_news == 0
    ):

        decision = "SELL_CANDIDATE"

    else:

        decision = "WAIT"

    return {
        "market": "XAUUSD",

        "bias": evidence.get(
            "evidence_bias",
            "unknown"
        ),

        "confidence": evidence.get(
            "confidence_state",
            "unknown"
        ),

        "decision": decision,

        "bullish_evidence": evidence.get(
            "bullish_evidence",
            []
        ),

        "bearish_evidence": evidence.get(
            "bearish_evidence",
            []
        ),

        "conflicts": [
            item
            for item in caution
            if (
                "mixed" in item.lower()
                or "Oversold" in item
            )
        ],

        "risk_factors": [
            item
            for item in caution
            if (
                "support" in item.lower()
                or "resistance" in item.lower()
                or "news" in item.lower()
            )
        ],

        "missing_information": [],

        "reasoning": (
            "The market has bearish evidence, "
            "but the evidence package contains "
            "conflicting or cautionary conditions. "
            "A conservative system should wait "
            "for stronger confirmation."
        ),
    }