def apply_decision_gate(ai_decision, evidence):
    """
    Final deterministic safety gate.

    The AI can suggest a decision.
    Python has final authority.

    This function does NOT place trades.
    """

    ai_decision = dict(ai_decision)

    # ==================================================
    # READ EVIDENCE
    # ==================================================

    market_state = evidence.get(
        "market_state",
        {}
    )

    overall_bias = market_state.get(
        "overall_bias",
        "unknown"
    )

    higher_bias = market_state.get(
        "higher_timeframe_bias",
        "unknown"
    )

    lower_bias = market_state.get(
        "lower_timeframe_bias",
        "unknown"
    )

    structure = evidence.get(
        "structure",
        {}
    ).get(
        "type",
        "unknown"
    )

    confidence = evidence.get(
        "confidence_state",
        "low"
    )

    caution = evidence.get(
        "caution",
        []
    )

    news = evidence.get(
        "news",
        {}
    )

    # ==================================================
    # 1. BASIC AI DECISION VALIDATION
    # ==================================================

    valid_decisions = {
        "BUY_CANDIDATE",
        "SELL_CANDIDATE",
        "WAIT",
        "NO_TRADE",
    }

    decision = ai_decision.get(
        "decision",
        "NO_TRADE"
    )

    if decision not in valid_decisions:

        return {
            **ai_decision,
            "decision": "NO_TRADE",
            "gate_status": "REJECTED",
            "gate_reason": "Invalid AI decision.",
        }

    # ==================================================
    # 2. NO_TRADE ALWAYS WINS
    # ==================================================

    if decision == "NO_TRADE":

        return {
            **ai_decision,
            "decision": "NO_TRADE",
            "gate_status": "PASSED",
            "gate_reason": (
                "AI selected NO_TRADE."
            ),
        }

    # ==================================================
    # 3. WAIT ALWAYS REMAINS WAIT
    # ==================================================

    if decision == "WAIT":

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "PASSED",
            "gate_reason": (
                "AI selected WAIT."
            ),
        }

    # ==================================================
    # 4. NEWS SAFETY FIREWALL
    # ==================================================
    #
    # The news engine has deterministic authority
    # over whether current news conditions permit
    # a directional candidate to continue.
    #
    # HIGH_RISK:
    #     Directional candidate -> WAIT
    #
    # trading_restriction=True:
    #     Directional candidate -> WAIT
    #
    # UNAVAILABLE / STALE:
    #     Directional candidate -> WAIT
    #
    # CAUTION:
    #     Candidate may continue.
    #
    # NORMAL:
    #     Candidate may continue.
    #
    # Legacy "high" field remains supported so
    # existing tests continue working.
    # ==================================================

    news_status = news.get(
        "status"
    )

    news_restriction = news.get(
        "trading_restriction",
        False
    )

    news_available = news.get(
        "available",
        True
    )

    legacy_high_news = news.get(
        "high",
        0
    )

    if news_status == "HIGH_RISK":

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "Directional trade blocked by "
                "HIGH_RISK news conditions."
            ),
        }

    if news_restriction:

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "Directional trade blocked because "
                "the news engine imposed a trading "
                "restriction."
            ),
        }

    if news_status in {
        "UNAVAILABLE",
        "STALE",
    }:

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                f"Directional trade blocked because "
                f"news status is {news_status}."
            ),
        }

    if legacy_high_news > 0:

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "High-relevance news detected."
            ),
        }

    # ==================================================
    # 5. LOW CONFIDENCE
    # ==================================================

    if confidence == "low":

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "Low evidence confidence."
            ),
        }

    # ==================================================
    # 6. HIGHER TIMEFRAME CONFLICT
    # ==================================================

    if higher_bias == "mixed":

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "Higher timeframe bias is mixed."
            ),
        }

    # ==================================================
    # 7. MARKET STRUCTURE CONFLICT
    # ==================================================

    if structure == "mixed":

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "Market structure is mixed."
            ),
        }

    # ==================================================
    # 8. BUY DIRECTION CHECK
    # ==================================================

    if decision == "BUY_CANDIDATE":

        if overall_bias == "bearish":

            return {
                **ai_decision,
                "decision": "WAIT",
                "gate_status": "OVERRIDDEN",
                "gate_reason": (
                    "BUY conflicts with bearish "
                    "overall market bias."
                ),
            }

        if lower_bias == "bearish":

            return {
                **ai_decision,
                "decision": "WAIT",
                "gate_status": "OVERRIDDEN",
                "gate_reason": (
                    "BUY conflicts with bearish "
                    "lower timeframe bias."
                ),
            }

    # ==================================================
    # 9. SELL DIRECTION CHECK
    # ==================================================

    if decision == "SELL_CANDIDATE":

        if overall_bias == "bullish":

            return {
                **ai_decision,
                "decision": "WAIT",
                "gate_status": "OVERRIDDEN",
                "gate_reason": (
                    "SELL conflicts with bullish "
                    "overall market bias."
                ),
            }

        if lower_bias == "bullish":

            return {
                **ai_decision,
                "decision": "WAIT",
                "gate_status": "OVERRIDDEN",
                "gate_reason": (
                    "SELL conflicts with bullish "
                    "lower timeframe bias."
                ),
            }

    # ==================================================
    # 10. MOMENTUM CHECK
    # ==================================================

    oversold = any(
        "Oversold:" in str(item)
        for item in caution
    )

    overbought = any(
        "Overbought:" in str(item)
        for item in caution
    )

    if decision == "SELL_CANDIDATE" and oversold:

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "SELL blocked because "
                "oversold conditions exist."
            ),
        }

    if decision == "BUY_CANDIDATE" and overbought:

        return {
            **ai_decision,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "BUY blocked because "
                "overbought conditions exist."
            ),
        }

    # ==================================================
    # 11. ACCEPT DECISION
    # ==================================================

    return {
        **ai_decision,
        "gate_status": "PASSED",
        "gate_reason": (
            "AI decision passed all current "
            "deterministic safety checks."
        ),
    }