from __future__ import annotations

import re
from typing import Any, Dict


def _as_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _normalise(value: Any) -> str:
    if value is None:
        return ""

    return str(value).strip().lower()


def _get_timeframe_summaries(
    evidence: Dict[str, Any],
) -> Dict[str, Dict[str, Any]]:
    """
    Extract clean timeframe summaries from AI evidence.

    Supports both:

        {
            "H4": {
                "summary": {...}
            }
        }

    and:

        {
            "H4": {
                "rsi_14": ...,
                "trend": ...
            }
        }
    """

    summaries = evidence.get(
        "timeframe_summaries",
        {},
    )

    if not isinstance(summaries, dict):
        return {}

    result: Dict[str, Dict[str, Any]] = {}

    for timeframe, value in summaries.items():

        if not isinstance(value, dict):
            continue

        nested = value.get("summary")

        if isinstance(nested, dict):
            result[str(timeframe).upper()] = nested

        else:
            result[str(timeframe).upper()] = value

    return result


def _extract_ai_reasoning(
    ai_decision: Dict[str, Any],
) -> str:
    reasoning = ai_decision.get(
        "reasoning",
        "",
    )

    if not isinstance(reasoning, str):
        return ""

    return reasoning.strip()


def _timeframe_patterns(
    timeframe: str,
) -> list[str]:
    """
    Generate expressions that identify sentences/clauses
    explicitly referring to a specific timeframe.

    Examples matched:

        H4 is bearish
        H4 shows a bearish trend
        on H4, RSI is neutral
        H4 RSI is oversold
        H4 EMA20 is below EMA50
        the H4 timeframe is bullish
    """

    tf = re.escape(timeframe.lower())

    return [
        rf"\b{tf}\b",
        rf"\b{tf}\s+timeframe\b",
    ]


def _extract_timeframe_sentences(
    *,
    reasoning: str,
    timeframe: str,
) -> list[str]:
    """
    Extract sentences/clauses containing the specific timeframe.

    We intentionally validate only statements that explicitly
    reference the timeframe.

    This prevents a statement such as:

        H4 is bearish while M15 is bullish

    from being interpreted as saying that H4 is bullish.
    """

    if not reasoning:
        return []

    # First split into normal sentences.
    sentences = re.split(
        r"(?<=[.!?])\s+",
        reasoning,
    )

    patterns = _timeframe_patterns(
        timeframe,
    )

    matching: list[str] = []

    for sentence in sentences:

        sentence_lower = sentence.lower()

        if any(
            re.search(
                pattern,
                sentence_lower,
            )
            for pattern in patterns
        ):
            matching.append(sentence.strip())

    # Some model outputs use semicolons/newlines rather than
    # conventional punctuation. Split those clauses as well.
    if not matching:

        clauses = re.split(
            r"[;\n]+",
            reasoning,
        )

        for clause in clauses:

            clause_lower = clause.lower()

            if any(
                re.search(
                    pattern,
                    clause_lower,
                )
                for pattern in patterns
            ):
                matching.append(
                    clause.strip()
                )

    return matching


def _check_rsi_consistency(
    *,
    timeframe: str,
    summary: Dict[str, Any],
    reasoning: str,
) -> list[Dict[str, Any]]:
    findings: list[Dict[str, Any]] = []

    rsi = _as_float(
        summary.get("rsi_14")
    )

    if rsi is None:
        return findings

    relevant_text = " ".join(
        _extract_timeframe_sentences(
            reasoning=reasoning,
            timeframe=timeframe,
        )
    )

    if not relevant_text:
        return findings

    text = relevant_text.lower()

    if rsi >= 70:
        expected = "overbought"

        if "oversold" in text:

            findings.append(
                {
                    "type": "RSI_CONTRADICTION",
                    "severity": "HIGH",
                    "timeframe": timeframe,
                    "value": rsi,
                    "expected": expected,
                    "claim": "oversold",
                    "message": (
                        f"{timeframe} RSI {rsi:.2f} is "
                        "overbought, but AI reasoning "
                        "describes it as oversold."
                    ),
                }
            )

    elif rsi <= 30:
        expected = "oversold"

        if "overbought" in text:

            findings.append(
                {
                    "type": "RSI_CONTRADICTION",
                    "severity": "HIGH",
                    "timeframe": timeframe,
                    "value": rsi,
                    "expected": expected,
                    "claim": "overbought",
                    "message": (
                        f"{timeframe} RSI {rsi:.2f} is "
                        "oversold, but AI reasoning "
                        "describes it as overbought."
                    ),
                }
            )

    else:
        expected = "neutral"

        if "oversold" in text:

            findings.append(
                {
                    "type": "RSI_CONTRADICTION",
                    "severity": "HIGH",
                    "timeframe": timeframe,
                    "value": rsi,
                    "expected": expected,
                    "claim": "oversold",
                    "message": (
                        f"{timeframe} RSI {rsi:.2f} is "
                        "neutral, but AI reasoning "
                        "describes it as oversold."
                    ),
                }
            )

        if "overbought" in text:

            findings.append(
                {
                    "type": "RSI_CONTRADICTION",
                    "severity": "HIGH",
                    "timeframe": timeframe,
                    "value": rsi,
                    "expected": expected,
                    "claim": "overbought",
                    "message": (
                        f"{timeframe} RSI {rsi:.2f} is "
                        "neutral, but AI reasoning "
                        "describes it as overbought."
                    ),
                }
            )

    return findings


def _check_trend_consistency(
    *,
    timeframe: str,
    summary: Dict[str, Any],
    reasoning: str,
) -> list[Dict[str, Any]]:
    findings: list[Dict[str, Any]] = []

    trend = _normalise(
        summary.get("trend")
    )

    if trend not in {
        "bullish",
        "bearish",
        "neutral",
    }:
        return findings

    relevant_text = " ".join(
        _extract_timeframe_sentences(
            reasoning=reasoning,
            timeframe=timeframe,
        )
    )

    if not relevant_text:
        return findings

    text = relevant_text.lower()

    if trend == "bullish" and "bearish" in text:

        findings.append(
            {
                "type": "TREND_CONTRADICTION",
                "severity": "HIGH",
                "timeframe": timeframe,
                "expected": "bullish",
                "claim": "bearish",
                "message": (
                    f"{timeframe} technical engine "
                    "reports bullish, but AI reasoning "
                    "describes that timeframe as bearish."
                ),
            }
        )

    elif trend == "bearish" and "bullish" in text:

        findings.append(
            {
                "type": "TREND_CONTRADICTION",
                "severity": "HIGH",
                "timeframe": timeframe,
                "expected": "bearish",
                "claim": "bullish",
                "message": (
                    f"{timeframe} technical engine "
                    "reports bearish, but AI reasoning "
                    "describes that timeframe as bullish."
                ),
            }
        )

    return findings


def _check_volume_consistency(
    *,
    timeframe: str,
    summary: Dict[str, Any],
    reasoning: str,
) -> list[Dict[str, Any]]:
    findings: list[Dict[str, Any]] = []

    condition = _normalise(
        summary.get("volume_condition")
    )

    if condition not in {
        "above_average",
        "below_average",
    }:
        return findings

    relevant_text = " ".join(
        _extract_timeframe_sentences(
            reasoning=reasoning,
            timeframe=timeframe,
        )
    )

    if not relevant_text:
        return findings

    text = relevant_text.lower()

    above_phrases = (
        "above-average volume",
        "above average volume",
        "volume is above average",
        "volume above average",
    )

    below_phrases = (
        "below-average volume",
        "below average volume",
        "volume is below average",
        "volume below average",
    )

    if condition == "above_average":

        if any(
            phrase in text
            for phrase in below_phrases
        ):

            findings.append(
                {
                    "type": "VOLUME_CONTRADICTION",
                    "severity": "MEDIUM",
                    "timeframe": timeframe,
                    "expected": "above_average",
                    "claim": "below_average",
                    "message": (
                        f"{timeframe} volume is above "
                        "average, but AI reasoning says "
                        "it is below average."
                    ),
                }
            )

    elif condition == "below_average":

        if any(
            phrase in text
            for phrase in above_phrases
        ):

            findings.append(
                {
                    "type": "VOLUME_CONTRADICTION",
                    "severity": "MEDIUM",
                    "timeframe": timeframe,
                    "expected": "below_average",
                    "claim": "above_average",
                    "message": (
                        f"{timeframe} volume is below "
                        "average, but AI reasoning says "
                        "it is above average."
                    ),
                }
            )

    return findings


def _check_ema_consistency(
    *,
    timeframe: str,
    summary: Dict[str, Any],
    reasoning: str,
) -> list[Dict[str, Any]]:
    findings: list[Dict[str, Any]] = []

    ema20 = _as_float(
        summary.get("ema_20")
    )

    ema50 = _as_float(
        summary.get("ema_50")
    )

    if ema20 is None or ema50 is None:
        return findings

    relevant_text = " ".join(
        _extract_timeframe_sentences(
            reasoning=reasoning,
            timeframe=timeframe,
        )
    )

    if not relevant_text:
        return findings

    text = relevant_text.lower()

    relationship = (
        "above"
        if ema20 > ema50
        else "below"
        if ema20 < ema50
        else "equal"
    )

    # ------------------------------------------------------------
    # EMA20 ABOVE EMA50
    # ------------------------------------------------------------

    if relationship == "above":

        contradictory_patterns = (
            "ema20 below ema50",
            "ema 20 below ema 50",
            "ema_20 below ema_50",
            "ema20 is below ema50",
            "ema 20 is below ema 50",
            "ema20 below the ema50",
            "ema 20 below the ema 50",
        )

        if any(
            pattern in text
            for pattern in contradictory_patterns
        ):

            findings.append(
                {
                    "type": "EMA_CONTRADICTION",
                    "severity": "HIGH",
                    "timeframe": timeframe,
                    "expected": "EMA20 above EMA50",
                    "claim": "EMA20 below EMA50",
                    "message": (
                        f"{timeframe} EMA20 is above "
                        "EMA50, but AI reasoning "
                        "states the opposite."
                    ),
                }
            )

    # ------------------------------------------------------------
    # EMA20 BELOW EMA50
    # ------------------------------------------------------------

    elif relationship == "below":

        contradictory_patterns = (
            "ema20 above ema50",
            "ema 20 above ema 50",
            "ema_20 above ema_50",
            "ema20 is above ema50",
            "ema 20 is above ema 50",
            "ema20 above the ema50",
            "ema 20 above the ema 50",
        )

        if any(
            pattern in text
            for pattern in contradictory_patterns
        ):

            findings.append(
                {
                    "type": "EMA_CONTRADICTION",
                    "severity": "HIGH",
                    "timeframe": timeframe,
                    "expected": "EMA20 below EMA50",
                    "claim": "EMA20 above EMA50",
                    "message": (
                        f"{timeframe} EMA20 is below "
                        "EMA50, but AI reasoning "
                        "states the opposite."
                    ),
                }
            )

    return findings


def validate_ai_evidence_consistency(
    *,
    evidence: Dict[str, Any],
    ai_decision: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Deterministically check AI reasoning against market evidence.

    IMPORTANT:

    This validator does NOT decide BUY or SELL.

    It only determines whether explicit factual claims made by
    the AI contradict deterministic evidence.

    Validation is timeframe-aware.

    A claim about H4 is checked against H4 data.
    A claim about M15 is checked against M15 data.

    A statement about one timeframe is not automatically applied
    to every other timeframe.
    """

    findings: list[Dict[str, Any]] = []

    # ------------------------------------------------------------
    # BASIC INPUT VALIDATION
    # ------------------------------------------------------------

    if not isinstance(evidence, dict):

        return {
            "valid": False,
            "status": "BLOCKED",
            "reason": (
                "AI evidence is not a dictionary."
            ),
            "findings": [],
            "high_severity_count": 0,
            "finding_count": 0,
        }

    if not isinstance(ai_decision, dict):

        return {
            "valid": False,
            "status": "BLOCKED",
            "reason": (
                "AI decision is not a dictionary."
            ),
            "findings": [],
            "high_severity_count": 0,
            "finding_count": 0,
        }

    reasoning = _extract_ai_reasoning(
        ai_decision
    )

    if not reasoning:

        return {
            "valid": False,
            "status": "BLOCKED",
            "reason": (
                "AI reasoning is missing."
            ),
            "findings": [],
            "high_severity_count": 0,
            "finding_count": 0,
        }

    # ------------------------------------------------------------
    # TIMEFRAME DATA
    # ------------------------------------------------------------

    timeframe_summaries = _get_timeframe_summaries(
        evidence
    )

    # ------------------------------------------------------------
    # VALIDATE EACH TIMEFRAME INDEPENDENTLY
    # ------------------------------------------------------------

    for timeframe, summary in timeframe_summaries.items():

        findings.extend(
            _check_rsi_consistency(
                timeframe=timeframe,
                summary=summary,
                reasoning=reasoning,
            )
        )

        findings.extend(
            _check_trend_consistency(
                timeframe=timeframe,
                summary=summary,
                reasoning=reasoning,
            )
        )

        findings.extend(
            _check_volume_consistency(
                timeframe=timeframe,
                summary=summary,
                reasoning=reasoning,
            )
        )

        findings.extend(
            _check_ema_consistency(
                timeframe=timeframe,
                summary=summary,
                reasoning=reasoning,
            )
        )

    # ------------------------------------------------------------
    # SEVERITY
    # ------------------------------------------------------------

    high_severity = [
        finding
        for finding in findings
        if finding.get("severity") == "HIGH"
    ]

    valid = len(high_severity) == 0

    # ------------------------------------------------------------
    # FINAL RESULT
    # ------------------------------------------------------------

    return {
        "valid": valid,

        "status": (
            "PASSED"
            if valid
            else "BLOCKED"
        ),

        "reason": (
            "AI reasoning is consistent with "
            "deterministic evidence."
            if valid
            else
            "AI reasoning contradicts "
            "deterministic evidence."
        ),

        "findings": findings,

        "high_severity_count": len(
            high_severity
        ),

        "finding_count": len(
            findings
        ),
    }