from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


AI_DATA_DIR = Path(__file__).resolve().parents[2] / "data" / "ai"

DECISION_LOG = AI_DATA_DIR / "decisions.jsonl"
EVIDENCE_LOG = AI_DATA_DIR / "evidence.jsonl"
REASONING_LOG = AI_DATA_DIR / "reasoning.jsonl"
REJECTION_LOG = AI_DATA_DIR / "rejected_decisions.jsonl"
PAPER_LOG = AI_DATA_DIR / "paper_trade_plans.jsonl"


VALID_DECISIONS = {
    "BUY_CANDIDATE",
    "SELL_CANDIDATE",
    "WAIT",
    "NO_TRADE",
}

VALID_DIRECTIONS = {
    "BUY",
    "SELL",
    "NONE",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None:
            return default
        value = float(value)
        if not math.isfinite(value):
            return default
        return value
    except (TypeError, ValueError):
        return default


def _safe_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _safe_list(value: Any) -> list:
    return value if isinstance(value, list) else []


def _json_safe(value: Any) -> Any:
    """
    Convert arbitrary project objects into JSON-safe structures.
    """
    if value is None or isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, dict):
        return {
            str(k): _json_safe(v)
            for k, v in value.items()
        }

    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]

    if hasattr(value, "to_dict"):
        try:
            return _json_safe(value.to_dict())
        except Exception:
            pass

    if hasattr(value, "__dict__"):
        try:
            return _json_safe(vars(value))
        except Exception:
            pass

    return str(value)


def _append_jsonl(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open(
        "a",
        encoding="utf-8",
    ) as handle:
        handle.write(
            json.dumps(
                _json_safe(payload),
                ensure_ascii=False,
                separators=(",", ":"),
            )
            + "\n"
        )


def _extract_orderflow(intelligence: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract validated native Level-II order-flow evidence.

    This function intentionally accepts several existing representations
    so the AI layer does not force a rewrite of the validated order-flow
    engine.
    """

    candidates = [
        intelligence.get("orderflow"),
        intelligence.get("order_flow"),
        intelligence.get("order_flow_intelligence"),
        intelligence.get("depth"),
    ]

    orderflow: Dict[str, Any] = {}

    for candidate in candidates:
        if isinstance(candidate, dict):
            orderflow.update(candidate)

    # Some implementations place the book snapshot directly inside
    # the order-flow package.
    book = (
        orderflow.get("orderbook")
        or orderflow.get("order_book")
        or orderflow.get("book")
        or {}
    )

    if not isinstance(book, dict):
        book = {}

    fields = {
        "best_bid",
        "best_ask",
        "spread",
        "bid_depth",
        "ask_depth",
        "raw_imbalance",
        "weighted_imbalance",
        "book_pressure",
        "short_term_book_momentum",
        "stacking_score",
        "pulling_score",
        "liquidity_migration",
        "absorption_proxy",
        "exhaustion_proxy",
        "confidence",
        "quote_count",
    }

    # Preserve the book itself while also flattening the critical
    # deterministic fields for the AI evidence package.
    merged = dict(orderflow)

    for field in fields:
        if field not in merged and field in book:
            merged[field] = book[field]

    heatmap = (
        merged.get("heatmap")
        or intelligence.get("heatmap")
        or {}
    )

    signal = (
        merged.get("signal")
        or merged.get("orderflow_signal")
        or merged.get("order_flow_signal")
        or {}
    )

    merged["heatmap"] = _safe_dict(heatmap)
    merged["signal"] = _safe_dict(signal)

    # Explicit provenance.
    merged["data_source"] = (
        merged.get(
            "data_source",
            "cTrader_native_level2",
        )
    )

    merged["executed_trade_volume_available"] = bool(
        merged.get(
            "executed_trade_volume_available",
            False,
        )
    )

    merged["true_trade_delta_available"] = bool(
        merged.get(
            "true_trade_delta_available",
            False,
        )
    )

    merged["depth_footprint_proxy"] = bool(
        merged.get(
            "depth_footprint_proxy",
            True,
        )
    )

    return merged


def build_complete_ai_evidence(
    *,
    symbol: str,
    intelligence: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Build the final evidence package supplied to the AI.

    Deterministic evidence is preserved exactly.
    """

    intelligence = _safe_dict(intelligence)

    # Existing evidence builder.
    from app.ai.reasoning_engine import build_ai_evidence

    base = build_ai_evidence(
        symbol=symbol,
        intelligence=intelligence,
    )

    orderflow = _extract_orderflow(intelligence)

    data_quality = _safe_dict(
        base.get("data_quality")
        or intelligence.get("data_quality")
    )

    data_quality = {
        **data_quality,
        "native_ctrader_level2": True,
        "executed_trade_volume_available": bool(
            orderflow.get(
                "executed_trade_volume_available",
                False,
            )
        ),
        "true_trade_delta_available": bool(
            orderflow.get(
                "true_trade_delta_available",
                False,
            )
        ),
        "depth_footprint_proxy": bool(
            orderflow.get(
                "depth_footprint_proxy",
                True,
            )
        ),
    }

    evidence = {
        **base,

        "symbol": symbol,

        "order_flow": orderflow,

        "orderflow": orderflow,

        "data_quality": data_quality,

        "evidence_timestamp": _now(),

        "evidence_version": "HAFNOT-AI-1.0",

        "ai_constraints": {
            "deterministic_evidence_authoritative": True,
            "ai_may_not_modify_market_facts": True,
            "ai_may_not_execute_orders": True,
            "ai_may_not_authorize_execution": True,
            "read_only": True,
        },
    }

    return _json_safe(evidence)


def _safe_no_trade(
    symbol: str,
    reason: str,
) -> Dict[str, Any]:

    return {
        "market": symbol,
        "bias": "unknown",
        "confidence": "low",
        "decision": "NO_TRADE",
        "setup": {
            "direction": "NONE",
            "quality": "LOW",
        },
        "conflicts": [reason],
        "missing_information": [],
        "reasoning": (
            "The AI decision system failed closed because "
            + reason
        ),
    }


def _validate_final_shape(
    symbol: str,
    decision: Dict[str, Any],
) -> Dict[str, Any]:

    decision = dict(decision)

    if decision.get("decision") not in VALID_DECISIONS:
        return _safe_no_trade(
            symbol,
            "AI returned an unsupported decision.",
        )

    setup = decision.get("setup")

    if not isinstance(setup, dict):
        decision["setup"] = {
            "direction": "NONE",
            "quality": "LOW",
        }

    if decision["decision"] in {
        "WAIT",
        "NO_TRADE",
    }:
        decision["setup"] = {
            "direction": "NONE",
            "quality": "LOW",
        }

    return decision


def _direction_from_decision(
    decision: str,
) -> str:

    if decision == "BUY_CANDIDATE":
        return "BUY"

    if decision == "SELL_CANDIDATE":
        return "SELL"

    return "NONE"


def _extract_trade_parameters(
    ai_decision: Dict[str, Any],
) -> Dict[str, Any]:

    setup = _safe_dict(
        ai_decision.get("setup")
    )

    entry = (
        setup.get("entry")
        if "entry" in setup
        else setup.get("entry_price")
    )

    stop = (
        setup.get("stop_loss")
        if "stop_loss" in setup
        else setup.get("stop")
    )

    target = (
        setup.get("take_profit")
        if "take_profit" in setup
        else setup.get("target")
    )

    risk_percent = setup.get(
        "risk_percent",
        ai_decision.get(
            "risk_percent",
            0.0,
        ),
    )

    reward_risk = setup.get(
        "reward_risk",
        ai_decision.get(
            "reward_risk",
        ),
    )

    return {
        "entry": _safe_float(entry),
        "stop_loss": _safe_float(stop),
        "take_profit": _safe_float(target),
        "risk_percent": _safe_float(
            risk_percent,
            0.0,
        ),
        "reward_risk": _safe_float(
            reward_risk
        ),
    }


def _create_paper_trade_plan(
    *,
    symbol: str,
    gated: Dict[str, Any],
    intelligence: Dict[str, Any],
) -> Dict[str, Any]:

    decision = gated.get(
        "decision",
        "NO_TRADE",
    )

    direction = _direction_from_decision(
        decision
    )

    parameters = _extract_trade_parameters(
        gated
    )

    plan = {
        "timestamp": _now(),
        "symbol": symbol,

        "decision": decision,
        "direction": direction,

        "entry": parameters["entry"],
        "stop_loss": parameters["stop_loss"],
        "take_profit": parameters["take_profit"],

        "risk_percent": parameters["risk_percent"],
        "reward_risk": parameters["reward_risk"],

        "paper_trade": True,

        "live_execution": False,
        "execution_allowed": False,
        "broker_order": False,

        "gate_status": gated.get(
            "gate_status",
            "UNKNOWN",
        ),

        "gate_reason": gated.get(
            "gate_reason",
            "",
        ),

        "ai_confidence": gated.get(
            "confidence",
            "low",
        ),

        "setup": gated.get(
            "setup",
            {},
        ),

        "evidence_version": (
            intelligence.get(
                "evidence_version"
            )
            if isinstance(intelligence, dict)
            else None
        ),
    }

    return plan


def _validate_risk_without_execution(
    paper_plan: Dict[str, Any],
    intelligence: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Validate trade geometry without submitting an order.

    Existing risk modules are used opportunistically. If a project
    risk API does not match, this layer fails closed rather than
    inventing a risk approval.
    """

    decision = paper_plan.get(
        "decision"
    )

    if decision not in {
        "BUY_CANDIDATE",
        "SELL_CANDIDATE",
    }:
        return {
            "valid": True,
            "status": "NOT_REQUIRED",
            "reason": "No directional trade candidate.",
        }

    entry = paper_plan.get("entry")
    stop = paper_plan.get("stop_loss")
    target = paper_plan.get("take_profit")

    if entry is None or stop is None:
        return {
            "valid": False,
            "status": "BLOCKED",
            "reason": (
                "Directional candidate has no valid "
                "entry and stop-loss."
            ),
        }

    if decision == "BUY_CANDIDATE":
        if stop >= entry:
            return {
                "valid": False,
                "status": "BLOCKED",
                "reason": (
                    "BUY stop-loss must be below entry."
                ),
            }

        if target is not None and target <= entry:
            return {
                "valid": False,
                "status": "BLOCKED",
                "reason": (
                    "BUY take-profit must be above entry."
                ),
            }

    if decision == "SELL_CANDIDATE":
        if stop <= entry:
            return {
                "valid": False,
                "status": "BLOCKED",
                "reason": (
                    "SELL stop-loss must be above entry."
                ),
            }

        if target is not None and target >= entry:
            return {
                "valid": False,
                "status": "BLOCKED",
                "reason": (
                    "SELL take-profit must be below entry."
                ),
            }

    risk_percent = _safe_float(
        paper_plan.get(
            "risk_percent"
        ),
        0.0,
    )

    if risk_percent is None or risk_percent <= 0:
        return {
            "valid": False,
            "status": "BLOCKED",
            "reason": (
                "Directional candidate has no positive "
                "risk percentage."
            ),
        }

    if risk_percent > 2.0:
        return {
            "valid": False,
            "status": "BLOCKED",
            "reason": (
                "Paper risk exceeds the current "
                "2% hard validation ceiling."
            ),
        }

    return {
        "valid": True,
        "status": "PASSED",
        "reason": (
            "Trade geometry and paper-risk constraints "
            "passed without execution."
        ),
    }


def run_complete_ai_decision(
    *,
    symbol: str,
    intelligence: Dict[str, Any],
) -> Dict[str, Any]:
    """
    COMPLETE HAFNOT AI DECISION PIPELINE.

    Intelligence
        -> Evidence
        -> Ollama
        -> normalization
        -> schema validation
        -> deterministic evidence validation
        -> decision gate
        -> paper risk validation
        -> paper trade plan

    HARD SAFETY:
        No broker order can be created by this function.
    """

    started = time.perf_counter()

    intelligence = _safe_dict(
        intelligence
    )

    # ------------------------------------------------------------
    # BUILD EVIDENCE
    # ------------------------------------------------------------

    try:
        evidence = build_complete_ai_evidence(
            symbol=symbol,
            intelligence=intelligence,
        )

    except Exception as exc:

        reason = (
            "Evidence construction failed: "
            f"{type(exc).__name__}: {exc}"
        )

        result = {
            "available": False,
            "symbol": symbol,
            "final_decision": "NO_TRADE",
            "ai_decision": _safe_no_trade(
                symbol,
                reason,
            ),
            "validator": {
                "valid": False,
                "errors": [reason],
                "warnings": [],
            },
            "evidence_validation": {
                "valid": False,
                "status": "BLOCKED",
                "reason": reason,
            },
            "gate": {
                "decision": "NO_TRADE",
                "gate_status": "REJECTED",
                "gate_reason": reason,
            },
            "trade_authorized": False,
            "execution_allowed": False,
            "read_only": True,
        }

        _append_jsonl(
            REJECTION_LOG,
            result,
        )

        return result

    # ------------------------------------------------------------
    # AI REASONING
    # ------------------------------------------------------------

    from app.ai.reasoning_engine import run_ai_reasoning

    try:
        reasoning_result = run_ai_reasoning(
            symbol=symbol,
            intelligence=intelligence,
        )

    except Exception as exc:

        reason = (
            "AI reasoning pipeline failed: "
            f"{type(exc).__name__}: {exc}"
        )

        reasoning_result = {
            "available": False,
            "symbol": symbol,
            "evidence": evidence,
            "ai_decision": _safe_no_trade(
                symbol,
                reason,
            ),
            "validator": {
                "valid": False,
                "errors": [reason],
                "warnings": [],
            },
            "evidence_validation": {
                "valid": False,
                "status": "BLOCKED",
                "reason": reason,
            },
            "gate": {
                "decision": "NO_TRADE",
                "gate_status": "REJECTED",
                "gate_reason": reason,
            },
            "final_decision": "NO_TRADE",
            "trade_authorized": False,
            "execution_allowed": False,
            "read_only": True,
        }

    ai_decision = _validate_final_shape(
        symbol,
        _safe_dict(
            reasoning_result.get(
                "ai_decision"
            )
        ),
    )

    validator = _safe_dict(
        reasoning_result.get(
            "validator"
        )
    )

    evidence_validation = _safe_dict(
        reasoning_result.get(
            "evidence_validation"
        )
    )

    gate = _safe_dict(
        reasoning_result.get(
            "gate"
        )
    )

    # ------------------------------------------------------------
    # HARD FAIL-CLOSED CHECKS
    # ------------------------------------------------------------

    if not validator.get(
        "valid",
        False,
    ):
        ai_decision = _safe_no_trade(
            symbol,
            "AI schema validation failed.",
        )

        gate = {
            "decision": "NO_TRADE",
            "gate_status": "REJECTED",
            "gate_reason": (
                "AI schema validation failed."
            ),
        }

    if not evidence_validation.get(
        "valid",
        False,
    ):
        ai_decision = _safe_no_trade(
            symbol,
            "Deterministic evidence consistency validation failed.",
        )

        gate = {
            "decision": "NO_TRADE",
            "gate_status": "REJECTED",
            "gate_reason": (
                "Deterministic evidence consistency "
                "validation failed."
            ),
        }

    # ------------------------------------------------------------
    # FINAL DECISION
    # ------------------------------------------------------------

    final_decision = gate.get(
        "decision",
        ai_decision.get(
            "decision",
            "NO_TRADE",
        ),
    )

    if final_decision not in VALID_DECISIONS:
        final_decision = "NO_TRADE"

    gated = {
        **gate,
        "decision": final_decision,
    }

    # ------------------------------------------------------------
    # PAPER PLAN
    # ------------------------------------------------------------

    paper_plan = _create_paper_trade_plan(
        symbol=symbol,
        gated={
            **ai_decision,
            **gated,
        },
        intelligence=intelligence,
    )

    risk_validation = _validate_risk_without_execution(
        paper_plan,
        intelligence,
    )

    # Risk failure converts directional candidate to WAIT.
    if (
        final_decision
        in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }
        and not risk_validation.get(
            "valid",
            False,
        )
    ):
        final_decision = "WAIT"

        gated = {
            **gated,
            "decision": "WAIT",
            "gate_status": "OVERRIDDEN",
            "gate_reason": (
                "Paper-risk validation blocked the "
                "directional candidate: "
                + str(
                    risk_validation.get(
                        "reason",
                        "risk validation failed",
                    )
                )
            ),
        }

        paper_plan = _create_paper_trade_plan(
            symbol=symbol,
            gated={
                **ai_decision,
                **gated,
            },
            intelligence=intelligence,
        )

    # ------------------------------------------------------------
    # HARD SAFETY FIELDS
    # ------------------------------------------------------------

    result = {
        "available": True,

        "timestamp": _now(),

        "symbol": symbol,

        "evidence": evidence,

        "ai_decision": ai_decision,

        "validator": validator,

        "evidence_validation": evidence_validation,

        "gate": gated,

        "final_decision": final_decision,

        "paper_trade_plan": paper_plan,

        "risk_validation": risk_validation,

        "latency_seconds": round(
            time.perf_counter() - started,
            6,
        ),

        "trade_authorized": False,

        "execution_allowed": False,

        "broker_order": False,

        "live_execution": False,

        "paper_trading": True,

        "ai_direct_execution": False,

        "read_only": True,
    }

    # ------------------------------------------------------------
    # AUDIT
    # ------------------------------------------------------------

    _append_jsonl(
        EVIDENCE_LOG,
        {
            "timestamp": result["timestamp"],
            "symbol": symbol,
            "evidence": evidence,
        },
    )

    _append_jsonl(
        REASONING_LOG,
        {
            "timestamp": result["timestamp"],
            "symbol": symbol,
            "ai_decision": ai_decision,
            "final_decision": final_decision,
            "validator": validator,
            "evidence_validation": evidence_validation,
            "gate": gated,
        },
    )

    _append_jsonl(
        DECISION_LOG,
        {
            "timestamp": result["timestamp"],
            "symbol": symbol,
            "decision": final_decision,
            "gate": gated,
            "risk_validation": risk_validation,
            "execution_allowed": False,
        },
    )

    if final_decision in {
        "BUY_CANDIDATE",
        "SELL_CANDIDATE",
    }:
        _append_jsonl(
            PAPER_LOG,
            paper_plan,
        )

    if final_decision in {
        "NO_TRADE",
        "WAIT",
    }:
        _append_jsonl(
            REJECTION_LOG,
            {
                "timestamp": result["timestamp"],
                "symbol": symbol,
                "decision": final_decision,
                "reason": gated.get(
                    "gate_reason",
                    "",
                ),
                "read_only": True,
            },
        )

    return result


def system_status() -> Dict[str, Any]:
    return {
        "ai_reasoning": True,
        "structured_output": True,
        "deterministic_validation": True,
        "decision_gate": True,
        "paper_trading": True,
        "live_execution": False,
        "broker_orders": 0,
        "ai_direct_execution": False,
        "read_only": True,
        "audit_logging": True,
    }
