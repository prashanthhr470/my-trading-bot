from __future__ import annotations

import json
import requests


# ============================================================
# OLLAMA CONFIGURATION
# ============================================================

OLLAMA_URL = "http://localhost:11434/api/chat"
# HAFNOT bounded Ollama request timeout.
HAFNOT_OLLAMA_TIMEOUT = 45
HAFNOT_OLLAMA_RETRY_TIMEOUT = 20


MODEL = "qwen3:0.6b"
# ============================================================
# STRICT JSON SCHEMA
# ============================================================

AI_SCHEMA = {
    "type": "object",
    "properties": {
        "market": {
            "type": "string",
        },

        "bias": {
            "type": "string",
            "enum": [
                "bullish",
                "bearish",
                "mixed",
                "unknown",
            ],
        },

        "confidence": {
            "type": "string",
            "enum": [
                "high",
                "medium",
                "low",
            ],
        },

        "decision": {
            "type": "string",
            "enum": [
                "BUY_CANDIDATE",
                "SELL_CANDIDATE",
                "WAIT",
                "NO_TRADE",
            ],
        },

        "setup": {
            "type": "object",
            "properties": {
                "direction": {
                    "type": "string",
                    "enum": [
                        "BUY",
                        "SELL",
                        "NONE",
                    ],
                },

                "quality": {
                    "type": "string",
                    "enum": [
                        "HIGH",
                        "MODERATE",
                        "LOW",
                    ],
                },
            },
            "required": [
                "direction",
                "quality",
            ],
        },

        "conflicts": {
            "type": "array",
            "items": {
                "type": "string",
            },
        },

        "missing_information": {
            "type": "array",
            "items": {
                "type": "string",
            },
        },

        "reasoning": {
            "type": "string",
            "minLength": 40,
        },
    },

    "required": [
        "market",
        "bias",
        "confidence",
        "decision",
        "setup",
        "conflicts",
        "missing_information",
        "reasoning",
    ],
}


# ============================================================
# SYSTEM INSTRUCTION
# ============================================================

SYSTEM_INSTRUCTION = """
You are a multi-symbol market-analysis component.

You analyze the requested symbol only. The requested symbol is authoritative.

You do NOT execute trades.
You do NOT place orders.

Python has final authority.

Analyze ONLY the supplied evidence.

============================================================
CORE RULES
============================================================

1. LOW EVIDENCE CONFIDENCE IS A HARD STOP.

If evidence.confidence_state is LOW:

    decision = WAIT
    setup.direction = NONE
    setup.quality = LOW

You MUST NOT return BUY_CANDIDATE.
You MUST NOT return SELL_CANDIDATE.

Do not override this rule because of:

- RSI
- oversold conditions
- overbought conditions
- support
- resistance
- liquidity sweeps
- a single timeframe
- a single indicator

============================================================
2. MIXED HIGHER TIMEFRAME IS A HARD STOP
============================================================

If:

    market_state.higher_timeframe_bias = mixed

then:

    decision = WAIT
    setup.direction = NONE
    setup.quality = LOW

============================================================
3. MIXED STRUCTURE
============================================================

If market structure is mixed or unclear:

    decision = WAIT
    setup.direction = NONE
    setup.quality = LOW

============================================================
4. FUNDAMENTAL EVIDENCE
============================================================

Fundamental information must be treated according to its
actual status.

If fundamentals are:

    actionable = false

then they MUST NOT be used as direct directional trade
confirmation.

For the requested symbol, relevant fundamental information may be
CONTEXT ONLY.

Do NOT convert contextual USD information into an automatic
BUY or SELL signal for gold.

For supported FX pairs:

BUY/SELL fundamental confirmation requires:

    actionable = true

and:

    conflict = false

and sufficient confidence.

If fundamental evidence is conflicting or non-actionable,
reduce confidence and prefer WAIT.

============================================================
5. BUY REQUIREMENTS
============================================================

BUY_CANDIDATE requires ALL of the following:

- actual bullish evidence
- evidence confidence is NOT LOW
- higher timeframe is not mixed
- structure supports bullish direction
- setup.direction = BUY
- setup.quality = HIGH or MODERATE

If any major requirement is missing:

    decision = WAIT

============================================================
6. SELL REQUIREMENTS
============================================================

SELL_CANDIDATE requires ALL of the following:

- actual bearish evidence
- evidence confidence is NOT LOW
- higher timeframe is not mixed
- structure supports bearish direction
- setup.direction = SELL
- setup.quality = HIGH or MODERATE

If any major requirement is missing:

    decision = WAIT

============================================================
7. INDICATORS DO NOT OVERRIDE STRUCTURE
============================================================

Oversold does NOT automatically mean BUY.

Overbought does NOT automatically mean SELL.

Liquidity sweeps do NOT automatically mean BUY or SELL.

Support does NOT automatically mean BUY.

Resistance does NOT automatically mean SELL.

A bearish structure must not be ignored because RSI is
oversold.

A bullish structure must not be ignored because RSI is
overbought.

============================================================
8. DETERMINISTIC TECHNICAL EVIDENCE
============================================================

The supplied timeframe technical evidence is calculated by
Python.

Python's technical values are authoritative.

For every timeframe:

- read EMA20 and EMA50 directly;
- determine their relationship from the numerical values;
- read the supplied trend directly;
- read RSI directly;
- read the supplied momentum state directly;
- read volume condition directly.

NEVER invent or reverse an EMA relationship.

If:

    EMA20 < EMA50

then EMA20 is BELOW EMA50.

If:

    EMA20 > EMA50

then EMA20 is ABOVE EMA50.

NEVER state the opposite relationship.

NEVER infer a different trend from the supplied deterministic
trend field.

For RSI:

- RSI >= 70 is OVERBOUGHT.
- RSI <= 30 is OVERSOLD.
- RSI between 30 and 70 is NEUTRAL.

Examples:

RSI 40 is NEUTRAL.
RSI 50 is NEUTRAL.
RSI 67 is NEUTRAL.
RSI 71 is OVERBOUGHT.
RSI 29 is OVERSOLD.

Do NOT call RSI 40 oversold.

Do NOT call RSI 67 overbought.

When describing a timeframe, associate the statement only with
that timeframe.

For example:

H4 bearish and M15 bullish

means:

H4 = bearish
M15 = bullish

Do NOT reverse them.

============================================================
9. TECHNICAL REASONING DISCIPLINE
============================================================

When discussing a timeframe, use the exact deterministic
values supplied for that timeframe.

If the evidence says:

H4:
EMA20 below EMA50
trend bearish

then acceptable reasoning includes:

"H4 is bearish with EMA20 below EMA50."

It is NOT acceptable to write:

"H4 is bearish with EMA20 above EMA50."

If the evidence says:

M15:
EMA20 above EMA50
trend bullish

then acceptable reasoning includes:

"M15 is bullish with EMA20 above EMA50."

Do not transfer technical facts from one timeframe to another.

============================================================
10. MISSING INFORMATION
============================================================

Missing information must reduce confidence.

Never invent information.

Never assume missing information.

Never predict with certainty.

============================================================
11. DECISION PRIORITY
============================================================

When evidence conflicts, use this priority:

1. Overall market bias
2. Higher timeframe bias
3. Market structure
4. Fundamental evidence
5. Lower timeframe bias
6. Liquidity
7. Momentum
8. Support/resistance
9. News

Do NOT allow one indicator to override broader structure.

============================================================
12. WAIT CONDITION
============================================================

If there is not enough evidence for a high-quality BUY or SELL:

    decision = WAIT
    setup.direction = NONE
    setup.quality = LOW

============================================================
13. STRICT DECISION / SETUP CONSISTENCY
============================================================

These combinations are FORBIDDEN:

WAIT + BUY
WAIT + SELL

NO_TRADE + BUY
NO_TRADE + SELL

If decision is WAIT:

    setup.direction = NONE
    setup.quality = LOW

If decision is NO_TRADE:

    setup.direction = NONE
    setup.quality = LOW

If decision is BUY_CANDIDATE:

    setup.direction = BUY
    setup.quality = HIGH or MODERATE

If decision is SELL_CANDIDATE:

    setup.direction = SELL
    setup.quality = HIGH or MODERATE

============================================================
14. REASONING REQUIREMENTS
============================================================

The "reasoning" field MUST contain a substantive explanation.

It MUST:

- explain why the selected decision was made;
- reference only evidence supplied in the input;
- explain the most important supporting evidence;
- explain important conflicts or uncertainty;
- explain relevant missing information;
- explain why a BUY or SELL is NOT justified when decision = WAIT;
- explain why NO_TRADE is required when applicable;
- remain consistent with bias, confidence, setup, structure,
  liquidity, fundamentals, news, sentiment, regime, and
  timeframe evidence.

For technical statements, use the deterministic technical
evidence exactly as supplied.

It MUST NOT:

- invent prices, indicators, news, structure, liquidity,
  fundamentals, sentiment, or market events;
- claim information that is not present in the supplied evidence;
- reverse EMA20/EMA50 relationships;
- assign a technical state to the wrong timeframe;
- use certainty such as "guaranteed", "certain", or
  "will definitely happen";
- merely repeat the decision;
- be empty or a meaningless placeholder.

For WAIT or NO_TRADE, explicitly state the main reason
there is insufficient evidence for a high-quality trade.

The reasoning must be at least 40 characters long.


============================================================
PAPER TRADE GEOMETRY
============================================================

For BUY_CANDIDATE or SELL_CANDIDATE, the setup should include:

- entry
- stop_loss
- take_profit
- risk_percent
- reward_risk

Use ONLY prices and deterministic evidence supplied in the
input.

Never invent market facts.

For WAIT or NO_TRADE, these values may be 0 and the setup
direction MUST remain NONE.

Python performs the final risk validation.

The AI never authorizes broker execution.
============================================================
15. FINAL SELF-CHECK
============================================================

Before returning JSON verify:

- Is decision consistent with setup?
- Does BUY have actual bullish evidence?
- Does SELL have actual bearish evidence?
- Is confidence consistent with evidence?
- If evidence confidence is LOW, is decision WAIT?
- If higher timeframe is mixed, is decision WAIT?
- If decision is WAIT, is setup.direction NONE?
- If decision is WAIT, is setup.quality LOW?
- Are fundamentals being treated according to actionable status?
- Does every timeframe technical claim match the supplied
  deterministic technical evidence?
- Are EMA20/EMA50 relationships numerically correct?
- Are RSI classifications correct?
- Is each technical statement associated with the correct
  timeframe?

If ANY answer is NO, correct the response.

Return ONLY the requested JSON object.
"""


# ============================================================
# AI EVIDENCE COMPACTION
# ============================================================

def _prepare_ai_evidence(evidence):
    """
    Keep the information useful for reasoning while removing
    very large repeated arrays.

    The full evidence remains available to the rest of the
    pipeline.

    Only the copy sent to Qwen is compacted.
    """

    if not isinstance(
        evidence,
        dict,
    ):
        return evidence

    compact = dict(evidence)

    # --------------------------------------------------------
    # MARKET STATE
    # --------------------------------------------------------

    if isinstance(
        evidence.get("market_state"),
        dict,
    ):
        compact["market_state"] = dict(
            evidence["market_state"]
        )

    # --------------------------------------------------------
    # DETERMINISTIC TIMEFRAME TECHNICAL EVIDENCE
    # --------------------------------------------------------

    timeframe_summaries = evidence.get(
        "timeframe_summaries"
    )

    if isinstance(
        timeframe_summaries,
        dict,
    ):

        technical_evidence = {}

        for timeframe, value in timeframe_summaries.items():

            if not isinstance(
                value,
                dict,
            ):
                continue

            summary = value.get(
                "summary"
            )

            if not isinstance(
                summary,
                dict,
            ):
                summary = value

            ema20 = summary.get(
                "ema_20"
            )

            ema50 = summary.get(
                "ema_50"
            )

            ema_relationship = "unknown"

            try:
                ema20_float = float(
                    ema20
                )

                ema50_float = float(
                    ema50
                )

                if ema20_float > ema50_float:
                    ema_relationship = (
                        "EMA20_ABOVE_EMA50"
                    )

                elif ema20_float < ema50_float:
                    ema_relationship = (
                        "EMA20_BELOW_EMA50"
                    )

                else:
                    ema_relationship = (
                        "EMA20_EQUAL_EMA50"
                    )

            except (
                TypeError,
                ValueError,
            ):
                pass

            technical_evidence[
                str(timeframe).upper()
            ] = {
                "close": summary.get(
                    "close"
                ),
                "ema_20": ema20,
                "ema_50": ema50,
                "ema_relationship": (
                    ema_relationship
                ),
                "ema_difference": summary.get(
                    "ema_difference"
                ),
                "ema_separation_atr": summary.get(
                    "ema_separation_atr"
                ),
                "rsi_14": summary.get(
                    "rsi_14"
                ),
                "rsi_state": summary.get(
                    "momentum",
                    "unknown",
                ),
                "atr_14": summary.get(
                    "atr_14"
                ),
                "volume": summary.get(
                    "volume"
                ),
                "average_volume_20": summary.get(
                    "average_volume_20"
                ),
                "trend": summary.get(
                    "trend"
                ),
                "momentum": summary.get(
                    "momentum"
                ),
                "volume_condition": summary.get(
                    "volume_condition"
                ),
            }

        compact[
            "deterministic_technical_evidence"
        ] = technical_evidence

        # The cleaned summaries are also retained.
        compact[
            "timeframe_summaries"
        ] = technical_evidence

    # --------------------------------------------------------
    # STRUCTURE
    # --------------------------------------------------------

    if isinstance(
        evidence.get("structure"),
        dict,
    ):
        compact["structure"] = dict(
            evidence["structure"]
        )

    # --------------------------------------------------------
    # FUNDAMENTALS
    # --------------------------------------------------------

    fundamentals = evidence.get(
        "fundamentals"
    )

    if isinstance(
        fundamentals,
        dict,
    ):

        compact_fundamentals = dict(
            fundamentals
        )

        # ----------------------------------------------------
        # Preserve critical fundamental controls.
        # ----------------------------------------------------

        for key in (
            "available",
            "instrument",
            "mode",
            "direction",
            "strength",
            "confidence",
            "conflict",
            "bias",
            "actionable",
            "base_currency",
            "quote_currency",
            "pair",
            "reason",
        ):

            if key in fundamentals:

                compact_fundamentals[
                    key
                ] = fundamentals[key]

        # ----------------------------------------------------
        # Preserve currency summaries.
        # ----------------------------------------------------

        currency = fundamentals.get(
            "currency"
        )

        if isinstance(
            currency,
            dict,
        ):

            compact_currency = {}

            for (
                currency_name,
                currency_data,
            ) in currency.items():

                if not isinstance(
                    currency_data,
                    dict,
                ):

                    compact_currency[
                        currency_name
                    ] = currency_data

                    continue

                compact_currency[
                    currency_name
                ] = {
                    "overall_direction_score":
                        currency_data.get(
                            "overall_direction_score"
                        ),
                    "score":
                        currency_data.get(
                            "score"
                        ),
                    "overall_strength":
                        currency_data.get(
                            "overall_strength"
                        ),
                    "strength":
                        currency_data.get(
                            "strength"
                        ),
                    "state":
                        currency_data.get(
                            "state"
                        ),
                    "confidence":
                        currency_data.get(
                            "confidence"
                        ),
                    "conflict":
                        currency_data.get(
                            "conflict"
                        ),
                    "monetary_policy":
                        currency_data.get(
                            "monetary_policy"
                        ),
                }

            compact_fundamentals[
                "currency"
            ] = compact_currency

        # ----------------------------------------------------
        # Released events.
        # Keep only important metadata.
        # ----------------------------------------------------

        released_events = fundamentals.get(
            "released_events"
        )

        if isinstance(
            released_events,
            dict,
        ):

            compact_released = {}

            for (
                currency_name,
                events,
            ) in released_events.items():

                if not isinstance(
                    events,
                    list,
                ):
                    continue

                compact_events = []

                for event in events[:10]:

                    if not isinstance(
                        event,
                        dict,
                    ):
                        continue

                    compact_events.append(
                        {
                            key: event.get(key)
                            for key in (
                                "currency",
                                "title",
                                "event_type",
                                "impact",
                                "impact_normalized",
                                "release_status",
                                "datetime_utc",
                                "actual",
                                "forecast",
                                "previous",
                                "event_score",
                                "fundamental_interpretation",
                                "policy_signal",
                            )
                            if key in event
                        }
                    )

                compact_released[
                    currency_name
                ] = compact_events

            compact_fundamentals[
                "released_events"
            ] = compact_released

        # ----------------------------------------------------
        # Upcoming event risk.
        # ----------------------------------------------------

        upcoming_risk = fundamentals.get(
            "upcoming_event_risk"
        )

        if isinstance(
            upcoming_risk,
            dict,
        ):

            compact_risk = {}

            for key in (
                "risk_level",
                "high_count",
                "medium_count",
                "imminent_high_count",
                "imminent_medium_count",
                "three_hour_event_count",
                "clusters",
            ):

                if key in upcoming_risk:

                    compact_risk[
                        key
                    ] = upcoming_risk[key]

            upcoming_events = (
                upcoming_risk.get(
                    "upcoming_events"
                )
            )

            if isinstance(
                upcoming_events,
                list,
            ):

                compact_risk[
                    "upcoming_events"
                ] = []

                for event in upcoming_events[:10]:

                    if not isinstance(
                        event,
                        dict,
                    ):
                        continue

                    compact_risk[
                        "upcoming_events"
                    ].append(
                        {
                            key: event.get(key)
                            for key in (
                                "currency",
                                "title",
                                "impact",
                                "importance",
                                "minutes_to_release",
                                "datetime_utc",
                            )
                            if key in event
                        }
                    )

            compact_fundamentals[
                "upcoming_event_risk"
            ] = compact_risk

        # ----------------------------------------------------
        # Data quality.
        # ----------------------------------------------------

        data_quality = fundamentals.get(
            "data_quality"
        )

        if isinstance(
            data_quality,
            dict,
        ):

            compact_fundamentals[
                "data_quality"
            ] = dict(
                data_quality
            )

        compact[
            "fundamentals"
        ] = compact_fundamentals

    # --------------------------------------------------------
    # LIQUIDITY
    # --------------------------------------------------------

    liquidity = evidence.get(
        "liquidity"
    )

    if isinstance(
        liquidity,
        dict,
    ):

        compact_liquidity = dict(
            liquidity
        )

        if isinstance(
            liquidity.get("levels"),
            dict,
        ):

            compact_liquidity[
                "levels"
            ] = dict(
                liquidity["levels"]
            )

        if isinstance(
            liquidity.get("nearest_level"),
            dict,
        ):

            compact_liquidity[
                "nearest_level"
            ] = dict(
                liquidity[
                    "nearest_level"
                ]
            )

        if isinstance(
            liquidity.get("sweeps"),
            dict,
        ):

            compact_liquidity[
                "sweeps"
            ] = dict(
                liquidity[
                    "sweeps"
                ]
            )

        if isinstance(
            liquidity.get("data_quality"),
            dict,
        ):

            compact_liquidity[
                "data_quality"
            ] = dict(
                liquidity[
                    "data_quality"
                ]
            )

        if isinstance(
            liquidity.get("data_source"),
            dict,
        ):

            compact_liquidity[
                "data_source"
            ] = dict(
                liquidity[
                    "data_source"
                ]
            )

        compact[
            "liquidity"
        ] = compact_liquidity

    # --------------------------------------------------------
    # LEVELS
    # --------------------------------------------------------

    levels = evidence.get(
        "levels"
    )

    if isinstance(
        levels,
        dict,
    ):

        compact_levels = {}

        for key in (
            "support_count",
            "resistance_count",
            "current_price",
            "nearest_support_distance",
            "nearest_resistance_distance",
        ):

            if key in levels:

                compact_levels[
                    key
                ] = levels[key]

        for key in (
            "nearest_support",
            "nearest_resistance",
            "strongest_support",
            "strongest_resistance",
        ):

            value = levels.get(
                key
            )

            if isinstance(
                value,
                dict,
            ):

                item = dict(
                    value
                )

                item.pop(
                    "levels",
                    None
                )

                compact_levels[
                    key
                ] = item

            elif value is not None:

                compact_levels[
                    key
                ] = value

        compact[
            "levels"
        ] = compact_levels

    # --------------------------------------------------------
    # NEWS
    # --------------------------------------------------------

    news = evidence.get(
        "news"
    )

    if isinstance(
        news,
        dict,
    ):

        compact_news = dict(
            news
        )

        recent_items = news.get(
            "recent_items"
        )

        if isinstance(
            recent_items,
            list,
        ):

            compact_recent = []

            for item in recent_items[:5]:

                if not isinstance(
                    item,
                    dict,
                ):
                    continue

                compact_recent.append(
                    {
                        key: item.get(key)
                        for key in (
                            "title",
                            "publishedAt",
                            "categories",
                            "relevance",
                            "recent",
                            "high_impact",
                            "age_minutes",
                        )
                        if key in item
                    }
                )

            compact_news[
                "recent_items"
            ] = compact_recent

        compact[
            "news"
        ] = compact_news

    # --------------------------------------------------------
    # CORE EVIDENCE FIELDS
    # --------------------------------------------------------

    for key in (
        "evidence_bias",
        "confidence_state",
        "bullish_evidence",
        "bearish_evidence",
        "caution",
    ):

        if key in evidence:

            compact[
                key
            ] = evidence[key]

    return compact


# ============================================================
# EVIDENCE RULE HELPERS
# ============================================================

def _get_evidence_confidence(
    evidence,
):
    """
    Return normalized evidence confidence.
    """

    if not isinstance(
        evidence,
        dict,
    ):
        return "low"

    value = evidence.get(
        "confidence_state",
        "low",
    )

    return str(
        value
    ).strip().lower()


def _get_higher_timeframe_bias(
    evidence,
):
    """
    Return normalized higher timeframe bias.
    """

    market_state = {}

    if isinstance(
        evidence,
        dict,
    ):
        market_state = evidence.get(
            "market_state",
            {},
        )

    if not isinstance(
        market_state,
        dict,
    ):
        return "unknown"

    return str(
        market_state.get(
            "higher_timeframe_bias",
            "unknown",
        )
    ).strip().lower()


def _get_structure_type(
    evidence,
):
    """
    Return normalized market structure.
    """

    structure = {}

    if isinstance(
        evidence,
        dict,
    ):
        structure = evidence.get(
            "structure",
            {},
        )

    if not isinstance(
        structure,
        dict,
    ):
        return "unknown"

    return str(
        structure.get(
            "type",
            structure.get(
                "dominant_structure",
                "unknown",
            ),
        )
    ).strip().lower()


def _get_fundamental_status(
    evidence,
):
    """
    Return the fundamental control state.

    Returns:

        available
        actionable
        conflict
        confidence
        mode
        direction
    """

    fundamentals = {}

    if isinstance(
        evidence,
        dict,
    ):
        fundamentals = evidence.get(
            "fundamentals",
            {},
        )

    if not isinstance(
        fundamentals,
        dict,
    ):

        return {
            "available": False,
            "actionable": False,
            "conflict": False,
            "confidence": "none",
            "mode": "unavailable",
            "direction": "neutral",
        }

    return {
        "available": bool(
            fundamentals.get(
                "available",
                False,
            )
        ),
        "actionable": bool(
            fundamentals.get(
                "actionable",
                False,
            )
        ),
        "conflict": bool(
            fundamentals.get(
                "conflict",
                False,
            )
        ),
        "confidence": str(
            fundamentals.get(
                "confidence",
                "none",
            )
        ).strip().lower(),
        "mode": str(
            fundamentals.get(
                "mode",
                "unknown",
            )
        ).strip().lower(),
        "direction": str(
            fundamentals.get(
                "direction",
                "neutral",
            )
        ).strip().lower(),
    }


# ============================================================
# PYTHON EVIDENCE ENFORCEMENT
# ============================================================

def _enforce_evidence_rules(
    parsed,
    evidence,
):
    """
    Deterministic Python layer after Qwen.

    Qwen is allowed to analyze.

    Python is allowed to correct the decision.

    This prevents the local LLM from violating hard
    evidence rules.
    """

    if not isinstance(
        parsed,
        dict,
    ):

        raise RuntimeError(
            "AI response must be a JSON object."
        )

    result = dict(
        parsed
    )

    # --------------------------------------------------------
    # Ensure setup object exists.
    # --------------------------------------------------------

    setup = result.get(
        "setup"
    )

    if not isinstance(
        setup,
        dict,
    ):
        setup = {}

    setup = dict(
        setup
    )

    # --------------------------------------------------------
    # Ensure arrays exist.
    # --------------------------------------------------------

    conflicts = result.get(
        "conflicts"
    )

    if not isinstance(
        conflicts,
        list,
    ):
        conflicts = []

    conflicts = [
        str(item)
        for item in conflicts
    ]

    missing_information = (
        result.get(
            "missing_information"
        )
    )

    if not isinstance(
        missing_information,
        list,
    ):
        missing_information = []

    missing_information = [
        str(item)
        for item in missing_information
    ]

    # --------------------------------------------------------
    # Normalize decision.
    # --------------------------------------------------------

    decision = str(
        result.get(
            "decision",
            "NO_TRADE",
        )
    ).strip().upper()

    if decision not in {
        "BUY_CANDIDATE",
        "SELL_CANDIDATE",
        "WAIT",
        "NO_TRADE",
    }:

        decision = "NO_TRADE"

        conflicts.append(
            "AI returned an invalid decision."
        )

    # --------------------------------------------------------
    # Normalize confidence.
    # --------------------------------------------------------

    confidence = str(
        result.get(
            "confidence",
            "low",
        )
    ).strip().lower()

    if confidence not in {
        "high",
        "medium",
        "low",
    }:

        confidence = "low"

        conflicts.append(
            "AI returned an invalid confidence level."
        )

    # --------------------------------------------------------
    # READ EVIDENCE
    # --------------------------------------------------------

    evidence_confidence = (
        _get_evidence_confidence(
            evidence
        )
    )

    higher_bias = (
        _get_higher_timeframe_bias(
            evidence
        )
    )

    structure_type = (
        _get_structure_type(
            evidence
        )
    )

    fundamental_status = (
        _get_fundamental_status(
            evidence
        )
    )

    # ========================================================
    # HARD RULE 1
    # LOW EVIDENCE CONFIDENCE
    # ========================================================

    if evidence_confidence == "low":

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            conflicts.append(
                "Python safety enforcement: "
                "evidence confidence is low."
            )

        decision = "WAIT"

        confidence = "low"

        setup = {
            "direction": "NONE",
            "quality": "LOW",
        }

    # ========================================================
    # HARD RULE 2
    # MIXED HIGHER TIMEFRAME
    # ========================================================

    elif higher_bias == "mixed":

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            conflicts.append(
                "Python safety enforcement: "
                "higher timeframe bias is mixed."
            )

        decision = "WAIT"

        setup = {
            "direction": "NONE",
            "quality": "LOW",
        }

    # ========================================================
    # HARD RULE 3
    # MIXED / UNKNOWN STRUCTURE
    # ========================================================

    elif structure_type in {
        "mixed",
        "unknown",
        "unclear",
    }:

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            conflicts.append(
                "Python safety enforcement: "
                "market structure is mixed or unclear."
            )

        decision = "WAIT"

        setup = {
            "direction": "NONE",
            "quality": "LOW",
        }

    # ========================================================
    # HARD RULE 4
    # FUNDAMENTAL CONFLICT
    # ========================================================

    if fundamental_status["conflict"]:

        if fundamental_status["mode"] != (
            "inverse_usd_context"
        ):

            if decision in {
                "BUY_CANDIDATE",
                "SELL_CANDIDATE",
            }:

                conflicts.append(
                    "Fundamental evidence is conflicting."
                )

                decision = "WAIT"

                setup = {
                    "direction": "NONE",
                    "quality": "LOW",
                }

    # ========================================================
    # HARD RULE 5
    # FX FUNDAMENTAL NON-ACTIONABLE
    # ========================================================

    if (
        fundamental_status["available"]
        and not fundamental_status["actionable"]
        and fundamental_status["mode"]
        not in {
            "inverse_usd_context",
            "context_only",
        }
    ):

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            conflicts.append(
                "Fundamental evidence is "
                "not actionable."
            )

            decision = "WAIT"

            setup = {
                "direction": "NONE",
                "quality": "LOW",
            }

    # ========================================================
    # FINAL DECISION / SETUP CONSISTENCY
    # ========================================================

    if decision in {
        "WAIT",
        "NO_TRADE",
    }:

        setup = {
            "direction": "NONE",
            "quality": "LOW",
        }

    elif decision == "BUY_CANDIDATE":

        setup_direction = str(
            setup.get(
                "direction",
                "NONE",
            )
        ).upper()

        setup_quality = str(
            setup.get(
                "quality",
                "LOW",
            )
        ).upper()

        if setup_direction != "BUY":

            conflicts.append(
                "BUY_CANDIDATE had inconsistent "
                "setup direction."
            )

            decision = "WAIT"

            setup = {
                "direction": "NONE",
                "quality": "LOW",
            }

        elif setup_quality not in {
            "HIGH",
            "MODERATE",
        }:

            conflicts.append(
                "BUY_CANDIDATE had insufficient "
                "setup quality."
            )

            decision = "WAIT"

            setup = {
                "direction": "NONE",
                "quality": "LOW",
            }

    elif decision == "SELL_CANDIDATE":

        setup_direction = str(
            setup.get(
                "direction",
                "NONE",
            )
        ).upper()

        setup_quality = str(
            setup.get(
                "quality",
                "LOW",
            )
        ).upper()

        if setup_direction != "SELL":

            conflicts.append(
                "SELL_CANDIDATE had inconsistent "
                "setup direction."
            )

            decision = "WAIT"

            setup = {
                "direction": "NONE",
                "quality": "LOW",
            }

        elif setup_quality not in {
            "HIGH",
            "MODERATE",
        }:

            conflicts.append(
                "SELL_CANDIDATE had insufficient "
                "setup quality."
            )

            decision = "WAIT"

            setup = {
                "direction": "NONE",
                "quality": "LOW",
            }

    # ========================================================
    # FINAL CONFIDENCE
    # ========================================================

    if (
        evidence_confidence == "low"
        or decision == "WAIT"
    ):

        confidence = "low"

    # ========================================================
    # FINALIZE
    # ========================================================

    result["decision"] = decision

    result["confidence"] = confidence

    result["setup"] = setup

    result["conflicts"] = conflicts

    result[
        "missing_information"
    ] = missing_information

    return result


# ============================================================
# SAFE FALLBACK
# ============================================================

def _safe_wait_result(reason, symbol="UNKNOWN"):
    """
    Deterministic safe fallback when the local LLM cannot return
    a valid structured response.
    """

    return {
        "market": str(symbol).upper() if symbol else "UNKNOWN",
        "bias": "unknown",
        "confidence": "low",
        "decision": "WAIT",
        "setup": {
            "direction": "NONE",
            "quality": "LOW",
        },
        "conflicts": [
            str(reason),
        ],
        "missing_information": [
            "Valid structured AI response was unavailable.",
        ],
        "reasoning": (
            "The AI response could not be parsed safely. "
            "The system therefore defaults to WAIT."
        ),
    }


# ============================================================
# OLLAMA JSON PARSER
# ============================================================

def _parse_ollama_json(content):
    """
    Parse Ollama's structured response robustly.
    """

    if not isinstance(
        content,
        str,
    ):
        raise RuntimeError(
            "Ollama response content must be text."
        )

    content = content.strip()

    if not content:
        raise RuntimeError(
            "Ollama returned an empty response."
        )

    try:
        parsed = json.loads(
            content
        )
    except json.JSONDecodeError:
        parsed = None

    if isinstance(
        parsed,
        str,
    ):

        try:
            parsed = json.loads(
                parsed
            )
        except json.JSONDecodeError:
            parsed = None

    if isinstance(
        parsed,
        dict,
    ):
        return parsed

    # Markdown fenced JSON fallback.
    if "```json" in content:

        start = (
            content.find(
                "```json"
            )
            + len(
                "```json"
            )
        )

        end = content.find(
            "```",
            start,
        )

        if end != -1:

            candidate = (
                content[start:end]
                .strip()
            )

            try:
                parsed = json.loads(
                    candidate
                )
            except json.JSONDecodeError:
                parsed = None

            if isinstance(
                parsed,
                str,
            ):

                try:
                    parsed = json.loads(
                        parsed
                    )
                except json.JSONDecodeError:
                    parsed = None

            if isinstance(
                parsed,
                dict,
            ):
                return parsed

    # Generic object fallback.
    start = content.find(
        "{"
    )

    end = content.rfind(
        "}"
    )

    if (
        start != -1
        and end > start
    ):

        candidate = (
            content[start:end + 1]
            .strip()
        )

        try:
            parsed = json.loads(
                candidate
            )
        except json.JSONDecodeError:
            parsed = None

        if isinstance(
            parsed,
            dict,
        ):
            return parsed

    raise RuntimeError(
        "Ollama returned invalid or truncated JSON."
    )


# ============================================================
# OLLAMA REQUEST
# ============================================================

def _call_ollama_json(
    system_instruction,
    evidence_json,
    compact_retry=False,
):
    """
    Make one Ollama request.
    """

    if compact_retry:

        user_instruction = (
            "Analyze the supplied market evidence.\n"
            "The deterministic technical evidence is authoritative.\n"
            "Copy EMA relationships, RSI states, trends and volume "
            "states exactly as supplied.\n"
            "Do not reverse any timeframe or indicator.\n"
            "Return ONLY the required JSON object.\n"
            "Do not explain outside JSON.\n"
            "Keep every string concise.\n"
            "The reasoning field must be one concise but factual "
            "sentence.\n"
            "The conflicts and missing_information arrays should "
            "contain only essential items.\n\n"
            + evidence_json
        )

        num_predict = 500

    else:

        user_instruction = (
            "Analyze the supplied market evidence and return the required "
            "structured response.\n"
            "The deterministic technical evidence is authoritative.\n"
            "Copy technical facts exactly as supplied.\n"
            "Never reverse EMA20/EMA50 relationships.\n"
            "Never assign a technical state to the wrong timeframe.\n"
            "Return ONLY the JSON object. Do not include markdown "
            "or additional commentary.\n\n"
            + evidence_json
        )

        num_predict = 600

    payload = {
        "model": MODEL,

        "messages": [
            {
                "role": "system",
                "content": system_instruction,
            },
            {
                "role": "user",
                "content": user_instruction,
            },
        ],

        "stream": False,

        "think": False,

        "format": AI_SCHEMA,

        "options": {
            "temperature": 0,
            "num_ctx": 4096,
            "num_predict": num_predict,
            "top_k": 20,
            "top_p": 0.8,
        },

        "keep_alive": "10m",
    }

    response = requests.post(
        OLLAMA_URL,
        json=payload,
        timeout=HAFNOT_OLLAMA_TIMEOUT,
    )

    response.raise_for_status()

    data = response.json()

    message = data.get(
        "message",
        {},
    )

    if not isinstance(
        message,
        dict,
    ):
        raise RuntimeError(
            "Ollama returned an invalid message object."
        )

    content = message.get(
        "content",
        "",
    )

    return _parse_ollama_json(
        content
    )


# ============================================================
# REASONING QUALITY VALIDATION
# ============================================================

def _validate_reasoning_quality(
    ai_decision,
):
    """
    Deterministic quality check for AI reasoning.

    The AI remains advisory.
    This function never creates a trade decision.
    Invalid reasoning fails closed.
    """

    if not isinstance(
        ai_decision,
        dict,
    ):

        return {
            "valid": False,
            "reason": (
                "AI response is not a dictionary."
            ),
        }

    reasoning = ai_decision.get(
        "reasoning"
    )

    if not isinstance(
        reasoning,
        str,
    ):

        return {
            "valid": False,
            "reason": (
                "AI reasoning is not a string."
            ),
        }

    reasoning = reasoning.strip()

    if len(reasoning) < 40:

        return {
            "valid": False,
            "reason": (
                "AI reasoning is too short."
            ),
        }

    normalized = reasoning.lower()

    meaningless = {
        "",
        "n/a",
        "na",
        "none",
        "unknown",
        "no reasoning",
        "no additional reasoning",
        "not applicable",
    }

    if normalized in meaningless:

        return {
            "valid": False,
            "reason": (
                "AI reasoning is empty or meaningless."
            ),
        }

    return {
        "valid": True,
        "reason": (
            "AI reasoning quality passed."
        ),
    }


# ============================================================
# MAIN OLLAMA ANALYSIS
# ============================================================

def analyze_with_ollama(
    system_instruction,
    evidence,
    symbol="UNKNOWN",
):

    ai_evidence = _prepare_ai_evidence(
        evidence
    )

    evidence_json = json.dumps(
        ai_evidence,
        ensure_ascii=False,
        separators=(
            ",",
            ":",
        ),
    )

    # ========================================================
    # FIRST ATTEMPT
    # ========================================================

    try:

        parsed = _call_ollama_json(
            system_instruction,
            evidence_json,
            compact_retry=False,
        )

    except (
        RuntimeError,
        requests.RequestException,
    ) as first_error:

        # ====================================================
        # SECOND ATTEMPT
        # ====================================================

        try:

            parsed = _call_ollama_json(
                system_instruction,
                evidence_json,
                compact_retry=True,
            )

        except (
            RuntimeError,
            requests.RequestException,
        ) as second_error:

            # =================================================
            # FAIL CLOSED
            # =================================================

            fallback_reason = (
                "Ollama structured-response failure after retry. "
                f"First error: {first_error}. "
                f"Retry error: {second_error}."
            )

            return _enforce_evidence_rules(
                _safe_wait_result(
                    fallback_reason,
                    symbol,
                ),
                evidence,
            )

    # ========================================================
    # SYMBOL AUTHORITY
    # ========================================================
    #
    # The requested market is authoritative.
    # Ollama must never be allowed to relabel the decision.
    #
    if isinstance(parsed, dict):
        parsed["market"] = (
            str(symbol).upper()
            if symbol
            else "UNKNOWN"
        )

    # ========================================================
    # PYTHON SAFETY ENFORCEMENT
    # ========================================================

    # Qwen proposes.
    #
    # Python checks.
    #
    # Python has final authority.

    parsed = _enforce_evidence_rules(
        parsed,
        evidence,
    )

    # ========================================================
    # REASONING QUALITY ENFORCEMENT
    # ========================================================

    reasoning_check = _validate_reasoning_quality(
        parsed
    )

    if not reasoning_check.get(
        "valid",
        False,
    ):

        return _enforce_evidence_rules(
            _safe_wait_result(
                reasoning_check.get(
                    "reason",
                    "AI reasoning quality check failed.",
                ),
                symbol,
            ),
            evidence,
        )

    return parsed


# ============================================================
# LEGACY JSON EXTRACTOR
# ============================================================

def extract_json(
    text,
):

    text = text.strip()

    # --------------------------------------------------------
    # Direct JSON
    # --------------------------------------------------------

    try:

        return json.loads(
            text
        )

    except json.JSONDecodeError:

        pass

    # --------------------------------------------------------
    # Markdown JSON fallback
    # --------------------------------------------------------

    if "```json" in text:

        start = (
            text.find(
                "```json"
            )
            + len(
                "```json"
            )
        )

        end = text.find(
            "```",
            start,
        )

        if end != -1:

            candidate = (
                text[start:end]
                .strip()
            )

            try:

                return json.loads(
                    candidate
                )

            except json.JSONDecodeError:

                pass

    # --------------------------------------------------------
    # Generic JSON object fallback
    # --------------------------------------------------------

    start = text.find(
        "{"
    )

    end = text.rfind(
        "}"
    )

    if (
        start != -1
        and end != -1
        and end > start
    ):

        candidate = (
            text[start:end + 1]
            .strip()
        )

        try:

            return json.loads(
                candidate
            )

        except json.JSONDecodeError:

            pass

    raise ValueError(
        "Qwen response did not contain valid JSON."
    )


# HAFNOT_BOUNDED_OLLAMA
# Ollama calls are intentionally bounded so an unavailable,
# overloaded, or non-responsive local model cannot stall the
# complete multi-symbol trading cycle for many minutes.
