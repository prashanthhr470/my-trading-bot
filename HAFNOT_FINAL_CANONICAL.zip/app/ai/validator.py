# ============================================================
# AI DECISION VALIDATOR
# ============================================================

import json


# ============================================================
# ALLOWED VALUES
# ============================================================

VALID_DECISIONS = {
    "BUY_CANDIDATE",
    "SELL_CANDIDATE",
    "WAIT",
    "NO_TRADE",
}

VALID_BIASES = {
    "bullish",
    "bearish",
    "mixed",
    "unknown",
}

VALID_CONFIDENCE = {
    "high",
    "medium",
    "low",
}

VALID_DIRECTIONS = {
    "BUY",
    "SELL",
    "NONE",
}

VALID_QUALITY = {
    "HIGH",
    "MODERATE",
    "LOW",
}


# ============================================================
# VALIDATOR
# ============================================================

def validate_ai_decision(
    ai_decision,
    evidence,
    expected_symbol=None,
):
    """
    Deterministic validation of the AI response.

    The AI is NOT trusted.

    Python independently checks:

        - Schema
        - Allowed values
        - Decision consistency
        - Evidence consistency
        - Confidence
        - Market state
        - Setup direction
        - Setup quality

    This function does NOT place trades.
    """

    errors = []
    warnings = []


    # ========================================================
    # 1. BASIC TYPE CHECK
    # ========================================================

    if not isinstance(
        ai_decision,
        dict,
    ):

        return {
            "valid": False,
            "errors": [
                "AI response is not a JSON object."
            ],
            "warnings": [],
            "decision": "NO_TRADE",
        }


    # ========================================================
    # 2. REQUIRED FIELDS
    # ========================================================

    required_fields = [
        "market",
        "bias",
        "confidence",
        "decision",
        "setup",
        "conflicts",
        "missing_information",
        "reasoning",
    ]

    for field in required_fields:

        if field not in ai_decision:

            errors.append(
                f"Missing required field: {field}"
            )


    if errors:

        return {
            "valid": False,
            "errors": errors,
            "warnings": warnings,
            "decision": "NO_TRADE",
        }


    # ========================================================
    # 3. MARKET
    # ========================================================
    market = ai_decision.get(
        "market"
    )

    # ========================================================
    # SYMBOL AUTHORITY
    # ========================================================
    # The actual pipeline symbol is authoritative.
    # AI must return the same market that Python requested.

    if not expected_symbol:

        errors.append(
            "Expected market symbol was not supplied."
        )

    else:

        expected_market = str(
            expected_symbol
        ).strip().upper()

        actual_market = (
            str(market).strip().upper()
            if market is not None
            else ""
        )

        if not actual_market:

            errors.append(
                "AI response market is missing."
            )

        elif actual_market != expected_market:

            errors.append(
                f"Invalid market: {market}; "
                f"expected: {expected_market}"
            )


    # ========================================================
    # 4. BIAS
    # ========================================================

    bias = ai_decision.get(
        "bias"
    )

    if bias not in VALID_BIASES:

        errors.append(
            f"Invalid bias: {bias}"
        )


    # ========================================================
    # 5. CONFIDENCE
    # ========================================================

    confidence = ai_decision.get(
        "confidence"
    )

    if confidence not in VALID_CONFIDENCE:

        errors.append(
            f"Invalid confidence: {confidence}"
        )


    # ========================================================
    # 6. DECISION
    # ========================================================

    decision = ai_decision.get(
        "decision"
    )

    if decision not in VALID_DECISIONS:

        errors.append(
            f"Invalid decision: {decision}"
        )


    # ========================================================
    # 7. SETUP
    # ========================================================

    setup = ai_decision.get(
        "setup"
    )

    if not isinstance(
        setup,
        dict,
    ):

        errors.append(
            "setup must be an object."
        )

        setup = {}


    setup_direction = setup.get(
        "direction"
    )

    setup_quality = setup.get(
        "quality"
    )


    if setup_direction not in VALID_DIRECTIONS:

        errors.append(
            f"Invalid setup direction: "
            f"{setup_direction}"
        )


    if setup_quality not in VALID_QUALITY:

        errors.append(
            f"Invalid setup quality: "
            f"{setup_quality}"
        )


    # ========================================================
    # 8. ARRAY FIELDS
    # ========================================================

    conflicts = ai_decision.get(
        "conflicts"
    )

    missing_information = ai_decision.get(
        "missing_information"
    )


    if not isinstance(
        conflicts,
        list,
    ):

        errors.append(
            "conflicts must be an array."
        )

        conflicts = []


    if not isinstance(
        missing_information,
        list,
    ):

        errors.append(
            "missing_information must be an array."
        )

        missing_information = []


    # ========================================================
    # 9. REASONING
    # ========================================================

    reasoning = ai_decision.get(
        "reasoning"
    )

    if not isinstance(
        reasoning,
        str,
    ):

        errors.append(
            "reasoning must be a string."
        )

    elif not reasoning.strip():

        warnings.append(
            "AI reasoning is empty."
        )


    # ========================================================
    # STOP IF BASIC SCHEMA INVALID
    # ========================================================

    if errors:

        return {
            "valid": False,
            "errors": errors,
            "warnings": warnings,
            "decision": "NO_TRADE",
        }


    # ========================================================
    # 10. EXTRACT MARKET EVIDENCE
    # ========================================================

    if not isinstance(
        evidence,
        dict,
    ):

        return {
            "valid": False,
            "errors": [
                "Market evidence is not a JSON object."
            ],
            "warnings": warnings,
            "decision": "NO_TRADE",
        }


    market_state = evidence.get(
        "market_state",
        {},
    )

    if not isinstance(
        market_state,
        dict,
    ):

        market_state = {}


    evidence_bias = evidence.get(
        "evidence_bias",
        "unknown",
    )

    evidence_confidence = evidence.get(
        "confidence_state",
        "low",
    )

    higher_bias = market_state.get(
        "higher_timeframe_bias",
        "unknown",
    )

    lower_bias = market_state.get(
        "lower_timeframe_bias",
        "unknown",
    )

    overall_bias = market_state.get(
        "overall_bias",
        "unknown",
    )


    structure = evidence.get(
        "structure",
        {},
    )

    if not isinstance(
        structure,
        dict,
    ):

        structure = {}


    structure_type = structure.get(
        "type",
        "unknown",
    )


    # ========================================================
    # 11. LOW CONFIDENCE CHECK
    # ========================================================

    if evidence_confidence == "low":

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            errors.append(
                "AI proposed a trade while "
                "evidence confidence is low."
            )


    # ========================================================
    # 12. HIGHER TIMEFRAME CONFLICT
    # ========================================================

    if higher_bias == "mixed":

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            errors.append(
                "AI proposed a trade while "
                "higher timeframe bias is mixed."
            )


    # ========================================================
    # 13. STRUCTURE CONFLICT
    # ========================================================

    if structure_type == "mixed":

        if decision in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            errors.append(
                "AI proposed a trade while "
                "market structure is mixed."
            )


    # ========================================================
    # 14. BUY CONSISTENCY
    # ========================================================

    if decision == "BUY_CANDIDATE":

        if bias != "bullish":

            errors.append(
                "BUY_CANDIDATE requires "
                "bullish AI bias."
            )


        if setup_direction != "BUY":

            errors.append(
                "BUY_CANDIDATE requires "
                "setup direction BUY."
            )


        if setup_quality not in {
            "HIGH",
            "MODERATE",
        }:

            errors.append(
                "BUY_CANDIDATE requires "
                "HIGH or MODERATE setup quality."
            )


        if overall_bias == "bearish":

            errors.append(
                "BUY_CANDIDATE conflicts with "
                "bearish overall market bias."
            )


        if lower_bias == "bearish":

            errors.append(
                "BUY_CANDIDATE conflicts with "
                "bearish lower timeframe bias."
            )


    # ========================================================
    # 15. SELL CONSISTENCY
    # ========================================================

    if decision == "SELL_CANDIDATE":

        if bias != "bearish":

            errors.append(
                "SELL_CANDIDATE requires "
                "bearish AI bias."
            )


        if setup_direction != "SELL":

            errors.append(
                "SELL_CANDIDATE requires "
                "setup direction SELL."
            )


        if setup_quality not in {
            "HIGH",
            "MODERATE",
        }:

            errors.append(
                "SELL_CANDIDATE requires "
                "HIGH or MODERATE setup quality."
            )


        if overall_bias == "bullish":

            errors.append(
                "SELL_CANDIDATE conflicts with "
                "bullish overall market bias."
            )


        if lower_bias == "bullish":

            errors.append(
                "SELL_CANDIDATE conflicts with "
                "bullish lower timeframe bias."
            )


    # ========================================================
    # 16. WAIT CONSISTENCY
    # ========================================================

    if decision == "WAIT":

        if setup_direction != "NONE":

            errors.append(
                "WAIT requires setup direction NONE."
            )


        if setup_quality != "LOW":

            errors.append(
                "WAIT requires setup quality LOW."
            )


    # ========================================================
    # 17. NO TRADE CONSISTENCY
    # ========================================================

    if decision == "NO_TRADE":

        if setup_direction != "NONE":

            errors.append(
                "NO_TRADE requires setup direction NONE."
            )


        if setup_quality != "LOW":

            errors.append(
                "NO_TRADE requires setup quality LOW."
            )


    # ========================================================
    # 18. BIAS / EVIDENCE CONSISTENCY
    # ========================================================

    if (
        evidence_bias in {
            "bullish",
            "bearish",
        }

        and bias in {
            "bullish",
            "bearish",
        }

        and evidence_bias != bias
    ):

        warnings.append(
            "AI bias differs from evidence bias."
        )


    # ========================================================
    # 19. CONFIDENCE CONSISTENCY
    # ========================================================

    if (
        evidence_confidence == "low"
        and confidence != "low"
    ):

        warnings.append(
            "AI confidence is higher than "
            "the evidence confidence."
        )


    # ========================================================
    # 20. FINAL RESULT
    # ========================================================

    valid = (
        len(errors) == 0
    )


    if not valid:

        final_decision = "NO_TRADE"

    else:

        final_decision = decision


    return {
        "valid": valid,
        "errors": errors,
        "warnings": warnings,
        "decision": final_decision,
        "ai_decision": ai_decision,
    }


# ============================================================
# DISPLAY HELPER
# ============================================================

def print_validation_result(
    result,
):
    """
    Pretty-print validator result.
    """

    print(
        "\n========== AI VALIDATION =========="
    )


    if result["valid"]:

        print(
            "VALIDATION: PASSED"
        )

    else:

        print(
            "VALIDATION: FAILED"
        )


    print(
        "Final validator decision:",
        result["decision"],
    )


    # ========================================================
    # ERRORS
    # ========================================================

    if result["errors"]:

        print(
            "\nERRORS:"
        )

        for error in result["errors"]:

            print(
                f"  [ERROR] {error}"
            )

    else:

        print(
            "\nERRORS:"
        )

        print(
            "  None"
        )


    # ========================================================
    # WARNINGS
    # ========================================================

    if result["warnings"]:

        print(
            "\nWARNINGS:"
        )

        for warning in result["warnings"]:

            print(
                f"  [WARNING] {warning}"
            )

    else:

        print(
            "\nWARNINGS:"
        )

        print(
            "  None"
        )


# ============================================================
# OPTIONAL JSON DISPLAY HELPER
# ============================================================

def validation_result_to_json(
    result,
):
    """
    Convert validator result into formatted JSON.
    """

    return json.dumps(
        result,
        indent=2,
        ensure_ascii=False,
    )