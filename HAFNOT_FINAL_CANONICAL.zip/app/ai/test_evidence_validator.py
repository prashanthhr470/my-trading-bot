from app.ai.evidence_validator import (
    validate_ai_evidence_consistency,
)


def test_rsi_40_is_not_oversold():
    evidence = {
        "timeframe_summaries": {
            "H4": {
                "rsi_14": 40.41177878860433,
                "ema_20": 4402.15,
                "ema_50": 4461.10,
                "trend": "bearish",
                "volume_condition": "below_average",
            }
        }
    }

    ai = {
        "reasoning": (
            "The H4 RSI is 40.41 and indicates an oversold "
            "condition while the broader trend remains bearish."
        )
    }

    result = validate_ai_evidence_consistency(
        evidence=evidence,
        ai_decision=ai,
    )

    assert result["valid"] is False
    assert result["status"] == "BLOCKED"
    assert result["high_severity_count"] >= 1


def test_correct_rsi_passes():
    evidence = {
        "timeframe_summaries": {
            "H4": {
                "rsi_14": 40.41177878860433,
                "ema_20": 4402.15,
                "ema_50": 4461.10,
                "trend": "bearish",
                "volume_condition": "below_average",
            }
        }
    }

    ai = {
        "reasoning": (
            "The H4 RSI is 40.41 and remains neutral, while the "
            "EMA structure indicates a bearish trend."
        )
    }

    result = validate_ai_evidence_consistency(
        evidence=evidence,
        ai_decision=ai,
    )

    assert result["valid"] is True
    assert result["status"] == "PASSED"


if __name__ == "__main__":
    test_rsi_40_is_not_oversold()
    test_correct_rsi_passes()

    print("EVIDENCE VALIDATOR TESTS PASSED")
