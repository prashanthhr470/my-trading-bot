from __future__ import annotations

from typing import Any, Dict


def build_ai_evidence(
    *,
    symbol: str,
    intelligence: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Build a clean, deterministic evidence package for the AI.

    The AI receives:
    - market regime
    - technical timeframe summaries
    - structure
    - liquidity
    - sentiment
    - fundamentals
    - news
    - confluence
    - setup
    - data quality

    Technical timeframe wrappers are flattened so the AI sees the
    actual indicator summary instead of unnecessary transport metadata.
    """

    regime = intelligence.get("regime") or {}
    context = intelligence.get("context") or {}
    confluence = intelligence.get("confluence") or {}
    setup = intelligence.get("setup") or {}
    sentiment = intelligence.get("sentiment") or {}
    data_quality = intelligence.get("data_quality") or {}
    orderflow = intelligence.get("orderflow") or intelligence.get("order_flow") or {}
    depth = intelligence.get("depth") or {}
    structure = intelligence.get("structure") or context.get("structure") or {}
    liquidity = intelligence.get("liquidity") or context.get("liquidity") or {}
    fundamentals = intelligence.get("fundamentals") or context.get("fundamentals") or {}
    news = intelligence.get("news") or context.get("news") or {}
    deterministic_technical_evidence = intelligence.get("evidence") or context.get("evidence") or {}

    # ------------------------------------------------------------
    # TIMEFRAME TECHNICAL EVIDENCE
    # ------------------------------------------------------------

    timeframe_summaries = intelligence.get(
        "timeframe_summaries",
        {},
    )

    if not isinstance(timeframe_summaries, dict):
        timeframe_summaries = {}

    clean_timeframe_summaries: Dict[str, Dict[str, Any]] = {}

    for timeframe, summary in timeframe_summaries.items():

        if not isinstance(summary, dict):
            continue

        # AgentRuntime currently stores timeframe data like:
        #
        # {
        #     "timeframe": "H4",
        #     "available": True,
        #     "bar_count": 168,
        #     "indicator_rows": 119,
        #     "summary": {
        #         ...
        #     }
        # }
        #
        # The AI should receive the actual technical summary.

        nested_summary = summary.get("summary")

        if isinstance(nested_summary, dict):
            clean_timeframe_summaries[
                str(timeframe).upper()
            ] = nested_summary

        else:
            # Support already-clean timeframe summaries.
            clean_timeframe_summaries[
                str(timeframe).upper()
            ] = summary

    # ------------------------------------------------------------
    # MARKET STATE
    # ------------------------------------------------------------

    market_state = {
        "regime": regime.get(
            "regime",
            "UNKNOWN",
        ),
        "direction": regime.get(
            "direction",
            "neutral",
        ),
        "confidence": regime.get(
            "confidence",
            "low",
        ),
        "volatility": regime.get(
            "volatility",
            "unknown",
        ),
        "bullish_timeframes": regime.get(
            "bullish_timeframes",
            0,
        ),
        "bearish_timeframes": regime.get(
            "bearish_timeframes",
            0,
        ),
        "known_timeframes": regime.get(
            "known_timeframes",
            0,
        ),
        "timeframes": regime.get(
            "timeframes",
            {},
        ),
    }

    # ------------------------------------------------------------
    # FINAL AI EVIDENCE
    # ------------------------------------------------------------

    return {
        "symbol": symbol,

        "market_state": market_state,

        "structure": context.get(
            "structure",
            {},
        ),

        "liquidity": context.get(
            "liquidity",
            {},
        ),

        "sentiment": sentiment,

        "fundamentals": context.get(
            "fundamentals",
            {},
        ),

        "news": context.get(
            "news",
            {},
        ),

        "confluence": confluence,

        "setup": setup,

        "data_quality": data_quality,

        "orderflow": orderflow,
        "order_flow": orderflow,
        "depth": depth,
        "deterministic_technical_evidence": deterministic_technical_evidence,
        "structure": structure,
        "liquidity": liquidity,
        "fundamentals": fundamentals,
        "news": news,

        "timeframe_summaries": clean_timeframe_summaries,
    }


def normalize_ai_result(
    result: Any,
) -> Dict[str, Any]:
    """
    Normalize AI output into a dictionary.

    Handles:
    - normal dictionaries
    - JSON strings
    - double-encoded JSON strings

    Invalid responses fail closed into NO_TRADE.
    """

    # ------------------------------------------------------------
    # ALREADY A PROPER OBJECT
    # ------------------------------------------------------------

    if isinstance(result, dict):
        return result

    # ------------------------------------------------------------
    # JSON STRING
    # ------------------------------------------------------------

    if isinstance(result, str):

        import json

        try:
            parsed = json.loads(result)

        except json.JSONDecodeError:
            parsed = None

        if isinstance(parsed, dict):
            return parsed

        # --------------------------------------------------------
        # DOUBLE-ENCODED JSON
        # --------------------------------------------------------

        if isinstance(parsed, str):

            try:
                parsed = json.loads(parsed)

            except json.JSONDecodeError:
                parsed = None

            if isinstance(parsed, dict):
                return parsed

    # ------------------------------------------------------------
    # FAIL CLOSED
    # ------------------------------------------------------------

    return {
        "market": "UNKNOWN",

        "bias": "unknown",

        "confidence": "low",

        "decision": "NO_TRADE",

        "setup": {
            "direction": "NONE",
            "quality": "LOW",
        },

        "conflicts": [
            "AI response could not be normalized.",
        ],

        "missing_information": [
            "Valid structured AI response.",
        ],

        "reasoning": (
            "AI response was invalid; "
            "system failed closed."
        ),
    }


def _safe_wait_decision(
    *,
    symbol: str,
    reason: str,
) -> Dict[str, Any]:
    """
    Create a deterministic safe WAIT decision.

    This function is used whenever AI reasoning contradicts
    deterministic evidence.
    """

    return {
        "market": symbol,

        "bias": "unknown",

        "confidence": "low",

        "decision": "WAIT",

        "setup": {
            "direction": "NONE",
            "quality": "LOW",
        },

        "conflicts": [
            reason,
        ],

        "missing_information": [],

        "reasoning": (
            "The AI reasoning failed deterministic evidence "
            "consistency validation. The system therefore "
            "failed closed and selected WAIT."
        ),
    }


def run_ai_reasoning(
    *,
    symbol: str,
    intelligence: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Run the complete AI reasoning stage.

    Pipeline:

        Intelligence
            ↓
        AI Evidence
            ↓
        Ollama
            ↓
        AI normalization
            ↓
        AI schema validator
            ↓
        Deterministic evidence validator
            ↓
        Decision gate
            ↓
        Final read-only result

    This function NEVER authorizes or executes a broker trade.
    """

    from app.ai.provider import (
        SYSTEM_INSTRUCTION,
        analyze_with_ollama,
    )

    from app.ai.validator import (
        validate_ai_decision,
    )

    from app.ai.decision_gate import (
        apply_decision_gate,
    )

    from app.ai.evidence_validator import (
        validate_ai_evidence_consistency,
    )

    # ------------------------------------------------------------
    # BUILD AI EVIDENCE
    # ------------------------------------------------------------

    evidence = build_ai_evidence(
        symbol=symbol,
        intelligence=intelligence,
    )

    # ------------------------------------------------------------
    # AI PROPOSAL
    # ------------------------------------------------------------

    try:

        raw_ai_decision = analyze_with_ollama(
            SYSTEM_INSTRUCTION,
            evidence,
            symbol=symbol,
        )

    except Exception as exc:

        raw_ai_decision = {
            "market": symbol,

            "bias": "unknown",

            "confidence": "low",

            "decision": "NO_TRADE",

            "setup": {
                "direction": "NONE",
                "quality": "LOW",
            },

            "conflicts": [
                "AI reasoning failed.",
            ],

            "missing_information": [
                "Valid AI reasoning response.",
            ],

            "reasoning": (
                f"AI reasoning failed: "
                f"{type(exc).__name__}: {exc}"
            ),
        }

    # ------------------------------------------------------------
    # NORMALIZE AI RESULT
    # ------------------------------------------------------------

    ai_decision = normalize_ai_result(
        raw_ai_decision,
    )

    # ------------------------------------------------------------
    # STANDARD AI VALIDATOR
    # ------------------------------------------------------------

    try:

        validator = validate_ai_decision(
            ai_decision,
            evidence,
            expected_symbol=symbol,
        )

    except Exception as exc:

        validator = {
            "valid": False,

            "errors": [
                (
                    "AI validator failure: "
                    f"{type(exc).__name__}: {exc}"
                )
            ],

            "warnings": [],

            "decision": "NO_TRADE",
        }

    # ------------------------------------------------------------
    # DETERMINISTIC EVIDENCE CONSISTENCY VALIDATION
    # ------------------------------------------------------------
    #
    # This is separate from the normal AI schema validator.
    #
    # The normal validator checks whether the AI response has
    # the correct structure and allowed values.
    #
    # The evidence validator checks whether the AI's factual
    # interpretations agree with deterministic market data.
    #
    # Example:
    #
    # Python:
    #     H4 RSI = 40.41
    #     momentum = neutral
    #
    # AI:
    #     RSI = oversold
    #
    # Result:
    #     BLOCKED
    #
    # The AI does NOT get to redefine deterministic evidence.

    try:

        evidence_validation = (
            validate_ai_evidence_consistency(
                evidence=evidence,
                ai_decision=ai_decision,
            )
        )

    except Exception as exc:

        evidence_validation = {
            "valid": False,

            "status": "BLOCKED",

            "reason": (
                "Evidence consistency validator failure: "
                f"{type(exc).__name__}: {exc}"
            ),

            "findings": [],

            "high_severity_count": 0,

            "finding_count": 0,
        }

    # ------------------------------------------------------------
    # FAIL CLOSED ON EVIDENCE CONTRADICTION
    # ------------------------------------------------------------

    if not evidence_validation.get(
        "valid",
        False,
    ):

        evidence_reason = evidence_validation.get(
            "reason",
            "AI evidence consistency validation failed.",
        )

        ai_decision = _safe_wait_decision(
            symbol=symbol,
            reason=evidence_reason,
        )

        # Update validator information so downstream systems
        # clearly know that the AI was blocked.

        if isinstance(validator, dict):

            validator = {
                **validator,

                "valid": False,

                "errors": [
                    *(
                        validator.get(
                            "errors",
                            [],
                        )
                        if isinstance(
                            validator.get(
                                "errors",
                                [],
                            ),
                            list,
                        )
                        else []
                    ),

                    (
                        "Deterministic evidence consistency "
                        "validation blocked the AI decision."
                    ),
                ],
            }

    # ------------------------------------------------------------
    # DECISION GATE
    # ------------------------------------------------------------

    try:

        gated = apply_decision_gate(
            ai_decision,
            evidence,
        )

    except Exception as exc:

        gated = {
            **ai_decision,

            "decision": "NO_TRADE",

            "gate_status": "REJECTED",

            "gate_reason": (
                "Decision gate failure: "
                f"{type(exc).__name__}: {exc}"
            ),
        }

    # ------------------------------------------------------------
    # FINAL AI RESULT
    # ------------------------------------------------------------

    return {
        "available": True,

        "symbol": symbol,

        "evidence": evidence,

        "ai_decision": ai_decision,

        "validator": validator,

        "evidence_validation": evidence_validation,

        "gate": gated,

        "final_decision": gated.get(
            "decision",
            "NO_TRADE",
        ),

        # --------------------------------------------------------
        # HARD SAFETY
        # --------------------------------------------------------
        #
        # AI reasoning NEVER authorizes execution.
        # Execution must pass the separate deterministic pipeline.

        "trade_authorized": False,

        "execution_allowed": False,

        "read_only": True,
    }