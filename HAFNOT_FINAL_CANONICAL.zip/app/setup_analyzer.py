"""
Setup Analyzer
==============

Technical setup detection layer for the AI Trading Agent.

Responsibilities
----------------
- Evaluate whether market evidence contains a directional setup candidate.
- Combine timeframe bias, market structure, momentum, liquidity and news context.
- Distinguish between a technical setup candidate and an executable trade.
- Never invent prices.
- Never place trades.
- Never bypass risk management or execution safety.

Design principle
---------------
The setup analyzer identifies CONDITIONS.

It does not decide whether the final trade should be executed.

Final execution remains controlled by:
    Evidence Engine
        ->
    AI Reasoning
        ->
    Validator
        ->
    Decision Gate
        ->
    Risk Management
        ->
    Broker Validation
        ->
    Final Execution Safety Gate
"""

from __future__ import annotations

from typing import Any, Dict, List


# ============================================================
# NORMALIZATION HELPERS
# ============================================================

VALID_BIASES = {
    "bullish",
    "bearish",
    "neutral",
    "mixed",
    "unknown",
}

VALID_DIRECTIONS = {
    "BUY",
    "SELL",
    "NONE",
}


def _normalize_text(value: Any, default: str = "") -> str:
    if value is None:
        return default

    return str(value).strip()


def _normalize_bias(value: Any) -> str:
    value = _normalize_text(value, "unknown").lower()

    aliases = {
        "buy": "bullish",
        "long": "bullish",
        "bull": "bullish",
        "up": "bullish",
        "sell": "bearish",
        "short": "bearish",
        "bear": "bearish",
        "down": "bearish",
        "sideways": "neutral",
        "flat": "neutral",
        "unclear": "mixed",
        "conflicted": "mixed",
    }

    value = aliases.get(value, value)

    if value not in VALID_BIASES:
        return "unknown"

    return value


def _normalize_confidence(value: Any) -> str:
    value = _normalize_text(value, "low").lower()

    if value in {"high", "higher", "strong"}:
        return "higher"

    if value in {"moderate", "medium", "mid"}:
        return "moderate"

    return "low"


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None

        return float(value)

    except (TypeError, ValueError):
        return None


def _append_unique(items: List[str], value: str) -> None:
    if value and value not in items:
        items.append(value)


# ============================================================
# LIQUIDITY HELPERS
# ============================================================

def _extract_liquidity_context(
    setup: Dict[str, Any],
    liquidity: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Extract liquidity information without treating liquidity alone
    as directional confirmation.
    """

    available = bool(liquidity.get("available", False))

    levels = liquidity.get("levels", {})
    if not isinstance(levels, dict):
        levels = {}

    nearest_level = liquidity.get("nearest_level", {})
    if not isinstance(nearest_level, dict):
        nearest_level = {}

    sweeps = liquidity.get("sweeps", {})
    if not isinstance(sweeps, dict):
        sweeps = {}

    contexts: List[str] = []

    buy_side_sweep = False
    sell_side_sweep = False

    # --------------------------------------------------------
    # Buy-side sweeps
    # --------------------------------------------------------

    for name, sweep in sweeps.items():
        if not isinstance(sweep, dict):
            continue

        detected = sweep.get("detected") is True
        side = _normalize_text(sweep.get("side")).lower()

        if detected and side == "buy_side":
            buy_side_sweep = True
            _append_unique(
                contexts,
                f"BUY_SIDE_SWEEP:{name}",
            )

    # --------------------------------------------------------
    # Sell-side sweeps
    # --------------------------------------------------------

    for name, sweep in sweeps.items():
        if not isinstance(sweep, dict):
            continue

        detected = sweep.get("detected") is True
        side = _normalize_text(sweep.get("side")).lower()

        if detected and side == "sell_side":
            sell_side_sweep = True
            _append_unique(
                contexts,
                f"SELL_SIDE_SWEEP:{name}",
            )

    # --------------------------------------------------------
    # Nearest liquidity
    # --------------------------------------------------------

    nearest_name = nearest_level.get("name")
    nearest_price = nearest_level.get("price")
    nearest_distance = nearest_level.get("distance")

    if nearest_name is not None:
        name_text = _normalize_text(nearest_name)

        _append_unique(
            contexts,
            f"NEAR_{name_text.upper()}",
        )

        if nearest_price is not None and nearest_distance is not None:
            distance = _safe_float(nearest_distance)

            if distance is not None:
                setup["reasons"].append(
                    f"Nearest liquidity level is "
                    f"{name_text} at {nearest_price} "
                    f"({distance:.2f} away)."
                )

    # --------------------------------------------------------
    # Final context
    # --------------------------------------------------------

    if not available:
        setup["liquidity_context"] = "UNAVAILABLE"

    elif contexts:
        setup["liquidity_context"] = " | ".join(contexts)

    elif levels:
        setup["liquidity_context"] = "LEVELS_AVAILABLE"

    else:
        setup["liquidity_context"] = "NO_ACTIVE_LIQUIDITY"

    return {
        "available": available,
        "buy_side_sweep": buy_side_sweep,
        "sell_side_sweep": sell_side_sweep,
        "nearest_name": nearest_name,
        "nearest_price": nearest_price,
        "nearest_distance": nearest_distance,
        "levels_available": bool(levels),
    }


# ============================================================
# NEWS HELPERS
# ============================================================

def _evaluate_news(
    setup: Dict[str, Any],
    news: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Evaluate news conditions.

    High-risk news remains a hard setup blocker.

    Normal news does not create a directional setup by itself.
    """

    if not isinstance(news, dict):
        news = {}

    available = bool(news.get("available", False))

    status = _normalize_text(
        news.get("status"),
        "UNAVAILABLE",
    ).upper()

    risk_level = _normalize_text(
        news.get("risk_level"),
        "UNKNOWN",
    ).upper()

    restriction = bool(
        news.get("trading_restriction", False)
    )

    high_relevance_count = news.get(
        "high_relevance_count",
        0,
    )

    try:
        high_relevance_count = int(
            high_relevance_count or 0
        )
    except (TypeError, ValueError):
        high_relevance_count = 0

    # --------------------------------------------------------
    # Legacy high-news compatibility
    # --------------------------------------------------------

    legacy_high = news.get("high", 0)

    try:
        legacy_high = int(legacy_high or 0)
    except (TypeError, ValueError):
        legacy_high = 0

    if legacy_high > 0:
        high_relevance_count = max(
            high_relevance_count,
            legacy_high,
        )

    # --------------------------------------------------------
    # News status
    # --------------------------------------------------------

    if not available:
        setup["news_status"] = "UNKNOWN"

        setup["warnings"].append(
            "News data unavailable."
        )

    elif status == "HIGH_RISK":
        setup["news_status"] = "HIGH_RISK"

        setup["warnings"].append(
            "High-risk news conditions detected."
        )

    elif risk_level == "HIGH":
        setup["news_status"] = "HIGH_RISK"

        setup["warnings"].append(
            "High economic/news risk detected."
        )

    elif status == "CAUTION":
        setup["news_status"] = "CAUTION"

        setup["warnings"].append(
            "News conditions require caution."
        )

    elif status == "STALE":
        setup["news_status"] = "STALE"

        setup["warnings"].append(
            "News data is stale."
        )

    elif status in {
        "NORMAL",
        "NO_HIGH_IMPACT_NEWS",
    }:
        setup["news_status"] = status

    else:
        setup["news_status"] = status

    # --------------------------------------------------------
    # High-relevance events
    # --------------------------------------------------------

    if high_relevance_count > 0:

        if setup["news_status"] not in {
            "HIGH_RISK",
            "CAUTION",
        }:
            setup["news_status"] = "HIGH_RISK"

        setup["warnings"].append(
            "High-relevance news detected."
        )

    # --------------------------------------------------------
    # Hard news blocker
    # --------------------------------------------------------

    news_blocked = (
        setup["news_status"] == "HIGH_RISK"
        or risk_level == "HIGH"
        or restriction
        or high_relevance_count > 0
    )

    if news_blocked:
        setup["warnings"].append(
            "Setup blocked by news risk restrictions."
        )

    return {
        "available": available,
        "status": setup["news_status"],
        "risk_level": risk_level,
        "restriction": restriction,
        "high_relevance_count": high_relevance_count,
        "blocked": news_blocked,
    }


# ============================================================
# MOMENTUM
# ============================================================

def _evaluate_momentum(
    setup: Dict[str, Any],
    caution: List[Any],
    direction: str,
) -> bool:
    """
    Evaluate momentum using existing evidence-engine caution
    observations.

    Momentum is confirmation, not the primary directional signal.
    """

    oversold = any(
        "Oversold:" in str(item)
        for item in caution
    )

    overbought = any(
        "Overbought:" in str(item)
        for item in caution
    )

    if direction == "BUY":

        if overbought:
            setup["warnings"].append(
                "BUY setup has overbought conditions."
            )

            return False

        setup["reasons"].append(
            "Momentum conditions do not contradict BUY."
        )

        return True

    if direction == "SELL":

        if oversold:
            setup["warnings"].append(
                "SELL setup has oversold conditions."
            )

            return False

        setup["reasons"].append(
            "Momentum conditions do not contradict SELL."
        )

        return True

    return False


# ============================================================
# DIRECTIONAL SCORING
# ============================================================

def _calculate_direction_scores(
    overall_bias: str,
    higher_bias: str,
    lower_bias: str,
    structure_type: str,
) -> Dict[str, Any]:
    """
    Calculate directional confluence.

    Structure receives the highest weight.

    Weighting:
        Overall bias       = 1
        Higher timeframe   = 2
        Lower timeframe    = 1
        Structure           = 3

    Maximum score = 7.

    A setup candidate requires:
        - valid structure
        - directional score >= 5
        - no equally strong opposing score

    This intentionally avoids the old requirement that every
    timeframe must agree perfectly.
    """

    bullish_score = 0
    bearish_score = 0

    # Overall market bias
    if overall_bias == "bullish":
        bullish_score += 1
    elif overall_bias == "bearish":
        bearish_score += 1

    # Higher timeframe
    if higher_bias == "bullish":
        bullish_score += 2
    elif higher_bias == "bearish":
        bearish_score += 2

    # Lower timeframe
    if lower_bias == "bullish":
        bullish_score += 1
    elif lower_bias == "bearish":
        bearish_score += 1

    # Structure
    if structure_type == "bullish":
        bullish_score += 3
    elif structure_type == "bearish":
        bearish_score += 3

    # Structure validity
    structure_direction = "NONE"

    if structure_type == "bullish":
        structure_direction = "BUY"

    elif structure_type == "bearish":
        structure_direction = "SELL"

    return {
        "bullish_score": bullish_score,
        "bearish_score": bearish_score,
        "structure_direction": structure_direction,
    }


# ============================================================
# DIRECTION SELECTION
# ============================================================

def _select_direction(
    scores: Dict[str, Any],
) -> str:
    bullish_score = int(
        scores.get("bullish_score", 0)
    )

    bearish_score = int(
        scores.get("bearish_score", 0)
    )

    structure_direction = scores.get(
        "structure_direction",
        "NONE",
    )

    # --------------------------------------------------------
    # No structure = no technical directional candidate
    # --------------------------------------------------------

    if structure_direction == "NONE":
        return "NONE"

    # --------------------------------------------------------
    # Require meaningful confluence
    # --------------------------------------------------------

    if (
        structure_direction == "BUY"
        and bullish_score >= 5
        and bullish_score > bearish_score
    ):
        return "BUY"

    if (
        structure_direction == "SELL"
        and bearish_score >= 5
        and bearish_score > bullish_score
    ):
        return "SELL"

    return "NONE"


# ============================================================
# SETUP QUALITY
# ============================================================

def _calculate_quality(
    structure_confirmation: bool,
    momentum_confirmation: bool,
    news_status: str,
    confidence: str,
    directional_score: int,
    liquidity_info: Dict[str, Any],
) -> str:
    """
    Calculate setup quality.

    Quality describes technical completeness.

    It does NOT mean that the trade is executable.

    HIGH requires strong directional confluence plus
    structure, momentum and clean news.

    MODERATE is a valid candidate but requires additional
    confirmation from downstream systems.
    """

    confirmations = 0

    if structure_confirmation:
        confirmations += 1

    if momentum_confirmation:
        confirmations += 1

    if news_status in {
        "NORMAL",
        "NO_HIGH_IMPACT_NEWS",
    }:
        confirmations += 1

    # A detected liquidity sweep is useful context.
    # It is not counted as mandatory directional confirmation.
    liquidity_sweep = (
        liquidity_info.get("buy_side_sweep", False)
        or liquidity_info.get("sell_side_sweep", False)
    )

    if liquidity_sweep:
        confirmations += 1

    # --------------------------------------------------------
    # HIGH
    # --------------------------------------------------------

    if (
        directional_score >= 6
        and confirmations >= 3
        and confidence == "higher"
    ):
        return "HIGH"

    # --------------------------------------------------------
    # MODERATE
    # --------------------------------------------------------

    if (
        directional_score >= 5
        and confirmations >= 2
        and confidence in {
            "higher",
            "moderate",
        }
    ):
        return "MODERATE"

    return "LOW"


# ============================================================
# MAIN ANALYZER
# ============================================================

def analyze_setup(evidence: Dict[str, Any]) -> Dict[str, Any]:
    """
    Determine whether current market evidence contains a
    technical trading setup candidate.

    IMPORTANT:
        This function does NOT place trades.

    It does NOT:
        - calculate final position size
        - authorize execution
        - bypass risk management
        - invent prices
        - create stop-loss or take-profit prices
    """

    if not isinstance(evidence, dict):
        evidence = {}

    # ========================================================
    # MARKET STATE
    # ========================================================

    market_state = evidence.get(
        "market_state",
        {},
    )

    if not isinstance(market_state, dict):
        market_state = {}

    overall_bias = _normalize_bias(
        market_state.get(
            "overall_bias",
            "unknown",
        )
    )

    higher_bias = _normalize_bias(
        market_state.get(
            "higher_timeframe_bias",
            "unknown",
        )
    )

    lower_bias = _normalize_bias(
        market_state.get(
            "lower_timeframe_bias",
            "unknown",
        )
    )

    # ========================================================
    # STRUCTURE
    # ========================================================

    structure = evidence.get(
        "structure",
        {},
    )

    if not isinstance(structure, dict):
        structure = {}

    structure_type = _normalize_bias(
        structure.get(
            "type",
            "unknown",
        )
    )

    # ========================================================
    # OTHER EVIDENCE
    # ========================================================

    caution = evidence.get(
        "caution",
        [],
    )

    if not isinstance(caution, list):
        caution = []

    confidence = _normalize_confidence(
        evidence.get(
            "confidence_state",
            "low",
        )
    )

    liquidity = evidence.get(
        "liquidity",
        {},
    )

    if not isinstance(liquidity, dict):
        liquidity = {}

    news = evidence.get(
        "news",
        {},
    )

    if not isinstance(news, dict):
        news = {}

    # ========================================================
    # INITIAL SETUP
    # ========================================================

    setup: Dict[str, Any] = {
        "setup_found": False,
        "direction": "NONE",
        "setup_quality": "LOW",

        "entry_zone": None,
        "invalidation": None,
        "stop_loss": None,
        "targets": [],

        "risk_reward": None,

        "liquidity_context": "UNKNOWN",
        "structure_confirmation": False,
        "momentum_confirmation": False,
        "news_status": "UNKNOWN",

        "reasons": [],
        "warnings": [],
    }

    # ========================================================
    # LIQUIDITY
    # ========================================================

    liquidity_info = _extract_liquidity_context(
        setup,
        liquidity,
    )

    # ========================================================
    # NEWS
    # ========================================================

    news_info = _evaluate_news(
        setup,
        news,
    )

    # ========================================================
    # CONFIDENCE
    # ========================================================

    if confidence == "low":
        setup["warnings"].append(
            "Evidence confidence is low; setup requires stronger confirmation."
        )

    # IMPORTANT:
    #
    # We do NOT immediately return here.
    #
    # Low evidence confidence is a warning, not a reason to
    # hide all technical structure from downstream AI logic.
    #
    # The AI/provider and final safety systems remain responsible
    # for deciding whether such a candidate can ever become
    # executable.

    # ========================================================
    # DIRECTIONAL CONFLUENCE
    # ========================================================

    scores = _calculate_direction_scores(
        overall_bias=overall_bias,
        higher_bias=higher_bias,
        lower_bias=lower_bias,
        structure_type=structure_type,
    )

    bullish_score = scores["bullish_score"]
    bearish_score = scores["bearish_score"]

    direction = _select_direction(
        scores
    )

    # ========================================================
    # STRUCTURE CONFIRMATION
    # ========================================================

    setup["structure_confirmation"] = (
        direction != "NONE"
        and (
            (
                direction == "BUY"
                and structure_type == "bullish"
            )
            or
            (
                direction == "SELL"
                and structure_type == "bearish"
            )
        )
    )

    # ========================================================
    # DIRECTION REASONS
    # ========================================================

    if direction == "BUY":

        setup["direction"] = "BUY"

        setup["reasons"].append(
            "Bullish technical confluence detected."
        )

        setup["reasons"].append(
            f"Bullish confluence score: "
            f"{bullish_score}/7."
        )

        if overall_bias == "bullish":
            setup["reasons"].append(
                "Overall market bias is bullish."
            )

        elif overall_bias == "bearish":
            setup["warnings"].append(
                "Overall market bias conflicts with BUY."
            )

        if higher_bias == "bullish":
            setup["reasons"].append(
                "Higher timeframe bias supports BUY."
            )

        elif higher_bias == "bearish":
            setup["warnings"].append(
                "Higher timeframe bias conflicts with BUY."
            )

        if lower_bias == "bullish":
            setup["reasons"].append(
                "Lower timeframe bias supports BUY."
            )

        elif lower_bias == "bearish":
            setup["warnings"].append(
                "Lower timeframe bias conflicts with BUY."
            )

        if structure_type == "bullish":
            setup["reasons"].append(
                "Market structure confirms BUY."
            )

    elif direction == "SELL":

        setup["direction"] = "SELL"

        setup["reasons"].append(
            "Bearish technical confluence detected."
        )

        setup["reasons"].append(
            f"Bearish confluence score: "
            f"{bearish_score}/7."
        )

        if overall_bias == "bearish":
            setup["reasons"].append(
                "Overall market bias is bearish."
            )

        elif overall_bias == "bullish":
            setup["warnings"].append(
                "Overall market bias conflicts with SELL."
            )

        if higher_bias == "bearish":
            setup["reasons"].append(
                "Higher timeframe bias supports SELL."
            )

        elif higher_bias == "bullish":
            setup["warnings"].append(
                "Higher timeframe bias conflicts with SELL."
            )

        if lower_bias == "bearish":
            setup["reasons"].append(
                "Lower timeframe bias supports SELL."
            )

        elif lower_bias == "bullish":
            setup["warnings"].append(
                "Lower timeframe bias conflicts with SELL."
            )

        if structure_type == "bearish":
            setup["reasons"].append(
                "Market structure confirms SELL."
            )

    else:

        setup["warnings"].append(
            "No sufficient directional confluence."
        )

        setup["reasons"].append(
            f"Bullish score: {bullish_score}/7."
        )

        setup["reasons"].append(
            f"Bearish score: {bearish_score}/7."
        )

        # No directional candidate means no momentum
        # or executable setup should be generated.
        return setup

    # ========================================================
    # MOMENTUM
    # ========================================================

    setup["momentum_confirmation"] = _evaluate_momentum(
        setup,
        caution,
        direction,
    )

    # ========================================================
    # NEWS HARD BLOCK
    # ========================================================

    if news_info["blocked"]:

        # Keep the direction so downstream AI can understand
        # what technical setup was blocked.
        setup["setup_quality"] = "LOW"
        setup["setup_found"] = False

        return setup

    # ========================================================
    # CONFIDENCE WARNING
    # ========================================================

    if confidence == "low":

        setup["warnings"].append(
            "Technical candidate exists, but evidence confidence "
            "is low."
        )

    # ========================================================
    # HIGHER TIMEFRAME CONFLICT
    # ========================================================

    if direction == "BUY" and higher_bias == "bearish":

        setup["warnings"].append(
            "Higher timeframe bias conflicts with BUY; "
            "additional confirmation is required."
        )

    if direction == "SELL" and higher_bias == "bullish":

        setup["warnings"].append(
            "Higher timeframe bias conflicts with SELL; "
            "additional confirmation is required."
        )

    # ========================================================
    # SETUP QUALITY
    # ========================================================

    directional_score = (
        bullish_score
        if direction == "BUY"
        else bearish_score
    )

    setup["setup_quality"] = _calculate_quality(
        structure_confirmation=setup[
            "structure_confirmation"
        ],
        momentum_confirmation=setup[
            "momentum_confirmation"
        ],
        news_status=setup["news_status"],
        confidence=confidence,
        directional_score=directional_score,
        liquidity_info=liquidity_info,
    )

    # ========================================================
    # SETUP FOUND
    # ========================================================

    #
    # IMPORTANT:
    #
    # A setup candidate is NOT automatically an executable
    # trade.
    #
    # We require HIGH quality here because this field is
    # consumed by downstream risk/execution logic.
    #

    if setup["setup_quality"] == "HIGH":

        setup["setup_found"] = True

    else:

        setup["setup_found"] = False

        if setup["setup_quality"] == "MODERATE":
            setup["warnings"].append(
                "Directional candidate exists but setup "
                "confirmation is not yet strong enough."
            )

        else:
            setup["warnings"].append(
                "Technical conditions are not strong enough "
                "for a confirmed setup."
            )

    # ========================================================
    # PRICE LEVEL SAFETY
    # ========================================================

    #
    # This analyzer intentionally does NOT manufacture:
    #     entry_zone
    #     invalidation
    #     stop_loss
    #     targets
    #
    # Those values must come from actual market/liquidity
    # evidence or a dedicated trade-planning layer.
    #

    if setup["setup_found"]:

        setup["warnings"].append(
            "No entry, stop-loss or target prices were "
            "manufactured by the setup analyzer."
        )

    # ========================================================
    # FINAL RETURN
    # ========================================================

    return setup