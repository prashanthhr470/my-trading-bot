"""
Canonical live/paper signal adapter - Phase K.

app.paper.multi_symbol_paper.py (the process actually running 24/7) calls
batch7_final_integration.FinalAgentPipeline.run(symbol=..., timeframes=...,
account_state=...) - the OLD AI-driven pipeline, entirely separate from
this session's app.quant.* research/validation architecture. This module
is a drop-in replacement with the SAME async call signature and the SAME
output contract (final_decision / paper_trade_plan / trade_authorized /
execution_allowed / broker_order / paper_trading / ai_direct_execution),
so multi_symbol_paper.py's process_trade()/journaling code needs no
changes - only the one line that currently calls FINAL_PIPELINE.run(...)
would need to call this module's run(...) instead.

That one-line swap is NOT made by this module. Editing the file backing
an already-running 24/7 process is a separate, deliberate step that
needs the user's go-ahead - see the project's HANDOFF notes / README for
the exact change once this adapter has been reviewed.

What this adapter does, precisely:
  1. Reads CLOSED live OHLC bars from data/live/bars/, refreshed every
     few minutes by hafnot_live_bar_feed.py over the native cTrader
     OpenAPI. An earlier version of this adapter used
     app.ctrader.market_data.get_market_snapshot instead, which only
     works while the cTrader DESKTOP APP's MCP server is listening on
     127.0.0.1:9876 - when it is not (verified: the port was closed),
     every cycle raised and the journal recorded a misleading "NO_TRADE".
     Reading refreshed files keeps this path alive whenever the market
     worker's own connection is alive, and yields bars shaped exactly
     like the backtest corpus.
  2. Looks up which registered app.quant.strategy_registry strategy runs
     for this symbol (STRATEGY_FOR_SYMBOL below) and calls its REAL
     signal_provider - the exact same function historically backtested,
     not a reimplementation.
  3. Any produced candidate is costed and risk-sized via app.forex_v2.
     risk.evaluate_paper_trade, then run through the REAL app.execution_
     safety.ExecutionSafetyGate via app.quant.safety_gate_bridge - the
     same safety gate class the old pipeline used.
  4. Returns NO_TRADE / WAIT for anything else (no setup, stale data, a
     rejected risk/safety check) - never forces a trade to keep activity
     up. See this module's docstring on strategy status below.

Honesty on strategy status: no strategy in app.quant.strategy_registry
currently has a validated edge (see data/strategy_registry/results - all
three tested strategies are NOT_VALIDATED / NOT_PROFITABLE / NO_EDGE
against real historical evidence). Running this adapter live will mostly
produce NO_TRADE/WAIT, which is the CORRECT and INTENDED behavior per
the project's own rule that WAIT/NO_TRADE are successful outcomes when
no validated edge exists - not a bug to fix by loosening gates.

Verification on Windows (with the runtime started so the bar feed and
market worker are alive):

    .venv\\Scripts\\python.exe -c "import asyncio; from app.paper.canonical_signal_adapter import run; print(asyncio.run(run('XAUUSD', account_state={})))"

A healthy result is a dict whose 'final_decision' is BUY_CANDIDATE /
SELL_CANDIDATE / NO_TRADE / WAIT, with gate.reason explaining which. A
'WAIT' mentioning missing or stale bars means the bar feed is not
running or not refreshing - check hafnot_live_bar_feed.py's output.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from app.forex_v2.risk import (
    AccountState, FX_USD_MAJOR_SPECS, FxQuote, RiskConfig, TradeRequest,
    evaluate_paper_trade,
)
from app.quant.safety_gate_bridge import (
    build_trade_plan_from_costed_trade, check_against_execution_safety_gate,
)
from app.quant.strategy_registry import load_strategy

PROJECT_ROOT = Path(__file__).resolve().parents[2]
LIVE_BARS_DIR = PROJECT_ROOT / "data" / "live" / "bars"
MARKET_EVENTS_DIR = PROJECT_ROOT / "data" / "openapi"

# A bars file older than this is treated as stale -> WAIT, never traded
# on. hafnot_live_bar_feed.py refreshes every 300s, so this allows for
# one missed refresh plus fetch time before the pipeline goes quiet.
MAX_BARS_AGE_SECONDS = 900

# symbol -> (strategy_id, version, period). `period` must match what
# hafnot_live_bar_feed.py actually writes (its FEEDS table) AND what each
# strategy was backtested against (see data/strategy_registry/specs) -
# not a free choice, changing it without re-validating would silently
# invalidate the strategy's historical evidence.
STRATEGY_FOR_SYMBOL: dict[str, tuple[str, str, str]] = {
    "XAUUSD": ("liquidity-sweep-fvg", "2.0.0", "M5"),
    "EURUSD": ("liquidity-sweep-fvg", "2.0.0", "M15"),
    "GBPUSD": ("liquidity-sweep-fvg", "2.0.0", "M15"),
    "USDJPY": ("liquidity-sweep-fvg", "2.0.0", "M15"),
}

DEFAULT_ACCOUNT_EQUITY_USD = 10_000.0

# Open paper positions allowed across ALL symbols at once: the
# ExecutionSafetyGate's limit, also enforced by the paper engine's shared
# portfolio account. Every backtest is single-symbol, so none is evidence
# about several symbols' positions being open together - raising this is a
# deliberate change that needs that evidence first.
MAX_OPEN_POSITIONS = 1

# A registered strategy is NOT automatically allowed to trade forward.
# It must also have a validated baseline: a positive-expectancy
# out-of-sample result with a meaningful sample size, per
# app.monitoring.degradation_monitor.find_validated_baseline. This
# enforces "a strategy earns the right to trade only through evidence" in
# code rather than by discipline - without it, merely registering a
# strategy and listing it in STRATEGY_FOR_SYMBOL would be enough to put
# it live. No strategy in this project currently passes this gate, so the
# honest live result is NO_TRADE, which is the intended outcome and not
# an error.
REQUIRE_VALIDATED_BASELINE = True


def _load_live_bars(symbol: str, period: str) -> tuple[list[dict], Optional[str]]:
    """
    Returns (bars, problem). `problem` is None when the bars are usable;
    otherwise it explains why not, for journaling as a WAIT reason.
    """

    path = LIVE_BARS_DIR / f"{symbol.lower()}_{period.lower()}.json"

    if not path.exists():
        return [], (
            f"No live bars file at {path.name} - hafnot_live_bar_feed.py "
            "has not produced one yet."
        )

    age_seconds = datetime.now(timezone.utc).timestamp() - path.stat().st_mtime

    if age_seconds > MAX_BARS_AGE_SECONDS:
        return [], (
            f"Live bars in {path.name} are {age_seconds / 60.0:.1f} minutes old "
            f"(limit {MAX_BARS_AGE_SECONDS / 60.0:.0f}) - the bar feed has stopped "
            "refreshing; waiting rather than trading on stale data."
        )

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [], f"Could not read {path.name}: {type(exc).__name__}: {exc}"

    bars = payload.get("bars") or []

    if not bars:
        return [], f"{path.name} contains no bars."

    return bars, None


def _no_trade_result(symbol: str, decision: str, reason: str) -> dict[str, Any]:
    return {
        "status": "COMPLETED",
        "symbol": symbol,
        "final_decision": decision,
        "paper_trade_plan": {},
        "trade_authorized": False,
        "execution_allowed": False,
        "broker_order": False,
        "paper_trading": True,
        "ai_direct_execution": False,
        "gate": {"reason": reason},
        "ai_decision": None,
    }


async def run(
    symbol: str, *,
    timeframes: tuple = (),
    account_state: Optional[dict] = None,
    bid: Optional[float] = None,
    ask: Optional[float] = None,
    load_bars=None,
) -> dict[str, Any]:
    """Drop-in for FinalAgentPipeline.run(); the decision path is _evaluate."""

    result = await _evaluate(
        symbol, timeframes=timeframes, account_state=account_state,
        bid=bid, ask=ask, load_bars=load_bars,
    )

    configured = STRATEGY_FOR_SYMBOL.get(symbol.upper())
    if configured and result.get("strategy_id") is None:
        # Blocked and no-setup results must still record which strategy was evaluated.
        result["strategy_id"], result["strategy_version"] = configured[0], configured[1]

    return result


async def _evaluate(
    symbol: str, *,
    timeframes: tuple = (),
    account_state: Optional[dict] = None,
    bid: Optional[float] = None,
    ask: Optional[float] = None,
    load_bars=None,
) -> dict[str, Any]:
    """
    Drop-in for FinalAgentPipeline.run(symbol=..., timeframes=..., account_state=...).

    `timeframes` is accepted only for call-signature compatibility - this
    adapter picks its own period per symbol via STRATEGY_FOR_SYMBOL,
    since the registered strategy spec (not the caller) determines what
    data it was actually validated against.

    `bid`/`ask`: the current quote. app.paper.multi_symbol_paper already
    reads these under its own lock each cycle, so it passes them in
    rather than this adapter re-reading the same event file. Omitted
    (e.g. a standalone verification run) means no quote is available and
    the result is WAIT - this adapter never invents a price.

    `load_bars`: injectable (symbol, period) -> (bars, problem) for
    tests; defaults to reading data/live/bars.

    `account_state`: the real paper account - equity_usd,
    day_start_equity_usd, realized_pnl_today_usd, open_positions
    (app.forex_v2.risk.PaperPosition), daily_loss_percent, kill_switch,
    duplicate_position. Missing keys mean a fresh, empty account.
    """

    symbol = symbol.upper()
    account_state = account_state or {}
    load_bars = load_bars or _load_live_bars

    if symbol not in STRATEGY_FOR_SYMBOL:
        return _no_trade_result(symbol, "NO_TRADE", f"No registered strategy configured for {symbol}.")

    strategy_id, version, period = STRATEGY_FOR_SYMBOL[symbol]

    try:
        spec = load_strategy(strategy_id, version)
    except FileNotFoundError:
        return _no_trade_result(symbol, "NO_TRADE", f"Strategy {strategy_id} {version} not found in registry.")

    if REQUIRE_VALIDATED_BASELINE:
        from app.monitoring.degradation_monitor import find_validated_baseline

        if find_validated_baseline(strategy_id, version) is None:
            return _no_trade_result(
                symbol, "NO_TRADE",
                f"{strategy_id} {version} has no validated out-of-sample baseline, so it is "
                "not permitted to trade forward. This is the intended outcome of the "
                "promotion rules, not a failure.",
            )

    bars, bars_problem = load_bars(symbol, period)

    if bars_problem:
        return _no_trade_result(symbol, "WAIT", bars_problem)

    try:
        provider = spec.build_signal_provider()
        candidate = provider(bars, len(bars) - 1)
    except Exception as exc:
        return _no_trade_result(symbol, "WAIT", f"Signal provider raised {type(exc).__name__}: {exc}.")

    if candidate is None:
        return _no_trade_result(symbol, "NO_TRADE", "No qualifying setup this cycle.")

    direction = candidate["direction"]
    entry_hint = float(candidate["entry"])
    stop_loss = float(candidate["stop_loss"])
    take_profit = float(candidate["take_profit"])

    if symbol not in FX_USD_MAJOR_SPECS:
        return _no_trade_result(symbol, "NO_TRADE", f"{symbol} is not in the supported costed-risk symbol list.")

    if bid is None or ask is None:
        return _no_trade_result(
            symbol, "WAIT",
            "No current bid/ask was supplied - waiting rather than trading blind.",
        )

    quote = FxQuote(symbol=symbol, bid=float(bid), ask=float(ask))
    request = TradeRequest(symbol=symbol, side=direction, stop_loss=stop_loss, take_profit=take_profit)
    open_positions = tuple(account_state.get("open_positions") or ())
    account = AccountState(
        equity_usd=float(account_state.get("equity_usd", DEFAULT_ACCOUNT_EQUITY_USD)),
        day_start_equity_usd=float(account_state.get("day_start_equity_usd", DEFAULT_ACCOUNT_EQUITY_USD)),
        realized_pnl_today_usd=float(account_state.get("realized_pnl_today_usd", 0.0)),
        open_positions=open_positions,
    )

    risk_decision = evaluate_paper_trade(request=request, quote=quote, account=account, config=RiskConfig())

    if not risk_decision.accepted or risk_decision.position is None:
        return _no_trade_result(symbol, "WAIT", f"Risk sizing rejected the candidate: {risk_decision.reason}")

    position = risk_decision.position

    trade_plan = build_trade_plan_from_costed_trade(
        symbol=symbol, direction=direction, entry_price=position.entry_fill_price,
        stop_loss=stop_loss, take_profit=take_profit,
        lots=position.lots, risk_amount_usd=position.risk_amount_usd,
    )

    current_spread_pips = (float(ask) - float(bid)) / FX_USD_MAJOR_SPECS[symbol].pip_size

    safety_result = check_against_execution_safety_gate(
        trade_plan, assumed_spread_pips=current_spread_pips, max_open_positions=MAX_OPEN_POSITIONS,
        open_positions=len(open_positions),
        daily_loss_percent=float(account_state.get("daily_loss_percent", 0.0)),
        kill_switch=bool(account_state.get("kill_switch", False)),
        duplicate_position=bool(account_state.get("duplicate_position", False)),
    )

    if not safety_result.allowed:
        return _no_trade_result(symbol, "WAIT", f"Execution safety gate blocked the candidate: {safety_result.reason}")

    return {
        "status": "COMPLETED",
        "symbol": symbol,
        "final_decision": f"{direction}_CANDIDATE",
        "paper_trade_plan": {
            "entry": position.entry_fill_price,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "lots": position.lots,
            "risk_amount_usd": position.risk_amount_usd,
            "expected_reward_usd": position.expected_reward_usd,
            # The full costed position, so the paper account prices the close
            # with the same spread/slippage/commission model as the backtests.
            "costed_position": asdict(position),
        },
        "trade_authorized": False,
        "execution_allowed": False,
        "broker_order": False,
        "paper_trading": True,
        "ai_direct_execution": False,
        "gate": {
            "reason": "Passed deterministic strategy + risk sizing + execution safety gate.",
            "safety_allowed": safety_result.allowed,
        },
        "ai_decision": None,
        "strategy_id": strategy_id,
        "strategy_version": version,
        "data_sources_used": candidate.get("data_sources_used"),
    }
