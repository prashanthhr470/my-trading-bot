﻿from __future__ import annotations

import json
import signal
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from app.ai.decision_system import (
    run_complete_ai_decision,
)

from app.paper.paper_account import (
    PaperAccount,
)

from app.paper.paper_journal import (
    record_cycle,
    record_trade,
    record_performance,
)

from app.paper.market_snapshot import (
    latest_market_event,
    market_event_after,
    market_events,
    latest_depth,
    extract_prices,
    build_orderflow_evidence,
)


STATE = Path(
    "data/paper/session.json"
)


def now_iso() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


class AutonomousPaperSession:

    def __init__(
        self,
        *,
        symbol: str = "XAUUSD",
        interval_seconds: float = 30.0,
        starting_equity: float = 10000.0,
        risk_percent: float = 1.0,
        max_positions: int = 1,
    ):

        self.symbol = symbol

        self.interval_seconds = max(
            5.0,
            float(interval_seconds),
        )

        self.account = PaperAccount(
            starting_equity=starting_equity,
            risk_percent=risk_percent,
            max_positions=max_positions,
        )

        self.running = False

        self.cycle = 0

        self.last_market_timestamp = None

        self.replay_mode = False

        self.replay_index = 0

        self.last_decision = None

        self.last_result = None

        self.last_error = None

        self.last_cycle_time = None

        self.load_state()

    # ------------------------------------------------------------
    # MARKET EVENT MODE
    # ------------------------------------------------------------

    def enable_replay_mode(self) -> None:

        self.replay_mode = True
        self.replay_index = 0

        events = market_events()

        if self.last_market_timestamp:

            for index, event in enumerate(events):

                if str(
                    event.get("timestamp")
                ) > str(
                    self.last_market_timestamp
                ):

                    self.replay_index = index
                    break

            else:
                self.replay_index = 0

    def next_replay_event(
        self,
    ) -> Optional[Dict[str, Any]]:

        events = market_events()

        if not events:
            return None

        if self.replay_index >= len(events):
            return None

        event = events[self.replay_index]

        self.replay_index += 1

        return event

    # ------------------------------------------------------------
    # STATE
    # ------------------------------------------------------------

    def save_state(self) -> None:

        STATE.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        STATE.write_text(
            json.dumps(
                {
                    "symbol":
                        self.symbol,

                    "interval_seconds":
                        self.interval_seconds,

                    "cycle":
                        self.cycle,

                    "last_market_timestamp":
                        self.last_market_timestamp,

                    "last_decision":
                        self.last_decision,

                    "last_cycle_time":
                        self.last_cycle_time,

                    "paper_trading":
                        True,

                    "live_execution":
                        False,

                    "broker_orders":
                        0,
                },
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )

    def load_state(self) -> None:

        if not STATE.exists():
            return

        try:

            payload = json.loads(
                STATE.read_text(
                    encoding="utf-8"
                )
            )

            self.cycle = int(
                payload.get(
                    "cycle",
                    0,
                )
            )

            self.last_market_timestamp = (
                payload.get(
                    "last_market_timestamp"
                )
            )

            self.last_decision = (
                payload.get(
                    "last_decision"
                )
            )

            self.last_cycle_time = (
                payload.get(
                    "last_cycle_time"
                )
            )

        except Exception:
            pass

    # ------------------------------------------------------------
    # STOP
    # ------------------------------------------------------------

    def stop(self) -> None:

        self.running = False

        self.account.save()
        self.save_state()

    # ------------------------------------------------------------
    # PRICE MONITOR
    # ------------------------------------------------------------

    def monitor_open_positions(
        self,
        prices: Dict[str, float],
    ) -> None:

        closed = self.account.update_price(
            self.symbol,
            prices["bid"],
            prices["ask"],
        )

        for trade in closed:

            record_trade(
                {
                    "event":
                        "CLOSED",

                    "trade":
                        trade,

                    "execution":
                        "PAPER_ONLY",

                    "broker_order":
                        False,

                    "live_execution":
                        False,
                }
            )

    # ------------------------------------------------------------
    # BUILD INTELLIGENCE
    # ------------------------------------------------------------

    def build_intelligence(
        self,
        prices: Dict[str, float],
        depth: Dict[str, Any],
    ) -> Dict[str, Any]:

        orderflow = build_orderflow_evidence(
            depth
        )

        # The complete AI decision system accepts
        # the existing intelligence structure.
        #
        # This adapter intentionally does NOT fabricate
        # technical/fundamental/news data when unavailable.

        return {
            "market_state": {
                "symbol":
                    self.symbol,

                "current_price":
                    (
                        prices["bid"]
                        + prices["ask"]
                    ) / 2.0,

                "bid":
                    prices["bid"],

                "ask":
                    prices["ask"],
            },

            "orderflow":
                orderflow,

            "order_flow":
                orderflow,

            "data_quality": {
                "native_ctrader_level2":
                    True,

                "current_price_available":
                    True,

                "executed_trade_volume_available":
                    bool(
                        orderflow.get(
                            "executed_trade_volume_available",
                            False,
                        )
                    ),

                "true_trade_delta_available":
                    bool(
                        orderflow.get(
                            "true_trade_delta_available",
                            False,
                        )
                    ),

                "depth_footprint_proxy":
                    bool(
                        orderflow.get(
                            "depth_footprint_proxy",
                            True,
                        )
                    ),
            },

            # Empty deterministic sections remain
            # explicitly empty rather than guessed.
            "regime": {},
            "context": {},
            "confluence": {},
            "setup": {},
            "sentiment": {},
            "timeframe_summaries": {},
        }

    # ------------------------------------------------------------
    # OPEN PAPER TRADE
    # ------------------------------------------------------------

    def maybe_open_trade(
        self,
        result: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:

        decision = result.get(
            "final_decision"
        )

        if decision not in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:
            return None

        # Never allow this autonomous layer
        # to bypass the safety contract.

        if result.get(
            "execution_allowed"
        ) is not False:
            return None

        if result.get(
            "trade_authorized"
        ) is not False:
            return None

        if result.get(
            "broker_order"
        ) is not False:
            return None

        if not self.account.can_open():
            return None

        plan = result.get(
            "paper_trade_plan",
            {},
        )

        try:

            entry = float(
                plan["entry"]
            )

            stop = float(
                plan["stop_loss"]
            )

            target = float(
                plan["take_profit"]
            )

        except (
            KeyError,
            TypeError,
            ValueError,
        ):
            return None

        if entry <= 0 or stop <= 0:
            return None

        if target <= 0:
            return None

        direction = (
            "BUY"
            if decision == "BUY_CANDIDATE"
            else "SELL"
        )

        trade_id = (
            "PAPER-"
            + datetime.now(
                timezone.utc
            ).strftime(
                "%Y%m%d%H%M%S"
            )
            + "-"
            + uuid.uuid4().hex[:8]
        )

        position = (
            self.account.open_position(
                trade_id=trade_id,
                symbol=self.symbol,
                direction=direction,
                entry=entry,
                stop_loss=stop,
                take_profit=target,
            )
        )

        if position is None:
            return None

        trade = {
            "event":
                "OPENED",

            "trade":
                position.__dict__,

            "execution":
                "PAPER_ONLY",

            "broker_order":
                False,

            "live_execution":
                False,

            "ai_decision":
                result.get(
                    "ai_decision"
                ),

            "gate":
                result.get(
                    "gate"
                ),
        }

        record_trade(
            trade
        )

        return trade

    # ------------------------------------------------------------
    # ONE AUTONOMOUS CYCLE
    # ------------------------------------------------------------

    def run_cycle(self) -> Dict[str, Any]:

        self.cycle += 1

        self.last_cycle_time = now_iso()

        if self.replay_mode:
            event = self.next_replay_event()
        else:
            event = latest_market_event()

        prices = extract_prices(
            event or {}
        )

        if prices is None:

            result = {
                "status":
                    "NO_MARKET_DATA",

                "cycle":
                    self.cycle,

                "symbol":
                    self.symbol,

                "timestamp":
                    now_iso(),

                "paper_trading":
                    True,

                "live_execution":
                    False,

                "broker_orders":
                    0,
            }

            record_cycle(
                result
            )

            self.save_state()

            return result

        market_timestamp = (
            event.get(
                "timestamp"
            )
            if event
            else None
        )

        self.monitor_open_positions(
            prices
        )

        # Prevent repeated AI calls for exactly
        # the same market event.

        if (
            not self.replay_mode
            and market_timestamp
            and market_timestamp
            == self.last_market_timestamp
        ):

            result = {
                "status":
                    "DUPLICATE_MARKET_EVENT",

                "cycle":
                    self.cycle,

                "symbol":
                    self.symbol,

                "market_timestamp":
                    market_timestamp,

                "paper_trading":
                    True,

                "live_execution":
                    False,

                "broker_orders":
                    0,
            }

            record_cycle(
                result
            )

            return result

        self.last_market_timestamp = (
            market_timestamp
        )

        depth = latest_depth()

        intelligence = (
            self.build_intelligence(
                prices,
                depth,
            )
        )

        # --------------------------------------------------------
        # COMPLETE AI DECISION
        # --------------------------------------------------------

        try:

            ai_result = (
                run_complete_ai_decision(
                    symbol=self.symbol,
                    intelligence=intelligence,
                )
            )

            self.last_result = ai_result

            self.last_decision = (
                ai_result.get(
                    "final_decision"
                )
            )

            self.last_error = None

        except Exception as exc:

            self.last_error = (
                f"{type(exc).__name__}: {exc}"
            )

            ai_result = {
                "available":
                    False,

                "final_decision":
                    "NO_TRADE",

                "error":
                    self.last_error,

                "execution_allowed":
                    False,

                "trade_authorized":
                    False,

                "broker_order":
                    False,

                "live_execution":
                    False,

                "read_only":
                    True,
            }

            self.last_result = (
                ai_result
            )

            self.last_decision = (
                "NO_TRADE"
            )

        paper_trade = (
            self.maybe_open_trade(
                ai_result
            )
        )

        snapshot = (
            self.account.snapshot()
        )

        result = {
            "status":
                "COMPLETED",

            "cycle":
                self.cycle,

            "symbol":
                self.symbol,

            "timestamp":
                now_iso(),

            "market_timestamp":
                market_timestamp,

            "prices":
                prices,

            "decision":
                ai_result.get(
                    "final_decision"
                ),

            "ai_decision":
                ai_result.get(
                    "ai_decision"
                ),

            "gate":
                ai_result.get(
                    "gate"
                ),

            "risk_validation":
                ai_result.get(
                    "risk_validation"
                ),

            "paper_trade":
                paper_trade,

            "account":
                snapshot,

            "paper_trading":
                True,

            "live_execution":
                False,

            "broker_orders":
                0,

            "ai_direct_execution":
                False,

            "execution_allowed":
                False,

            "trade_authorized":
                False,

            "read_only":
                True,
        }

        record_cycle(
            result
        )

        record_performance(
            snapshot
        )

        self.save_state()

        return result

    # ------------------------------------------------------------
    # LOOP
    # ------------------------------------------------------------

    def run_forever(self) -> None:

        self.running = True

        print("")
        print(
            "=" * 72
        )
        print(
            "HAFNOT AUTONOMOUS PAPER VALIDATION"
        )
        print(
            "=" * 72
        )

        print(
            f"SYMBOL:           {self.symbol}"
        )

        print(
            f"INTERVAL:         {self.interval_seconds}s"
        )

        print(
            "PAPER TRADING:    TRUE"
        )

        print(
            "LIVE EXECUTION:   FALSE"
        )

        print(
            "BROKER ORDERS:    0"
        )

        print(
            "AI DIRECT EXEC:   FALSE"
        )

        print(
            "=" * 72
        )

        while self.running:

            started = time.monotonic()

            try:

                result = self.run_cycle()

                decision = result.get(
                    "decision",
                    result.get(
                        "status"
                    ),
                )

                account = result.get(
                    "account",
                    {},
                )

                print(
                    "[CYCLE {:06d}] "
                    "decision={} "
                    "equity={:.2f} "
                    "trades={} "
                    "open={}".format(
                        self.cycle,
                        decision,
                        float(
                            account.get(
                                "equity",
                                self.account.equity,
                            )
                        ),
                        account.get(
                            "trades",
                            0,
                        ),
                        account.get(
                            "open_positions",
                            0,
                        ),
                    )
                )

            except KeyboardInterrupt:

                self.stop()

                print(
                    "\nStopped by user."
                )

                break

            except Exception as exc:

                self.last_error = (
                    f"{type(exc).__name__}: {exc}"
                )

                print(
                    "[ERROR]",
                    self.last_error,
                )

            elapsed = (
                time.monotonic()
                - started
            )

            remaining = max(
                0.0,
                self.interval_seconds
                - elapsed,
            )

            try:
                time.sleep(
                    remaining
                )
            except KeyboardInterrupt:

                self.stop()

                print(
                    "\nStopped by user."
                )

                break

        self.account.save()
        self.save_state()

        print("")
        print(
            "=" * 72
        )
        print(
            "AUTONOMOUS PAPER SESSION STOPPED"
        )
        print(
            "=" * 72
        )

        print(
            json.dumps(
                self.account.snapshot(),
                indent=2,
                default=str,
            )
        )

        print(
            "LIVE EXECUTION: FALSE"
        )

        print(
            "BROKER ORDERS: 0"
        )

