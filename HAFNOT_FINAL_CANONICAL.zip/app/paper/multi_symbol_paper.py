from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
import sys
import time
import threading
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.paper import canonical_signal_adapter
from app.paper.paper_account import PaperAccount
from app.forex_v2.risk import PaperPosition as CostedPosition
from app.forex_v2.risk import RiskConfig
from app.paper.market_snapshot import (
    latest_market_event,
    latest_depth,
    extract_prices,
    build_orderflow_evidence,
)
from app.core.kill_switch import is_tripped as kill_switch_is_tripped

# ============================================================
# HARD SAFETY
# ============================================================

PAPER_TRADING = True
LIVE_EXECUTION = False
BROKER_ORDERS = 0
AI_DIRECT_EXECUTION = False
READ_ONLY = True
DRY_RUN = True

# ============================================================
# SYMBOL UNIVERSE
# ============================================================

SYMBOLS = [
    "XAUUSD",
    "EURUSD",
    "GBPUSD",
    "USDJPY",
    "USDCHF",
    "USDCAD",
    "AUDUSD",
    "NZDUSD",
    "GBPJPY",
    "AUDJPY",
    "GBPAUD",
]

# User's primary strategy universe.
PRIMARY_SYMBOLS = [
    "XAUUSD",
    "GBPUSD",
    "USDJPY",
    "AUDUSD",
]

INTERVAL_SECONDS = 30.0

DATA_ROOT = ROOT / "data" / "openapi"
PAPER_ROOT = ROOT / "data" / "paper"
JOURNAL_ROOT = ROOT / "data" / "journals"

PAPER_ROOT.mkdir(parents=True, exist_ok=True)
JOURNAL_ROOT.mkdir(parents=True, exist_ok=True)

STATE_FILE = PAPER_ROOT / "multi_symbol_state.json"
JOURNAL_FILE = JOURNAL_ROOT / "multi_symbol_24x7.jsonl"
PERFORMANCE_FILE = JOURNAL_ROOT / "multi_symbol_performance.jsonl"

# Protect shared market_snapshot globals during multi-symbol access.
_MARKET_SNAPSHOT_LOCK = threading.RLock()

# ============================================================
# TIME
# ============================================================

def now():
    return datetime.now(timezone.utc).isoformat()

# ============================================================
# SAFE JSON
# ============================================================

def append_jsonl(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open(
        "a",
        encoding="utf-8",
    ) as f:
        f.write(
            json.dumps(
                payload,
                default=str,
                separators=(",", ":"),
            )
            + "\n"
        )

# ============================================================
# STATE
# ============================================================

def load_state():
    if not STATE_FILE.exists():
        return {}

    try:
        return json.loads(
            STATE_FILE.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {}

def save_state(state):
    tmp = STATE_FILE.with_suffix(".tmp")

    tmp.write_text(
        json.dumps(
            state,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    tmp.replace(STATE_FILE)

# ============================================================
# SYMBOL DATA PATHS
# ============================================================

def event_file(symbol):
    return (
        DATA_ROOT /
        f"{symbol.lower()}_market_events.jsonl"
    )

def depth_file(symbol):
    return (
        DATA_ROOT /
        f"{symbol.lower()}_depth_snapshot.json"
    )

# ============================================================
# DYNAMIC MARKET SNAPSHOT
# ============================================================

def get_market(symbol):

    import app.paper.market_snapshot as ms

    # market_snapshot uses shared module-level paths.
    # Serialize only this short path-selection/read section.
    with _MARKET_SNAPSHOT_LOCK:

        original_event = ms.EVENT_FILE
        original_depth = ms.DEPTH_FILE

        ms.EVENT_FILE = event_file(symbol)
        ms.DEPTH_FILE = depth_file(symbol)

        try:

            event = ms.latest_market_event()

            if not event:
                return None

            prices = ms.extract_prices(event)

            if not prices:
                return None

            bid = float(prices["bid"])
            ask = float(prices["ask"])

            if bid <= 0 or ask <= 0:
                return None

            if ask < bid:
                return None

            depth = ms.latest_depth()

            return {
                "event": event,
                "prices": {
                    "bid": bid,
                    "ask": ask,
                },
                "depth": depth,
            }

        except Exception:
            return None

        finally:

            ms.EVENT_FILE = original_event
            ms.DEPTH_FILE = original_depth


# ============================================================
# INTELLIGENCE
# ============================================================

def build_intelligence(symbol, market):
    prices = market["prices"]
    depth = market["depth"] or {}

    import app.paper.market_snapshot as ms

    orderflow = ms.build_orderflow_evidence(
        depth
    )

    return {
        "symbol": symbol,

        "market": {
            "symbol": symbol,
            "bid": prices["bid"],
            "ask": prices["ask"],
            "spread": prices["ask"] - prices["bid"],
            "timestamp": market["event"].get(
                "timestamp"
            ),
        },

        "orderflow": orderflow,

        "order_flow": orderflow,

        "depth": depth,

        "data_quality": {
            "native_ctrader_level2": True,
            "current_price_available": True,
            "executed_trade_volume_available":
                bool(
                    orderflow.get(
                        "executed_trade_volume_available",
                        False,
                    )
                ),
            "true_trade_delta_available":
                bool(
                    orderflow.get(
                        "true_trade_delta_available",
                        False,
                    )
                ),
            "depth_footprint_proxy":
                bool(
                    orderflow.get(
                        "depth_footprint_proxy",
                        True,
                    )
                ),
        },

        "regime": {},
        "context": {},
        "confluence": {},
        "setup": {},
        "sentiment": {},
        "timeframe_summaries": {},
    }

# ============================================================
# PAPER ACCOUNT
# ============================================================

# ONE account for every symbol. Until 2026-09-12 each symbol had its own
# $10,000 account at 1% risk: 11 symbols could hold 11 positions at once
# (much of it the same USD bet), the risk model and safety gate were never
# shown an open position, and paper P&L ignored costs. No paper position
# had ever been opened, so the change lost no history.
PORTFOLIO_ACCOUNT_FILE = PAPER_ROOT / "portfolio_account.json"

# The backtests' risk model: 0.5% per trade, 2% total open risk, one
# position per symbol, 1% same-direction exposure per currency.
PORTFOLIO_RISK = RiskConfig()

_PORTFOLIO_ACCOUNT = None
_PORTFOLIO_ACCOUNT_LOCK = threading.Lock()


def portfolio_account():
    global _PORTFOLIO_ACCOUNT

    # Symbols run on worker threads; unguarded, two could each create an
    # account on the first cycle.
    with _PORTFOLIO_ACCOUNT_LOCK:
        if _PORTFOLIO_ACCOUNT is None:
            _PORTFOLIO_ACCOUNT = PaperAccount(
                starting_equity=canonical_signal_adapter.DEFAULT_ACCOUNT_EQUITY_USD,
                risk_percent=PORTFOLIO_RISK.risk_per_trade_pct,
                max_positions=canonical_signal_adapter.MAX_OPEN_POSITIONS,
                state_path=PORTFOLIO_ACCOUNT_FILE,
                portfolio_limits=PORTFOLIO_RISK,
            )

    return _PORTFOLIO_ACCOUNT


def _journal_open_rejected(symbol, reason):
    append_jsonl(
        JOURNAL_FILE,
        {
            "timestamp": now(),
            "event": "PAPER_OPEN_REJECTED",
            "symbol": symbol,
            "reason": reason,
            "paper_trading": True,
            "live_execution": False,
            "broker_order": False,
        },
    )

    return None

# ============================================================
# PAPER POSITION
# ============================================================

def process_trade(symbol, result, account):
    decision = result.get(
        "final_decision"
    )

    if decision not in {
        "BUY_CANDIDATE",
        "SELL_CANDIDATE",
    }:
        return None

    # HARD SAFETY
    if result.get(
        "execution_allowed"
    ) is not False:
        return None

    if result.get(
        "trade_authorized"
    ) is not False:
        return None

    if result.get(
        "broker_order"
    ) is not False:
        return None

    plan = result.get(
        "paper_trade_plan"
    ) or {}

    try:
        entry = float(plan["entry"])
        stop = float(plan["stop_loss"])
        target = float(plan["take_profit"])
    except (
        KeyError,
        TypeError,
        ValueError,
    ):
        return None

    if (
        entry <= 0
        or stop <= 0
        or target <= 0
    ):
        return None

    direction = (
        "BUY"
        if decision == "BUY_CANDIDATE"
        else "SELL"
    )

    trade_id = (
        "PAPER-"
        + datetime.now(
            timezone.utc
        ).strftime(
            "%Y%m%d%H%M%S"
        )
        + "-"
        + symbol
    )

    # Only a costed position may be paper-traded: uncosted paper P&L would
    # not be comparable with the backtests it is monitored against.
    try:
        costed_position = CostedPosition(**plan["costed_position"])
    except (KeyError, TypeError):
        return _journal_open_rejected(symbol, "MISSING_COSTED_POSITION")

    position, reason = account.try_open_position(
        trade_id=trade_id,
        symbol=symbol,
        direction=direction,
        entry=entry,
        stop_loss=stop,
        take_profit=target,
        costed_position=costed_position,
    )

    if position is None:
        return _journal_open_rejected(symbol, reason)

    trade = {
        "timestamp": now(),
        "event": "OPENED",
        "symbol": symbol,
        "trade": position.__dict__,
        "execution": "PAPER_ONLY",
        "broker_order": False,
        "live_execution": False,
        "ai_decision": result.get(
            "ai_decision"
        ),
        "gate": result.get(
            "gate"
        ),
    }

    append_jsonl(
        JOURNAL_FILE,
        trade,
    )

    return trade

# ============================================================
# ONE SYMBOL
# ============================================================

def build_account_state(symbol, account):
    return {
        "duplicate_position": account.has_open_position(symbol),
        "daily_loss_percent": account.daily_loss_percent(),
        "kill_switch": kill_switch_is_tripped(
            account.consecutive_losses()
        ),
        # The real portfolio, so the risk model's caps and the safety
        # gate's open-position check actually see open positions. Raises
        # (this symbol's cycle errors, nothing opens) if an open position
        # lacks costed data.
        "realized_pnl_today_usd": account.realized_pnl_today(),
        "equity_usd": account.equity,
        "day_start_equity_usd": account.day_start_equity,
        "open_positions": account.open_costed_positions(),
    }


def run_symbol(symbol, state):
    market = get_market(symbol)

    if market is None:
        append_jsonl(
            JOURNAL_FILE,
            {
                "timestamp": now(),
                "event": "NO_MARKET_DATA",
                "symbol": symbol,
                "paper_trading": True,
                "live_execution": False,
                "broker_order": False,
            },
        )

        return {
            "status": "NO_MARKET_DATA",
            "symbol": symbol,
        }

    event = market["event"]
    prices = market["prices"]

    timestamp = str(
        event.get(
            "timestamp",
            "",
        )
    )

    previous = state.get(
        symbol,
        {}
    ).get(
        "last_timestamp"
    )

    if timestamp and timestamp == previous:
        return {
            "status": "DUPLICATE",
            "symbol": symbol,
        }

    account = portfolio_account()

    # --------------------------------------------------------
    # MONITOR EXISTING PAPER POSITION
    # --------------------------------------------------------

    account.update_price(
        symbol,
        prices["bid"],
        prices["ask"],
    )

    # --------------------------------------------------------
    # CANONICAL AI / INTELLIGENCE PIPELINE
    # --------------------------------------------------------

    account_state = build_account_state(
        symbol,
        account,
    )

    try:
        result = asyncio.run(
            canonical_signal_adapter.run(
                symbol=symbol,
                timeframes=("H4", "H1", "M15", "M5"),
                account_state=account_state,
                bid=prices["bid"],
                ask=prices["ask"],
            )
        )

    except Exception as exc:
        result = {
            "status": "FAILED",
            "available": False,
            "symbol": symbol,
            "final_decision": "NO_TRADE",
            "error": f"{type(exc).__name__}: {exc}",
            "execution_allowed": False,
            "trade_authorized": False,
            "broker_order": False,
            "live_execution": False,
            "paper_trading": True,
            "ai_direct_execution": False,
            "read_only": True,
        }

    # Forward research dataset: live-only microstructure is collected prospectively, never backfilled.
    try:
        from app.core.market_hours import is_market_open
        from app.core.research_archive import record_snapshot
        from app.core.sessions import get_session_state
        import app.paper.market_snapshot as ms_archive

        record_snapshot(
            symbol=symbol,
            bid=prices["bid"],
            ask=prices["ask"],
            orderflow_evidence=ms_archive.build_orderflow_evidence(market.get("depth") or {}),
            core_strategy_result={
                "decision": result.get("final_decision"),
                "reason": (result.get("gate") or {}).get("reason"),
                "strategy_id": result.get("strategy_id"),
                "strategy_version": result.get("strategy_version"),
            },
            session_label=get_session_state().session_label,
            # Session labels have no weekend concept; this says whether the broker was actually open.
            market_open=is_market_open(symbol),
        )
    except Exception as exc:
        print(f"[ARCHIVE WARNING] {symbol}: {type(exc).__name__}: {exc}")

    trade = process_trade(
        symbol,
        result,
        account,
    )

    snapshot = account.snapshot()

    decision = result.get(
        "final_decision",
        "NO_TRADE",
    )

    record = {
        "timestamp": now(),
        "event": "CYCLE",
        "symbol": symbol,
        "market_timestamp": timestamp,
        "bid": prices["bid"],
        "ask": prices["ask"],
        "decision": decision,
        # Why this decision, not just what it was. Without these, a
        # pipeline that is crashing every cycle is indistinguishable in
        # the journal from one calmly deciding "no setup" - which is
        # exactly how a dead market-data dependency went unnoticed.
        "decision_reason": (result.get("gate") or {}).get("reason"),
        "pipeline_status": result.get("status"),
        "pipeline_error": result.get("error"),
        "strategy_id": result.get("strategy_id"),
        "strategy_version": result.get("strategy_version"),
        "trade": trade,
        "equity": snapshot.get(
            "equity"
        ),
        "trades": snapshot.get(
            "trades",
            0,
        ),
        "open_positions": snapshot.get(
            "open_positions",
            0,
        ),
        "paper_trading": True,
        "live_execution": False,
        "broker_orders": 0,
        "ai_direct_execution": False,
        "read_only": True,
    }

    append_jsonl(
        JOURNAL_FILE,
        record,
    )

    append_jsonl(
        PERFORMANCE_FILE,
        {
            "timestamp": now(),
            "symbol": symbol,
            "equity": snapshot.get(
                "equity"
            ),
            "trades": snapshot.get(
                "trades",
                0,
            ),
            "open_positions": snapshot.get(
                "open_positions",
                0,
            ),
        },
    )

    state[symbol] = {
        "last_timestamp": timestamp,
        "last_decision": decision,
        "last_cycle": now(),
        "equity": snapshot.get(
            "equity"
        ),
    }

    return {
        "status": "COMPLETED",
        "symbol": symbol,
        "decision": decision,
        "equity": snapshot.get(
            "equity"
        ),
        "trades": snapshot.get(
            "trades",
            0,
        ),
        "open": snapshot.get(
            "open_positions",
            0,
        ),
    }


# ============================================================
# MAIN LOOP
# ============================================================

def _hafnot_symbol_worker(symbol, state):

    started = time.monotonic()

    try:

        result = run_symbol(
            symbol,
            state,
        )

        elapsed = time.monotonic() - started

        if isinstance(result, dict):

            decision = result.get(
                "final_decision",
                result.get(
                    "decision",
                    "NO_TRADE",
                ),
            )

        else:
            decision = "NO_TRADE"

        return {
            "symbol": symbol,
            "result": result,
            "decision": decision,
            "elapsed": round(elapsed, 2),
            "error": None,
        }

    except Exception as exc:

        elapsed = time.monotonic() - started

        return {
            "symbol": symbol,
            "result": None,
            "decision": "NO_TRADE",
            "elapsed": round(elapsed, 2),
            "error": (
                f"{type(exc).__name__}: {exc}"
            ),
        }


def _hafnot_run_concurrent_cycle(state):

    workers = min(
        9,
        len(SYMBOLS),
    )

    total = len(SYMBOLS)

    print(
        f"[MASTER] "
        f"{workers} workers / {total} symbols"
    )

    started = time.monotonic()

    completed = 0
    errors = 0

    with ThreadPoolExecutor(
        max_workers=workers,
        thread_name_prefix="HAFNOT",
    ) as executor:

        futures = {
            executor.submit(
                _hafnot_symbol_worker,
                symbol,
                state,
            ): symbol

            for symbol in SYMBOLS
        }

        for future in as_completed(futures):

            symbol = futures[future]

            try:

                item = future.result()

            except Exception as exc:

                errors += 1

                print(
                    f"[ERROR] {symbol}: "
                    f"{type(exc).__name__}: {exc}"
                )

                continue

            completed += 1

            error = item.get("error")

            if error:

                errors += 1

                print(
                    f"[{completed}/{total}] "
                    f"{symbol} -> ERROR: {error}"
                )

            else:

                print(
                    f"[{completed}/{total}] "
                    f"{symbol} -> "
                    f"{item.get('decision', 'NO_TRADE')} "
                    f"({item.get('elapsed')}s)"
                )

    elapsed = time.monotonic() - started

    print("")
    print("=" * 70)
    print(
        f"[CYCLE COMPLETE] "
        f"{completed}/{total}"
    )
    print(
        f"[CYCLE TIME] "
        f"{elapsed:.2f}s"
    )
    print(
        f"[CYCLE ERRORS] "
        f"{errors}"
    )
    print("=" * 70)
    print("")

    return {
        "completed": completed,
        "total": total,
        "errors": errors,
        "elapsed": elapsed,
    }


# ============================================================
# DEGRADATION MONITORING
# ============================================================

# How many 30-second cycles between forward-degradation assessments.
# 20 cycles ~ 10 minutes: often enough to catch deterioration promptly,
# rare enough not to re-read account files on every tick.
DEGRADATION_CHECK_EVERY_CYCLES = 20


def run_degradation_checks():
    """
    Assess forward performance for every symbol with a strategy attached
    and journal the verdict. Read-only: quarantining a degraded strategy
    is done by hafnot_check_degradation.py --enforce (or an explicit
    operator action), because it needs the promotion candidate_id that
    identifies WHICH candidate is being disabled.
    """

    try:
        from app.core.research_archive import enforce_retention

        freed = enforce_retention()
        if freed:
            print(f"[ARCHIVE] Retention freed {freed / (1024 * 1024):.1f} MB")
    except Exception as exc:
        print(f"[ARCHIVE WARNING] retention: {type(exc).__name__}: {exc}")

    try:
        from app.forex_v2.risk import FX_USD_MAJOR_SPECS
        from app.monitoring.degradation_monitor import assess_symbol
        from app.paper.canonical_signal_adapter import STRATEGY_FOR_SYMBOL

        for symbol, (strategy_id, version, _period) in STRATEGY_FOR_SYMBOL.items():

            spec = FX_USD_MAJOR_SPECS.get(symbol)

            report = assess_symbol(
                symbol,
                strategy_id=strategy_id,
                strategy_version=version,
                assumed_backtest_spread_pips=1.2,
                pip_size=spec.pip_size if spec else None,
            )

            append_jsonl(
                JOURNAL_FILE,
                {
                    "timestamp": now(),
                    "event": "DEGRADATION_CHECK",
                    "symbol": symbol,
                    "strategy_id": strategy_id,
                    "strategy_version": version,
                    "verdict": report.verdict,
                    "degraded": report.degraded,
                    "forward_trade_count": report.forward_trade_count,
                    "triggered_reasons": report.triggered_reasons,
                },
            )

            if report.degraded:
                print(
                    f"[DEGRADATION] {symbol} {strategy_id} v{version}: "
                    f"{report.verdict} - {'; '.join(report.triggered_reasons)}"
                )

    except Exception as exc:
        # Monitoring must never take the trading loop down.
        print(f"[DEGRADATION WARNING] {type(exc).__name__}: {exc}")


def main():

    print("")
    print("=" * 78)
    print(" HAFNOT 24/7 MULTI-SYMBOL PAPER TRADING ENGINE")
    print("=" * 78)
    print("")

    print(
        "Symbols:"
    )

    print(
        "  " + ", ".join(SYMBOLS)
    )

    print("")

    print(
        "Primary strategy:"
    )

    print(
        "  " + ", ".join(PRIMARY_SYMBOLS)
    )

    print("")

    print(
        "Market data       : cTrader DEMO"
    )
    print(
        "Execution         : PAPER ONLY"
    )
    print(
        "Paper trading     : TRUE"
    )
    print(
        "Live execution    : FALSE"
    )
    print(
        "Broker orders     : 0"
    )
    print(
        "AI direct exec    : FALSE"
    )
    print(
        "Read only         : TRUE"
    )
    print(
        "Dry run           : TRUE"
    )

    print("")
    print("=" * 78)

    state = load_state()

    cycle = 0

    while True:

        cycle += 1

        cycle_started = time.monotonic()

        print("")
        print(
            f"[MASTER CYCLE {cycle:08d}] "
            f"{now()}"
        )

        result = _hafnot_run_concurrent_cycle(
            state
        )

        if cycle % DEGRADATION_CHECK_EVERY_CYCLES == 1:
            run_degradation_checks()

        try:

            save_state(state)

        except Exception as exc:

            print(
                f"[STATE WARNING] "
                f"{type(exc).__name__}: {exc}"
            )

        elapsed = (
            time.monotonic()
            - cycle_started
        )

        remaining = max(
            0.0,
            INTERVAL_SECONDS - elapsed,
        )

        print(
            f"[SUPERVISOR] "
            f"Cycle elapsed: {elapsed:.2f}s"
        )

        print(
            f"[SUPERVISOR] "
            f"Next cycle in: {remaining:.2f}s"
        )

        if remaining > 0:

            time.sleep(
                remaining
            )


if __name__ == "__main__":
    main()
