﻿from __future__ import annotations

import json
import threading
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Tuple

from app.forex_v2.risk import PaperPosition as CostedPosition
from app.forex_v2.risk import RiskConfig, close_paper_position, portfolio_limit_problem


STATE_FILE = Path("data/paper/account.json")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class PaperPosition:
    trade_id: str
    symbol: str
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    risk_amount: float
    opened_at: str
    status: str = "OPEN"

    exit_price: Optional[float] = None
    exit_reason: Optional[str] = None
    closed_at: Optional[str] = None
    result_r: Optional[float] = None
    pnl: Optional[float] = None

    # The app.forex_v2.risk costed position this was opened from (lots,
    # fills, commission). When present, the close is priced by that same
    # cost model, so paper P&L is comparable with the costed backtests.
    costed: Optional[Dict[str, Any]] = None


class PaperAccount:

    def __init__(
        self,
        starting_equity: float = 10000.0,
        risk_percent: float = 1.0,
        max_positions: int = 1,
        state_path: Optional[Path] = None,
        portfolio_limits: Optional[RiskConfig] = None,
    ):

        self.starting_equity = float(
            starting_equity
        )

        self.equity = float(
            starting_equity
        )

        self.peak_equity = float(
            starting_equity
        )

        self.risk_percent = float(
            risk_percent
        )

        self.max_positions = int(
            max_positions
        )

        # Portfolio caps (per-symbol, total open risk, currency exposure)
        # re-checked at open time under the lock. None = legacy behaviour.
        self.portfolio_limits = portfolio_limits

        self.state_path = (
            Path(state_path)
            if state_path is not None
            else STATE_FILE
        )

        self.positions: Dict[
            str,
            PaperPosition,
        ] = {}

        self.closed_trades: List[
            Dict[str, Any]
        ] = []

        self.day_start_date: str = ""
        self.day_start_equity: float = float(starting_equity)

        self._lock = threading.RLock()

        self.load()

    # ------------------------------------------------------------
    # DAILY LOSS / KILL SWITCH SUPPORT
    # ------------------------------------------------------------

    def _roll_day_anchor(self) -> None:
        """
        Reset the start-of-day equity anchor when the UTC calendar
        day has changed. Must be called under self._lock.
        """

        today = datetime.now(timezone.utc).date().isoformat()

        if self.day_start_date != today:
            self.day_start_date = today
            self.day_start_equity = self.equity

    def daily_loss_percent(self) -> float:
        """
        Percent equity lost since the start of the current UTC day.
        Returns 0.0 if equity is flat or up for the day.
        """

        with self._lock:

            self._roll_day_anchor()

            if self.day_start_equity <= 0:
                return 0.0

            loss = self.day_start_equity - self.equity

            if loss <= 0:
                return 0.0

            return (loss / self.day_start_equity) * 100.0

    def consecutive_losses(self) -> int:
        """
        Count trailing consecutive losing trades (most recent first).
        """

        with self._lock:

            count = 0

            for trade in reversed(self.closed_trades):

                result_r = trade.get("result_r")

                if result_r is None:
                    break

                if float(result_r) < 0:
                    count += 1
                else:
                    break

            return count

    def has_open_position(self, symbol: str) -> bool:

        with self._lock:

            return any(
                p.symbol == symbol
                for p in self.positions.values()
            )

    def _exposures(self) -> List[SimpleNamespace]:
        # Must be called under self._lock.
        return [
            SimpleNamespace(
                symbol=p.symbol,
                side=p.direction,
                risk_amount_usd=p.risk_amount,
            )
            for p in self.positions.values()
        ]

    def open_exposures(self) -> List[SimpleNamespace]:
        """Open positions as symbol / side / risk_amount_usd, for risk checks."""

        with self._lock:
            return self._exposures()

    def open_costed_positions(self) -> List[CostedPosition]:
        """
        Open positions as app.forex_v2.risk positions - the only form the
        risk model accepts. Raises if one has no costed data: its true risk
        is unknown, and under-reporting it would loosen every portfolio cap.
        """

        with self._lock:

            missing = [
                p.trade_id
                for p in self.positions.values()
                if not p.costed
            ]

            if missing:
                raise ValueError(
                    "Open paper position(s) without costed data: "
                    + ", ".join(missing)
                )

            return [
                CostedPosition(**p.costed)
                for p in self.positions.values()
            ]

    def realized_pnl_today(self) -> float:
        """Realized P&L since the start of the UTC day (equity moves only on closes)."""

        with self._lock:
            self._roll_day_anchor()
            return self.equity - self.day_start_equity

    # ------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------

    def save(self) -> None:

        with self._lock:

            self.state_path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            payload = {
                "starting_equity":
                    self.starting_equity,

                "equity":
                    self.equity,

                "peak_equity":
                    self.peak_equity,

                "risk_percent":
                    self.risk_percent,

                "max_positions":
                    self.max_positions,

                "positions": {
                    key: asdict(value)
                    for key, value
                    in self.positions.items()
                },

                "closed_trades":
                    self.closed_trades,

                "day_start_date":
                    self.day_start_date,

                "day_start_equity":
                    self.day_start_equity,

                "paper_trading":
                    True,

                "live_execution":
                    False,

                "broker_orders":
                    0,
            }

            self.state_path.write_text(
                json.dumps(
                    payload,
                    indent=2,
                    default=str,
                ),
                encoding="utf-8",
            )

    def load(self) -> None:

        if not self.state_path.exists():
            return

        try:

            payload = json.loads(
                self.state_path.read_text(
                    encoding="utf-8"
                )
            )

            self.equity = float(
                payload.get(
                    "equity",
                    self.starting_equity,
                )
            )

            self.peak_equity = float(
                payload.get(
                    "peak_equity",
                    self.equity,
                )
            )

            self.positions = {}

            for key, value in payload.get(
                "positions",
                {},
            ).items():

                self.positions[key] = PaperPosition(
                    **value
                )

            self.closed_trades = list(
                payload.get(
                    "closed_trades",
                    [],
                )
            )

            self.day_start_date = str(
                payload.get(
                    "day_start_date",
                    "",
                )
            )

            self.day_start_equity = float(
                payload.get(
                    "day_start_equity",
                    self.equity,
                )
            )

        except Exception:
            # Corrupt state must never create
            # an accidental trading action.
            self.positions = {}
            self.closed_trades = []

    # ------------------------------------------------------------
    # POSITION LIMIT
    # ------------------------------------------------------------

    def can_open(self) -> bool:

        with self._lock:

            return (
                len(self.positions)
                < self.max_positions
            )

    # ------------------------------------------------------------
    # OPEN PAPER POSITION
    # ------------------------------------------------------------

    def open_position(
        self,
        *,
        trade_id: str,
        symbol: str,
        direction: str,
        entry: float,
        stop_loss: float,
        take_profit: float,
        costed_position: Optional[CostedPosition] = None,
    ) -> Optional[PaperPosition]:

        position, _reason = self.try_open_position(
            trade_id=trade_id,
            symbol=symbol,
            direction=direction,
            entry=entry,
            stop_loss=stop_loss,
            take_profit=take_profit,
            costed_position=costed_position,
        )

        return position

    def try_open_position(
        self,
        *,
        trade_id: str,
        symbol: str,
        direction: str,
        entry: float,
        stop_loss: float,
        take_profit: float,
        costed_position: Optional[CostedPosition] = None,
    ) -> Tuple[Optional[PaperPosition], Optional[str]]:
        """
        Open a paper position, or return (None, reason). Every limit is
        checked here under the account lock: symbols are evaluated on
        concurrent threads, so a check made before this call can be stale
        by the time two of them try to open at once.
        """

        with self._lock:

            if not self.can_open():
                return None, "MAX_POSITIONS_REACHED"

            if trade_id in self.positions:
                return None, "DUPLICATE_TRADE_ID"

            entry = float(entry)
            stop_loss = float(stop_loss)
            take_profit = float(take_profit)

            distance = abs(
                entry - stop_loss
            )

            if distance <= 0:
                return None, "INVALID_STOP_DISTANCE"

            if costed_position is not None:

                if (
                    costed_position.symbol != symbol
                    or costed_position.side != direction
                ):
                    return None, "COSTED_POSITION_MISMATCH"

                # The cost model's full loss at the stop, including
                # spread, slippage and commission.
                risk_amount = float(
                    costed_position.risk_amount_usd
                )

            else:

                risk_amount = (
                    self.equity
                    * self.risk_percent
                    / 100.0
                )

            if self.portfolio_limits is not None:

                problem = portfolio_limit_problem(
                    open_positions=self._exposures(),
                    symbol=symbol,
                    side=direction,
                    risk_amount_usd=risk_amount,
                    equity_usd=self.equity,
                    config=self.portfolio_limits,
                )

                if problem:
                    return None, problem

            position = PaperPosition(
                trade_id=trade_id,
                symbol=symbol,
                direction=direction,
                entry=entry,
                stop_loss=stop_loss,
                take_profit=take_profit,
                risk_amount=risk_amount,
                opened_at=now_iso(),
                costed=(
                    asdict(costed_position)
                    if costed_position is not None
                    else None
                ),
            )

            self.positions[
                trade_id
            ] = position

            self.save()

            return position, None

    # ------------------------------------------------------------
    # MONITOR PAPER POSITION
    # ------------------------------------------------------------

    def update_price(
        self,
        symbol: str,
        bid: float,
        ask: float,
    ) -> List[Dict[str, Any]]:

        closed = []

        with self._lock:

            bid = float(bid)
            ask = float(ask)

            for trade_id, position in list(
                self.positions.items()
            ):

                if position.symbol != symbol:
                    continue

                if position.direction == "BUY":

                    # Conservative execution model:
                    # BUY exits at BID.

                    price = bid

                    if price <= position.stop_loss:

                        closed.append(
                            self._close(
                                position,
                                position.stop_loss,
                                "STOP_LOSS",
                            )
                        )

                    elif price >= position.take_profit:

                        closed.append(
                            self._close(
                                position,
                                position.take_profit,
                                "TAKE_PROFIT",
                            )
                        )

                elif position.direction == "SELL":

                    # SELL exits at ASK.

                    price = ask

                    if price >= position.stop_loss:

                        closed.append(
                            self._close(
                                position,
                                position.stop_loss,
                                "STOP_LOSS",
                            )
                        )

                    elif price <= position.take_profit:

                        closed.append(
                            self._close(
                                position,
                                position.take_profit,
                                "TAKE_PROFIT",
                            )
                        )

            if closed:
                self.save()

        return closed

    # ------------------------------------------------------------
    # CLOSE
    # ------------------------------------------------------------

    def _close(
        self,
        position: PaperPosition,
        exit_price: float,
        reason: str,
    ) -> Dict[str, Any]:

        if position.direction == "BUY":

            price_change = (
                exit_price
                - position.entry
            )

            risk_distance = (
                position.entry
                - position.stop_loss
            )

        else:

            price_change = (
                position.entry
                - exit_price
            )

            risk_distance = (
                position.stop_loss
                - position.entry
            )

        if risk_distance <= 0:
            result_r = -1.0
        else:
            result_r = (
                price_change
                / risk_distance
            )

        pnl = (
            result_r
            * position.risk_amount
        )

        exit_fill_price = None
        cost_model_problem = None

        if position.costed:

            # The backtests' cost model: one adverse closing slippage
            # charge plus the round-turn commission reserved at open.
            costed_close = close_paper_position(
                position=CostedPosition(**position.costed),
                exit_price=float(exit_price),
                config=self.portfolio_limits or RiskConfig(),
            )

            if costed_close.accepted:
                pnl = float(costed_close.net_pnl_usd)
                result_r = float(costed_close.result_r)
                exit_fill_price = costed_close.exit_fill_price
            else:
                cost_model_problem = costed_close.reason

        position.exit_price = float(
            exit_price
        )

        position.exit_reason = reason

        position.closed_at = now_iso()

        position.result_r = float(
            result_r
        )

        position.pnl = float(
            pnl
        )

        position.status = "CLOSED"

        self.equity += pnl

        self.peak_equity = max(
            self.peak_equity,
            self.equity,
        )

        trade = asdict(position)

        trade["exit_fill_price"] = exit_fill_price

        if cost_model_problem:
            # Never silent: this close fell back to the uncosted R formula.
            trade["cost_model_problem"] = cost_model_problem

        self.closed_trades.append(
            trade
        )

        self.positions.pop(
            position.trade_id,
            None,
        )

        return trade

    # ------------------------------------------------------------
    # SNAPSHOT
    # ------------------------------------------------------------

    def snapshot(self) -> Dict[str, Any]:

        with self._lock:

            results = [
                float(
                    t["result_r"]
                )
                for t in self.closed_trades
                if t.get("result_r") is not None
            ]

            wins = [
                r for r in results
                if r > 0
            ]

            losses = [
                r for r in results
                if r < 0
            ]

            gross_profit = sum(
                wins
            )

            gross_loss = abs(
                sum(losses)
            )

            profit_factor = (
                gross_profit
                / gross_loss
                if gross_loss > 0
                else None
            )

            max_drawdown = (
                self.peak_equity
                - self.equity
            )

            win_rate = (
                len(wins)
                / len(results)
                * 100.0
                if results
                else 0.0
            )

            expectancy = (
                sum(results)
                / len(results)
                if results
                else 0.0
            )

            return {
                "starting_equity":
                    self.starting_equity,

                "equity":
                    self.equity,

                "peak_equity":
                    self.peak_equity,

                "max_drawdown":
                    max_drawdown,

                "trades":
                    len(results),

                "wins":
                    len(wins),

                "losses":
                    len(losses),

                "win_rate":
                    win_rate,

                "net_r":
                    sum(results),

                "expectancy_r":
                    expectancy,

                "profit_factor":
                    profit_factor,

                "open_positions":
                    len(self.positions),

                "paper_trading":
                    True,

                "live_execution":
                    False,

                "broker_orders":
                    0,
            }

