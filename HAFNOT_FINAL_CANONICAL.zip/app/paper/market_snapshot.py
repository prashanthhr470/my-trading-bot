﻿from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parents[2]
EVENT_FILE = ROOT / "data" / "openapi" / "xauusd_market_events.jsonl"
DEPTH_FILE = ROOT / "data" / "openapi" / "xauusd_depth_snapshot.json"

def _json_object(value: Any) -> Optional[Dict[str, Any]]:
    return value if isinstance(value, dict) else None

# Only the end of an event file is read. The files grow by about a gigabyte a trading
# day across symbols, and reading all of one - to use its last line - on every
# 30-second cycle for every symbol was pure waste. The window widens only if the tail
# holds no valid spot quote.
TAIL_BYTES = 64 * 1024
MAX_TAIL_BYTES = 8 * 1024 * 1024


def latest_market_event() -> Optional[Dict[str, Any]]:
    """Return the newest *valid* spot event, skipping partial quotes."""
    if not EVENT_FILE.exists():
        return None
    try:
        size = EVENT_FILE.stat().st_size
        chunk = TAIL_BYTES
        while True:
            start = max(0, size - chunk)
            with EVENT_FILE.open("rb") as f:
                f.seek(start)
                lines = f.read().split(b"\n")
            if start > 0:
                lines = lines[1:]  # the first line of a tail may be cut
            for raw in reversed(lines):
                if not raw.strip():
                    continue
                try:
                    payload = json.loads(raw)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue
                if not isinstance(payload, dict) or payload.get("type") != "spot":
                    continue
                if extract_prices(payload) is not None:
                    return payload
            if start == 0 or chunk >= MAX_TAIL_BYTES:
                return None
            chunk *= 4
    except OSError:
        return None


def latest_valid_market_event() -> Optional[Dict[str, Any]]:
    """Explicit compatibility alias for callers requiring a valid quote."""
    return latest_market_event()

def latest_depth() -> Dict[str, Any]:
    if not DEPTH_FILE.exists():
        return {}
    try:
        payload=json.loads(DEPTH_FILE.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {}

def extract_prices(event: Dict[str, Any]) -> Optional[Dict[str, float]]:
    if not isinstance(event, dict): return None
    for candidate in (event, event.get("data"), event.get("spot")):
        if not isinstance(candidate, dict): continue
        try:
            bid=float(candidate.get("bid")); ask=float(candidate.get("ask"))
        except (TypeError, ValueError): continue
        if bid > 0 and ask > 0 and ask >= bid:
            return {"bid":bid,"ask":ask}
    return None

def build_orderflow_evidence(depth: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(depth, dict): return {}
    for key in ("order_flow","orderflow","intelligence","snapshot"):
        candidate=depth.get(key)
        if isinstance(candidate, dict):
            return candidate
    return {
        "data_source":"cTrader_native_level2",
        "raw_depth":depth,
        "executed_trade_volume_available":False,
        "true_trade_delta_available":False,
        "depth_footprint_proxy":True,
    }
def _read_event_lines() -> list[Dict[str, Any]]:
    if not EVENT_FILE.exists():
        return []
    try:
        lines = EVENT_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        return []
    result = []
    for line in lines:
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                result.append(obj)
        except Exception:
            continue
    return result


def market_events(limit: int = 1000) -> list[Dict[str, Any]]:
    events = _read_event_lines()
    if limit is not None and limit > 0:
        return events[-limit:]
    return events


def market_event_after(timestamp: Any, limit: int = 1000) -> list[Dict[str, Any]]:
    events = _read_event_lines()
    if timestamp is None:
        return events[-limit:] if limit and limit > 0 else events

    cutoff = str(timestamp)
    result = []
    for event in events:
        event_ts = event.get("timestamp")
        if event_ts is not None and str(event_ts) > cutoff:
            result.append(event)

    if limit and limit > 0:
        return result[-limit:]
    return result


def first_market_event() -> Optional[Dict[str, Any]]:
    events = _read_event_lines()
    return events[0] if events else None


def latest_valid_market_event() -> Optional[Dict[str, Any]]:
    return latest_market_event()


def valid_market_events(limit: int = 1000) -> list[Dict[str, Any]]:
    events = _read_event_lines()
    valid = []
    for event in events:
        try:
            bid = float(event.get("bid"))
            ask = float(event.get("ask"))
            if bid > 0 and ask > 0 and ask >= bid:
                valid.append(event)
        except (TypeError, ValueError):
            continue

    if limit and limit > 0:
        return valid[-limit:]
    return valid


def market_event_count() -> int:
    return len(_read_event_lines())


