﻿from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


ROOT = Path("data/paper")

CYCLE_LOG = ROOT / "cycles.jsonl"
TRADE_LOG = ROOT / "trades.jsonl"
PERFORMANCE_LOG = ROOT / "performance.jsonl"


def now_iso() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


def write_jsonl(
    path: Path,
    payload: Dict[str, Any],
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "a",
        encoding="utf-8",
    ) as handle:

        handle.write(
            json.dumps(
                payload,
                default=str,
                ensure_ascii=False,
                separators=(
                    ",",
                    ":",
                ),
            )
            + "\n"
        )


def record_cycle(
    payload: Dict[str, Any],
) -> None:

    write_jsonl(
        CYCLE_LOG,
        {
            "timestamp": now_iso(),
            **payload,
        },
    )


def record_trade(
    payload: Dict[str, Any],
) -> None:

    write_jsonl(
        TRADE_LOG,
        {
            "timestamp": now_iso(),
            **payload,
        },
    )


def record_performance(
    payload: Dict[str, Any],
) -> None:

    write_jsonl(
        PERFORMANCE_LOG,
        {
            "timestamp": now_iso(),
            **payload,
        },
    )
