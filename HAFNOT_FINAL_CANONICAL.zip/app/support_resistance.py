import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

DEFAULT_TOLERANCE = 0.003
DEFAULT_MAX_LEVELS = 50


# ============================================================
# SUPPORT / RESISTANCE DETECTION
# ============================================================

def find_support_resistance(
    df,
    tolerance=DEFAULT_TOLERANCE,
    max_levels=DEFAULT_MAX_LEVELS,
    lookback=None,
):
    """
    Identify support and resistance levels from swing highs
    and swing lows.

    Improvements:
        - Ignores invalid price values.
        - Handles missing columns safely.
        - Allows optional lookback.
        - Prioritizes more recent swing levels.
        - Limits the number of raw levels returned.
        - Preserves the original output structure.

    NOTE:
        tolerance is retained here for API compatibility.
        Actual grouping is handled by group_levels().
    """

    levels = []

    if df is None:
        return levels

    if not isinstance(df, pd.DataFrame):
        return levels

    if df.empty:
        return levels

    # --------------------------------------------------------
    # Optional lookback
    # --------------------------------------------------------

    data = df

    if lookback is not None:

        try:
            lookback = int(lookback)

            if lookback > 0:
                data = df.tail(lookback)

        except (TypeError, ValueError):
            pass

    # --------------------------------------------------------
    # Swing highs → resistance
    # --------------------------------------------------------

    if (
        "swing_high" in data.columns
        and "high" in data.columns
    ):

        swing_highs = data[
            data["swing_high"].fillna(False).astype(bool)
        ]

        for _, row in swing_highs.iterrows():

            price = row["high"]

            if pd.isna(price):
                continue

            try:
                price = float(price)
            except (TypeError, ValueError):
                continue

            if price <= 0:
                continue

            timestamp = (
                row["timestamp"]
                if "timestamp" in data.columns
                else None
            )

            levels.append({
                "type": "resistance",
                "price": price,
                "timestamp": timestamp,
            })

    # --------------------------------------------------------
    # Swing lows → support
    # --------------------------------------------------------

    if (
        "swing_low" in data.columns
        and "low" in data.columns
    ):

        swing_lows = data[
            data["swing_low"].fillna(False).astype(bool)
        ]

        for _, row in swing_lows.iterrows():

            price = row["low"]

            if pd.isna(price):
                continue

            try:
                price = float(price)
            except (TypeError, ValueError):
                continue

            if price <= 0:
                continue

            timestamp = (
                row["timestamp"]
                if "timestamp" in data.columns
                else None
            )

            levels.append({
                "type": "support",
                "price": price,
                "timestamp": timestamp,
            })

    # --------------------------------------------------------
    # Most recent levels first
    # --------------------------------------------------------

    def timestamp_sort_key(level):

        timestamp = level.get("timestamp")

        if timestamp is None:
            return pd.Timestamp.min

        try:
            return pd.Timestamp(timestamp)
        except Exception:
            return pd.Timestamp.min

    levels.sort(
        key=timestamp_sort_key,
        reverse=True,
    )

    # --------------------------------------------------------
    # Limit raw levels
    # --------------------------------------------------------

    if max_levels is not None:

        try:
            max_levels = int(max_levels)

            if max_levels > 0:
                levels = levels[:max_levels]

        except (TypeError, ValueError):
            pass

    return levels


# ============================================================
# GROUP LEVELS INTO ZONES
# ============================================================

def group_levels(
    levels,
    tolerance=DEFAULT_TOLERANCE,
):
    """
    Group nearby support levels together and nearby
    resistance levels together.

    IMPORTANT:
        Support and resistance are NEVER merged into the
        same zone.

    Each zone contains:
        - price
        - type
        - levels
        - strength
        - touch_count
        - price_range
    """

    if not levels:
        return []

    # --------------------------------------------------------
    # Validate tolerance
    # --------------------------------------------------------

    try:
        tolerance = float(tolerance)
    except (TypeError, ValueError):
        tolerance = DEFAULT_TOLERANCE

    if tolerance < 0:
        tolerance = DEFAULT_TOLERANCE

    # --------------------------------------------------------
    # Clean levels
    # --------------------------------------------------------

    cleaned_levels = []

    for level in levels:

        if not isinstance(level, dict):
            continue

        level_type = level.get("type")

        if level_type not in {
            "support",
            "resistance",
        }:
            continue

        price = level.get("price")

        try:
            price = float(price)
        except (TypeError, ValueError):
            continue

        if price <= 0:
            continue

        cleaned_levels.append({
            "type": level_type,
            "price": price,
            "timestamp": level.get("timestamp"),
        })

    if not cleaned_levels:
        return []

    # --------------------------------------------------------
    # Sort by price
    # --------------------------------------------------------

    cleaned_levels.sort(
        key=lambda x: x["price"]
    )

    zones = []

    # --------------------------------------------------------
    # Create zones
    # --------------------------------------------------------

    for level in cleaned_levels:

        added = False

        for zone in zones:

            # ------------------------------------------------
            # CRITICAL:
            # Never merge support with resistance.
            # ------------------------------------------------

            if zone["type"] != level["type"]:
                continue

            zone_price = zone["price"]

            if zone_price <= 0:
                continue

            difference = (
                abs(level["price"] - zone_price)
                / zone_price
            )

            if difference <= tolerance:

                zone["levels"].append(level)

                prices = [
                    item["price"]
                    for item in zone["levels"]
                ]

                zone["price"] = (
                    sum(prices)
                    / len(prices)
                )

                zone["strength"] = len(
                    zone["levels"]
                )

                zone["touch_count"] = len(
                    zone["levels"]
                )

                zone["price_range"] = {
                    "low": min(prices),
                    "high": max(prices),
                }

                added = True

                break

        # ----------------------------------------------------
        # Create new zone
        # ----------------------------------------------------

        if not added:

            price = level["price"]

            zones.append({
                "price": price,
                "type": level["type"],
                "levels": [level],
                "strength": 1,
                "touch_count": 1,
                "price_range": {
                    "low": price,
                    "high": price,
                },
            })

    # --------------------------------------------------------
    # Sort zones by price
    # --------------------------------------------------------

    zones.sort(
        key=lambda x: x["price"]
    )

    return zones