from dataclasses import dataclass
from typing import Optional


# ============================================================
# FINAL EXECUTION SAFETY RESULT
# ============================================================

@dataclass
class ExecutionSafetyResult:

    allowed: bool

    symbol: str
    direction: str

    reason: str

    checks_passed: list
    errors: list
    warnings: list


# ============================================================
# FINAL EXECUTION SAFETY GATE
# ============================================================

class ExecutionSafetyGate:

    """
    Final deterministic safety layer.

    AI has NO authority here.

    This gate only evaluates an already-created trade plan
    and broker validation result.

    It does NOT:

    - call AI
    - modify the trade
    - place orders
    - close orders
    - modify broker positions

    The default configuration is intentionally conservative.
    """

    def __init__(
        self,
        max_spread: float = 5.0,
        max_open_positions: int = 1,
        max_daily_loss_percent: float = 3.0,
        require_dry_run: bool = True,
    ):

        self.max_spread = float(max_spread)
        self.max_open_positions = int(
            max_open_positions
        )
        self.max_daily_loss_percent = float(
            max_daily_loss_percent
        )
        self.require_dry_run = bool(
            require_dry_run
        )

    # ========================================================
    # MAIN SAFETY CHECK
    # ========================================================

    def check(
        self,
        trade_plan,
        broker_result,
        *,
        open_positions: int = 0,
        daily_loss_percent: float = 0.0,
        kill_switch: bool = False,
        duplicate_position: bool = False,
        dry_run: bool = True,
    ) -> ExecutionSafetyResult:

        checks_passed = []
        errors = []
        warnings = []

        # ----------------------------------------------------
        # Basic objects
        # ----------------------------------------------------

        if trade_plan is None:

            return ExecutionSafetyResult(
                False,
                "UNKNOWN",
                "NONE",
                "Trade plan is unavailable.",
                checks_passed,
                ["Trade plan is unavailable."],
                warnings,
            )

        symbol = getattr(
            trade_plan,
            "symbol",
            "UNKNOWN",
        )

        direction = getattr(
            trade_plan,
            "direction",
            "NONE",
        )

        # ====================================================
        # 1. KILL SWITCH
        # ====================================================

        if kill_switch:

            errors.append(
                "Kill switch is active."
            )

        else:

            checks_passed.append(
                "Kill switch is inactive."
            )

        # ====================================================
        # 2. TRADE PLAN STATUS
        # ====================================================

        if getattr(
            trade_plan,
            "status",
            None,
        ) != "READY":

            errors.append(
                "Trade plan is not READY."
            )

        else:

            checks_passed.append(
                "Trade plan status is READY."
            )

        # ====================================================
        # 3. DECISION
        # ====================================================

        decision = getattr(
            trade_plan,
            "decision",
            None,
        )

        if decision not in {
            "BUY_CANDIDATE",
            "SELL_CANDIDATE",
        }:

            errors.append(
                "Trade decision is not executable."
            )

        else:

            checks_passed.append(
                "Trade decision is executable."
            )

        # ====================================================
        # 4. DIRECTION
        # ====================================================

        if direction not in {
            "BUY",
            "SELL",
        }:

            errors.append(
                "Trade direction must be BUY or SELL."
            )

        else:

            checks_passed.append(
                "Trade direction is valid."
            )

        # ====================================================
        # 5. DECISION / DIRECTION CONSISTENCY
        # ====================================================

        expected_direction = {
            "BUY_CANDIDATE": "BUY",
            "SELL_CANDIDATE": "SELL",
        }.get(
            decision
        )

        if (
            expected_direction is not None
            and direction != expected_direction
        ):

            errors.append(
                "Decision and direction do not match."
            )

        elif expected_direction is not None:

            checks_passed.append(
                "Decision and direction are consistent."
            )

        # ====================================================
        # 6. BROKER VALIDATION
        # ====================================================

        if not getattr(
            trade_plan,
            "broker_valid",
            False,
        ):

            errors.append(
                "Trade plan broker validation failed."
            )

        else:

            checks_passed.append(
                "Trade plan broker validation passed."
            )

        # ====================================================
        # 7. BROKER RESULT
        # ====================================================

        if broker_result is None:

            errors.append(
                "Broker execution validation result is unavailable."
            )

        else:

            broker_allowed = getattr(
                broker_result,
                "allowed",
                False,
            )

            if not broker_allowed:

                errors.append(
                    "Broker execution validation failed."
                )

            else:

                checks_passed.append(
                    "Broker execution validation passed."
                )

        # ====================================================
        # 8. POSITION SIZE
        # ====================================================

        position_size = getattr(
            trade_plan,
            "position_size",
            None,
        )

        if (
            position_size is None
            or position_size <= 0
        ):

            errors.append(
                "Position size is invalid."
            )

        else:

            checks_passed.append(
                "Position size is valid."
            )

        # ====================================================
        # 9. ENTRY / STOP / TARGET
        # ====================================================

        entry = getattr(
            trade_plan,
            "entry_price",
            None,
        )

        stop = getattr(
            trade_plan,
            "stop_loss",
            None,
        )

        target = getattr(
            trade_plan,
            "take_profit",
            None,
        )

        if (
            entry is None
            or stop is None
            or target is None
        ):

            errors.append(
                "Entry, stop-loss or take-profit is missing."
            )

        else:

            if direction == "BUY":

                if stop >= entry:

                    errors.append(
                        "BUY stop-loss must be below entry."
                    )

                elif target <= entry:

                    errors.append(
                        "BUY take-profit must be above entry."
                    )

                else:

                    checks_passed.append(
                        "BUY price structure is valid."
                    )

            elif direction == "SELL":

                if stop <= entry:

                    errors.append(
                        "SELL stop-loss must be above entry."
                    )

                elif target >= entry:

                    errors.append(
                        "SELL take-profit must be below entry."
                    )

                else:

                    checks_passed.append(
                        "SELL price structure is valid."
                    )

        # ====================================================
        # 10. REWARD / RISK
        # ====================================================

        reward_risk = getattr(
            trade_plan,
            "reward_risk",
            None,
        )

        if (
            reward_risk is None
            or reward_risk < 1.5
        ):

            errors.append(
                "Reward/risk is below the minimum safety threshold of 1.5."
            )

        else:

            checks_passed.append(
                "Reward/risk meets minimum threshold."
            )

        # ====================================================
        # 11. SPREAD
        # ====================================================

        spread = None

        if broker_result is not None:

            spread = getattr(
                broker_result,
                "spread",
                None,
            )

        if spread is None:

            errors.append(
                "Current broker spread is unavailable."
            )

        elif spread > self.max_spread:

            errors.append(
                f"Spread {spread} exceeds maximum allowed spread "
                f"{self.max_spread}."
            )

        else:

            checks_passed.append(
                f"Spread {spread} is within allowed limit."
            )

        # ====================================================
        # 12. OPEN POSITIONS
        # ====================================================

        if open_positions < 0:

            errors.append(
                "Open position count is invalid."
            )

        elif open_positions >= self.max_open_positions:

            errors.append(
                f"Maximum open positions reached: "
                f"{open_positions}/{self.max_open_positions}."
            )

        else:

            checks_passed.append(
                f"Open positions within limit: "
                f"{open_positions}/{self.max_open_positions}."
            )

        # ====================================================
        # 13. DUPLICATE POSITION
        # ====================================================

        if duplicate_position:

            errors.append(
                "Duplicate position protection blocked execution."
            )

        else:

            checks_passed.append(
                "No duplicate position detected."
            )

        # ====================================================
        # 14. DAILY LOSS LIMIT
        # ====================================================

        if daily_loss_percent < 0:

            errors.append(
                "Daily loss percentage cannot be negative."
            )

        elif (
            daily_loss_percent
            >= self.max_daily_loss_percent
        ):

            errors.append(
                f"Daily loss limit reached: "
                f"{daily_loss_percent}% / "
                f"{self.max_daily_loss_percent}%."
            )

        else:

            checks_passed.append(
                f"Daily loss within limit: "
                f"{daily_loss_percent}%."
            )

        # ====================================================
        # 15. DRY RUN SAFETY
        # ====================================================

        if self.require_dry_run:

            if not dry_run:

                errors.append(
                    "Safety gate requires DRY-RUN mode."
                )

            else:

                checks_passed.append(
                    "DRY-RUN safety requirement satisfied."
                )

        else:

            warnings.append(
                "DRY-RUN requirement is disabled."
            )

        # ====================================================
        # FINAL DECISION
        # ====================================================

        if errors:

            return ExecutionSafetyResult(

                allowed=False,

                symbol=symbol,

                direction=direction,

                reason=(
                    "FINAL EXECUTION SAFETY GATE "
                    "REJECTED THE TRADE."
                ),

                checks_passed=checks_passed,

                errors=errors,

                warnings=warnings,
            )

        return ExecutionSafetyResult(

            allowed=True,

            symbol=symbol,

            direction=direction,

            reason=(
                "FINAL EXECUTION SAFETY GATE "
                "PASSED ALL CHECKS."
            ),

            checks_passed=checks_passed,

            errors=[],

            warnings=warnings,
        )