from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class TradeLifecycle(str, Enum):
    PLANNED = "PLANNED"
    READY = "READY"
    OPEN = "OPEN"
    PROTECTED = "PROTECTED"
    PARTIAL = "PARTIAL"
    CLOSED = "CLOSED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"


@dataclass
class ManagedTrade:
    symbol: str
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    state: TradeLifecycle = TradeLifecycle.PLANNED
    initial_risk: float = 0.0
    realized_r: float = 0.0


class TradeManager:
    """State machine only. Does not place broker orders."""

    def __init__(self):
        self.trades = {}

    def register(self, trade_id: str, trade: ManagedTrade):
        if trade_id in self.trades:
            raise ValueError(f"Duplicate trade id: {trade_id}")
        self.trades[trade_id] = trade

    def transition(self, trade_id: str, state: TradeLifecycle):
        trade = self.trades[trade_id]

        allowed = {
            TradeLifecycle.PLANNED: {
                TradeLifecycle.READY,
                TradeLifecycle.CANCELLED,
                TradeLifecycle.REJECTED,
            },
            TradeLifecycle.READY: {
                TradeLifecycle.OPEN,
                TradeLifecycle.CANCELLED,
                TradeLifecycle.REJECTED,
            },
            TradeLifecycle.OPEN: {
                TradeLifecycle.PROTECTED,
                TradeLifecycle.PARTIAL,
                TradeLifecycle.CLOSED,
            },
            TradeLifecycle.PROTECTED: {
                TradeLifecycle.PARTIAL,
                TradeLifecycle.CLOSED,
            },
            TradeLifecycle.PARTIAL: {
                TradeLifecycle.PROTECTED,
                TradeLifecycle.CLOSED,
            },
            TradeLifecycle.CLOSED: set(),
            TradeLifecycle.CANCELLED: set(),
            TradeLifecycle.REJECTED: set(),
        }

        if state not in allowed[trade.state]:
            raise ValueError(
                f"Invalid transition {trade.state} -> {state}"
            )

        trade.state = state
        return trade

    def get(self, trade_id: str) -> Optional[ManagedTrade]:
        return self.trades.get(trade_id)

    def active(self):
        return {
            key: value
            for key, value in self.trades.items()
            if value.state in {
                TradeLifecycle.READY,
                TradeLifecycle.OPEN,
                TradeLifecycle.PROTECTED,
                TradeLifecycle.PARTIAL,
            }
        }
