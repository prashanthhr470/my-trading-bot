import json
from datetime import datetime, timezone


# ============================================================
# XAUUSD NEWS KEYWORDS
# ============================================================

DIRECT_GOLD_KEYWORDS = [
    "gold",
    "xau",
    "bullion",
    "gold price",
    "gold prices",
    "gold futures",
    "gold market",
]


USD_MACRO_KEYWORDS = [
    "federal reserve",
    "fed",
    "fed chair",
    "interest rate",
    "interest rates",
    "inflation",
    "treasury yield",
    "treasury yields",
    "us dollar",
    "usd",
    "dxy",
    "jolts",
    "ism",
    "employment",
    "jobs report",
    "nonfarm",
    "nonfarm payroll",
    "nfp",
    "fomc",
    "fed funds",
    "fed policy",
]


GEOPOLITICAL_KEYWORDS = [
    "war",
    "iran",
    "israel",
    "middle east",
    "attack",
    "missile",
    "military",
    "geopolitical",
    "geopolitics",
    "conflict",
    "strike",
    "strikes",
    "hormuz",
    "sanctions",
]


RISK_SENTIMENT_KEYWORDS = [
    "risk sentiment",
    "safe haven",
    "equities",
    "stocks",
    "global markets",
    "risk appetite",
    "risk aversion",
    "selloff",
    "sell-off",
]


MACRO_KEYWORDS = [
    "gdp",
    "pmi",
    "retail sales",
    "central bank",
    "monetary policy",
    "economic data",
    "economic growth",
    "economic activity",
]


# ============================================================
# HIGH IMPACT KEYWORDS
# ============================================================

HIGH_IMPACT_KEYWORDS = [
    "breaking",
    "urgent",
    "surprise",
    "unexpected",
    "emergency",
    "rate decision",
    "interest rate decision",
    "fed decision",
    "fomc",
    "fed chair",
    "nonfarm payroll",
    "nfp",
    "jobs report",
    "inflation",
    "cpi",
    "pce",
    "war",
    "attack",
    "missile",
    "military",
    "strike",
    "strikes",
    "iran",
    "hormuz",
    "geopolitical",
    "sanctions",
]


# ============================================================
# PARSER
# ============================================================

def extract_news_from_mcp(content):
    """
    Convert cTrader MCP news response
    into a normal Python list.
    """

    for item in content:

        if not hasattr(item, "text"):
            continue

        try:
            data = json.loads(item.text)

        except (TypeError, json.JSONDecodeError):
            continue

        if isinstance(data, dict):

            news = data.get("news", [])

            if isinstance(news, list):
                return news

        if isinstance(data, list):
            return data

    return []


# ============================================================
# HELPERS
# ============================================================

def _combined_text(item):
    title = item.get("title", "") or ""
    summary = item.get("summary", "") or ""

    return f"{title} {summary}".lower()


def _contains_any(text, keywords):
    return any(
        keyword in text
        for keyword in keywords
    )


def _parse_timestamp(timestamp):

    if not timestamp:
        return None

    try:

        value = timestamp

        if value.endswith("Z"):
            value = value[:-1] + "+00:00"

        parsed = datetime.fromisoformat(value)

        if parsed.tzinfo is None:
            parsed = parsed.replace(
                tzinfo=timezone.utc
            )

        return parsed

    except (TypeError, ValueError):
        return None


# ============================================================
# NEWS CLASSIFICATION
# ============================================================

def classify_news(news_items):
    """
    Classify news according to relevance for XAUUSD.

    This function DOES NOT predict BUY or SELL.
    """

    results = []

    for item in news_items:

        title = item.get("title", "")
        summary = item.get("summary", "")
        published_at = item.get("publishedAt")

        text = _combined_text(item)

        categories = []

        # ----------------------------------------------------
        # GOLD
        # ----------------------------------------------------

        if _contains_any(
            text,
            DIRECT_GOLD_KEYWORDS
        ):
            categories.append("direct_gold")

        # ----------------------------------------------------
        # USD / FED
        # ----------------------------------------------------

        if _contains_any(
            text,
            USD_MACRO_KEYWORDS
        ):
            categories.append("usd_macro")

        # ----------------------------------------------------
        # GEOPOLITICAL
        # ----------------------------------------------------

        if _contains_any(
            text,
            GEOPOLITICAL_KEYWORDS
        ):
            categories.append("geopolitical")

        # ----------------------------------------------------
        # RISK SENTIMENT
        # ----------------------------------------------------

        if _contains_any(
            text,
            RISK_SENTIMENT_KEYWORDS
        ):
            categories.append("risk_sentiment")

        # ----------------------------------------------------
        # GENERAL MACRO
        # ----------------------------------------------------

        if _contains_any(
            text,
            MACRO_KEYWORDS
        ):
            categories.append("macro")

        # ----------------------------------------------------
        # RELEVANCE
        # ----------------------------------------------------

        if "direct_gold" in categories:

            relevance = "HIGH"

        elif (
            "usd_macro" in categories
            or "geopolitical" in categories
        ):

            relevance = "MEDIUM"

        elif (
            "risk_sentiment" in categories
            or "macro" in categories
        ):

            relevance = "LOW"

        else:

            relevance = "NONE"

        # ----------------------------------------------------
        # KEEP RELEVANT NEWS
        # ----------------------------------------------------

        if relevance != "NONE":

            results.append({
                "title": title,
                "summary": summary,
                "publishedAt": published_at,
                "categories": sorted(
                    set(categories)
                ),
                "relevance": relevance,
            })

    return results


# ============================================================
# NEWS RISK ENGINE
# ============================================================

def analyze_news_risk(
    news_items,
    freshness_minutes=180,
):
    """
    Determine current XAUUSD news risk.

    This function does NOT predict direction.

    It determines whether news conditions
    require caution or trading restriction.
    """

    classified = classify_news(
        news_items
    )

    now = datetime.now(
        timezone.utc
    )

    recent_items = []
    stale_items = []

    high_relevance_count = 0
    high_impact_count = 0
    geopolitical_count = 0
    gold_count = 0
    usd_macro_count = 0

    for item in classified:

        published_at = item.get(
            "publishedAt"
        )

        parsed_time = _parse_timestamp(
            published_at
        )

        age_minutes = None
        is_recent = True

        if parsed_time is not None:

            age_minutes = (
                now - parsed_time
            ).total_seconds() / 60

            is_recent = (
                age_minutes >= 0
                and age_minutes <= freshness_minutes
            )

        text = (
            item.get("title", "")
            + " "
            + item.get("summary", "")
        ).lower()

        high_impact = _contains_any(
            text,
            HIGH_IMPACT_KEYWORDS
        )

        categories = item.get(
            "categories",
            []
        )

        if item.get("relevance") == "HIGH":
            high_relevance_count += 1

        if high_impact:
            high_impact_count += 1

        if "geopolitical" in categories:
            geopolitical_count += 1

        if "direct_gold" in categories:
            gold_count += 1

        if "usd_macro" in categories:
            usd_macro_count += 1

        enriched = {
            **item,
            "recent": is_recent,
            "high_impact": high_impact,
            "age_minutes": age_minutes,
        }

        if is_recent:
            recent_items.append(enriched)
        else:
            stale_items.append(enriched)

    # ========================================================
    # FINAL NEWS STATE
    # ========================================================

    if not news_items:

        status = "UNAVAILABLE"
        risk_level = "UNKNOWN"
        trading_restriction = True

        reason = (
            "News data is unavailable. "
            "The system cannot assume that "
            "news conditions are safe."
        )

    elif not recent_items:

        status = "STALE"
        risk_level = "UNKNOWN"
        trading_restriction = True

        reason = (
            "No relevant recent news was found "
            f"inside the {freshness_minutes}-minute window."
        )

    elif (
        high_impact_count > 0
        and (
            geopolitical_count > 0
            or gold_count > 0
            or usd_macro_count > 0
        )
    ):

        status = "HIGH_RISK"
        risk_level = "HIGH"
        trading_restriction = True

        reason = (
            "Recent high-impact news is relevant "
            "to gold, USD macro conditions, "
            "or geopolitical risk."
        )

    elif (
        high_relevance_count > 0
        or usd_macro_count > 0
    ):

        status = "CAUTION"
        risk_level = "MEDIUM"
        trading_restriction = False

        reason = (
            "Recent news is relevant to XAUUSD "
            "or USD macro conditions. Stronger "
            "technical confirmation is required."
        )

    else:

        status = "NORMAL"
        risk_level = "LOW"
        trading_restriction = False

        reason = (
            "No significant recent XAUUSD "
            "news risk was detected."
        )

    return {
        "available": bool(news_items),

        "status": status,

        "risk_level": risk_level,

        "trading_restriction":
            trading_restriction,

        "reason": reason,

        "total_news":
            len(news_items),

        "classified_news":
            len(classified),

        "recent_news":
            len(recent_items),

        "stale_news":
            len(stale_items),

        "high_relevance_count":
            high_relevance_count,

        "high_impact_count":
            high_impact_count,

        "geopolitical_count":
            geopolitical_count,

        "gold_count":
            gold_count,

        "usd_macro_count":
            usd_macro_count,

        "recent_items":
            recent_items,
    }