"""Deterministic market/news sentiment engine for HAFNOT.

This module produces directional sentiment only from supplied evidence.
It never places trades and never converts sentiment into an automatic order.
"""
from __future__ import annotations
from typing import Any, Dict, Iterable, List


POSITIVE_WORDS = {
    "bullish", "strength", "strong", "higher", "support", "dovish",
    "easing", "growth", "beat", "beats", "positive", "safe haven",
    "risk aversion", "demand",
}
NEGATIVE_WORDS = {
    "bearish", "weak", "lower", "resistance", "hawkish", "tightening",
    "recession", "miss", "misses", "negative", "selloff", "risk appetite",
}


def _text(item: Any) -> str:
    if isinstance(item, str):
        return item.lower()
    if isinstance(item, dict):
        return " ".join(
            str(item.get(k, "") or "")
            for k in ("title", "summary", "headline", "text", "reasoning", "reason")
        ).lower()
    return str(item).lower()


def _score_text(text: str) -> float:
    score = 0.0
    for word in POSITIVE_WORDS:
        if word in text:
            score += 1.0
    for word in NEGATIVE_WORDS:
        if word in text:
            score -= 1.0
    return max(-1.0, min(1.0, score / 5.0))


def _weighted(values: Iterable[float], weights: Iterable[float]) -> float:
    pairs = [(float(v), float(w)) for v, w in zip(values, weights) if w > 0]
    if not pairs:
        return 0.0
    return sum(v * w for v, w in pairs) / sum(w for _, w in pairs)


def analyze_sentiment(
    *,
    news: Any = None,
    fundamentals: Any = None,
    market: Any = None,
) -> Dict[str, Any]:
    """Return a conservative, explainable sentiment snapshot."""
    components: List[Dict[str, Any]] = []

    if isinstance(news, dict):
        risk = str(news.get("status", news.get("risk_status", "NORMAL"))).upper()
        items = news.get("items", news.get("classified_news", news.get("news", [])))
        if not isinstance(items, list):
            items = []
        score = _weighted(
            [_score_text(_text(x)) for x in items[:50]],
            [1.0] * min(len(items), 50),
        )
        components.append({
            "source": "news",
            "score": score,
            "status": risk,
            "sample_count": min(len(items), 50),
        })

    if isinstance(fundamentals, dict):
        snapshot = fundamentals.get("snapshot", fundamentals)
        currency_scores = snapshot.get("currency_scores", {}) if isinstance(snapshot, dict) else {}
        if isinstance(currency_scores, dict):
            # For XAUUSD, USD strength is treated as contextual rather than
            # an automatic gold trade signal.
            usd = currency_scores.get("USD", {})
            raw = usd.get("score", 0.0) if isinstance(usd, dict) else usd
            try:
                score = -max(-1.0, min(1.0, float(raw) / 10.0))
            except (TypeError, ValueError):
                score = 0.0
            components.append({"source": "fundamentals", "score": score})

    if isinstance(market, dict):
        texts = []
        for value in market.values():
            if isinstance(value, dict):
                texts.append(_text(value))
        score = _weighted([_score_text(t) for t in texts], [1.0] * len(texts))
        if texts:
            components.append({"source": "market", "score": score, "sample_count": len(texts)})

    score = _weighted(
        [c["score"] for c in components],
        [1.0 if c["source"] != "market" else 0.75 for c in components],
    )
    if score > 0.20:
        direction = "bullish"
    elif score < -0.20:
        direction = "bearish"
    else:
        direction = "neutral"

    high_risk = any(
        str(c.get("status", "")).upper() in {"HIGH_RISK", "STALE"}
        for c in components
    )
    if high_risk:
        confidence = "low"
    elif abs(score) >= 0.55 and len(components) >= 2:
        confidence = "high"
    elif abs(score) >= 0.20:
        confidence = "moderate"
    else:
        confidence = "low"

    return {
        "available": bool(components),
        "direction": direction,
        "score": round(score, 4),
        "confidence": confidence,
        "risk_override": high_risk,
        "components": components,
        "reason": (
            "Sentiment is contextual evidence only; it does not independently "
            "authorize a trade."
        ),
    }
