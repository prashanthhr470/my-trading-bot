"""
HAFNOT AI Trading Agent
Production Agent Runtime

Architecture:

    ToolSelector
        ↓
    AgentOrchestrator
        ↓
    CTraderAgentTools
        ↓
    cTrader MCP
        ↓
    Real read-only market data / analysis

SAFETY:

    DRY_RUN = True
    Live execution = disabled

This runtime is intentionally limited to the
read-only capabilities that are actually provided
by CTraderAgentTools.
"""

from __future__ import annotations

from typing import Any

from app.agent.orchestrator import AgentOrchestrator
from app.agent.ctrader_tools import CTraderAgentTools




# ============================================================
# HAFNOT_SAFE_INTELLIGENCE_HANDOFF_V3
# ============================================================

def _hafnot_prepare_ai_handoff(result, intelligence):
    """
    Safely expose deterministic intelligence to downstream AI
    evidence construction.

    This function:
      - never invents evidence
      - never overwrites existing available_data
      - never authorizes execution
      - preserves the complete intelligence object in metadata
    """

    try:

        if isinstance(intelligence, dict):

            intel = dict(intelligence)

        elif hasattr(intelligence, "to_dict"):

            intel = dict(intelligence.to_dict())

        elif hasattr(intelligence, "__dict__"):

            intel = dict(vars(intelligence))

        else:

            intel = {}

        if not intel:

            result.metadata["intelligence_handoff"] = {
                "status": "EMPTY",
                "execution_authorized": False,
            }

            return result

        # Preserve the complete deterministic intelligence.
        result.metadata["intelligence"] = intel

        # Canonical downstream evidence fields.
        fields = (
            "market_state",
            "regime",
            "direction",
            "confidence",
            "volatility",
            "higher_timeframe_bias",
            "bullish_timeframes",
            "bearish_timeframes",
            "known_timeframes",
            "timeframes",
            "timeframe_summaries",
            "deterministic_technical_evidence",
            "structure",
            "market_structure",
            "liquidity",
            "sentiment",
            "fundamentals",
            "news",
            "confluence",
            "data_quality",
            "setup",
        )

        for field in fields:

            value = intel.get(field)

            if (
                value is not None
                and value != {}
                and value != []
                and value != ""
            ):

                result.available_data.setdefault(
                    field,
                    value
                )

        # Structure aliases.
        if (
            not result.available_data.get("structure")
            and result.available_data.get("market_structure")
        ):

            result.available_data["structure"] = (
                result.available_data["market_structure"]
            )

        if (
            not result.available_data.get("market_structure")
            and result.available_data.get("structure")
        ):

            result.available_data["market_structure"] = (
                result.available_data["structure"]
            )

        result.metadata["intelligence_handoff"] = {
            "status": "POPULATED",
            "execution_authorized": False,
            "field_count": len(
                [
                    k for k, v in intel.items()
                    if (
                        v is not None
                        and v != {}
                        and v != []
                        and v != ""
                    )
                ]
            ),
        }

    except Exception as exc:

        # Fail closed.
        result.metadata["intelligence_handoff"] = {
            "status": "FAILED_CLOSED",
            "error": str(exc),
            "execution_authorized": False,
        }

    return result


class AgentRuntime:
    """
    Production read-only runtime.

    Responsibilities:
        - create CTraderAgentTools
        - register real read-only executors
        - connect the orchestrator to cTrader
        - enforce DRY_RUN

    It does NOT:
        - make trading decisions
        - calculate risk
        - place orders
        - modify broker positions
        - enable live execution
    """

    def __init__(
        self,
        *,
        dry_run: bool = True,
        max_calls_per_cycle: int = 20,
        max_cycle_seconds: float = 120.0,
    ) -> None:

        # ========================================================
        # HARD SAFETY
        # ========================================================

        if dry_run is not True:
            raise RuntimeError(
                "AgentRuntime currently requires "
                "dry_run=True."
            )

        self.dry_run = True

        # ========================================================
        # REAL CTRADER TOOL ADAPTER
        # ========================================================

        self.ctrader = CTraderAgentTools()

        # ========================================================
        # ORCHESTRATOR
        # ========================================================

        self.orchestrator = AgentOrchestrator(
            max_calls_per_cycle=max_calls_per_cycle,
            max_cycle_seconds=max_cycle_seconds,
            dry_run=True,
            allow_execution=False,
        )

        # ========================================================
        # REGISTER ONLY VERIFIED READ-ONLY TOOLS
        # ========================================================

        self._register_tools()

    # ============================================================
    # TOOL REGISTRATION
    # ============================================================

    def _register_tools(self) -> None:
        """
        Register only the cTraderAgentTools methods that belong
        to the current read-only adapter.
        """

        self.orchestrator.register_executor(
            "get_spot_prices",
            self._get_spot_prices,
        )


        self.orchestrator.register_executor(
            "assess_data_quality",
            self._assess_data_quality,
        )

        self.orchestrator.register_executor(
            "analyze_sentiment",
            self._analyze_sentiment,
        )
        self.orchestrator.register_executor(
            "get_account",
            self._get_account,
        )

        self.orchestrator.register_executor(
            "get_positions",
            self._get_positions,
        )

        self.orchestrator.register_executor(
            "get_pending_orders",
            self._get_pending_orders,
        )


        self.orchestrator.register_executor(
            "get_trendbars",
            self._get_trendbars,
        )

        self.orchestrator.register_executor(
            "get_news",
            self._get_news,
        )

        self.orchestrator.register_executor(
            "analyze_market_structure",
            self._analyze_market_structure,
        )

        self.orchestrator.register_executor(
            "analyze_support_resistance",
            self._analyze_support_resistance,
        )

        self.orchestrator.register_executor(
            "analyze_liquidity",
            self._analyze_liquidity,
        )

        self.orchestrator.register_executor(
            "analyze_evidence",
            self._analyze_evidence,
        )

        self.orchestrator.register_executor(
            "analyze_fundamentals",
            self._analyze_fundamentals,
        )



    # ============================================================
    # ACCOUNT STATE
    # ============================================================

    async def _analyze_sentiment(self, request: Any) -> Any:
        """Build deterministic sentiment from evidence already collected."""

        from app.sentiment_engine import analyze_sentiment

        parameters = self._parameters(request)
        available = parameters.get("_available_data", {})

        news = available.get("news")
        fundamentals = available.get("analyze_fundamentals")

        market = {}

        for key, payload in available.items():
            if key.startswith("bars_"):
                market[key] = payload

        result = analyze_sentiment(
            news=news,
            fundamentals=fundamentals,
            market=market,
        )

        return {
            "available": bool(result.get("available", True)),
            "symbol": self._symbol(request),
            "sentiment": result,
            "source": "app.sentiment_engine",
        }

    async def _run_intelligence_pipeline(
        self,
        symbol: str,
        timeframes: tuple[str, ...],
        available_data: dict[str, Any],
    ) -> dict[str, Any]:
        """Run deterministic market intelligence after data collection."""
        from app.agent.intelligence_pipeline import (
            build_intelligence_result,
        )

        return build_intelligence_result(
            symbol=symbol,
            available_data=available_data,
            timeframes=timeframes,
        )

    async def _assess_data_quality(
        self,
        request: Any,
    ) -> Any:
        """
        Assess quality of market data already collected
        during the current agent cycle.
        """

        from app.core.data_quality import (
            assess_ohlc_quality,
            combine_quality_reports,
        )

        parameters = self._parameters(request)

        available_data = parameters.get(
            "_available_data",
            {},
        )

        symbol = self._symbol(request)

        reports = []

        for key, payload in available_data.items():

            if not key.startswith(
                "get_trendbars:"
            ):
                continue

            if not isinstance(payload, dict):
                continue

            bars = payload.get("bars")

            if not isinstance(bars, list):
                continue

            timeframe = payload.get(
                "timeframe"
            )

            report = assess_ohlc_quality(
                bars,
                symbol=symbol,
                timeframe=timeframe,
                expected_count=None,
            )

            reports.append(report)

        if not reports:

            return {
                "available": False,
                "symbol": symbol,
                "status": "UNAVAILABLE",
                "reason": (
                    "No OHLC bars were available "
                    "for quality assessment."
                ),
            }

        combined = combine_quality_reports(
            reports,
            source="agent_cycle",
            symbol=symbol,
        )

        return {
            "available": True,
            "symbol": symbol,
            "status": combined.status.value,
            "level": combined.level.value,
            "score": combined.score,
            "sample_count": combined.sample_count,
            "missing_count": combined.missing_count,
            "duplicate_count": combined.duplicate_count,
            "invalid_count": combined.invalid_count,
            "gap_count": combined.gap_count,
            "large_gap_count": combined.large_gap_count,
            "stale_seconds": combined.stale_seconds,
            "issues": list(combined.issues),
            "warnings": list(combined.warnings),
            "checks": dict(combined.checks),
            "source": "app.core.data_quality",
        }


    async def _get_account(
        self,
        request: Any,
    ) -> Any:
        """
        Retrieve read-only trading account state.

        This executor never performs a trading operation.
        """

        return await self.ctrader.get_account()


    async def _get_positions(
        self,
        request: Any,
    ) -> Any:
        """
        Retrieve currently open positions.

        This executor never performs a trading operation.
        """

        return await self.ctrader.get_positions()


    async def _get_pending_orders(
        self,
        request: Any,
    ) -> Any:
        """
        Retrieve currently pending orders.

        This executor never performs a trading operation.
        """

        return await self.ctrader.get_pending_orders()


    # ============================================================
    # REQUEST HELPERS
    # ============================================================

    @staticmethod
    def _parameters(
        request: Any,
    ) -> dict[str, Any]:
        """
        Return request parameters safely.
        """

        parameters = getattr(
            request,
            "parameters",
            None,
        )

        if isinstance(parameters, dict):
            return dict(parameters)

        return {}

    @classmethod
    def _symbol(
        cls,
        request: Any,
    ) -> str | None:
        """
        Extract symbol from request.
        """

        symbol = getattr(
            request,
            "symbol",
            None,
        )

        if symbol:
            return str(symbol).upper()

        parameters = cls._parameters(
            request
        )

        symbol = parameters.get(
            "symbol"
        )

        if symbol:
            return str(symbol).upper()

        return None

    @classmethod
    def _timeframe(
        cls,
        request: Any,
    ) -> str | None:
        """
        Extract timeframe from request.
        """

        timeframe = getattr(
            request,
            "timeframe",
            None,
        )

        if timeframe:
            return str(timeframe).upper()

        parameters = cls._parameters(
            request
        )

        timeframe = parameters.get(
            "timeframe"
        )

        if timeframe:
            return str(timeframe).upper()

        return None

    # ============================================================
    # SPOT
    # ============================================================

    async def _get_spot_prices(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)

        if not symbol:
            raise ValueError(
                "get_spot_prices requires a symbol."
            )

        return await self.ctrader.get_spot_prices(
            symbol
        )

    # ============================================================
    # HISTORICAL BARS
    # ============================================================

    async def _get_trendbars(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)
        timeframe = self._timeframe(request)

        if not symbol:
            raise ValueError(
                "get_trendbars requires a symbol."
            )

        if not timeframe:
            raise ValueError(
                "get_trendbars requires a timeframe."
            )

        parameters = self._parameters(
            request
        )

        hours = parameters.get(
            "hours"
        )

        limit = parameters.get(
            "limit",
            200,
        )

        kwargs = {
            "symbol": symbol,
            "timeframe": timeframe,
            "limit": int(limit),
        }

        if hours is not None:
            kwargs["hours"] = int(hours)

        return await self.ctrader.get_trendbars(
            **kwargs
        )

    # ============================================================
    # NEWS
    # ============================================================

    async def _get_news(
        self,
        request: Any,
    ) -> Any:

        parameters = self._parameters(
            request
        )

        feed = str(
            parameters.get(
                "feed",
                "general",
            )
        )

        limit = int(
            parameters.get(
                "limit",
                50,
            )
        )

        return await self.ctrader.get_news(
            feed=feed,
            limit=limit,
        )

    # ============================================================
    # MARKET STRUCTURE
    # ============================================================

    async def _analyze_market_structure(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)
        timeframe = self._timeframe(request)

        if not symbol:
            raise ValueError(
                "analyze_market_structure requires "
                "a symbol."
            )

        if not timeframe:
            raise ValueError(
                "analyze_market_structure requires "
                "a timeframe."
            )

        bars_result = await self.ctrader.get_trendbars(
            symbol=symbol,
            timeframe=timeframe,
            limit=200,
        )

        bars = (
            bars_result.get("bars", [])
            if isinstance(bars_result, dict)
            else []
        )

        return self.ctrader.analyze_structure(
            bars=bars,
        )

    # ============================================================
    # SUPPORT / RESISTANCE
    # ============================================================

    async def _analyze_support_resistance(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)
        timeframe = self._timeframe(request)

        if not symbol:
            raise ValueError(
                "analyze_support_resistance requires "
                "a symbol."
            )

        if not timeframe:
            raise ValueError(
                "analyze_support_resistance requires "
                "a timeframe."
            )

        bars_result = await self.ctrader.get_trendbars(
            symbol=symbol,
            timeframe=timeframe,
            limit=200,
        )

        bars = (
            bars_result.get("bars", [])
            if isinstance(bars_result, dict)
            else []
        )

        return self.ctrader.analyze_support_resistance(
            bars=bars,
        )


    # ============================================================
    # LIQUIDITY
    # ============================================================

    async def _analyze_liquidity(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)

        if not symbol:
            raise ValueError(
                "analyze_liquidity requires "
                "a symbol."
            )

        spot_result = await self.ctrader.get_spot_prices(
            symbol=symbol,
        )

        current_price = None

        if isinstance(spot_result, dict):
            current_price = spot_result.get(
                "current_price"
            )

            if current_price is None:
                current_price = spot_result.get(
                    "bid"
                )

        m5_result = await self.ctrader.get_trendbars(
            symbol=symbol,
            timeframe="M5",
            limit=200,
        )

        daily_result = await self.ctrader.get_trendbars(
            symbol=symbol,
            timeframe="D1",
            limit=200,
        )

        m5_bars = (
            m5_result.get("bars", [])
            if isinstance(m5_result, dict)
            else []
        )

        daily_bars = (
            daily_result.get("bars", [])
            if isinstance(daily_result, dict)
            else []
        )

        return self.ctrader.analyze_liquidity(
            m5_bars=m5_bars,
            daily_bars=daily_bars,
            current_price=current_price,
        )

    # ============================================================
    # EVIDENCE
    # ============================================================

    async def _analyze_evidence(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)

        if not symbol:
            raise ValueError(
                "analyze_evidence requires "
                "a symbol."
            )

        parameters = self._parameters(request)

        available_data = parameters.get(
            "_available_data",
            {},
        )

        if not isinstance(
            available_data,
            dict,
        ):
            raise ValueError(
                "analyze_evidence received "
                "invalid available_data."
            )

        # ========================================================
        # 1. MULTI-TIMEFRAME SUMMARIES
        # ========================================================

        timeframe_summaries = {}

        for timeframe in (
            "H4",
            "H1",
            "M15",
            "M5",
        ):
            data = available_data.get(
                f"bars_{timeframe.lower()}",
            )

            if not isinstance(data, dict):
                continue

            bars = data.get(
                "bars",
                [],
            )

            if not bars:
                continue

            timeframe_result = (
                self.ctrader.analyze_timeframe(
                    bars=bars,
                    timeframe=timeframe,
                )
            )

            if isinstance(
                timeframe_result,
                dict,
            ):
                summary = (
                    timeframe_result.get(
                        "summary"
                    )
                    or timeframe_result
                )

                timeframe_summaries[
                    timeframe.lower()
                ] = summary

        # ========================================================
        # 2. MARKET STATE
        # ========================================================

        from app.market_state import (
            determine_market_state,
        )

        market_state = (
            determine_market_state(
                timeframe_summaries
            )
            if timeframe_summaries
            else {}
        )

        # ========================================================
        # 3. STRUCTURE
        # ========================================================

        structure_result = available_data.get(
            "analyze_market_structure",
            {},
        )

        if isinstance(
            structure_result,
            dict,
        ):
            structure = (
                structure_result.get(
                    "structure",
                    structure_result,
                )
            )
        else:
            structure = {}

        # ========================================================
        # 4. SUPPORT / RESISTANCE
        # ========================================================

        sr_result = available_data.get(
            "analyze_support_resistance",
            {},
        )

        if isinstance(
            sr_result,
            dict,
        ):
            support_levels = sr_result.get(
                "support",
                [],
            )

            resistance_levels = sr_result.get(
                "resistance",
                [],
            )
        else:
            support_levels = []
            resistance_levels = []

        # ========================================================
        # 5. LIQUIDITY
        # ========================================================

        liquidity_result = available_data.get(
            "analyze_liquidity",
            {},
        )

        if isinstance(
            liquidity_result,
            dict,
        ):
            liquidity_evidence = (
                liquidity_result.get(
                    "liquidity",
                    liquidity_result,
                )
            )
        else:
            liquidity_evidence = {}

        # ========================================================
        # 6. NEWS
        # ========================================================

        news_result = available_data.get(
            "news",
            {},
        )

        if isinstance(
            news_result,
            dict,
        ):
            news_analysis = news_result.get(
                "analysis",
                news_result,
            )
        else:
            news_analysis = news_result

        # ========================================================
        # 7. FUNDAMENTALS
        # ========================================================

        fundamental_evidence = (
            available_data.get(
                "analyze_fundamentals",
                None,
            )
        )

        # ========================================================
        # 8. BUILD COMPLETE EVIDENCE
        # ========================================================

        return self.ctrader.analyze_evidence(
            market_state=market_state,
            timeframe_summaries=timeframe_summaries,
            structure=structure,
            support_levels=support_levels,
            resistance_levels=resistance_levels,
            news_analysis=news_analysis,
            liquidity_evidence=liquidity_evidence,
            fundamental_evidence=fundamental_evidence,
        )

    # ============================================================
    # FUNDAMENTALS
    # ============================================================

    async def _analyze_fundamentals(
        self,
        request: Any,
    ) -> Any:

        symbol = self._symbol(request)

        if not symbol:
            raise ValueError(
                "analyze_fundamentals requires a symbol."
            )

        from app.fundamental_engine import (
            fetch_forex_factory_calendar,
            build_fundamental_snapshot,
        )

        events, reconciliation = (
            fetch_forex_factory_calendar()
        )

        snapshot = build_fundamental_snapshot(
            events,
            reconciliation,
        )

        return {
            "available": True,
            "symbol": symbol,
            "snapshot": snapshot,
        }

    # ============================================================
    # RUN ONE AGENT CYCLE
    # ============================================================

    async def run_cycle(
        self,
        *,
        symbol: str,
        timeframes: tuple[str, ...] = (
            "H4",
            "H1",
            "M15",
            "M5",
        ),
        needs: Any = None,
    ) -> Any:
        """
        Run one real read-only agent cycle.
        """

        if not self.dry_run:
            raise RuntimeError(
                "Live execution is disabled."
            )

        result = await self.orchestrator.run_cycle(
            symbol=symbol.upper(),
            timeframes=timeframes,
            needs=needs,
        )

        try:
            intelligence = await self._run_intelligence_pipeline(
                symbol=symbol.upper(),
                timeframes=timeframes,
                available_data=result.available_data,
            )

            result.metadata["intelligence"] = intelligence

        except Exception as exc:
            intelligence = {
                "available": False,
                "error": f"{type(exc).__name__}: {exc}",
                "trade_authorized": False,
                "execution_allowed": False,
                "read_only": True,
            }

            result.metadata["intelligence"] = intelligence

        # Batch 4: AI reasoning.
        # AI is advisory only. Python remains authoritative.
        # No live execution is permitted.
        try:
            ai_reasoning = await self._run_ai_reasoning(
                symbol=symbol.upper(),
                intelligence=intelligence,
            )

            result.metadata["ai_reasoning"] = ai_reasoning

        except Exception as exc:
            result.metadata["ai_reasoning"] = {
                "available": False,
                "error": f"{type(exc).__name__}: {exc}",
                "trade_authorized": False,
                "execution_allowed": False,
                "read_only": True,
            }

        return result

    # ============================================================
    # SAFETY STATUS
    # ============================================================


    async def _run_ai_reasoning(
        self,
        *,
        symbol: str,
        intelligence: dict,
    ) -> dict:
        """
        Batch 4 AI reasoning bridge.

        AI is advisory only.
        Python remains authoritative.
        No execution is performed here.
        """

        from app.ai.reasoning_engine import (
            run_ai_reasoning,
        )

        return run_ai_reasoning(
            symbol=symbol,
            intelligence=intelligence,
        )

    def status(self) -> dict[str, Any]:
        """
        Return runtime safety state.
        """

        execution_tools = []

        for tool in (
            self.orchestrator.registry.all_tools()
        ):
            permission = getattr(
                tool,
                "permission",
                None,
            )

            permission_value = getattr(
                permission,
                "value",
                permission,
            )

            if str(
                permission_value
            ).upper() == "EXECUTION":
                execution_tools.append(
                    tool.name
                )

        return {
            "runtime": "AgentRuntime",
            "dry_run": True,
            "allow_execution": False,
            "execution_tools_registered": (
                execution_tools
            ),
            "execution_enabled": False,
        }


# ================================================================
# FACTORY
# ================================================================

def build_agent_runtime() -> AgentRuntime:
    """
    Build the production read-only runtime.
    """

    return AgentRuntime(
        dry_run=True,
        max_calls_per_cycle=20,
        max_cycle_seconds=120.0,
    )


__all__ = [
    "AgentRuntime",
    "build_agent_runtime",
]