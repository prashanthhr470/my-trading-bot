from app.sentiment_engine import analyze_sentiment
from app.market_regime import classify_market_regime
from app.market_context import build_market_context
from app.confluence_engine import score_confluence


def test_sentiment():
    out = analyze_sentiment(
        news={"status": "NORMAL", "items": [{"title": "bullish strength"}]},
    )
    assert out["available"] is True
    assert out["direction"] == "bullish"


def test_regime():
    out = classify_market_regime({
        "H4": {"trend": "bearish"},
        "H1": {"trend": "bearish"},
        "M15": {"trend": "bearish"},
        "M5": {"trend": "neutral"},
    })
    assert out["regime"] == "TREND_BEAR"


def test_context_and_confluence():
    ctx = build_market_context(
        symbol="XAUUSD",
        timeframe_summaries={"H4": {"trend": "bullish"}, "H1": {"trend": "bullish"}},
        structure={"structure": "bullish"},
        sentiment={"direction": "bullish", "risk_override": False},
        setup={"direction": "bullish"},
    )
    out = score_confluence(ctx)
    assert out["dominant_direction"] == "bullish"
    assert out["trade_authorized"] is False
