﻿"""
HAFNOT AI Trading Agent
Agent Orchestrator

Purpose
-------
Central coordinator for the intelligent agent.

The orchestrator controls the lifecycle of an agent analysis
cycle:

    Goal
      â†“
    Requirements
      â†“
    Tool Selection
      â†“
    Tool Execution Adapter
      â†“
    Results
      â†“
    State Update
      â†“
    Next Selection
      â†“
    Final Cycle Result

Important safety rule
---------------------
This orchestrator does NOT directly place broker orders.

Execution remains protected by:

    AI
      â†“
    Validator
      â†“
    Decision Gate
      â†“
    Risk Management
      â†“
    Trade Plan
      â†“
    Broker Validation
      â†“
    Execution Safety
      â†“
    Broker

DRY-RUN remains the default.

This module is deliberately independent from the existing
analysis engines. Integration adapters can be attached without
rewriting the orchestrator itself.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Iterable, Mapping, Optional

from app.agent.tool_registry import (
    ToolDefinition,
    ToolPermission,
    ToolRegistry,
    ToolStatus,
    DEFAULT_TOOL_REGISTRY,
)

from app.agent.tool_selector import (
    AgentToolContext,
    InformationNeed,
    RequestPriority,
    ToolSelectionRequest,
    ToolSelectionResult,
    ToolSelector,
    build_standard_analysis_needs,
    build_tool_selector,
)


# ============================================================
# TYPES
# ============================================================


ToolExecutor = Callable[
    [ToolSelectionRequest],
    Awaitable[Any],
]


class CycleStatus(str, Enum):
    """Overall state of one agent cycle."""

    CREATED = "CREATED"

    RUNNING = "RUNNING"

    COMPLETED = "COMPLETED"

    PARTIAL = "PARTIAL"

    BLOCKED = "BLOCKED"

    FAILED = "FAILED"


class ToolExecutionStatus(str, Enum):
    """Result of executing one selected tool."""

    SUCCESS = "SUCCESS"

    FAILED = "FAILED"

    BLOCKED = "BLOCKED"

    SKIPPED = "SKIPPED"


# ============================================================
# TOOL EXECUTION RESULT
# ============================================================


@dataclass(frozen=True)
class ToolExecutionResult:
    """
    Result of one tool execution.

    The orchestrator stores the result but does not interpret
    trading direction from it.
    """

    tool_name: str

    status: ToolExecutionStatus

    duration_seconds: float = 0.0

    data: Any = None

    error: Optional[str] = None

    metadata: Mapping[str, Any] = field(
        default_factory=dict
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "status": self.status.value,
            "duration_seconds": self.duration_seconds,
            "data": self.data,
            "error": self.error,
            "metadata": dict(self.metadata),
        }


# ============================================================
# AGENT CYCLE RESULT
# ============================================================


@dataclass(frozen=True)
class AgentCycleResult:
    """
    Complete output of one orchestrator cycle.
    """

    cycle_id: str

    status: CycleStatus

    symbol: Optional[str]

    started_at: float

    finished_at: float

    duration_seconds: float

    selection: ToolSelectionResult

    executions: tuple[
        ToolExecutionResult,
        ...
    ] = field(
        default_factory=tuple
    )

    available_data: Mapping[str, Any] = field(
        default_factory=dict
    )

    completed_tools: tuple[
        str,
        ...
    ] = field(
        default_factory=tuple
    )

    failed_tools: tuple[
        str,
        ...
    ] = field(
        default_factory=tuple
    )

    errors: tuple[
        str,
        ...
    ] = field(
        default_factory=tuple
    )

    metadata: Mapping[str, Any] = field(
        default_factory=dict
    )

    @property
    def success_count(self) -> int:
        return sum(
            result.status
            == ToolExecutionStatus.SUCCESS
            for result in self.executions
        )

    @property
    def failure_count(self) -> int:
        return sum(
            result.status
            == ToolExecutionStatus.FAILED
            for result in self.executions
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "cycle_id": self.cycle_id,
            "status": self.status.value,
            "symbol": self.symbol,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_seconds": self.duration_seconds,
            "selection": self.selection.to_dict(),
            "executions": [
                result.to_dict()
                for result in self.executions
            ],
            "available_data": dict(
                self.available_data
            ),
            "completed_tools": list(
                self.completed_tools
            ),
            "failed_tools": list(
                self.failed_tools
            ),
            "errors": list(self.errors),
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "metadata": dict(self.metadata),
        }


# ============================================================
# ORCHESTRATOR STATE
# ============================================================


@dataclass
class OrchestratorState:
    """
    Mutable internal state for one agent cycle.
    """

    cycle_id: str

    status: CycleStatus = CycleStatus.CREATED

    available_data: dict[str, Any] = field(
        default_factory=dict
    )

    completed_tools: list[str] = field(
        default_factory=list
    )

    failed_tools: list[str] = field(
        default_factory=list
    )

    executions: list[
        ToolExecutionResult
    ] = field(
        default_factory=list
    )

    errors: list[str] = field(
        default_factory=list
    )

    tool_calls: int = 0

    started_at: float = field(
        default_factory=time.monotonic
    )


# ============================================================
# ORCHESTRATOR
# ============================================================


class AgentOrchestrator:
    """
    Central intelligent-agent coordinator.

    The orchestrator owns:
        - cycle state
        - tool selection
        - execution routing
        - tool-call limits
        - multi-timeframe expansion
        - result collection

    It does NOT own:
        - trading decisions
        - risk calculations
        - broker execution
        - AI reasoning
    """

    def __init__(
        self,
        *,
        registry: ToolRegistry = DEFAULT_TOOL_REGISTRY,
        selector: Optional[ToolSelector] = None,
        tool_executors: Optional[
            Mapping[str, ToolExecutor]
        ] = None,
        max_calls_per_cycle: int = 20,
        max_cycle_seconds: float = 120.0,
        dry_run: bool = True,
        allow_execution: bool = False,
    ) -> None:

        if max_calls_per_cycle <= 0:
            raise ValueError(
                "max_calls_per_cycle must be greater than 0."
            )

        if max_cycle_seconds <= 0:
            raise ValueError(
                "max_cycle_seconds must be greater than 0."
            )

        self.registry = registry

        self.selector = (
            selector
            if selector is not None
            else build_tool_selector(
                registry,
                max_calls_per_cycle=(
                    max_calls_per_cycle
                ),
            )
        )

        self.tool_executors: dict[
            str,
            ToolExecutor,
        ] = dict(
            tool_executors or {}
        )

        self.max_calls_per_cycle = (
            max_calls_per_cycle
        )

        self.max_cycle_seconds = (
            max_cycle_seconds
        )

        self.dry_run = dry_run

        self.allow_execution = (
            allow_execution
        )

        # ----------------------------------------------------
        # Absolute safety:
        # execution is impossible while DRY-RUN is enabled.
        # ----------------------------------------------------

        if self.dry_run:
            self.allow_execution = False

    # ========================================================
    # EXECUTOR REGISTRATION
    # ========================================================

    def register_executor(
        self,
        tool_name: str,
        executor: ToolExecutor,
    ) -> None:
        """
        Attach an implementation to a registered tool.
        """

        if not self.registry.exists(
            tool_name
        ):
            raise KeyError(
                f"Cannot register executor for "
                f"unknown tool: {tool_name}"
            )

        if not callable(executor):
            raise TypeError(
                "executor must be callable."
            )

        self.tool_executors[
            tool_name
        ] = executor

    # ========================================================
    # CYCLE
    # ========================================================

    async def run_cycle(
        self,
        *,
        symbol: Optional[str] = None,
        timeframes: Iterable[str] = (),
        needs: Optional[
            Iterable[InformationNeed]
        ] = None,
        available_data: Optional[
            Mapping[str, Any]
        ] = None,
        completed_tools: Iterable[str] = (),
        failed_tools: Iterable[str] = (),
        account_available: bool = False,
        existing_positions: bool = False,
        existing_pending_orders: bool = False,
        market_open: Optional[bool] = None,
        cycle_id: Optional[str] = None,
    ) -> AgentCycleResult:
        """
        Execute one complete agent orchestration cycle.
        """

        cycle_id = (
            cycle_id
            if cycle_id
            else self._make_cycle_id()
        )

        state = OrchestratorState(
            cycle_id=cycle_id,
            available_data=dict(
                available_data or {}
            ),
            completed_tools=list(
                completed_tools
            ),
            failed_tools=list(
                failed_tools
            ),
        )

        state.status = CycleStatus.RUNNING

        timeframe_tuple = tuple(
            timeframes
        )

        context = AgentToolContext(
            symbol=symbol,
            timeframes=timeframe_tuple,
            available_data=(
                state.available_data
            ),
            completed_tools=tuple(
                state.completed_tools
            ),
            failed_tools=tuple(
                state.failed_tools
            ),
            dry_run=self.dry_run,
            allow_execution=(
                self.allow_execution
            ),
            account_available=(
                account_available
            ),
            existing_positions=(
                existing_positions
            ),
            existing_pending_orders=(
                existing_pending_orders
            ),
            market_open=market_open,
        )

        requested_needs = tuple(
            needs
            if needs is not None
            else build_standard_analysis_needs()
        )

        # ----------------------------------------------------
        # Select tools
        # ----------------------------------------------------

        selection = self.selector.select(
            requested_needs,
            context=context,
        )

        # ----------------------------------------------------
        # Expand multi-timeframe requests.
        #
        # The selector creates one logical request.
        # The orchestrator expands it into actual requests
        # for each requested timeframe.
        # ----------------------------------------------------

        expanded_requests = (
            self._expand_requests(
                selection.requests,
                timeframe_tuple,
            )
        )

        selection = self._replace_selection_requests(
            selection,
            expanded_requests,
        )

        # ----------------------------------------------------
        # Execute selected tools
        # ----------------------------------------------------

        for request in expanded_requests:

            if self._cycle_expired(
                state.started_at
            ):
                state.errors.append(
                    "Agent cycle time budget exceeded."
                )

                break

            if (
                state.tool_calls
                >= self.max_calls_per_cycle
            ):
                state.errors.append(
                    "Agent tool-call budget exceeded."
                )

                break

            result = await self._execute_request(
                request,
                state,
            )

            state.executions.append(
                result
            )

            state.tool_calls += 1

            if (
                result.status
                == ToolExecutionStatus.SUCCESS
            ):
                if (
                    request.tool_name
                    not in state.completed_tools
                ):
                    state.completed_tools.append(
                        request.tool_name
                    )

                self._record_result_data(
                    request,
                    result,
                    state,
                )

            elif (
                result.status
                == ToolExecutionStatus.FAILED
            ):
                if (
                    request.tool_name
                    not in state.failed_tools
                ):
                    state.failed_tools.append(
                        request.tool_name
                    )

                if result.error:
                    state.errors.append(
                        f"{request.tool_name}: "
                        f"{result.error}"
                    )

        # ----------------------------------------------------
        # Final state
        # ----------------------------------------------------

        state.status = self._final_status(
            state,
            selection,
        )

        finished_at = time.monotonic()

        return AgentCycleResult(
            cycle_id=cycle_id,
            status=state.status,
            symbol=symbol,
            started_at=state.started_at,
            finished_at=finished_at,
            duration_seconds=(
                finished_at
                - state.started_at
            ),
            selection=selection,
            executions=tuple(
                state.executions
            ),
            available_data=dict(
                state.available_data
            ),
            completed_tools=tuple(
                state.completed_tools
            ),
            failed_tools=tuple(
                state.failed_tools
            ),
            errors=tuple(
                state.errors
            ),
            metadata={
                "dry_run": self.dry_run,
                "allow_execution": (
                    self.allow_execution
                ),
                "tool_calls": state.tool_calls,
                "max_tool_calls": (
                    self.max_calls_per_cycle
                ),
                "max_cycle_seconds": (
                    self.max_cycle_seconds
                ),
            },
        )

    # ========================================================
    # REQUEST EXECUTION
    # ========================================================

    async def _execute_request(
        self,
        request: ToolSelectionRequest,
        state: OrchestratorState,
    ) -> ToolExecutionResult:
        """
        Execute one request through its registered adapter.
        """

        tool = self.registry.get(
            request.tool_name
        )

        if tool is None:
            return ToolExecutionResult(
                tool_name=request.tool_name,
                status=ToolExecutionStatus.BLOCKED,
                error=(
                    "Tool is not registered."
                ),
            )

        # ----------------------------------------------------
        # Permission validation
        # ----------------------------------------------------

        allowed, reason = (
            self.registry.validate_selection(
                tool.name,
                dry_run=self.dry_run,
                allow_execution=(
                    self.allow_execution
                ),
            )
        )

        if not allowed:
            return ToolExecutionResult(
                tool_name=tool.name,
                status=ToolExecutionStatus.BLOCKED,
                error=reason,
            )

        # ----------------------------------------------------
        # Hard execution protection
        # ----------------------------------------------------

        if (
            tool.permission
            == ToolPermission.EXECUTION
        ):
            return ToolExecutionResult(
                tool_name=tool.name,
                status=ToolExecutionStatus.BLOCKED,
                error=(
                    "Execution tools are blocked by "
                    "the orchestrator."
                ),
            )

        # ----------------------------------------------------
        # Missing executor
        # ----------------------------------------------------

        executor = self.tool_executors.get(
            tool.name
        )

        if executor is None:
            return ToolExecutionResult(
                tool_name=tool.name,
                status=ToolExecutionStatus.SKIPPED,
                error=(
                    "No executor registered yet."
                ),
            )

        # ----------------------------------------------------
        # Execute
        # ----------------------------------------------------

        started = time.monotonic()

        try:
            # ------------------------------------------------
            # Provide the executor with the accumulated cycle
            # data without exposing mutable orchestrator state.
            #
            # This allows aggregation tools such as
            # analyze_evidence to consume results produced by
            # earlier tools in the same cycle.
            # ------------------------------------------------

            execution_parameters = dict(
                request.parameters
            )

            execution_parameters[
                "_available_data"
            ] = dict(
                state.available_data
            )

            execution_request = ToolSelectionRequest(
                tool_name=request.tool_name,
                reason=request.reason,
                priority=request.priority,
                symbol=request.symbol,
                timeframe=request.timeframe,
                parameters=execution_parameters,
                dependencies=request.dependencies,
                sequence=request.sequence,
            )

            data = await executor(
                execution_request
            )

            duration = (
                time.monotonic()
                - started
            )

            return ToolExecutionResult(
                tool_name=tool.name,
                status=ToolExecutionStatus.SUCCESS,
                duration_seconds=duration,
                data=data,
            )

        except Exception as exc:
            duration = (
                time.monotonic()
                - started
            )

            return ToolExecutionResult(
                tool_name=tool.name,
                status=ToolExecutionStatus.FAILED,
                duration_seconds=duration,
                error=(
                    f"{type(exc).__name__}: "
                    f"{exc}"
                ),
            )

    # ========================================================
    # MULTI-TIMEFRAME EXPANSION
    # ========================================================

    def _expand_requests(
        self,
        requests: Iterable[
            ToolSelectionRequest
        ],
        timeframes: tuple[str, ...],
    ) -> tuple[
        ToolSelectionRequest,
        ...
    ]:
        """
        Expand all timeframe-sensitive requests.

        Historical bars, structure and liquidity are all
        timeframe-dependent.  Every such logical request is
        expanded into one request per requested timeframe.

        Dependency ordering is handled after expansion so
        aggregation tools such as analyze_evidence only run
        after their upstream evidence exists.
        """

        expanded: list[
            ToolSelectionRequest
        ] = []

        sequence = 1

        for request in requests:

            tool = self.registry.get(
                request.tool_name
            )

            if tool is None:
                continue

            requires_timeframe = bool(
                getattr(
                    tool,
                    "requires_timeframe",
                    False,
                )
            )

            # ------------------------------------------------
            # Expand every timeframe-sensitive tool.
            # ------------------------------------------------

            if (
                requires_timeframe
                and timeframes
            ):

                for timeframe in timeframes:

                    parameters = dict(
                        request.parameters
                    )

                    parameters.pop(
                        "timeframes",
                        None,
                    )

                    parameters[
                        "timeframe"
                    ] = timeframe

                    expanded.append(
                        ToolSelectionRequest(
                            tool_name=request.tool_name,
                            reason=(
                                request.reason
                                + f" Timeframe: "
                                f"{timeframe}."
                            ),
                            priority=request.priority,
                            symbol=request.symbol,
                            timeframe=timeframe,
                            parameters=parameters,
                            dependencies=(
                                request.dependencies
                            ),
                            sequence=sequence,
                        )
                    )

                    sequence += 1

                continue

            # ------------------------------------------------
            # Normal request.
            # ------------------------------------------------

            expanded.append(
                ToolSelectionRequest(
                    tool_name=request.tool_name,
                    reason=request.reason,
                    priority=request.priority,
                    symbol=request.symbol,
                    timeframe=request.timeframe,
                    parameters=dict(
                        request.parameters
                    ),
                    dependencies=(
                        request.dependencies
                    ),
                    sequence=sequence,
                )
            )

            sequence += 1

        # ----------------------------------------------------
        # Dependency-aware stable ordering.
        #
        # A request can execute only after all dependency tool
        # names have completed at least once.
        #
        # This is intentionally deterministic.
        # ----------------------------------------------------

        ordered: list[
            ToolSelectionRequest
        ] = []

        remaining = list(expanded)
        completed_tools: set[str] = set()

        while remaining:

            progress = False

            for request in list(remaining):

                dependencies = set(
                    request.dependencies
                )

                if dependencies.issubset(
                    completed_tools
                ):

                    ordered.append(
                        request
                    )

                    remaining.remove(
                        request
                    )

                    completed_tools.add(
                        request.tool_name
                    )

                    progress = True

            if not progress:
                # Dependency cycle or unresolved dependency.
                # Preserve deterministic order rather than silently
                # dropping requests.
                ordered.extend(
                    remaining
                )
                break

        # Re-number after dependency ordering.
        renumbered: list[
            ToolSelectionRequest
        ] = []

        for index, request in enumerate(
            ordered,
            start=1,
        ):

            renumbered.append(
                ToolSelectionRequest(
                    tool_name=request.tool_name,
                    reason=request.reason,
                    priority=request.priority,
                    symbol=request.symbol,
                    timeframe=request.timeframe,
                    parameters=dict(
                        request.parameters
                    ),
                    dependencies=(
                        request.dependencies
                    ),
                    sequence=index,
                )
            )

        return tuple(
            renumbered
        )
    # ========================================================
    # SELECTION REPLACEMENT
    # ========================================================

    @staticmethod
    def _replace_selection_requests(
        selection: ToolSelectionResult,
        requests: Iterable[
            ToolSelectionRequest
        ],
    ) -> ToolSelectionResult:
        """
        Replace logical requests with expanded requests.
        """

        request_tuple = tuple(
            requests
        )

        return ToolSelectionResult(
            requests=request_tuple,
            unmet_needs=selection.unmet_needs,
            rejected_tools=selection.rejected_tools,
            reasons=selection.reasons,
            call_budget=selection.call_budget,
            calls_selected=len(
                request_tuple
            ),
            budget_remaining=max(
                0,
                selection.call_budget
                - len(request_tuple),
            ),
        )

    # ========================================================
    # DATA RECORDING
    # ========================================================

    @staticmethod
    def _record_result_data(
        request: ToolSelectionRequest,
        result: ToolExecutionResult,
        state: OrchestratorState,
    ) -> None:
        """
        Record successful tool results into available data.

        The data is stored under a deterministic key.

        This does not interpret the result.
        """

        if result.data is None:
            return

        tool_name = request.tool_name

        # ----------------------------------------------------
        # Multi-timeframe bar data
        # ----------------------------------------------------

        if (
            tool_name
            == "get_trendbars"
            and request.timeframe
        ):
            key = (
                f"bars_"
                f"{request.timeframe.lower()}"
            )

            state.available_data[
                key
            ] = result.data

            # Also indicate that historical data exists.
            state.available_data[
                "historical_bars"
            ] = True

            return

        # ----------------------------------------------------
        # Spot
        # ----------------------------------------------------

        if tool_name == "get_spot_prices":
            state.available_data[
                "current_price"
            ] = result.data

            state.available_data[
                "spot"
            ] = result.data

            return

        # ----------------------------------------------------
        # News
        # ----------------------------------------------------

        if tool_name == "get_news":
            state.available_data[
                "news"
            ] = result.data

            return

        # ----------------------------------------------------
        # Account
        # ----------------------------------------------------

        if tool_name == "get_account":
            state.available_data[
                "account"
            ] = result.data

            return

        # ----------------------------------------------------
        # Positions
        # ----------------------------------------------------

        if tool_name == "get_positions":
            state.available_data[
                "open_positions"
            ] = result.data

            return

        # ----------------------------------------------------
        # Pending orders
        # ----------------------------------------------------

        if tool_name == "get_pending_orders":
            state.available_data[
                "pending_orders"
            ] = result.data

            return

        # ----------------------------------------------------
        # Generic analysis
        # ----------------------------------------------------

        state.available_data[
            tool_name
        ] = result.data

    # ========================================================
    # STATUS
    # ========================================================

    def _final_status(
        self,
        state: OrchestratorState,
        selection: ToolSelectionResult,
    ) -> CycleStatus:
        """
        Determine overall cycle status.
        """

        if state.errors and not state.executions:
            return CycleStatus.FAILED

        if not state.executions:
            if selection.unmet_needs:
                return CycleStatus.BLOCKED

            return CycleStatus.COMPLETED

        failed = any(
            result.status
            == ToolExecutionStatus.FAILED
            for result in state.executions
        )

        skipped = any(
            result.status
            in {
                ToolExecutionStatus.SKIPPED,
                ToolExecutionStatus.BLOCKED,
            }
            for result in state.executions
        )

        successful = any(
            result.status
            == ToolExecutionStatus.SUCCESS
            for result in state.executions
        )

        if failed:
            return CycleStatus.PARTIAL

        if skipped and successful:
            return CycleStatus.PARTIAL

        if skipped and not successful:
            return CycleStatus.BLOCKED

        return CycleStatus.COMPLETED

    # ========================================================
    # TIME BUDGET
    # ========================================================

    def _cycle_expired(
        self,
        started_at: float,
    ) -> bool:
        """Return whether the cycle exceeded its time budget."""

        return (
            time.monotonic()
            - started_at
            > self.max_cycle_seconds
        )

    # ========================================================
    # CYCLE ID
    # ========================================================

    @staticmethod
    def _make_cycle_id() -> str:
        """
        Generate a local cycle identifier.
        """

        return (
            f"cycle-"
            f"{time.time_ns()}"
        )


# ============================================================
# SIMPLE ASYNC TEST EXECUTOR
# ============================================================


async def _test_executor(
    request: ToolSelectionRequest,
) -> dict[str, Any]:
    """
    Small executor useful for unit/integration tests.

    It does not call any external system.
    """

    return {
        "tool": request.tool_name,
        "symbol": request.symbol,
        "timeframe": request.timeframe,
        "parameters": dict(
            request.parameters
        ),
        "test": True,
    }


# ============================================================
# TEST ORCHESTRATOR FACTORY
# ============================================================


def build_test_orchestrator() -> AgentOrchestrator:
    """
    Build an orchestrator with safe local test executors.

    This function is intended for tests only.
    """

    orchestrator = AgentOrchestrator(
        max_calls_per_cycle=20,
        max_cycle_seconds=30.0,
        dry_run=True,
        allow_execution=False,
    )

    for tool in orchestrator.registry.all_tools():

        # Never attach test executors to execution tools.
        if (
            tool.permission
            == ToolPermission.EXECUTION
        ):
            continue

        orchestrator.register_executor(
            tool.name,
            _test_executor,
        )

    return orchestrator


# ============================================================
# PUBLIC API
# ============================================================


__all__ = [
    "ToolExecutor",
    "CycleStatus",
    "ToolExecutionStatus",
    "ToolExecutionResult",
    "AgentCycleResult",
    "OrchestratorState",
    "AgentOrchestrator",
    "build_test_orchestrator",
]

