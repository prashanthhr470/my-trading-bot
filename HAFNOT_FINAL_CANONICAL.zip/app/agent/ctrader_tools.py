"""
============================================================
HAFNOT AI TRADING AGENT
cTRADER AGENT TOOL BRIDGE
============================================================

Purpose
-------
Connect the new Agent Orchestrator to the existing HAFNOT
cTrader MCP + analysis infrastructure.

IMPORTANT
---------
This module does NOT:
    - place live orders
    - enable live trading
    - bypass risk management
    - bypass the final safety gate

Execution tools remain blocked by the orchestrator.

Architecture
------------

Agent Orchestrator
        |
        v
Tool Registry / Selector
        |
        v
This Adapter
        |
        +---- cTrader MCP
        |
        +---- Technical Analysis
        |
        +---- Structure
        |
        +---- Liquidity
        |
        +---- Fundamentals
        |
        +---- News
        |
        +---- Evidence
        |
        +---- Sentiment (when available)
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional


# ============================================================
# EXISTING cTRADER CONNECTION
# ============================================================

from app.ctrader.mcp_client import connect


# ============================================================
# EXISTING ANALYSIS COMPONENTS
# ============================================================

from app.analysis_engine import (
    calculate_indicators,
    create_market_summary,
)

from app.market_state import (
    determine_market_state,
)

from app.market_structure import (
    find_swing_points,
    determine_structure,
)

from app.support_resistance import (
    find_support_resistance,
    group_levels,
)

from app.liquidity_engine import (
    build_liquidity_evidence,
)

from app.evidence_engine import (
    build_evidence,
)

from app.news_analyzer import (
    extract_news_from_mcp,
    analyze_news_risk,
)


# ============================================================
# DEFAULT CONFIGURATION
# ============================================================

DEFAULT_TIMEFRAMES = (
    "h4",
    "h1",
    "m15",
    "m5",
)

# Approximate history requested for each timeframe.
#
# These are intentionally generous because the existing
# indicator engine requires enough bars for SMA/EMA/ATR.
#
# The actual MCP response limit is still capped.
TIMEFRAME_HOURS = {
    "m5": 72,
    "m15": 120,
    "h1": 240,
    "h4": 960,
    "d1": 7200,
}

DEFAULT_BAR_LIMIT = 1000
DEFAULT_NEWS_LIMIT = 50


# ============================================================
# RESULT HELPERS
# ============================================================

def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _json_loads_safe(value: Any) -> Any:
    """
    Safely decode JSON when possible.
    """
    if not isinstance(value, str):
        return value

    text = value.strip()

    if not text:
        return None

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def _extract_mcp_content(result: Any) -> List[Any]:
    """
    Extract textual MCP content without assuming a specific
    MCP response object implementation.
    """
    output: List[Any] = []

    content_items = getattr(
        result,
        "content",
        [],
    )

    for content in content_items:
        if hasattr(content, "text"):
            text = getattr(
                content,
                "text",
                None,
            )

            if text is None:
                continue

            parsed = _json_loads_safe(text)

            if parsed is not None:
                output.append(parsed)

        elif isinstance(content, (dict, list)):
            output.append(content)

    return output


def _first_dict(items: Iterable[Any]) -> Optional[Dict[str, Any]]:
    """
    Return the first dictionary found in an MCP response.
    """
    for item in items:
        if isinstance(item, dict):
            return item

    return None


def _extract_bars(result: Any) -> List[Dict[str, Any]]:
    """
    Extract the 'bars' array from an MCP get_trendbars response.
    """
    items = _extract_mcp_content(result)

    for item in items:
        if not isinstance(item, dict):
            continue

        bars = item.get("bars")

        if isinstance(bars, list):
            return [
                bar
                for bar in bars
                if isinstance(bar, dict)
            ]

    return []


def _extract_news_payload(result: Any) -> Any:
    """
    Extract the useful news payload from MCP.
    """
    items = _extract_mcp_content(result)

    if len(items) == 1:
        return items[0]

    return items


def _normalize_timeframe(timeframe: str) -> str:
    """
    Normalize timeframe names used by the agent.
    """
    value = str(timeframe).strip().lower()

    aliases = {
        "5m": "m5",
        "m5": "m5",
        "15m": "m15",
        "m15": "m15",
        "1h": "h1",
        "h1": "h1",
        "4h": "h4",
        "h4": "h4",
        "1d": "d1",
        "d1": "d1",
    }

    return aliases.get(
        value,
        value,
    )


def _safe_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None

        return float(value)

    except (TypeError, ValueError):
        return None


# ============================================================
# MAIN BRIDGE
# ============================================================

class CTraderAgentTools:
    """
    Adapter between the Agent Orchestrator and existing
    cTrader/analysis infrastructure.

    All methods are read-only or analytical.

    No method in this class can place a broker order.
    """

    def __init__(
        self,
        *,
        default_timeframes=DEFAULT_TIMEFRAMES,
        bar_limit: int = DEFAULT_BAR_LIMIT,
        news_limit: int = DEFAULT_NEWS_LIMIT,
    ):
        self.default_timeframes = tuple(
            _normalize_timeframe(x)
            for x in default_timeframes
        )

        self.bar_limit = int(
            bar_limit
        )

        self.news_limit = int(
            news_limit
        )

    # ========================================================
    # SPOT PRICE
    # ========================================================


    async def get_account(
        self,
    ) -> Dict[str, Any]:
        """
        Retrieve the complete read-only trading account state
        from cTrader MCP.

        Combines:
        - get_balance
        - get_accounts_list
        - get_account_statistics

        No trading operation is performed.
        """

        async with connect() as session:

            balance_result = await session.call_tool(
                "get_balance",
                {},
            )

            accounts_result = await session.call_tool(
                "get_accounts_list",
                {},
            )

            statistics_result = await session.call_tool(
                "get_account_statistics",
                {},
            )

        balance = _extract_mcp_content(
            balance_result
        )

        accounts = _extract_mcp_content(
            accounts_result
        )

        statistics = _extract_mcp_content(
            statistics_result
        )

        return {
            "available": True,
            "balance": balance,
            "accounts": accounts,
            "statistics": statistics,
            "source": "ctrader_mcp",
            "timestamp": _utc_now().isoformat(),
        }


    async def get_positions(
        self,
    ) -> Dict[str, Any]:
        """
        Retrieve all currently open positions.

        Read-only operation.
        """

        async with connect() as session:

            result = await session.call_tool(
                "get_positions",
                {},
            )

        raw_positions = _extract_mcp_content(
            result
        )

        positions = []

        for item in raw_positions:

            if isinstance(item, dict):

                nested = item.get("positions")

                if isinstance(nested, list):

                    positions.extend(
                        row
                        for row in nested
                        if isinstance(row, dict)
                    )

                else:

                    positions.append(item)

        return {
            "available": True,
            "positions": positions,
            "position_count": len(positions),
            "source": "ctrader_mcp",
            "timestamp": _utc_now().isoformat(),
        }


    async def get_pending_orders(
        self,
    ) -> Dict[str, Any]:
        """
        Retrieve all currently pending orders.

        Read-only operation.
        """

        async with connect() as session:

            result = await session.call_tool(
                "get_pending_orders",
                {},
            )

        raw_orders = _extract_mcp_content(
            result
        )

        pending_orders = []

        for item in raw_orders:

            if isinstance(item, dict):

                nested = item.get("orders")

                if isinstance(nested, list):

                    pending_orders.extend(
                        row
                        for row in nested
                        if isinstance(row, dict)
                    )

                else:

                    pending_orders.append(item)

        return {
            "available": True,
            "pending_orders": pending_orders,
            "pending_order_count": len(
                pending_orders
            ),
            "source": "ctrader_mcp",
            "timestamp": _utc_now().isoformat(),
        }


    async def get_spot_prices(
        self,
        symbol: str,
    ) -> Dict[str, Any]:
        """
        Get current bid/ask information from cTrader MCP.
        """

        async with connect() as session:

            result = await session.call_tool(
                "get_spot_prices",
                {
                    "symbolName": symbol,
                },
            )

        items = _extract_mcp_content(
            result
        )

        records = []

        for item in items:

            if isinstance(item, dict):
                records.append(item)

            elif isinstance(item, list):

                for row in item:
                    if isinstance(row, dict):
                        records.append(row)

        selected = None

        for row in records:

            row_symbol = (
                row.get("symbolName")
                or row.get("symbol")
                or row.get("name")
            )

            if (
                row_symbol is None
                or str(row_symbol).upper() == symbol.upper()
            ):
                selected = row
                break

        if selected is None:
            selected = (
                records[0]
                if records
                else {}
            )

        bid = _safe_float(
            selected.get("bid")
        )

        ask = _safe_float(
            selected.get("ask")
        )

        spread = None

        if bid is not None and ask is not None:
            spread = ask - bid

        return {
            "symbol": symbol,
            "bid": bid,
            "ask": ask,
            "spread": spread,
            "timestamp": _utc_now().isoformat(),
            "available": (
                bid is not None
                and ask is not None
            ),
            "source": "ctrader_mcp",
        }

    # ========================================================
    # HISTORICAL BARS
    # ========================================================

    async def get_trendbars(
        self,
        symbol: str,
        timeframe: str,
        *,
        hours: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Retrieve historical candles from cTrader MCP.
        """

        timeframe = _normalize_timeframe(
            timeframe
        )

        if hours is None:
            hours = TIMEFRAME_HOURS.get(
                timeframe,
                240,
            )

        if limit is None:
            limit = self.bar_limit

        end_time = _utc_now()

        start_time = (
            end_time
            - timedelta(
                hours=int(hours)
            )
        )

        async with connect() as session:

            result = await session.call_tool(
                "get_trendbars",
                {
                    "symbolName": symbol,
                    "timeframe": timeframe,
                    "from": start_time.isoformat(),
                    "to": end_time.isoformat(),
                    "limit": int(limit),
                },
            )

        bars = _extract_bars(
            result
        )

        # ----------------------------------------------------
        # Normalize ordering.
        # ----------------------------------------------------

        bars = sorted(
            bars,
            key=lambda x: str(
                x.get("timestamp", "")
            ),
        )

        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "bars": bars,
            "bar_count": len(bars),
            "requested_from": start_time.isoformat(),
            "requested_to": end_time.isoformat(),
            "latest_timestamp": (
                bars[-1].get("timestamp")
                if bars
                else None
            ),
            "available": bool(bars),
            "source": "ctrader_mcp",
        }

    # ========================================================
    # MULTI-TIMEFRAME MARKET DATA
    # ========================================================

    async def get_multi_timeframe_data(
        self,
        symbol: str,
        timeframes=None,
    ) -> Dict[str, Any]:
        """
        Retrieve multiple timeframes.

        This is deliberately separate from the existing
        market_data.py function so the agent can request only
        the timeframes it actually needs.
        """

        if timeframes is None:
            timeframes = (
                self.default_timeframes
            )

        normalized = []

        for timeframe in timeframes:

            tf = _normalize_timeframe(
                timeframe
            )

            if tf not in normalized:
                normalized.append(tf)

        output = {
            "symbol": symbol,
            "requested_timeframes": normalized,
            "timeframes": {},
            "timestamp": _utc_now().isoformat(),
            "source": "ctrader_mcp",
        }

        for timeframe in normalized:

            try:

                output["timeframes"][timeframe] = (
                    await self.get_trendbars(
                        symbol,
                        timeframe,
                    )
                )

            except Exception as error:

                output["timeframes"][timeframe] = {
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "bars": [],
                    "bar_count": 0,
                    "available": False,
                    "error": str(error),
                    "source": "ctrader_mcp",
                }

        return output

    # ========================================================
    # TECHNICAL ANALYSIS
    # ========================================================

    def analyze_timeframe(
        self,
        bars: List[Dict[str, Any]],
        timeframe: str,
    ) -> Dict[str, Any]:
        """
        Run the existing technical-analysis engine.
        """

        if not bars:
            return {
                "timeframe": timeframe,
                "available": False,
                "error": "No bars available.",
            }

        try:

            df = calculate_indicators(
                bars
            )

            summary = create_market_summary(
                df
            )

            return {
                "timeframe": timeframe,
                "available": True,
                "bar_count": len(bars),
                "indicator_rows": len(df),
                "summary": summary,
            }

        except Exception as error:

            return {
                "timeframe": timeframe,
                "available": False,
                "bar_count": len(bars),
                "error": str(error),
            }

    def analyze_all_timeframes(
        self,
        multi_timeframe_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Run the existing technical engine over every
        requested timeframe.
        """

        summaries = {}

        raw_timeframes = (
            multi_timeframe_data.get(
                "timeframes",
                {},
            )
        )

        for timeframe, data in raw_timeframes.items():

            bars = data.get(
                "bars",
                [],
            )

            result = self.analyze_timeframe(
                bars,
                timeframe,
            )

            if result.get("available"):

                summaries[timeframe] = (
                    result["summary"]
                )

        market_state = determine_market_state(
            summaries
        ) if summaries else {
            "overall_bias": "mixed",
            "higher_timeframe_bias": "mixed",
            "lower_timeframe_bias": "mixed",
            "timeframe_conflict": False,
        }

        return {
            "timeframe_summaries": summaries,
            "market_state": market_state,
            "available": bool(summaries),
        }

    # ========================================================
    # STRUCTURE
    # ========================================================

    def analyze_structure(
        self,
        bars: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Run existing swing/structure analysis.
        """

        if not bars:
            return {
                "available": False,
                "error": "No bars available.",
            }

        try:

            df = calculate_indicators(
                bars
            )

            df = find_swing_points(
                df
            )

            structure = determine_structure(
                df
            )

            return {
                "available": True,
                "structure": structure,
                "bar_count": len(bars),
            }

        except Exception as error:

            return {
                "available": False,
                "error": str(error),
            }

    # ========================================================
    # SUPPORT / RESISTANCE
    # ========================================================

    def analyze_support_resistance(
        self,
        bars: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Run existing support/resistance engine.
        """

        if not bars:
            return {
                "available": False,
                "error": "No bars available.",
            }

        try:

            df = calculate_indicators(
                bars
            )

            df = find_swing_points(
                df
            )

            raw_levels = (
                find_support_resistance(
                    df
                )
            )

            zones = group_levels(
                raw_levels
            )

            support = [
                zone
                for zone in zones
                if zone.get("type")
                == "support"
            ]

            resistance = [
                zone
                for zone in zones
                if zone.get("type")
                == "resistance"
            ]

            return {
                "available": True,
                "raw_levels": raw_levels,
                "zones": zones,
                "support": support,
                "resistance": resistance,
            }

        except Exception as error:

            return {
                "available": False,
                "error": str(error),
            }

    # ========================================================
    # LIQUIDITY
    # ========================================================

    def analyze_liquidity(
        self,
        *,
        m5_bars: List[Dict[str, Any]],
        daily_bars: List[Dict[str, Any]],
        current_price: Optional[float],
    ) -> Dict[str, Any]:
        """
        Run existing liquidity engine.
        """

        try:

            result = build_liquidity_evidence(
                m5_bars=m5_bars,
                daily_bars=daily_bars,
                current_price=current_price,
            )

            return {
                "available": True,
                "liquidity": result,
            }

        except Exception as error:

            return {
                "available": False,
                "liquidity": {},
                "error": str(error),
            }

    # ========================================================
    # NEWS
    # ========================================================

    async def get_news(
        self,
        *,
        feed: str = "general",
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Retrieve news through the existing cTrader MCP
        get_news tool and feed it into news_analyzer.py.
        """

        if limit is None:
            limit = self.news_limit

        try:

            async with connect() as session:

                result = await session.call_tool(
                    "get_news",
                    {
                        "feed": feed,
                        "limit": int(limit),
                    },
                )

            raw_payload = (
                _extract_news_payload(
                    result
                )
            )

            parsed_news = (
                extract_news_from_mcp(
                    raw_payload
                )
            )

            analysis = analyze_news_risk(
                parsed_news
            )

            return {
                "available": True,
                "feed": feed,
                "requested_limit": int(limit),
                "raw_count": (
                    len(parsed_news)
                    if isinstance(
                        parsed_news,
                        list,
                    )
                    else 0
                ),
                "news": parsed_news,
                "analysis": analysis,
                "source": "ctrader_mcp",
                "timestamp": _utc_now().isoformat(),
            }

        except Exception as error:

            fallback = analyze_news_risk(
                []
            )

            return {
                "available": False,
                "feed": feed,
                "requested_limit": int(limit),
                "news": [],
                "analysis": fallback,
                "source": "ctrader_mcp",
                "error": str(error),
                "timestamp": _utc_now().isoformat(),
            }

    # ========================================================
    # EVIDENCE
    # ========================================================

    def analyze_evidence(
        self,
        *,
        market_state: Dict[str, Any],
        timeframe_summaries: Dict[str, Any],
        structure: Dict[str, Any],
        support_levels=None,
        resistance_levels=None,
        news_analysis=None,
        liquidity_evidence=None,
        fundamental_evidence=None,
    ) -> Dict[str, Any]:
        """
        Run the existing evidence engine.

        This remains an analysis operation only.
        """

        try:

            result = build_evidence(
                market_state=market_state,
                timeframe_summaries=timeframe_summaries,
                structure=structure,
                support_levels=(
                    support_levels or []
                ),
                resistance_levels=(
                    resistance_levels or []
                ),
                news_analysis=(
                    news_analysis or []
                ),
                liquidity_evidence=(
                    liquidity_evidence or {}
                ),
                fundamental_evidence=(
                    fundamental_evidence
                ),
            )

            return {
                "available": True,
                "evidence": result,
            }

        except TypeError:
            # Compatibility fallback for versions of the
            # evidence engine that do not yet accept
            # fundamental_evidence.
            try:

                result = build_evidence(
                    market_state=market_state,
                    timeframe_summaries=(
                        timeframe_summaries
                    ),
                    structure=structure,
                    support_levels=(
                        support_levels or []
                    ),
                    resistance_levels=(
                        resistance_levels or []
                    ),
                    news_analysis=(
                        news_analysis or []
                    ),
                    liquidity_evidence=(
                        liquidity_evidence or {}
                    ),
                )

                return {
                    "available": True,
                    "evidence": result,
                    "warning": (
                        "Evidence engine version "
                        "does not accept fundamental_evidence."
                    ),
                }

            except Exception as error:

                return {
                    "available": False,
                    "evidence": {},
                    "error": str(error),
                }

        except Exception as error:

            return {
                "available": False,
                "evidence": {},
                "error": str(error),
            }

    # ========================================================
    # COMPLETE READ-ONLY MARKET ANALYSIS
    # ========================================================

    async def analyze_market(
        self,
        symbol: str,
        *,
        timeframes=None,
    ) -> Dict[str, Any]:
        """
        Perform a complete read-only market intelligence
        collection cycle.

        This method does not call AI and does not trade.
        """

        if timeframes is None:
            timeframes = (
                self.default_timeframes
            )

        # ----------------------------------------------------
        # 1. Spot
        # ----------------------------------------------------

        spot = await self.get_spot_prices(
            symbol
        )

        current_price = (
            spot.get("ask")
        )

        # ----------------------------------------------------
        # 2. Multi-timeframe data
        # ----------------------------------------------------

        market_data = (
            await self.get_multi_timeframe_data(
                symbol,
                timeframes,
            )
        )

        # ----------------------------------------------------
        # 3. Technical analysis
        # ----------------------------------------------------

        technical = (
            self.analyze_all_timeframes(
                market_data
            )
        )

        timeframe_summaries = (
            technical.get(
                "timeframe_summaries",
                {},
            )
        )

        market_state = (
            technical.get(
                "market_state",
                {},
            )
        )

        # ----------------------------------------------------
        # 4. Structure
        # ----------------------------------------------------

        m5_data = (
            market_data
            .get("timeframes", {})
            .get("m5", {})
        )

        m5_bars = m5_data.get(
            "bars",
            [],
        )

        structure_result = (
            self.analyze_structure(
                m5_bars
            )
        )

        structure = (
            structure_result.get(
                "structure",
                {},
            )
        )

        # ----------------------------------------------------
        # 5. Support / Resistance
        # ----------------------------------------------------

        sr_result = (
            self.analyze_support_resistance(
                m5_bars
            )
        )

        # ----------------------------------------------------
        # 6. Daily data
        # ----------------------------------------------------

        d1_data = (
            market_data
            .get("timeframes", {})
            .get("d1", {})
        )

        d1_bars = d1_data.get(
            "bars",
            [],
        )

        # ----------------------------------------------------
        # 7. Liquidity
        # ----------------------------------------------------

        liquidity_result = (
            self.analyze_liquidity(
                m5_bars=m5_bars,
                daily_bars=d1_bars,
                current_price=current_price,
            )
        )

        liquidity = (
            liquidity_result.get(
                "liquidity",
                {},
            )
        )

        # ----------------------------------------------------
        # 8. News
        # ----------------------------------------------------

        news_result = (
            await self.get_news()
        )

        news_analysis = (
            news_result.get(
                "analysis",
                {},
            )
        )

        # Existing evidence engine expects the relevant
        # news evidence structure. If the analyzer provides
        # a list directly, use it; otherwise safely fallback.
        evidence_news = (
            news_analysis
            if isinstance(
                news_analysis,
                list,
            )
            else news_analysis.get(
                "items",
                [],
            )
            if isinstance(
                news_analysis,
                dict,
            )
            else []
        )

        # ----------------------------------------------------
        # 9. Evidence
        # ----------------------------------------------------

        evidence_result = (
            self.analyze_evidence(
                market_state=market_state,
                timeframe_summaries=(
                    timeframe_summaries
                ),
                structure=structure,
                support_levels=(
                    sr_result.get(
                        "support",
                        [],
                    )
                ),
                resistance_levels=(
                    sr_result.get(
                        "resistance",
                        [],
                    )
                ),
                news_analysis=evidence_news,
                liquidity_evidence=liquidity,
            )
        )

        return {
            "symbol": symbol,
            "timestamp": _utc_now().isoformat(),

            "spot": spot,

            "market_data": market_data,

            "technical": technical,

            "market_state": market_state,

            "structure": structure_result,

            "support_resistance": sr_result,

            "liquidity": liquidity_result,

            "news": news_result,

            "evidence": evidence_result,

            "capabilities": {
                "spot": spot.get(
                    "available",
                    False,
                ),

                "historical_bars": (
                    market_data.get(
                        "timeframes",
                        {},
                    )
                ),

                "structure": (
                    structure_result.get(
                        "available",
                        False,
                    )
                ),

                "support_resistance": (
                    sr_result.get(
                        "available",
                        False,
                    )
                ),

                "liquidity": (
                    liquidity_result.get(
                        "available",
                        False,
                    )
                ),

                "news": (
                    news_result.get(
                        "available",
                        False,
                    )
                ),

                # These remain unavailable until the
                # dedicated depth/tick infrastructure
                # is connected.
                "true_tick_history": False,
                "market_depth": False,
                "dom": False,
                "footprint": False,
                "order_flow": False,
                "heatmap": False,
            },

            "read_only": True,
            "execution_attempted": False,
        }


# ============================================================
# FACTORY
# ============================================================

def build_ctrader_agent_tools(
    *,
    timeframes=DEFAULT_TIMEFRAMES,
    bar_limit: int = DEFAULT_BAR_LIMIT,
    news_limit: int = DEFAULT_NEWS_LIMIT,
) -> CTraderAgentTools:
    """
    Construct the standard cTrader agent tool adapter.
    """

    return CTraderAgentTools(
        default_timeframes=timeframes,
        bar_limit=bar_limit,
        news_limit=news_limit,
    )