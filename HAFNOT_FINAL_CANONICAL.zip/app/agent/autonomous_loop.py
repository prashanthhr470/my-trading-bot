from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Awaitable, Callable, Optional


@dataclass
class LoopResult:
    cycles: int
    stopped: bool
    errors: int
    duration_seconds: float


class AutonomousLoop:
    """Continuous orchestration shell.

    The callback decides what to analyze. This class never places orders itself.
    """

    def __init__(
        self,
        cycle_callback: Callable[[], Awaitable[object]],
        interval_seconds: float = 60.0,
        max_cycles: Optional[int] = None,
    ):
        self.cycle_callback = cycle_callback
        self.interval_seconds = max(1.0, float(interval_seconds))
        self.max_cycles = max_cycles
        self.running = False
        self.stop_requested = False

    def stop(self):
        self.stop_requested = True
        self.running = False

    async def run(self):
        started = time.monotonic()
        cycles = 0
        errors = 0
        self.running = True

        try:
            while not self.stop_requested:
                if self.max_cycles is not None and cycles >= self.max_cycles:
                    break

                try:
                    await self.cycle_callback()
                except Exception:
                    errors += 1

                cycles += 1

                if self.stop_requested:
                    break

                await asyncio.sleep(self.interval_seconds)

        finally:
            self.running = False

        return LoopResult(
            cycles=cycles,
            stopped=self.stop_requested,
            errors=errors,
            duration_seconds=time.monotonic() - started,
        )
