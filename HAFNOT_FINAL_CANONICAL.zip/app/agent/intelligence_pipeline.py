from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def _first(data: Dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = data.get(key)

        if value is not None:
            return value

    return None


def _unwrap_analysis(value: Any, inner_key: str) -> Any:
    """
    Convert an analysis wrapper into the actual analysis payload.

    Example:

        {
            "available": True,
            "structure": {
                "structure": "bearish"
            }
        }

    becomes:

        {
            "structure": "bearish"
        }
    """

    if not isinstance(
        value,
        dict,
    ):
        return value

    nested = value.get(
        inner_key
    )

    if isinstance(
        nested,
        dict,
    ):
        return nested

    return value


def _load_native_depth(symbol: str) -> Dict[str, Any]:
    """Read the latest native cTrader OpenAPI Level-II snapshot.

    The snapshot is a broker-depth feed, not exchange trade delta.  It is
    therefore exposed explicitly as a depth/footprint proxy and never
    represented as true executed-volume delta.
    """
    path = (
        Path(__file__).resolve().parents[2]
        / "data" / "openapi"
        / f"{str(symbol).lower()}_depth_snapshot.json"
    )
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _build_native_orderflow(depth: Dict[str, Any]) -> Dict[str, Any]:
    """Build deterministic depth imbalance evidence from native Level-II."""
    bids = depth.get("bids", []) if isinstance(depth, dict) else []
    asks = depth.get("asks", []) if isinstance(depth, dict) else []
    bid_volume = sum(float(x.get("size", 0) or 0) for x in bids if isinstance(x, dict))
    ask_volume = sum(float(x.get("size", 0) or 0) for x in asks if isinstance(x, dict))
    total = bid_volume + ask_volume
    imbalance = ((bid_volume - ask_volume) / total) if total > 0 else 0.0
    return {
        "data_source": "cTrader_native_level2",
        "bid_volume": bid_volume,
        "ask_volume": ask_volume,
        "depth_imbalance": imbalance,
        "bid_levels": len(bids),
        "ask_levels": len(asks),
        "executed_trade_volume_available": False,
        "true_trade_delta_available": False,
        "depth_footprint_proxy": bool(bids or asks),
        "raw_depth": depth,
    }


def _build_ohlc_data_quality(
    *,
    symbol: str,
    timeframe_summaries: Dict[str, Any],
    existing_quality: Any,
) -> Dict[str, Any]:
    """
    Build deterministic OHLC data quality from the actual
    timeframe data already retrieved by the agent.

    This prevents a stale/independent quality tool result from
    claiming that OHLC data is unavailable when the technical
    engine has successfully processed the bars.

    This function is advisory only.

    It does NOT make a trading decision.
    """

    # --------------------------------------------------------
    # Existing quality information
    # --------------------------------------------------------

    quality: Dict[str, Any] = {}

    if isinstance(
        existing_quality,
        dict,
    ):
        quality = dict(
            existing_quality
        )

    # --------------------------------------------------------
    # Inspect actual timeframe data
    # --------------------------------------------------------

    available_timeframes: list[str] = []
    unavailable_timeframes: list[str] = []

    total_bars = 0
    total_indicator_rows = 0

    for timeframe, result in (
        timeframe_summaries.items()
    ):

        if not isinstance(
            result,
            dict,
        ):
            continue

        available = bool(
            result.get(
                "available",
                False,
            )
        )

        bar_count = result.get(
            "bar_count",
            0,
        )

        indicator_rows = result.get(
            "indicator_rows",
            0,
        )

        try:
            bar_count = int(
                bar_count or 0
            )
        except (
            TypeError,
            ValueError,
        ):
            bar_count = 0

        try:
            indicator_rows = int(
                indicator_rows or 0
            )
        except (
            TypeError,
            ValueError,
        ):
            indicator_rows = 0

        if available and bar_count > 0:

            available_timeframes.append(
                str(timeframe).upper()
            )

            total_bars += bar_count
            total_indicator_rows += indicator_rows

        else:

            unavailable_timeframes.append(
                str(timeframe).upper()
            )

    # --------------------------------------------------------
    # No usable OHLC data
    # --------------------------------------------------------

    if not available_timeframes:

        return {
            "available": False,
            "symbol": symbol,
            "status": "UNAVAILABLE",
            "reason": (
                "No usable OHLC timeframe data "
                "was available for quality assessment."
            ),
            "timeframes_checked": list(
                timeframe_summaries.keys()
            ),
            "available_timeframes": [],
            "unavailable_timeframes": (
                unavailable_timeframes
            ),
            "total_bars": 0,
            "total_indicator_rows": 0,
            "source": "intelligence_pipeline",
        }

    # --------------------------------------------------------
    # Determine quality
    # --------------------------------------------------------

    timeframe_count = len(
        available_timeframes
    )

    if timeframe_count >= 4:
        status = "EXCELLENT"
        quality_score = 1.0

    elif timeframe_count >= 3:
        status = "GOOD"
        quality_score = 0.85

    elif timeframe_count >= 2:
        status = "FAIR"
        quality_score = 0.70

    else:
        status = "LIMITED"
        quality_score = 0.55

    # --------------------------------------------------------
    # Preserve useful existing fields where appropriate
    # --------------------------------------------------------

    existing_status = str(
        quality.get(
            "status",
            "",
        )
    ).strip().upper()

    existing_reason = quality.get(
        "reason"
    )

    # A stale UNAVAILABLE result must never override actual
    # successfully processed OHLC data.
    if existing_status == "UNAVAILABLE":

        existing_status = ""
        existing_reason = None

    result: Dict[str, Any] = {
        "available": True,
        "symbol": symbol,
        "status": status,
        "score": quality_score,
        "quality_score": quality_score,
        "reason": (
            "OHLC data was successfully retrieved and processed "
            "for the available timeframes."
        ),
        "timeframes_checked": list(
            timeframe_summaries.keys()
        ),
        "available_timeframes": (
            available_timeframes
        ),
        "unavailable_timeframes": (
            unavailable_timeframes
        ),
        "timeframe_count": timeframe_count,
        "total_bars": total_bars,
        "total_indicator_rows": total_indicator_rows,
        "source": "intelligence_pipeline",
    }

    # --------------------------------------------------------
    # Preserve additional existing metadata
    # --------------------------------------------------------

    for key in (
        "current_price_available",
        "stale",
        "invalid",
        "missing",
        "details",
    ):

        if key in quality:
            result[key] = quality[key]

    # Preserve the original assessment for diagnostics.
    if quality:
        result["original_assessment"] = quality

    return result


def build_intelligence_result(
    *,
    symbol: str,
    available_data: Dict[str, Any],
    timeframes: tuple[str, ...],
) -> Dict[str, Any]:

    from app.agent.ctrader_tools import (
        CTraderAgentTools,
    )

    from app.market_regime import (
        classify_market_regime,
    )

    from app.market_context import (
        build_market_context,
    )

    from app.confluence_engine import (
        score_confluence,
    )

    from app.setup_analyzer import (
        analyze_setup,
    )

    # ============================================================
    # 1. TECHNICAL ANALYSIS
    # ============================================================

    timeframe_summaries: Dict[str, Any] = {}

    tools = CTraderAgentTools()

    for timeframe in timeframes:

        bars_key = (
            f"bars_{timeframe.lower()}"
        )

        payload = available_data.get(
            bars_key
        )

        if not isinstance(
            payload,
            dict,
        ):
            continue

        bars = payload.get(
            "bars"
        )

        if not isinstance(
            bars,
            list,
        ) or not bars:
            continue

        try:

            summary = tools.analyze_timeframe(
                bars,
                timeframe,
            )

        except Exception as exc:

            summary = {
                "timeframe": timeframe,
                "available": False,
                "error": (
                    f"{type(exc).__name__}: {exc}"
                ),
            }

        # --------------------------------------------------------
        # Preserve actual bar metadata.
        #
        # The technical summary does not need the entire OHLC
        # array, but the intelligence layer must retain the fact
        # that these bars existed and were processed.
        # --------------------------------------------------------

        if isinstance(
            summary,
            dict,
        ):

            summary = dict(
                summary
            )

            summary.setdefault(
                "bar_count",
                len(bars),
            )

            summary.setdefault(
                "available",
                True,
            )

            summary[
                "source_bar_count"
            ] = len(bars)

        timeframe_summaries[
            str(timeframe).upper()
        ] = summary

    # ============================================================
    # 2. REGIME INPUT NORMALIZATION
    # ============================================================

    regime_input: Dict[str, Any] = {}

    for timeframe, result in (
        timeframe_summaries.items()
    ):

        if not isinstance(
            result,
            dict,
        ):
            continue

        nested_summary = result.get(
            "summary"
        )

        if isinstance(
            nested_summary,
            dict,
        ):

            regime_input[
                timeframe
            ] = nested_summary

    # ============================================================
    # 3. MARKET REGIME
    # ============================================================

    try:

        regime = classify_market_regime(
            regime_input
        )

    except Exception as exc:

        regime = {
            "available": False,
            "regime": "UNKNOWN",
            "direction": "neutral",
            "confidence": "low",
            "error": (
                f"{type(exc).__name__}: {exc}"
            ),
        }

    # ============================================================
    # 4. RAW INTELLIGENCE
    # ============================================================

    spot = _first(
        available_data,
        "spot",
        "current_price",
    )

    raw_structure = _first(
        available_data,
        "analyze_market_structure",
        "structure",
    )

    raw_sentiment = _first(
        available_data,
        "analyze_sentiment",
        "sentiment",
    )

    fundamentals = _first(
        available_data,
        "analyze_fundamentals",
        "fundamentals",
    )

    news = _first(
        available_data,
        "news",
        "get_news",
    )

    liquidity = _first(
        available_data,
        "analyze_liquidity",
        "liquidity",
    )

    existing_data_quality = _first(
        available_data,
        "assess_data_quality",
        "data_quality",
    )

    evidence = _first(
        available_data,
        "analyze_evidence",
        "evidence",
    )

    # Native Level-II is produced by the cTrader OpenAPI market worker and
    # is independent of the slower MCP analysis path.  Merge it here so the
    # AI sees the same order-flow evidence that the paper engine sees.
    native_depth = _load_native_depth(symbol)
    native_orderflow = _build_native_orderflow(native_depth)

    # ============================================================
    # 5. NORMALIZE STRUCTURE
    # ============================================================

    structure = _unwrap_analysis(
        raw_structure,
        "structure",
    )

    # ============================================================
    # 6. NORMALIZE SENTIMENT
    # ============================================================

    sentiment = _unwrap_analysis(
        raw_sentiment,
        "sentiment",
    )

    # ============================================================
    # 7. DETERMINISTIC OHLC DATA QUALITY
    # ============================================================

    data_quality = _build_ohlc_data_quality(
        symbol=symbol,
        timeframe_summaries=timeframe_summaries,
        existing_quality=existing_data_quality,
    )
    data_quality["native_ctrader_level2"] = True
    data_quality["current_price_available"] = spot is not None
    data_quality["executed_trade_volume_available"] = False
    data_quality["true_trade_delta_available"] = False
    data_quality["depth_footprint_proxy"] = native_orderflow["depth_footprint_proxy"]

    # ============================================================
    # 8. SETUP EVIDENCE
    # ============================================================

    setup_evidence = {
        "symbol": symbol,
        "spot": spot,

        # Keep full technical wrappers for setup analysis.
        "timeframe_summaries": (
            timeframe_summaries
        ),

        "timeframes": (
            timeframe_summaries
        ),

        "regime": regime,

        "structure": structure,

        "liquidity": liquidity,

        "fundamentals": fundamentals,

        "news": news,

        "sentiment": sentiment,

        "data_quality": data_quality,

        "orderflow": native_orderflow,
        "order_flow": native_orderflow,
        "depth": native_depth,

        "evidence": evidence,
    }

    try:

        setup = analyze_setup(
            setup_evidence
        )

    except Exception as exc:

        setup = {
            "setup_found": False,
            "direction": "NONE",
            "setup_quality": "LOW",
            "error": (
                f"{type(exc).__name__}: {exc}"
            ),
        }

    # ============================================================
    # 9. MARKET CONTEXT
    # ============================================================

    try:

        context = build_market_context(
            symbol=symbol,
            spot=spot,
            timeframe_summaries=(
                timeframe_summaries
            ),
            structure=structure,
            liquidity=liquidity,
            fundamentals=fundamentals,
            news=news,
            sentiment=sentiment,
            data_quality=data_quality,
            setup=setup,
        )

        context["regime"] = regime

    except Exception as exc:

        return {
            "available": False,
            "symbol": symbol,
            "stage": "market_context",
            "error": (
                f"{type(exc).__name__}: {exc}"
            ),
            "timeframe_summaries": (
                timeframe_summaries
            ),
            "regime": regime,
            "data_quality": data_quality,
            "trade_authorized": False,
            "execution_allowed": False,
            "read_only": True,
        }

    # ============================================================
    # 10. CONFLUENCE
    # ============================================================

    try:

        confluence = score_confluence(
            context
        )

    except Exception as exc:

        confluence = {
            "available": False,
            "stage": "confluence",
            "error": (
                f"{type(exc).__name__}: {exc}"
            ),
            "trade_authorized": False,
        }

    # ============================================================
    # 11. FINAL INTELLIGENCE
    # ============================================================

    return {
        "available": True,

        "symbol": symbol,

        "timeframe_summaries": (
            timeframe_summaries
        ),

        "regime": regime,

        "context": context,

        "market": {
            "symbol": symbol,
            "spot": spot,
        },

        "structure": structure,
        "liquidity": liquidity,
        "fundamentals": fundamentals,
        "news": news,
        "evidence": evidence,
        "orderflow": native_orderflow,
        "order_flow": native_orderflow,
        "depth": native_depth,

        "sentiment": sentiment,

        "confluence": confluence,

        "setup": setup,

        "data_quality": data_quality,

        # ========================================================
        # HARD SAFETY
        # ========================================================

        "trade_authorized": False,

        "execution_allowed": False,

        "read_only": True,
    }