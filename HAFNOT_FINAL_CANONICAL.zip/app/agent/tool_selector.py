﻿"""
HAFNOT AI Trading Agent
Agent Tool Selector

Purpose
-------
Determine which tools are actually needed for an agent cycle.

The selector is deliberately deterministic.

The AI may eventually REQUEST tools, but Python decides whether
those requests are valid and appropriate.

This module does NOT:
    - execute tools
    - call cTrader
    - call Ollama
    - place orders
    - make BUY/SELL decisions

Architecture
------------

Agent Goal
    |
    v
Tool Selector
    |
    +--> Current information already available?
    |
    +--> What information is missing?
    |
    +--> What tools can provide it?
    |
    +--> Dependencies satisfied?
    |
    +--> Call budget available?
    |
    v
Validated Tool Requests
    |
    v
Orchestrator
"""


from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping, Optional

from app.agent.tool_registry import (
    ToolCategory,
    ToolDefinition,
    ToolPermission,
    ToolRegistry,
    ToolStatus,
    DEFAULT_TOOL_REGISTRY,
)


# ============================================================
# INFORMATION REQUIREMENTS
# ============================================================


class InformationNeed(str, Enum):
    """
    Types of information the agent may need.
    """

    SYMBOL = "SYMBOL"

    CURRENT_PRICE = "CURRENT_PRICE"

    SYMBOL_SPECIFICATION = "SYMBOL_SPECIFICATION"

    HISTORICAL_BARS = "HISTORICAL_BARS"

    MULTI_TIMEFRAME_CONTEXT = "MULTI_TIMEFRAME_CONTEXT"

    NEWS = "NEWS"

    FUNDAMENTALS = "FUNDAMENTALS"

    SENTIMENT = "SENTIMENT"

    MARKET_STRUCTURE = "MARKET_STRUCTURE"

    LIQUIDITY = "LIQUIDITY"

    EVIDENCE = "EVIDENCE"

    DATA_QUALITY = "DATA_QUALITY"

    ACCOUNT = "ACCOUNT"

    OPEN_POSITIONS = "OPEN_POSITIONS"

    PENDING_ORDERS = "PENDING_ORDERS"

    TRADE_HISTORY = "TRADE_HISTORY"

    BACKTEST_DATA = "BACKTEST_DATA"

    TRADE_MANAGEMENT = "TRADE_MANAGEMENT"


# ============================================================
# REQUEST PRIORITY
# ============================================================


class RequestPriority(str, Enum):
    """
    Priority of an information/tool request.
    """

    CRITICAL = "CRITICAL"

    HIGH = "HIGH"

    NORMAL = "NORMAL"

    LOW = "LOW"


_PRIORITY_VALUE = {
    RequestPriority.CRITICAL: 4,
    RequestPriority.HIGH: 3,
    RequestPriority.NORMAL: 2,
    RequestPriority.LOW: 1,
}


# ============================================================
# TOOL REQUEST
# ============================================================


@dataclass(frozen=True)
class ToolSelectionRequest:
    """
    A validated request for one tool.

    This is a planning object.

    It does NOT execute anything.
    """

    tool_name: str

    reason: str

    priority: RequestPriority = RequestPriority.NORMAL

    symbol: Optional[str] = None

    timeframe: Optional[str] = None

    parameters: Mapping[str, Any] = field(
        default_factory=dict
    )

    dependencies: tuple[str, ...] = field(
        default_factory=tuple
    )

    sequence: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert request to JSON-friendly data."""

        return {
            "tool_name": self.tool_name,
            "reason": self.reason,
            "priority": self.priority.value,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "parameters": dict(self.parameters),
            "dependencies": list(self.dependencies),
            "sequence": self.sequence,
        }


# ============================================================
# SELECTION RESULT
# ============================================================


@dataclass(frozen=True)
class ToolSelectionResult:
    """
    Complete result of a tool-selection cycle.
    """

    requests: tuple[
        ToolSelectionRequest,
        ...
    ] = field(
        default_factory=tuple
    )

    unmet_needs: tuple[
        InformationNeed,
        ...
    ] = field(
        default_factory=tuple
    )

    rejected_tools: tuple[
        str,
        ...
    ] = field(
        default_factory=tuple
    )

    reasons: tuple[
        str,
        ...
    ] = field(
        default_factory=tuple
    )

    call_budget: int = 0

    calls_selected: int = 0

    budget_remaining: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert result to JSON-friendly data."""

        return {
            "requests": [
                request.to_dict()
                for request in self.requests
            ],
            "unmet_needs": [
                need.value
                for need in self.unmet_needs
            ],
            "rejected_tools": list(
                self.rejected_tools
            ),
            "reasons": list(
                self.reasons
            ),
            "call_budget": self.call_budget,
            "calls_selected": self.calls_selected,
            "budget_remaining": self.budget_remaining,
        }


# ============================================================
# AGENT CONTEXT
# ============================================================


@dataclass(frozen=True)
class AgentToolContext:
    """
    Current information available to the selector.

    `available_data` contains names of information already
    available to the agent.

    Example:

        {
            "current_price": True,
            "h1_bars": True,
            "m15_bars": False,
            "news": False
        }

    The selector uses this to avoid unnecessary tool calls.
    """

    symbol: Optional[str] = None

    timeframes: tuple[str, ...] = field(
        default_factory=tuple
    )

    available_data: Mapping[str, Any] = field(
        default_factory=dict
    )

    completed_tools: tuple[str, ...] = field(
        default_factory=tuple
    )

    failed_tools: tuple[str, ...] = field(
        default_factory=tuple
    )

    dry_run: bool = True

    allow_execution: bool = False

    account_available: bool = False

    existing_positions: bool = False

    existing_pending_orders: bool = False

    market_open: Optional[bool] = None

    metadata: Mapping[str, Any] = field(
        default_factory=dict
    )

    def has(
        self,
        key: str,
    ) -> bool:
        """
        Check whether information is already available.
        """

        value = self.available_data.get(
            key
        )

        return bool(value)

    def tool_completed(
        self,
        tool_name: str,
    ) -> bool:
        """Check whether a tool already ran."""

        return tool_name in self.completed_tools


# ============================================================
# TOOL SELECTOR
# ============================================================


class ToolSelector:
    """
    Deterministic intelligent tool-selection engine.

    Responsibilities:
        1. Translate information needs into tools.
        2. Avoid unnecessary calls.
        3. Respect tool permissions.
        4. Respect DRY-RUN.
        5. Respect call budgets.
        6. Respect dependencies.
        7. Prioritize critical information.
    """

    def __init__(
        self,
        registry: ToolRegistry = DEFAULT_TOOL_REGISTRY,
        *,
        max_calls_per_cycle: int = 20,
    ) -> None:

        if max_calls_per_cycle <= 0:
            raise ValueError(
                "max_calls_per_cycle must be greater than 0."
            )

        self.registry = registry

        self.max_calls_per_cycle = (
            max_calls_per_cycle
        )

    # ========================================================
    # PUBLIC API
    # ========================================================

    def select(
        self,
        needs: Iterable[InformationNeed],
        *,
        context: Optional[
            AgentToolContext
        ] = None,
        priorities: Optional[
            Mapping[
                InformationNeed,
                RequestPriority,
            ]
        ] = None,
    ) -> ToolSelectionResult:
        """
        Select tools required to satisfy information needs.
        """

        context = (
            context
            if context is not None
            else AgentToolContext()
        )

        priorities = (
            priorities
            if priorities is not None
            else {}
        )

        unique_needs = self._unique_needs(
            needs
        )

        ordered_needs = sorted(
            unique_needs,
            key=lambda need: (
                -_PRIORITY_VALUE.get(
                    priorities.get(
                        need,
                        self.default_priority(
                            need
                        ),
                    ),
                    2,
                ),
                need.value,
            ),
        )

        requests: list[
            ToolSelectionRequest
        ] = []

        unmet: list[
            InformationNeed
        ] = []

        rejected: list[str] = []

        reasons: list[str] = []

        selected_tool_names: set[str] = set()

        for need in ordered_needs:

            if self.need_is_satisfied(
                need,
                context,
            ):
                reasons.append(
                    f"{need.value} already available."
                )
                continue

            candidates = self.tools_for_need(
                need
            )

            candidate = self._choose_candidate(
                candidates,
                context=context,
                selected_tool_names=(
                    selected_tool_names
                ),
            )

            if candidate is None:
                unmet.append(need)

                if not candidates:
                    reasons.append(
                        f"No registered tool can satisfy "
                        f"{need.value}."
                    )
                else:
                    reasons.append(
                        f"No selectable tool can satisfy "
                        f"{need.value}."
                    )

                continue

            if (
                len(requests)
                >= self.max_calls_per_cycle
            ):
                unmet.append(need)

                reasons.append(
                    f"Call budget exhausted before "
                    f"{need.value}."
                )

                break

            request = self._build_request(
                need,
                candidate,
                context,
                priority=priorities.get(
                    need,
                    self.default_priority(
                        need
                    ),
                ),
                sequence=len(requests) + 1,
            )

            requests.append(
                request
            )

            selected_tool_names.add(
                candidate.name
            )

        # ----------------------------------------------------
        # Collect tools rejected by permission/availability.
        # ----------------------------------------------------

        for need in ordered_needs:

            if self.need_is_satisfied(
                need,
                context,
            ):
                continue

            for candidate in self.tools_for_need(
                need
            ):

                if candidate.name in selected_tool_names:
                    continue

                allowed, _ = self.registry.validate_selection(
                    candidate.name,
                    dry_run=context.dry_run,
                    allow_execution=(
                        context.allow_execution
                    ),
                )

                if not allowed:
                    rejected.append(
                        candidate.name
                    )

        rejected = list(
            dict.fromkeys(rejected)
        )

        return ToolSelectionResult(
            requests=tuple(requests),
            unmet_needs=tuple(unmet),
            rejected_tools=tuple(rejected),
            reasons=tuple(reasons),
            call_budget=self.max_calls_per_cycle,
            calls_selected=len(requests),
            budget_remaining=max(
                0,
                self.max_calls_per_cycle
                - len(requests),
            ),
        )

    # ========================================================
    # INFORMATION NEEDS
    # ========================================================

    def need_is_satisfied(
        self,
        need: InformationNeed,
        context: AgentToolContext,
    ) -> bool:
        """
        Determine whether an information requirement is
        already satisfied.
        """

        mapping = {
            InformationNeed.SYMBOL: (
                context.symbol is not None
                or context.has("symbol")
            ),

            InformationNeed.CURRENT_PRICE: (
                context.has("current_price")
                or context.has("spot")
                or context.has("bid_ask")
            ),

            InformationNeed.SYMBOL_SPECIFICATION: (
                context.has("symbol_specification")
                or context.has("symbol_details")
            ),

            InformationNeed.HISTORICAL_BARS: (
                context.has("historical_bars")
                or context.has("bars")
            ),

            InformationNeed.MULTI_TIMEFRAME_CONTEXT: (
                context.has(
                    "multi_timeframe_context"
                )
            ),

            InformationNeed.NEWS: (
                context.has("news")
            ),

            InformationNeed.FUNDAMENTALS: (
                context.has("fundamentals")
            ),

            InformationNeed.SENTIMENT: (
                context.has("sentiment")
            ),

            InformationNeed.MARKET_STRUCTURE: (
                context.has("market_structure")
                or context.has("structure")
            ),

            InformationNeed.LIQUIDITY: (
                context.has("liquidity")
            ),

            InformationNeed.EVIDENCE: (
                context.has("evidence")
            ),

            InformationNeed.DATA_QUALITY: (
                context.has("data_quality")
            ),

            InformationNeed.ACCOUNT: (
                context.account_available
                or context.has("account")
            ),

            InformationNeed.OPEN_POSITIONS: (
                context.has("open_positions")
            ),

            InformationNeed.PENDING_ORDERS: (
                context.has("pending_orders")
            ),

            InformationNeed.TRADE_HISTORY: (
                context.has("trade_history")
                or context.has("order_history")
            ),

            InformationNeed.BACKTEST_DATA: (
                context.has("backtest_data")
            ),

            InformationNeed.TRADE_MANAGEMENT: (
                context.has("trade_management")
            ),
        }

        return mapping.get(
            need,
            False,
        )

    # ========================================================
    # TOOL MAPPING
    # ========================================================

    def tools_for_need(
        self,
        need: InformationNeed,
    ) -> tuple[ToolDefinition, ...]:
        """
        Map information requirements to candidate tools.
        """

        mapping: dict[
            InformationNeed,
            tuple[str, ...],
        ] = {

            InformationNeed.SYMBOL: (
                "get_symbols",
            ),

            InformationNeed.CURRENT_PRICE: (
                "get_spot_prices",
            ),

            InformationNeed.SYMBOL_SPECIFICATION: (
                "get_symbol_details",
            ),

            InformationNeed.HISTORICAL_BARS: (
                "get_trendbars",
            ),

            InformationNeed.MULTI_TIMEFRAME_CONTEXT: (
                "get_trendbars",
            ),

            InformationNeed.NEWS: (
                "get_news",
            ),

            InformationNeed.FUNDAMENTALS: (
                "analyze_fundamentals",
            ),

            InformationNeed.SENTIMENT: (
                "analyze_sentiment",
            ),

            InformationNeed.MARKET_STRUCTURE: (
                "analyze_market_structure",
            ),

            InformationNeed.LIQUIDITY: (
                "analyze_liquidity",
            ),

            InformationNeed.EVIDENCE: (
                "analyze_evidence",
            ),

            InformationNeed.DATA_QUALITY: (
                "assess_data_quality",
            ),

            InformationNeed.ACCOUNT: (
                "get_account",
            ),

            InformationNeed.OPEN_POSITIONS: (
                "get_positions",
            ),

            InformationNeed.PENDING_ORDERS: (
                "get_pending_orders",
            ),

            InformationNeed.TRADE_HISTORY: (
                "get_order_history",
                "get_deals",
            ),

            InformationNeed.BACKTEST_DATA: (
                "get_trendbars",
            ),

            InformationNeed.TRADE_MANAGEMENT: (
                "amend_order",
            ),
        }

        names = mapping.get(
            need,
            (),
        )

        tools: list[
            ToolDefinition
        ] = []

        for name in names:

            tool = self.registry.get(
                name
            )

            if tool is not None:
                tools.append(tool)

        return tuple(tools)

    # ========================================================
    # DEFAULT PRIORITIES
    # ========================================================

    @staticmethod
    def default_priority(
        need: InformationNeed,
    ) -> RequestPriority:
        """
        Default importance of each information type.
        """

        critical = {
            InformationNeed.SYMBOL,
            InformationNeed.CURRENT_PRICE,
            InformationNeed.DATA_QUALITY,
        }

        high = {
            InformationNeed.HISTORICAL_BARS,
            InformationNeed.MULTI_TIMEFRAME_CONTEXT,
            InformationNeed.MARKET_STRUCTURE,
            InformationNeed.LIQUIDITY,
            InformationNeed.ACCOUNT,
            InformationNeed.OPEN_POSITIONS,
        }

        normal = {
            InformationNeed.NEWS,
            InformationNeed.FUNDAMENTALS,
            InformationNeed.SENTIMENT,
            InformationNeed.EVIDENCE,
            InformationNeed.PENDING_ORDERS,
            InformationNeed.TRADE_HISTORY,
            InformationNeed.TRADE_MANAGEMENT,
        }

        if need in critical:
            return RequestPriority.CRITICAL

        if need in high:
            return RequestPriority.HIGH

        if need in normal:
            return RequestPriority.NORMAL

        return RequestPriority.LOW

    # ========================================================
    # INTERNAL SELECTION
    # ========================================================

    def _choose_candidate(
        self,
        candidates: Iterable[
            ToolDefinition
        ],
        *,
        context: AgentToolContext,
        selected_tool_names: set[str],
    ) -> Optional[
        ToolDefinition
    ]:
        """
        Choose the best selectable candidate.
        """

        candidates = tuple(
            candidates
        )

        ranked: list[
            tuple[int, ToolDefinition]
        ] = []

        for tool in candidates:

            if (
                tool.name
                in selected_tool_names
            ):
                continue

            if context.tool_completed(
                tool.name
            ):
                continue

            allowed, _ = (
                self.registry.validate_selection(
                    tool.name,
                    dry_run=context.dry_run,
                    allow_execution=(
                        context.allow_execution
                    ),
                )
            )

            if not allowed:
                continue

            score = 0

            # Read-only tools are preferred.
            if (
                tool.permission
                == ToolPermission.READ_ONLY
            ):
                score += 30

            # Analysis tools are next.
            elif (
                tool.permission
                == ToolPermission.ANALYSIS
            ):
                score += 20

            # Management is intentionally lower.
            elif (
                tool.permission
                == ToolPermission.MANAGEMENT
            ):
                score += 5

            # Execution should never normally arrive here.
            elif (
                tool.permission
                == ToolPermission.EXECUTION
            ):
                score -= 100

            # Prefer tools that don't require a live
            # connection when possible.
            if not tool.requires_live_connection:
                score += 5

            # Dangerous tools receive a penalty.
            if tool.dangerous:
                score -= 50

            ranked.append(
                (
                    score,
                    tool,
                )
            )

        if not ranked:
            return None

        ranked.sort(
            key=lambda item: (
                -item[0],
                item[1].name,
            )
        )

        return ranked[0][1]

    # ========================================================
    # REQUEST CREATION
    # ========================================================

    def _build_request(
        self,
        need: InformationNeed,
        tool: ToolDefinition,
        context: AgentToolContext,
        *,
        priority: RequestPriority,
        sequence: int,
    ) -> ToolSelectionRequest:
        """
        Construct a tool request.
        """

        parameters: dict[
            str,
            Any,
        ] = {}

        symbol = context.symbol

        timeframe: Optional[str] = None

        # ----------------------------------------------------
        # Symbol-dependent tools
        # ----------------------------------------------------

        if tool.requires_symbol:
            if symbol is not None:
                parameters["symbol"] = symbol

        # ----------------------------------------------------
        # Timeframe-dependent tools
        # ----------------------------------------------------

        if tool.requires_timeframe:

            if context.timeframes:
                timeframe = (
                    context.timeframes[0]
                )

                parameters[
                    "timeframe"
                ] = timeframe

        # ----------------------------------------------------
        # Special multi-timeframe handling
        # ----------------------------------------------------

        if (
            need
            == InformationNeed.MULTI_TIMEFRAME_CONTEXT
        ):

            if context.timeframes:
                parameters[
                    "timeframes"
                ] = list(
                    context.timeframes
                )

        # ----------------------------------------------------
        # News
        # ----------------------------------------------------

        if tool.name == "get_news":

            parameters[
                "feed"
            ] = "general"

            parameters[
                "limit"
            ] = 50

        # ----------------------------------------------------
        # Analysis tool context
        # ----------------------------------------------------

        if tool.name.startswith(
            "analyze_"
        ):
            parameters[
                "symbol"
            ] = symbol

            if timeframe:
                parameters[
                    "timeframe"
                ] = timeframe

        # ----------------------------------------------------
        # Data quality
        # ----------------------------------------------------

        if (
            tool.name
            == "assess_data_quality"
        ):
            parameters[
                "symbol"
            ] = symbol

        # ----------------------------------------------------
        # Reason
        # ----------------------------------------------------

        reason = self.reason_for(
            need,
            tool,
            context,
        )

        return ToolSelectionRequest(
            tool_name=tool.name,
            reason=reason,
            priority=priority,
            symbol=symbol,
            timeframe=timeframe,
            parameters=parameters,
            dependencies=tool.dependencies,
            sequence=sequence,
        )

    # ========================================================
    # REASONING TEXT
    # ========================================================

    @staticmethod
    def reason_for(
        need: InformationNeed,
        tool: ToolDefinition,
        context: AgentToolContext,
    ) -> str:
        """
        Generate an auditable reason for tool selection.
        """

        symbol_text = (
            f" for {context.symbol}"
            if context.symbol
            else ""
        )

        timeframe_text = ""

        if context.timeframes:
            timeframe_text = (
                " across "
                + ", ".join(
                    context.timeframes
                )
            )

        reasons = {
            InformationNeed.CURRENT_PRICE: (
                f"Current market price is required"
                f"{symbol_text}."
            ),

            InformationNeed.HISTORICAL_BARS: (
                f"Historical OHLC data is required"
                f"{symbol_text}{timeframe_text}."
            ),

            InformationNeed.MULTI_TIMEFRAME_CONTEXT: (
                f"Multi-timeframe market context is required"
                f"{symbol_text}."
            ),

            InformationNeed.NEWS: (
                "Current news is required to evaluate "
                "macro and event risk."
            ),

            InformationNeed.FUNDAMENTALS: (
                f"Fundamental context is required"
                f"{symbol_text}."
            ),

            InformationNeed.SENTIMENT: (
                f"Sentiment context is required"
                f"{symbol_text}."
            ),

            InformationNeed.MARKET_STRUCTURE: (
                f"Market structure analysis is required"
                f"{symbol_text}."
            ),

            InformationNeed.LIQUIDITY: (
                f"Liquidity analysis is required"
                f"{symbol_text}."
            ),

            InformationNeed.EVIDENCE: (
                f"Evidence synthesis is required"
                f"{symbol_text}."
            ),

            InformationNeed.DATA_QUALITY: (
                f"Data quality must be verified"
                f"{symbol_text}."
            ),

            InformationNeed.ACCOUNT: (
                "Account state is required before "
                "trade-risk evaluation."
            ),

            InformationNeed.OPEN_POSITIONS: (
                "Open positions are required to evaluate "
                "exposure and duplicate-trade risk."
            ),

            InformationNeed.PENDING_ORDERS: (
                "Pending orders are required to evaluate "
                "existing order exposure."
            ),

            InformationNeed.TRADE_HISTORY: (
                "Historical execution information is required."
            ),

            InformationNeed.SYMBOL: (
                "Symbol discovery is required."
            ),

            InformationNeed.SYMBOL_SPECIFICATION: (
                f"Broker symbol specifications are required"
                f"{symbol_text}."
            ),

            InformationNeed.BACKTEST_DATA: (
                "Historical market data is required for "
                "backtesting."
            ),

            InformationNeed.TRADE_MANAGEMENT: (
                "Existing trade-management state requires "
                "the appropriate management tool."
            ),
        }

        reason = reasons.get(
            need,
            f"{need.value} is required."
        )

        return (
            reason
            + f" Selected tool: {tool.name}."
        )

    # ========================================================
    # UTILITIES
    # ========================================================

    @staticmethod
    def _unique_needs(
        needs: Iterable[
            InformationNeed
        ],
    ) -> tuple[
        InformationNeed,
        ...
    ]:
        """
        Remove duplicate information requirements while
        preserving the first occurrence.
        """

        result: list[
            InformationNeed
        ] = []

        seen: set[
            InformationNeed
        ] = set()

        for need in needs:

            if not isinstance(
                need,
                InformationNeed,
            ):
                raise TypeError(
                    "All needs must be "
                    "InformationNeed values."
                )

            if need in seen:
                continue

            seen.add(need)
            result.append(need)

        return tuple(result)


# ============================================================
# STANDARD TRADING REQUEST
# ============================================================


def build_standard_analysis_needs(
    *,
    include_news: bool = True,
    include_fundamentals: bool = True,
    include_sentiment: bool = True,
    include_account: bool = True,
) -> tuple[
    InformationNeed,
    ...
]:
    """
    Build the standard information request for a trading
    analysis cycle.

    This is intentionally broad but still deterministic.

    The selector removes anything already available.
    """

    needs: list[
        InformationNeed
    ] = [
        InformationNeed.CURRENT_PRICE,
        InformationNeed.HISTORICAL_BARS,
        InformationNeed.DATA_QUALITY,
        InformationNeed.MARKET_STRUCTURE,
        InformationNeed.LIQUIDITY,
        InformationNeed.EVIDENCE,
    ]

    if include_news:
        needs.append(
            InformationNeed.NEWS
        )

    if include_fundamentals:
        needs.append(
            InformationNeed.FUNDAMENTALS
        )

    if include_sentiment:
        needs.append(
            InformationNeed.SENTIMENT
        )

    if include_account:
        needs.extend(
            [
                InformationNeed.ACCOUNT,
                InformationNeed.OPEN_POSITIONS,
                InformationNeed.PENDING_ORDERS,
            ]
        )

    return tuple(needs)


# ============================================================
# FACTORY
# ============================================================


def build_tool_selector(
    registry: ToolRegistry = DEFAULT_TOOL_REGISTRY,
    *,
    max_calls_per_cycle: int = 20,
) -> ToolSelector:
    """
    Create a configured tool selector.
    """

    return ToolSelector(
        registry,
        max_calls_per_cycle=max_calls_per_cycle,
    )


# ============================================================
# PUBLIC API
# ============================================================


__all__ = [
    "InformationNeed",
    "RequestPriority",
    "ToolSelectionRequest",
    "ToolSelectionResult",
    "AgentToolContext",
    "ToolSelector",
    "build_standard_analysis_needs",
    "build_tool_selector",
]
