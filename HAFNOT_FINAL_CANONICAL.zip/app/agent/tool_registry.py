﻿"""
HAFNOT AI Trading Agent
Agent Tool Registry

Purpose
-------
Defines the tools that the intelligent agent is allowed to use.

The registry is intentionally separate from the actual tool
implementation.

This module:
    - describes tools
    - classifies tools
    - controls permissions
    - provides tool metadata
    - prevents unknown tools from being selected

This module does NOT:
    - execute broker orders
    - call the AI
    - make BUY/SELL decisions
    - bypass execution safety
    - directly connect to cTrader

Architecture
------------

                    Agent
                      |
                      v
                Tool Registry
                      |
             +--------+--------+
             |                 |
        Allowed Tools      Permissions
             |
             v
        Tool Selector
             |
             v
        Tool Executor
             |
             v
       Actual subsystem
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Final, Mapping, Optional


# ============================================================
# TOOL CATEGORIES
# ============================================================


class ToolCategory(str, Enum):
    """
    High-level tool classification.
    """

    MARKET_DATA = "MARKET_DATA"

    TECHNICAL_ANALYSIS = "TECHNICAL_ANALYSIS"

    FUNDAMENTAL = "FUNDAMENTAL"

    NEWS = "NEWS"

    SENTIMENT = "SENTIMENT"

    LIQUIDITY = "LIQUIDITY"

    STRUCTURE = "STRUCTURE"

    EVIDENCE = "EVIDENCE"

    ACCOUNT = "ACCOUNT"

    TRADE_MANAGEMENT = "TRADE_MANAGEMENT"

    EXECUTION = "EXECUTION"

    STORAGE = "STORAGE"

    BACKTEST = "BACKTEST"

    SYSTEM = "SYSTEM"


# ============================================================
# TOOL PERMISSION
# ============================================================


class ToolPermission(str, Enum):
    """
    Permission level for a tool.

    READ_ONLY:
        Retrieves information.

    ANALYSIS:
        Performs deterministic analysis.

    MANAGEMENT:
        Can affect an existing trade-management workflow.

    EXECUTION:
        Can potentially create/modify/cancel broker orders.

    SYSTEM:
        Internal system operations.
    """

    READ_ONLY = "READ_ONLY"

    ANALYSIS = "ANALYSIS"

    MANAGEMENT = "MANAGEMENT"

    EXECUTION = "EXECUTION"

    SYSTEM = "SYSTEM"


# ============================================================
# TOOL STATUS
# ============================================================


class ToolStatus(str, Enum):
    """
    Availability state of a registered tool.
    """

    AVAILABLE = "AVAILABLE"

    DEGRADED = "DEGRADED"

    DISABLED = "DISABLED"

    NOT_IMPLEMENTED = "NOT_IMPLEMENTED"


# ============================================================
# TOOL DEFINITION
# ============================================================


@dataclass(frozen=True)
class ToolDefinition:
    """
    Describes one agent tool.

    Important:
        A ToolDefinition describes a capability.
        It does not execute the capability.
    """

    name: str

    description: str

    category: ToolCategory

    permission: ToolPermission

    status: ToolStatus = ToolStatus.AVAILABLE

    enabled: bool = True

    requires_symbol: bool = False

    requires_timeframe: bool = False

    requires_account: bool = False

    requires_live_connection: bool = False

    dangerous: bool = False

    allowed_in_dry_run: bool = True

    max_calls_per_cycle: int = 5

    tags: tuple[str, ...] = field(
        default_factory=tuple
    )

    dependencies: tuple[str, ...] = field(
        default_factory=tuple
    )

    metadata: Mapping[str, Any] = field(
        default_factory=dict
    )

    def is_selectable(
        self,
        *,
        dry_run: bool = True,
        allow_execution: bool = False,
    ) -> bool:
        """
        Determine whether the agent may select this tool.

        Execution tools are blocked unless explicitly allowed.

        Even when allow_execution=True, another independent
        execution-safety layer must still approve the action.
        """

        if not self.enabled:
            return False

        if self.status != ToolStatus.AVAILABLE:
            return False

        if (
            dry_run
            and not self.allowed_in_dry_run
        ):
            return False

        if (
            self.permission
            == ToolPermission.EXECUTION
            and not allow_execution
        ):
            return False

        return True

    def to_dict(self) -> dict[str, Any]:
        """Return JSON-friendly tool metadata."""

        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "permission": self.permission.value,
            "status": self.status.value,
            "enabled": self.enabled,
            "requires_symbol": self.requires_symbol,
            "requires_timeframe": self.requires_timeframe,
            "requires_account": self.requires_account,
            "requires_live_connection": (
                self.requires_live_connection
            ),
            "dangerous": self.dangerous,
            "allowed_in_dry_run": (
                self.allowed_in_dry_run
            ),
            "max_calls_per_cycle": (
                self.max_calls_per_cycle
            ),
            "tags": list(self.tags),
            "dependencies": list(self.dependencies),
            "metadata": dict(self.metadata),
        }


# ============================================================
# TOOL REGISTRY
# ============================================================


class ToolRegistry:
    """
    Central registry of all agent capabilities.

    The registry is the source of truth for:

        What tools exist?
        What does each tool do?
        What permissions does it have?
        Can the agent select it?
    """

    def __init__(
        self,
        tools: Optional[
            list[ToolDefinition]
        ] = None,
    ) -> None:

        self._tools: dict[
            str,
            ToolDefinition,
        ] = {}

        if tools:
            for tool in tools:
                self.register(tool)

    # --------------------------------------------------------
    # Registration
    # --------------------------------------------------------

    def register(
        self,
        tool: ToolDefinition,
    ) -> None:
        """
        Register a tool.

        Duplicate names are rejected because ambiguous
        tool identity would be dangerous.
        """

        name = tool.name.strip()

        if not name:
            raise ValueError(
                "Tool name cannot be empty."
            )

        if name in self._tools:
            raise ValueError(
                f"Tool already registered: {name}"
            )

        if tool.max_calls_per_cycle <= 0:
            raise ValueError(
                f"Invalid max_calls_per_cycle for {name}."
            )

        self._tools[name] = tool

    # --------------------------------------------------------
    # Removal
    # --------------------------------------------------------

    def unregister(
        self,
        name: str,
    ) -> bool:
        """
        Remove a tool from the registry.
        """

        return (
            self._tools.pop(
                name,
                None,
            )
            is not None
        )

    # --------------------------------------------------------
    # Lookup
    # --------------------------------------------------------

    def get(
        self,
        name: str,
    ) -> Optional[ToolDefinition]:
        """
        Get a tool by exact name.
        """

        return self._tools.get(name)

    def require(
        self,
        name: str,
    ) -> ToolDefinition:
        """
        Get a tool or raise an explicit error.
        """

        tool = self.get(name)

        if tool is None:
            raise KeyError(
                f"Unknown agent tool: {name}"
            )

        return tool

    def exists(
        self,
        name: str,
    ) -> bool:
        """Return whether a tool exists."""

        return name in self._tools

    # --------------------------------------------------------
    # Listing
    # --------------------------------------------------------

    def all_tools(
        self,
    ) -> tuple[ToolDefinition, ...]:
        """Return all registered tools."""

        return tuple(
            self._tools.values()
        )

    def names(
        self,
    ) -> tuple[str, ...]:
        """Return all registered tool names."""

        return tuple(
            self._tools.keys()
        )

    def by_category(
        self,
        category: ToolCategory,
    ) -> tuple[ToolDefinition, ...]:
        """Return tools belonging to a category."""

        return tuple(
            tool
            for tool in self._tools.values()
            if tool.category == category
        )

    def by_permission(
        self,
        permission: ToolPermission,
    ) -> tuple[ToolDefinition, ...]:
        """Return tools with a specific permission."""

        return tuple(
            tool
            for tool in self._tools.values()
            if tool.permission == permission
        )

    # --------------------------------------------------------
    # Agent-selectable tools
    # --------------------------------------------------------

    def selectable_tools(
        self,
        *,
        dry_run: bool = True,
        allow_execution: bool = False,
    ) -> tuple[ToolDefinition, ...]:
        """
        Return tools currently selectable by the agent.
        """

        return tuple(
            tool
            for tool in self._tools.values()
            if tool.is_selectable(
                dry_run=dry_run,
                allow_execution=allow_execution,
            )
        )

    def selectable_names(
        self,
        *,
        dry_run: bool = True,
        allow_execution: bool = False,
    ) -> tuple[str, ...]:
        """Return names of selectable tools."""

        return tuple(
            tool.name
            for tool in self.selectable_tools(
                dry_run=dry_run,
                allow_execution=allow_execution,
            )
        )

    # --------------------------------------------------------
    # Validation
    # --------------------------------------------------------

    def validate_selection(
        self,
        name: str,
        *,
        dry_run: bool = True,
        allow_execution: bool = False,
    ) -> tuple[bool, str]:
        """
        Validate whether a specific tool can be selected.
        """

        tool = self.get(name)

        if tool is None:
            return (
                False,
                f"Unknown tool: {name}",
            )

        if not tool.enabled:
            return (
                False,
                f"Tool disabled: {name}",
            )

        if tool.status != ToolStatus.AVAILABLE:
            return (
                False,
                f"Tool unavailable: {name} "
                f"({tool.status.value})",
            )

        if (
            dry_run
            and not tool.allowed_in_dry_run
        ):
            return (
                False,
                f"Tool blocked in DRY-RUN: {name}",
            )

        if (
            tool.permission
            == ToolPermission.EXECUTION
            and not allow_execution
        ):
            return (
                False,
                f"Execution permission denied: {name}",
            )

        return (
            True,
            "Tool selection allowed.",
        )

    # --------------------------------------------------------
    # Serialization
    # --------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize the registry."""

        return {
            "tool_count": len(self._tools),
            "tools": [
                tool.to_dict()
                for tool in self._tools.values()
            ],
        }


# ============================================================
# BUILT-IN CTRADER / MARKET TOOLS
# ============================================================


CTRADER_MARKET_TOOLS: Final[
    tuple[ToolDefinition, ...]
] = (

    # --------------------------------------------------------
    # Symbol discovery
    # --------------------------------------------------------

    ToolDefinition(
        name="get_symbols",
        description=(
            "Retrieve available cTrader trading symbols "
            "and symbol metadata."
        ),
        category=ToolCategory.MARKET_DATA,
        permission=ToolPermission.READ_ONLY,
        requires_symbol=False,
        tags=(
            "symbols",
            "discovery",
            "market",
        ),
    ),

    ToolDefinition(
        name="get_symbol_details",
        description=(
            "Retrieve detailed information for a specific "
            "cTrader symbol including trading specifications."
        ),
        category=ToolCategory.MARKET_DATA,
        permission=ToolPermission.READ_ONLY,
        requires_symbol=True,
        tags=(
            "symbol",
            "specification",
            "broker",
        ),
    ),

    # --------------------------------------------------------
    # Spot
    # --------------------------------------------------------

    ToolDefinition(
        name="get_spot_prices",
        description=(
            "Retrieve current bid/ask/spot prices for "
            "market symbols."
        ),
        category=ToolCategory.MARKET_DATA,
        permission=ToolPermission.READ_ONLY,
        requires_symbol=True,
        tags=(
            "spot",
            "price",
            "bid",
            "ask",
            "spread",
        ),
    ),

    # --------------------------------------------------------
    # Historical candles
    # --------------------------------------------------------

    ToolDefinition(
        name="get_trendbars",
        description=(
            "Retrieve historical OHLC trend bars for a "
            "symbol and timeframe."
        ),
        category=ToolCategory.MARKET_DATA,
        permission=ToolPermission.READ_ONLY,
        requires_symbol=True,
        requires_timeframe=True,
        tags=(
            "ohlc",
            "candles",
            "bars",
            "historical",
            "timeframe",
        ),
    ),

    # --------------------------------------------------------
    # News
    # --------------------------------------------------------

    ToolDefinition(
        name="get_news",
        description=(
            "Retrieve available cTrader market/news feed "
            "information for macro and market context."
        ),
        category=ToolCategory.NEWS,
        permission=ToolPermission.READ_ONLY,
        tags=(
            "news",
            "macro",
            "events",
            "geopolitics",
        ),
    ),
)


# ============================================================
# ACCOUNT / POSITION TOOLS
# ============================================================


CTRADER_ACCOUNT_TOOLS: Final[
    tuple[ToolDefinition, ...]
] = (

    ToolDefinition(
        name="get_account",
        description=(
            "Retrieve current trading-account information "
            "such as balance, equity and account state."
        ),
        category=ToolCategory.ACCOUNT,
        permission=ToolPermission.READ_ONLY,
        requires_account=True,
        tags=(
            "account",
            "balance",
            "equity",
            "margin",
        ),
    ),

    ToolDefinition(
        name="get_positions",
        description=(
            "Retrieve currently open positions."
        ),
        category=ToolCategory.ACCOUNT,
        permission=ToolPermission.READ_ONLY,
        requires_account=True,
        tags=(
            "positions",
            "open_trades",
            "portfolio",
        ),
    ),

    ToolDefinition(
        name="get_pending_orders",
        description=(
            "Retrieve currently active pending orders."
        ),
        category=ToolCategory.ACCOUNT,
        permission=ToolPermission.READ_ONLY,
        requires_account=True,
        tags=(
            "pending_orders",
            "orders",
        ),
    ),

    ToolDefinition(
        name="get_order_history",
        description=(
            "Retrieve historical orders and order activity."
        ),
        category=ToolCategory.ACCOUNT,
        permission=ToolPermission.READ_ONLY,
        requires_account=True,
        tags=(
            "orders",
            "history",
            "execution",
        ),
    ),

    ToolDefinition(
        name="get_deals",
        description=(
            "Retrieve historical deal/execution information."
        ),
        category=ToolCategory.ACCOUNT,
        permission=ToolPermission.READ_ONLY,
        requires_account=True,
        tags=(
            "deals",
            "history",
            "executions",
        ),
    ),
)


# ============================================================
# TRADE MANAGEMENT TOOLS
# ============================================================


CTRADER_MANAGEMENT_TOOLS: Final[
    tuple[ToolDefinition, ...]
] = (

    ToolDefinition(
        name="amend_order",
        description=(
            "Modify an existing pending order. "
            "This capability is management-sensitive and "
            "must pass independent safety validation."
        ),
        category=ToolCategory.TRADE_MANAGEMENT,
        permission=ToolPermission.MANAGEMENT,
        requires_account=True,
        requires_live_connection=True,
        dangerous=True,
        allowed_in_dry_run=True,
        tags=(
            "order",
            "modify",
            "management",
            "pending_order",
        ),
    ),
)


# ============================================================
# FUTURE ANALYSIS TOOLS
# ============================================================


ANALYSIS_TOOLS: Final[
    tuple[ToolDefinition, ...]
] = (

    ToolDefinition(
        name="analyze_market_structure",
        description=(
            "Analyze deterministic market structure including "
            "trend, swing points, BOS/CHoCH and structure state."
        ),
        category=ToolCategory.STRUCTURE,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        requires_timeframe=True,
        tags=(
            "structure",
            "trend",
            "swing",
            "bos",
            "choch",
        ),
        dependencies=(
            "get_trendbars",
        ),
    ),

    ToolDefinition(
        name="analyze_support_resistance",
        description=(
            "Analyze deterministic support and resistance "
            "levels and price zones from swing points."
        ),
        category=ToolCategory.STRUCTURE,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        requires_timeframe=True,
        tags=(
            "support",
            "resistance",
            "levels",
            "zones",
            "swing",
        ),
        dependencies=(
            "get_trendbars",
        ),
    ),

    ToolDefinition(
        name="analyze_liquidity",
        description=(
            "Analyze deterministic liquidity context including "
            "previous highs/lows, session levels and liquidity "
            "sweeps."
        ),
        category=ToolCategory.LIQUIDITY,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        requires_timeframe=True,
        tags=(
            "liquidity",
            "sweep",
            "highs",
            "lows",
            "sessions",
        ),
        dependencies=(
            "get_trendbars",
        ),
    ),

    ToolDefinition(
        name="analyze_evidence",
        description=(
            "Combine available analytical evidence and assess "
            "directional confidence and conflicts."
        ),
        category=ToolCategory.EVIDENCE,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        tags=(
            "evidence",
            "confluence",
            "confidence",
        ),
    ),

    ToolDefinition(
        name="analyze_sentiment",
        description=(
            "Analyze market sentiment from available news, "
            "macro and market context."
        ),
        category=ToolCategory.SENTIMENT,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        tags=(
            "sentiment",
            "risk_sentiment",
            "news",
            "macro",
        ),
        dependencies=(
            "get_news",
        ),
    ),

    ToolDefinition(
        name="analyze_fundamentals",
        description=(
            "Analyze currency-level fundamental information "
            "and pair-level macro pressure."
        ),
        category=ToolCategory.FUNDAMENTAL,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        tags=(
            "fundamental",
            "macro",
            "currency",
            "central_bank",
        ),
    ),

    ToolDefinition(
        name="assess_data_quality",
        description=(
            "Assess freshness, completeness, validity, gaps "
            "and reliability of supplied market data."
        ),
        category=ToolCategory.SYSTEM,
        permission=ToolPermission.ANALYSIS,
        requires_symbol=True,
        tags=(
            "quality",
            "validation",
            "freshness",
            "integrity",
        ),
    ),
)


# ============================================================
# STORAGE / BACKTEST TOOLS
# ============================================================


SYSTEM_TOOLS: Final[
    tuple[ToolDefinition, ...]
] = (

    ToolDefinition(
        name="store_market_data",
        description=(
            "Persist market data into the historical-data "
            "storage layer."
        ),
        category=ToolCategory.STORAGE,
        permission=ToolPermission.SYSTEM,
        tags=(
            "storage",
            "historical",
            "database",
        ),
    ),

    ToolDefinition(
        name="store_audit_event",
        description=(
            "Persist an immutable audit record describing "
            "an agent/system event."
        ),
        category=ToolCategory.STORAGE,
        permission=ToolPermission.SYSTEM,
        tags=(
            "audit",
            "logging",
            "compliance",
        ),
    ),

    ToolDefinition(
        name="run_backtest",
        description=(
            "Run deterministic historical replay/backtesting "
            "against stored market data."
        ),
        category=ToolCategory.BACKTEST,
        permission=ToolPermission.ANALYSIS,
        tags=(
            "backtest",
            "replay",
            "simulation",
        ),
    ),
)


# ============================================================
# EXECUTION TOOLS
# ============================================================


EXECUTION_TOOLS: Final[
    tuple[ToolDefinition, ...]
] = (

    ToolDefinition(
        name="place_market_order",
        description=(
            "Potentially place a live market order through "
            "the broker execution layer."
        ),
        category=ToolCategory.EXECUTION,
        permission=ToolPermission.EXECUTION,
        requires_symbol=True,
        requires_account=True,
        requires_live_connection=True,
        dangerous=True,
        allowed_in_dry_run=False,
        tags=(
            "execution",
            "market_order",
            "broker",
            "live",
        ),
    ),

    ToolDefinition(
        name="place_pending_order",
        description=(
            "Potentially create a pending broker order."
        ),
        category=ToolCategory.EXECUTION,
        permission=ToolPermission.EXECUTION,
        requires_symbol=True,
        requires_account=True,
        requires_live_connection=True,
        dangerous=True,
        allowed_in_dry_run=False,
        tags=(
            "execution",
            "pending_order",
            "broker",
            "live",
        ),
    ),

    ToolDefinition(
        name="cancel_pending_order",
        description=(
            "Potentially cancel an existing pending broker "
            "order."
        ),
        category=ToolCategory.EXECUTION,
        permission=ToolPermission.EXECUTION,
        requires_account=True,
        requires_live_connection=True,
        dangerous=True,
        allowed_in_dry_run=False,
        tags=(
            "execution",
            "cancel",
            "order",
            "live",
        ),
    ),
)


# ============================================================
# DEFAULT REGISTRY
# ============================================================


def build_default_registry() -> ToolRegistry:
    """
    Build the standard HAFNOT agent tool registry.

    Execution tools are registered so the architecture knows
    they exist, but the registry will not make them selectable
    while execution permission is disabled.
    """

    tools: list[ToolDefinition] = []

    tools.extend(
        CTRADER_MARKET_TOOLS
    )

    tools.extend(
        CTRADER_ACCOUNT_TOOLS
    )

    tools.extend(
        CTRADER_MANAGEMENT_TOOLS
    )

    tools.extend(
        ANALYSIS_TOOLS
    )

    tools.extend(
        SYSTEM_TOOLS
    )

    tools.extend(
        EXECUTION_TOOLS
    )

    return ToolRegistry(tools)


# ============================================================
# DEFAULT GLOBAL REGISTRY
# ============================================================


DEFAULT_TOOL_REGISTRY: Final[
    ToolRegistry
] = build_default_registry()


# ============================================================
# PUBLIC API
# ============================================================


__all__ = [
    "ToolCategory",
    "ToolPermission",
    "ToolStatus",
    "ToolDefinition",
    "ToolRegistry",
    "CTRADER_MARKET_TOOLS",
    "CTRADER_ACCOUNT_TOOLS",
    "CTRADER_MANAGEMENT_TOOLS",
    "ANALYSIS_TOOLS",
    "SYSTEM_TOOLS",
    "EXECUTION_TOOLS",
    "build_default_registry",
    "DEFAULT_TOOL_REGISTRY",
]

