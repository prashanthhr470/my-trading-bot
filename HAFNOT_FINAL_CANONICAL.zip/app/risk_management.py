from dataclasses import dataclass
from typing import Optional


# ============================================================
# BROKER / RISK CONFIGURATION
# ============================================================

MAX_RISK_PERCENT = 2.0
MIN_REWARD_RISK = 1.5

# Safety floor for stop distance.
# This is deliberately conservative for XAUUSD.
MIN_STOP_DISTANCE = 0.01


# ============================================================
# RESULT MODEL
# ============================================================

@dataclass
class RiskResult:

    allowed: bool
    direction: str

    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]

    stop_distance: Optional[float]
    reward_risk: Optional[float]

    risk_amount: Optional[float]

    # Broker volume in units
    position_size: Optional[float]

    # Convenient lot equivalent
    position_lots: Optional[float]

    reason: str


# ============================================================
# DEFAULT XAUUSD BROKER SPECIFICATION
# ============================================================

@dataclass
class SymbolSpec:

    symbol: str = "XAUUSD"

    digits: float = 2.0

    pip_size: float = 0.1

    lot_size: float = 100.0

    min_volume: float = 1.0

    max_volume: float = 5000.0

    volume_step: float = 1.0


DEFAULT_XAUUSD_SPEC = SymbolSpec()


# ============================================================
# HELPERS
# ============================================================

def _invalid(
    direction,
    entry_price,
    stop_loss,
    take_profit,
    reason,
):
    return RiskResult(
        allowed=False,
        direction=direction,
        entry_price=entry_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        stop_distance=None,
        reward_risk=None,
        risk_amount=None,
        position_size=None,
        position_lots=None,
        reason=reason,
    )


def _round_volume(
    volume: float,
    spec: SymbolSpec,
) -> float:

    if spec.volume_step <= 0:
        raise ValueError(
            "Broker volume step must be greater than zero."
        )

    steps = int(
        volume / spec.volume_step
    )

    rounded = (
        steps
        * spec.volume_step
    )

    return round(
        rounded,
        8,
    )


def _validate_symbol_spec(
    spec: SymbolSpec,
):

    if spec.lot_size <= 0:
        raise ValueError(
            "Broker lot size must be greater than zero."
        )

    if spec.min_volume <= 0:
        raise ValueError(
            "Broker minimum volume must be greater than zero."
        )

    if spec.max_volume < spec.min_volume:
        raise ValueError(
            "Broker maximum volume cannot be below minimum volume."
        )

    if spec.volume_step <= 0:
        raise ValueError(
            "Broker volume step must be greater than zero."
        )


# ============================================================
# MAIN RISK ENGINE
# ============================================================

def calculate_risk(
    account_balance: float,
    direction: str,
    entry_price: float,
    stop_loss: float,
    take_profit: float,

    risk_percent: float = 1.0,

    reward_risk: Optional[float] = None,

    symbol_spec: Optional[SymbolSpec] = None,
):
    """
    Deterministic risk-management engine.

    This function:

    - validates trade direction
    - validates account balance
    - validates risk percentage
    - validates BUY/SELL stop placement
    - validates BUY/SELL target placement
    - calculates stop distance
    - calculates reward/risk
    - calculates monetary risk
    - calculates broker volume
    - enforces broker volume limits
    - enforces broker volume step
    - verifies requested reward/risk

    This function DOES NOT:

    - call the broker
    - place an order
    - modify an order
    - close an order
    - make a trading decision
    """

    # ========================================================
    # SYMBOL SPEC
    # ========================================================

    if symbol_spec is None:

        symbol_spec = DEFAULT_XAUUSD_SPEC

    try:

        _validate_symbol_spec(
            symbol_spec
        )

    except ValueError as error:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            str(error),
        )

    # ========================================================
    # BASIC VALIDATION
    # ========================================================

    if account_balance <= 0:

        return _invalid(
            direction,
            None,
            None,
            None,
            "Account balance must be greater than zero.",
        )

    if direction not in {
        "BUY",
        "SELL",
    }:

        return _invalid(
            direction,
            None,
            None,
            None,
            "Invalid trade direction.",
        )

    if risk_percent <= 0:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            "Risk percentage must be greater than zero.",
        )

    if risk_percent > MAX_RISK_PERCENT:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            (
                "Risk percentage exceeds maximum "
                f"allowed risk of {MAX_RISK_PERCENT}%."
            ),
        )

    # ========================================================
    # PRICE VALIDATION
    # ========================================================

    if entry_price <= 0:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            "Entry price must be greater than zero.",
        )

    if stop_loss <= 0:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            "Stop-loss must be greater than zero.",
        )

    if take_profit <= 0:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            "Take-profit must be greater than zero.",
        )

    # ========================================================
    # DIRECTIONAL STOP VALIDATION
    # ========================================================

    if direction == "BUY":

        if stop_loss >= entry_price:

            return _invalid(
                direction,
                entry_price,
                stop_loss,
                take_profit,
                "BUY stop-loss must be below entry price.",
            )

        if take_profit <= entry_price:

            return _invalid(
                direction,
                entry_price,
                stop_loss,
                take_profit,
                "BUY take-profit must be above entry price.",
            )

    else:

        if stop_loss <= entry_price:

            return _invalid(
                direction,
                entry_price,
                stop_loss,
                take_profit,
                "SELL stop-loss must be above entry price.",
            )

        if take_profit >= entry_price:

            return _invalid(
                direction,
                entry_price,
                stop_loss,
                take_profit,
                "SELL take-profit must be below entry price.",
            )

    # ========================================================
    # DISTANCES
    # ========================================================

    stop_distance = abs(
        entry_price - stop_loss
    )

    target_distance = abs(
        take_profit - entry_price
    )

    if stop_distance < MIN_STOP_DISTANCE:

        return _invalid(
            direction,
            entry_price,
            stop_loss,
            take_profit,
            "Stop-loss distance is too small.",
        )

    # ========================================================
    # REWARD / RISK
    # ========================================================

    calculated_reward_risk = (
        target_distance
        / stop_distance
    )

    calculated_reward_risk = round(
        calculated_reward_risk,
        8,
    )

    if calculated_reward_risk < MIN_REWARD_RISK:

        return RiskResult(
            allowed=False,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            stop_distance=stop_distance,
            reward_risk=calculated_reward_risk,
            risk_amount=None,
            position_size=None,
            position_lots=None,
            reason=(
                "Reward/risk is below minimum "
                f"required value of {MIN_REWARD_RISK}."
            ),
        )

    # ========================================================
    # SUPPLIED REWARD/RISK VALIDATION
    # ========================================================

    if reward_risk is not None:

        tolerance = 0.0001

        if abs(
            reward_risk
            - calculated_reward_risk
        ) > tolerance:

            return RiskResult(
                allowed=False,
                direction=direction,
                entry_price=entry_price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                stop_distance=stop_distance,
                reward_risk=calculated_reward_risk,
                risk_amount=None,
                position_size=None,
                position_lots=None,
                reason=(
                    "Requested reward/risk does not "
                    "match entry, stop-loss and take-profit."
                ),
            )

    # ========================================================
    # MONETARY RISK
    # ========================================================

    risk_amount = (
        account_balance
        * risk_percent
        / 100.0
    )

    # ========================================================
    # POSITION SIZE
    # ========================================================
    #
    # XAUUSD:
    #
    # lot_size = 100
    #
    # Therefore:
    #
    # P/L per 1 unit for a $1 move = $1
    #
    # P/L per 1 lot for a $1 move = $100
    #
    # Risk per 1 volume unit =
    # stop_distance
    #
    # Therefore:
    #
    # volume =
    # risk_amount / stop_distance
    #
    # The broker volume is expressed in units.
    #
    # Example:
    #
    # $10,000 balance
    # 1% risk = $100
    # $10 stop
    #
    # volume = 100 / 10
    #        = 10 units
    #
    # lot equivalent:
    #
    # 10 / 100
    # = 0.10 lots
    #
    # ========================================================

    raw_volume = (
        risk_amount
        / stop_distance
    )

    # ========================================================
    # BROKER VOLUME LIMITS
    # ========================================================

    if raw_volume < symbol_spec.min_volume:

        return RiskResult(
            allowed=False,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            stop_distance=stop_distance,
            reward_risk=calculated_reward_risk,
            risk_amount=risk_amount,
            position_size=None,
            position_lots=None,
            reason=(
                "Calculated position size is below "
                "the broker minimum volume."
            ),
        )

    if raw_volume > symbol_spec.max_volume:

        return RiskResult(
            allowed=False,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            stop_distance=stop_distance,
            reward_risk=calculated_reward_risk,
            risk_amount=risk_amount,
            position_size=None,
            position_lots=None,
            reason=(
                "Calculated position size exceeds "
                "the broker maximum volume."
            ),
        )

    # ========================================================
    # VOLUME STEP
    # ========================================================

    volume = _round_volume(
        raw_volume,
        symbol_spec,
    )

    if volume < symbol_spec.min_volume:

        return RiskResult(
            allowed=False,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            stop_distance=stop_distance,
            reward_risk=calculated_reward_risk,
            risk_amount=risk_amount,
            position_size=None,
            position_lots=None,
            reason=(
                "Rounded position size is below "
                "the broker minimum volume."
            ),
        )

    if volume > symbol_spec.max_volume:

        return RiskResult(
            allowed=False,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            stop_distance=stop_distance,
            reward_risk=calculated_reward_risk,
            risk_amount=risk_amount,
            position_size=None,
            position_lots=None,
            reason=(
                "Rounded position size exceeds "
                "the broker maximum volume."
            ),
        )

    # ========================================================
    # LOT CONVERSION
    # ========================================================

    position_lots = (
        volume
        / symbol_spec.lot_size
    )

    position_lots = round(
        position_lots,
        8,
    )

    # ========================================================
    # FINAL RESULT
    # ========================================================

    return RiskResult(
        allowed=True,
        direction=direction,
        entry_price=entry_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        stop_distance=stop_distance,
        reward_risk=calculated_reward_risk,
        risk_amount=risk_amount,
        position_size=volume,
        position_lots=position_lots,
        reason=(
            "Risk parameters passed all deterministic "
            "safety checks."
        ),
    )